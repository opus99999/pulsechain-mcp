# PulseChain external-observer Grok remote MCP gateway

This isolated Cloudflare Worker-compatible service implements five stateless Streamable HTTP MCP connector paths. Each path is separately authenticated and exposes exactly one observer-specific publish tool plus three bounded public read tools. Connector identity is selected from the request path and injected server-side before strict observation validation.

R12 is fail-closed with `PUBLICATION_MODE=DISABLED`. In that mode valid publish calls return `PUBLICATION_MODE_DISABLED` and never resolve a GitHub credential, create an issue, poll a receipt, run a workflow, or mutate a ledger pointer. `ENABLED` support reuses the governed Control Room publication factory and issue/comment receipt transport and requires a separately approved later release.

## Secret labels

- `GROK_MCP_TOKEN_X_PROTOCOL`
- `GROK_MCP_TOKEN_INFRASTRUCTURE_INCIDENTS`
- `GROK_MCP_TOKEN_MARKET_LIQUIDITY`
- `GROK_MCP_TOKEN_IDENTITY_EVIDENCE`
- `GROK_MCP_TOKEN_RED_TEAM`
- Preferred GitHub App: `EXTERNAL_OBSERVER_GITHUB_APP_ID`, `EXTERNAL_OBSERVER_GITHUB_INSTALLATION_ID`, `EXTERNAL_OBSERVER_GITHUB_PRIVATE_KEY`
- Approved fallback: `EXTERNAL_OBSERVER_GITHUB_ISSUES_TOKEN`

Secret values must be entered only in the isolated hosting provider and the matching Grok connector configuration. They must never be committed, logged, described in tool schemas, or copied into a checkpoint.

## Local gate

Run `npm run validate` from this directory. The suite uses invented data and no network writes.
