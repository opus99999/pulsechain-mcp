let cachedInstallationToken = null;

function base64url(bytes) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/u, "");
}

function pemBytes(pem) {
  const body = pem.replace(/-----BEGIN PRIVATE KEY-----|-----END PRIVATE KEY-----|\s/gu, "");
  if (!body || !/^[A-Za-z0-9+/=]+$/u.test(body)) throw new Error("GitHub App private key is invalid");
  return Uint8Array.from(atob(body), (character) => character.charCodeAt(0));
}

async function appJwt(appId, privateKey) {
  if (!/^[0-9]+$/u.test(appId || "")) throw new Error("GitHub App ID is invalid");
  const now = Math.floor(Date.now() / 1000);
  const header = base64url(new TextEncoder().encode(JSON.stringify({ alg: "RS256", typ: "JWT" })));
  const payload = base64url(new TextEncoder().encode(JSON.stringify({ iat: now - 30, exp: now + 540, iss: appId })));
  const input = `${header}.${payload}`;
  const key = await crypto.subtle.importKey("pkcs8", pemBytes(privateKey), { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  const signature = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(input));
  return `${input}.${base64url(new Uint8Array(signature))}`;
}

export async function resolveGitHubIssuesToken(env, fetchImpl = fetch) {
  const fallback = env.EXTERNAL_OBSERVER_GITHUB_ISSUES_TOKEN;
  if (typeof fallback === "string" && fallback.length >= 20) return fallback;
  const appId = env.EXTERNAL_OBSERVER_GITHUB_APP_ID;
  const installationId = env.EXTERNAL_OBSERVER_GITHUB_INSTALLATION_ID;
  const privateKey = env.EXTERNAL_OBSERVER_GITHUB_PRIVATE_KEY;
  if (!appId || !/^[0-9]+$/u.test(installationId || "") || !privateKey) throw new Error("A server-held GitHub credential is required");
  if (cachedInstallationToken && cachedInstallationToken.expiresAt > Date.now() + 60_000) return cachedInstallationToken.token;
  const jwt = await appJwt(appId, privateKey);
  const response = await fetchImpl(`https://api.github.com/app/installations/${installationId}/access_tokens`, {
    method: "POST",
    headers: { Accept: "application/vnd.github+json", Authorization: `Bearer ${jwt}`, "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "pulsechain-external-observer-grok-mcp" },
  });
  if (!response.ok) throw new Error(`GitHub App installation token request returned HTTP ${response.status}`);
  const body = await response.json();
  if (typeof body.token !== "string" || body.token.length < 20 || Number.isNaN(Date.parse(body.expires_at))) throw new Error("GitHub App installation token response is invalid");
  cachedInstallationToken = { token: body.token, expiresAt: Date.parse(body.expires_at) };
  return body.token;
}
