import assert from "node:assert/strict";
import test from "node:test";
import { createHash } from "node:crypto";
import { CONNECTORS, DISABLED_CODE, canonicalJson, discoveryFingerprint, toolsFor } from "../src/contracts.mjs";
import { createGateway } from "../src/worker.mjs";

const TOKENS = Object.fromEntries(CONNECTORS.map((connector, index) => [connector.tokenLabel, `r12-test-token-${index}-abcdefghijklmnopqrstuvwxyz`]));
const ENV = { ...TOKENS, PUBLICATION_MODE: "DISABLED", CONTROL_ROOM_ORIGIN: "https://control-room.test" };
const baseObservation = {
  schema_version: "pulsechain-external-observation@1.0.0",
  observation_id: "synthetic-r12-disabled-00001",
  generated_at_utc: "2026-08-27T20:00:00Z",
  observed_window: { from_utc: "2026-08-27T19:55:00Z", to_utc: "2026-08-27T20:00:00Z" },
  source_class: "PUBLIC_SECONDARY_SOURCE",
  source_records: [{ url: "https://example.com/synthetic-r12", source_id: "synthetic-r12-source", author_or_domain: "example.com", published_at_utc: null, retrieved_at_utc: "2026-08-27T20:00:00Z", content_sha256: `sha256:${"1".repeat(64)}`, primary_source: false, authenticated_source: false }],
  claim_summary: "SYNTHETIC_CANARY — INFRASTRUCTURE ONLY. Invented disabled-mode validation payload.",
  what_changed: "Invented test bytes exercised local validation only.",
  why_material: "Proves disabled remote MCP validation without publication.",
  materiality: "HIGH",
  confidence: "HIGH",
  evidence_state: "PROVISIONAL_EXTERNAL_SIGNAL",
  target_workstreams: ["signals-platform"],
  related_assets: [], related_addresses: [], related_contracts: [], related_transactions: [], related_update_ids: [],
  specialist_questions: ["Does this synthetic payload remain nonactionable?"],
  prohibited_inferences: ["No real-world claim may be inferred."],
  duplicate_check: { checked_observation_ids: [], duplicate_of: null, canonical_duplicate_key: `sha256:${"3".repeat(64)}` },
  recheck_at_utc: null,
  adjudication_state: "PENDING_SPECIALIST_REVIEW",
  synthetic_canary: true,
  public_safe: true,
  raw_sensitive_material_included: false,
};

function validArgs(connector, overrides = {}) {
  const args = structuredClone({ ...baseObservation, ...overrides });
  const identity = { ...args, observer_id: connector.observerId };
  args.content_sha256 = `sha256:${createHash("sha256").update(canonicalJson(identity)).digest("hex")}`;
  return args;
}

function rpc(connector, token, method, params, id = 1) {
  return new Request(`https://gateway.test${connector.path}`, { method: "POST", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id, method, ...(params ? { params } : {}) }) });
}

function fakeFetch(url) {
  const parsed = new URL(url);
  if (parsed.pathname.includes("/bootstrap/grok-")) return Promise.resolve(new Response(JSON.stringify({ observer_id: parsed.pathname.split("/").at(-1), ok: true }), { status: 200 }));
  if (parsed.pathname.includes("/trusted-team/bootstrap/")) return Promise.resolve(new Response(JSON.stringify({ workstream_id: parsed.pathname.split("/").at(-1), ok: true }), { status: 200 }));
  if (parsed.pathname.includes("/observations/")) return Promise.resolve(new Response(JSON.stringify({ observation_id: parsed.pathname.split("/").at(-1), ok: true }), { status: 200 }));
  throw new Error(`Unexpected upstream ${url}`);
}

test("five connector mappings are exact and schemas omit server-selected controls", async () => {
  assert.equal(CONNECTORS.length, 5);
  const fingerprints = new Set();
  for (const connector of CONNECTORS) {
    const tools = toolsFor(connector);
    assert.deepEqual(tools.map((tool) => tool.name), [connector.publishTool, "read_external_observer_bootstrap", "read_workstream_bootstrap", "read_external_observation"]);
    const schema = JSON.stringify(tools[0].inputSchema).toLowerCase();
    for (const forbidden of ["observer_id", "repository", "workflow", "ledger path", "github credential", "connector credential", "publication mode"]) assert.equal(schema.includes(forbidden), false);
    assert.equal(schema.includes("$ref"), false);
    const fingerprint = await discoveryFingerprint(connector);
    assert.match(fingerprint, /^sha256:[0-9a-f]{64}$/u);
    assert.equal(fingerprint, `sha256:${createHash("sha256").update(canonicalJson(tools)).digest("hex")}`);
    fingerprints.add(fingerprint);
  }
  assert.equal(fingerprints.size, 5);
});

test("authentication is connector-specific and precedes discovery", async () => {
  const gateway = createGateway({ fetchImpl: fakeFetch });
  for (let index = 0; index < CONNECTORS.length; index += 1) {
    const connector = CONNECTORS[index];
    const correct = TOKENS[connector.tokenLabel];
    assert.equal((await gateway.fetch(rpc(connector, correct, "tools/list"), ENV)).status, 200);
    assert.equal((await gateway.fetch(rpc(connector, "wrong-token-abcdefghijklmnopqrstuvwxyz", "tools/list"), ENV)).status, 401);
    const foreign = TOKENS[CONNECTORS[(index + 1) % CONNECTORS.length].tokenLabel];
    assert.equal((await gateway.fetch(rpc(connector, foreign, "tools/list"), ENV)).status, 401);
  }
});

test("parallel discovery never exposes a foreign publish tool", async () => {
  const gateway = createGateway({ fetchImpl: fakeFetch });
  const responses = await Promise.all(CONNECTORS.map((connector) => gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "tools/list"), ENV).then((response) => response.json())));
  responses.forEach((body, index) => {
    const names = body.result.tools.map((tool) => tool.name).filter((name) => name.startsWith("publish_"));
    assert.deepEqual(names, [CONNECTORS[index].publishTool]);
  });
});

test("five disabled writes validate and inject fixed identities without transport", async () => {
  let upstreamCalls = 0;
  const gateway = createGateway({ fetchImpl: async () => { upstreamCalls += 1; throw new Error("transport forbidden"); } });
  for (const connector of CONNECTORS) {
    const response = await gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "tools/call", { name: connector.publishTool, arguments: validArgs(connector, { observation_id: `${connector.observerId}-r12-disabled` }) }), ENV);
    assert.equal(response.status, 200);
    const body = await response.json();
    assert.equal(body.result.structuredContent.error_code, DISABLED_CODE);
    assert.equal(body.result.structuredContent.issue_number, null);
    assert.equal(body.result.structuredContent.publication_commit, null);
  }
  assert.equal(upstreamCalls, 0);
});

test("direct, nested, and foreign publish-tool identity selection are rejected", async () => {
  const gateway = createGateway({ fetchImpl: fakeFetch });
  const connector = CONNECTORS[0];
  for (const injected of [{ ...validArgs(connector), observer_id: connector.observerId }, { ...validArgs(connector), source_records: [{ ...baseObservation.source_records[0], metadata: { observerId: connector.observerId } }] }]) {
    const body = await gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "tools/call", { name: connector.publishTool, arguments: injected }), ENV).then((response) => response.json());
    assert.equal(body.result.isError, true);
    assert.equal(body.result.structuredContent.error, "INVALID_TOOL_INPUT");
  }
  const foreignTool = CONNECTORS[1].publishTool;
  const body = await gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "tools/call", { name: foreignTool, arguments: validArgs(connector) }), ENV).then((response) => response.json());
  assert.equal(body.result.isError, true);
});

test("strict schema, privacy, and secret rejection remain active in disabled mode", async () => {
  const gateway = createGateway({ fetchImpl: fakeFetch });
  const connector = CONNECTORS[0];
  const cases = [
    { ...validArgs(connector), unexpected: true },
    validArgs(connector, { raw_sensitive_material_included: true }),
    validArgs(connector, { public_safe: false }),
    validArgs(connector, { claim_summary: "ghp_abcdefghijklmnopqrstuvwxyz1234567890" }),
    validArgs(connector, { adjudication_state: "ACCEPTED" }),
  ];
  for (const args of cases) {
    const body = await gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "tools/call", { name: connector.publishTool, arguments: args }), ENV).then((response) => response.json());
    assert.equal(body.result.isError, true);
  }
});

test("common read tools are bounded to public Control Room routes", async () => {
  const gateway = createGateway({ fetchImpl: fakeFetch });
  const connector = CONNECTORS[2]; const token = TOKENS[connector.tokenLabel];
  const bootstrap = await gateway.fetch(rpc(connector, token, "tools/call", { name: "read_external_observer_bootstrap", arguments: {} }), ENV).then((response) => response.json());
  assert.equal(bootstrap.result.structuredContent.observer_id, connector.observerId);
  const workstream = await gateway.fetch(rpc(connector, token, "tools/call", { name: "read_workstream_bootstrap", arguments: { workstream_id: "investor-intelligence" } }), ENV).then((response) => response.json());
  assert.equal(workstream.result.structuredContent.workstream_id, "investor-intelligence");
  const observation = await gateway.fetch(rpc(connector, token, "tools/call", { name: "read_external_observation", arguments: { observation_id: "synthetic-observation-00001" } }), ENV).then((response) => response.json());
  assert.equal(observation.result.structuredContent.observation_id, "synthetic-observation-00001");
});

test("Streamable HTTP protocol surface is stateless and fail-closed", async () => {
  const gateway = createGateway({ fetchImpl: fakeFetch }); const connector = CONNECTORS[0]; const token = TOKENS[connector.tokenLabel];
  const initialized = await gateway.fetch(rpc(connector, token, "initialize", { protocolVersion: "2025-06-18", capabilities: {}, clientInfo: { name: "test", version: "1" } }), ENV).then((response) => response.json());
  assert.equal(initialized.result.protocolVersion, "2025-06-18");
  assert.equal((await gateway.fetch(new Request(`https://gateway.test${connector.path}`, { method: "GET", headers: { Authorization: `Bearer ${token}` } }), ENV)).status, 405);
  assert.equal((await gateway.fetch(new Request("https://gateway.test/mcp/external-observers/foreign", { method: "POST" }), ENV)).status, 404);
  assert.equal((await gateway.fetch(new Request(`https://gateway.test${connector.path}`, { method: "POST", headers: { Authorization: `Bearer ${token}` }, body: "{" }), ENV)).status, 400);
});
