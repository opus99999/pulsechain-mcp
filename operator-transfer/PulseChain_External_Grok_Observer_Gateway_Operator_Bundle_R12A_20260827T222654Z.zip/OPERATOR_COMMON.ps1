#Requires -Version 7.4

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Assert-WindowsOperator {
    if (-not $IsWindows) {
        throw "This operator bundle may run only on Windows."
    }
    Add-Type -AssemblyName System.Security.Cryptography.ProtectedData -ErrorAction Stop
}

function Get-ConnectorDefinitions {
    @(
        [pscustomobject]@{
            observer_id = "grok-x-protocol"
            path = "/mcp/external-observers/grok-x-protocol"
            publish_tool = "publish_external_observation_grok_x_protocol"
            token_label = "GROK_MCP_TOKEN_X_PROTOCOL"
            target_workstream = "signals-platform"
            observation_id = "grok-x-protocol-r12a-disabled"
            fingerprint = "sha256:d19b907221f241a57a51c4fa0b0ad0fb57ed4ea3c50b7b488d53301384191355"
        }
        [pscustomobject]@{
            observer_id = "grok-infrastructure-incidents"
            path = "/mcp/external-observers/grok-infrastructure-incidents"
            publish_tool = "publish_external_observation_grok_infrastructure_incidents"
            token_label = "GROK_MCP_TOKEN_INFRASTRUCTURE_INCIDENTS"
            target_workstream = "validator-flows"
            observation_id = "grok-infrastructure-incidents-r12a-disabled"
            fingerprint = "sha256:0d00b2289ef749e625e91e52da4a611dce0685e6b47738d6d2ffe746fe9dc7ff"
        }
        [pscustomobject]@{
            observer_id = "grok-market-liquidity"
            path = "/mcp/external-observers/grok-market-liquidity"
            publish_tool = "publish_external_observation_grok_market_liquidity"
            token_label = "GROK_MCP_TOKEN_MARKET_LIQUIDITY"
            target_workstream = "investor-intelligence"
            observation_id = "grok-market-liquidity-r12a-disabled"
            fingerprint = "sha256:95a97b12f667cf05e3ebdf4621b1506ccaa451d422ebb96851536200c2e64dae"
        }
        [pscustomobject]@{
            observer_id = "grok-identity-evidence"
            path = "/mcp/external-observers/grok-identity-evidence"
            publish_tool = "publish_external_observation_grok_identity_evidence"
            token_label = "GROK_MCP_TOKEN_IDENTITY_EVIDENCE"
            target_workstream = "identity-attribution"
            observation_id = "grok-identity-evidence-r12a-disabled"
            fingerprint = "sha256:a59ba28f8dcb8470b127f3a6ceefb139763678f4efe8714c005e463b88bc72dd"
        }
        [pscustomobject]@{
            observer_id = "grok-red-team"
            path = "/mcp/external-observers/grok-red-team"
            publish_tool = "publish_external_observation_grok_red_team"
            token_label = "GROK_MCP_TOKEN_RED_TEAM"
            target_workstream = "signals-platform"
            observation_id = "grok-red-team-r12a-disabled"
            fingerprint = "sha256:d7023e1fca3dbb0e7fc66461b87be07dd287c2aa8b3c84dc08be6a04f6190389"
        }
    )
}

function Get-OperatorStateDirectory {
    if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
        throw "LOCALAPPDATA is unavailable."
    }
    [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA "PulseChain\ExternalObserverGateway"))
}

function Get-ConnectorVaultPath {
    Join-Path (Get-OperatorStateDirectory) "connector-tokens.dpapi.json"
}

function Get-VerificationReportPath {
    Join-Path (Get-OperatorStateDirectory) "LOCAL_DISABLED_MODE_VERIFICATION.json"
}

function Set-PrivateDirectoryAcl {
    param([Parameter(Mandatory = $true)][string]$Path)
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    if ($null -eq $identity.User) {
        throw "The current Windows user SID is unavailable."
    }
    $security = [Security.AccessControl.DirectorySecurity]::new()
    $security.SetAccessRuleProtection($true, $false)
    $rights = [Security.AccessControl.FileSystemRights]::FullControl
    $inheritance = [Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [Security.AccessControl.InheritanceFlags]::ObjectInherit
    $rule = [Security.AccessControl.FileSystemAccessRule]::new(
        $identity.User,
        $rights,
        $inheritance,
        [Security.AccessControl.PropagationFlags]::None,
        [Security.AccessControl.AccessControlType]::Allow
    )
    [void]$security.AddAccessRule($rule)
    Set-Acl -LiteralPath $Path -AclObject $security
}

function Set-PrivateFileAcl {
    param([Parameter(Mandatory = $true)][string]$Path)
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    if ($null -eq $identity.User) {
        throw "The current Windows user SID is unavailable."
    }
    $security = [Security.AccessControl.FileSecurity]::new()
    $security.SetAccessRuleProtection($true, $false)
    $rule = [Security.AccessControl.FileSystemAccessRule]::new(
        $identity.User,
        [Security.AccessControl.FileSystemRights]::FullControl,
        [Security.AccessControl.AccessControlType]::Allow
    )
    [void]$security.AddAccessRule($rule)
    Set-Acl -LiteralPath $Path -AclObject $security
}

function Initialize-PrivateDirectory {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        [void][IO.Directory]::CreateDirectory($Path)
    }
    Set-PrivateDirectoryAcl -Path $Path
}

function Get-DpapiEntropy {
    $bytes = [Text.Encoding]::UTF8.GetBytes("PulseChain.ExternalObserverGateway.R12A.v1")
    try {
        [Security.Cryptography.SHA256]::HashData($bytes)
    }
    finally {
        [Array]::Clear($bytes, 0, $bytes.Length)
    }
}

function Protect-ConnectorToken {
    param([Parameter(Mandatory = $true)][string]$Token)
    [byte[]]$plain = [Text.Encoding]::UTF8.GetBytes($Token)
    [byte[]]$entropy = Get-DpapiEntropy
    try {
        $cipher = [Security.Cryptography.ProtectedData]::Protect(
            $plain,
            $entropy,
            [Security.Cryptography.DataProtectionScope]::CurrentUser
        )
        try {
            [Convert]::ToBase64String($cipher)
        }
        finally {
            [Array]::Clear($cipher, 0, $cipher.Length)
        }
    }
    finally {
        [Array]::Clear($plain, 0, $plain.Length)
        [Array]::Clear($entropy, 0, $entropy.Length)
    }
}

function Unprotect-ConnectorToken {
    param([Parameter(Mandatory = $true)][string]$CiphertextBase64)
    [byte[]]$cipher = [Convert]::FromBase64String($CiphertextBase64)
    [byte[]]$entropy = Get-DpapiEntropy
    try {
        $plain = [Security.Cryptography.ProtectedData]::Unprotect(
            $cipher,
            $entropy,
            [Security.Cryptography.DataProtectionScope]::CurrentUser
        )
        try {
            [Text.Encoding]::UTF8.GetString($plain)
        }
        finally {
            [Array]::Clear($plain, 0, $plain.Length)
        }
    }
    finally {
        [Array]::Clear($cipher, 0, $cipher.Length)
        [Array]::Clear($entropy, 0, $entropy.Length)
    }
}

function Write-PrivateTextFile {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Text
    )
    $directory = Split-Path -Parent $Path
    Initialize-PrivateDirectory -Path $directory
    $temporary = Join-Path $directory (".tmp-" + [Guid]::NewGuid().ToString("N"))
    $stream = [IO.File]::Open($temporary, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    $stream.Dispose()
    try {
        Set-PrivateFileAcl -Path $temporary
        [IO.File]::WriteAllText($temporary, $Text, [Text.UTF8Encoding]::new($false))
        [IO.File]::Move($temporary, $Path, $true)
        Set-PrivateFileAcl -Path $Path
    }
    finally {
        if (Test-Path -LiteralPath $temporary) {
            Remove-Item -LiteralPath $temporary -Force
        }
    }
}

function Write-ConnectorVault {
    param([Parameter(Mandatory = $true)][psobject]$Vault)
    $json = $Vault | ConvertTo-Json -Depth 12
    Write-PrivateTextFile -Path (Get-ConnectorVaultPath) -Text ($json + [Environment]::NewLine)
}

function Assert-ConnectorVault {
    param(
        [Parameter(Mandatory = $true)][psobject]$Vault,
        [switch]$RequireOrigin
    )
    if ($Vault.schema_version -ne "pulsechain-external-observer-connector-vault@1.0.0") {
        throw "The connector vault schema is invalid."
    }
    if ($Vault.worker_name -ne "pulsechain-external-observer-grok-mcp") {
        throw "The connector vault Worker identity is invalid."
    }
    if ([string]$Vault.account_id -notmatch "^[0-9a-fA-F]{32}$") {
        throw "The connector vault account identity is invalid."
    }
    if (
        $Vault.source_branch -ne "external-observer-grok-mcp-r12-20260827" -or
        $Vault.source_commit -ne "e1a3ffae1e735ec3e7c310b147b2ee7d793e51c0" -or
        $Vault.source_tree -ne "3c2de63d326bcd4ca62dfcf43a5bd8a5496d8db5" -or
        $Vault.publication_mode -ne "DISABLED"
    ) {
        throw "The connector vault source or publication-mode identity is invalid."
    }
    if ($RequireOrigin -and [string]$Vault.worker_origin -notmatch "^https://pulsechain-external-observer-grok-mcp\.[a-z0-9-]+\.workers\.dev/?$") {
        throw "The connector vault Worker origin is invalid."
    }
    if ($RequireOrigin -and [string]$Vault.current_version_id -notmatch "^[0-9a-fA-F-]{36}$") {
        throw "The connector vault Worker version identity is invalid."
    }
    $definitions = @(Get-ConnectorDefinitions)
    $expected = @($definitions.observer_id | Sort-Object)
    $actual = @($Vault.tokens.PSObject.Properties.Name | Sort-Object)
    if (($expected -join [Environment]::NewLine) -ne ($actual -join [Environment]::NewLine)) {
        throw "The connector vault observer set is invalid."
    }
    foreach ($definition in $definitions) {
        $record = $Vault.tokens.($definition.observer_id)
        if ($record.secret_label -ne $definition.token_label) {
            throw "The connector vault secret-label map is invalid."
        }
        if ([string]::IsNullOrWhiteSpace([string]$record.ciphertext_base64)) {
            throw "The connector vault ciphertext is missing."
        }
    }
}

function Read-ConnectorVault {
    param([switch]$RequireOrigin)
    $path = Get-ConnectorVaultPath
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "The local connector vault is unavailable."
    }
    $vault = Get-Content -LiteralPath $path -Raw -Encoding utf8 | ConvertFrom-Json -Depth 20
    Assert-ConnectorVault -Vault $vault -RequireOrigin:$RequireOrigin
    $vault
}

function Get-ConnectorToken {
    param(
        [Parameter(Mandatory = $true)][psobject]$Vault,
        [Parameter(Mandatory = $true)][string]$ObserverId
    )
    $record = $Vault.tokens.$ObserverId
    if ($null -eq $record) {
        throw "The requested observer is not present in the connector vault."
    }
    Unprotect-ConnectorToken -CiphertextBase64 $record.ciphertext_base64
}

function ConvertFrom-LocalSecureString {
    param([Parameter(Mandatory = $true)][Security.SecureString]$SecureValue)
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureValue)
    try {
        [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
    }
    finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)
    }
}

function Get-Sha256Hex {
    param([Parameter(Mandatory = $true)][byte[]]$Bytes)
    [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($Bytes)).ToLowerInvariant()
}
