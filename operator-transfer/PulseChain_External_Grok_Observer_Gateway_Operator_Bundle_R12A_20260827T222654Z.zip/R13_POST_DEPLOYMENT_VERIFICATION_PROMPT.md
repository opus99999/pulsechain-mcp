# PulseChain external observer gateway R13 post-deployment verification

Continue only after the R12A Windows operator deployment command has completed
and LOCAL_DISABLED_MODE_VERIFICATION.json reports PASS.

This is a read-only post-deployment verification task. It is not authorization
to change source, redeploy, create an issue, create an observation, configure
Grok, schedule monitoring, or change PUBLICATION_MODE.

First:

1. Validate the exact R12A operator bundle by filename, byte size, member count,
   SHA-256, ZIP integrity, inventory, and path safety.
2. Read SOURCE_MANIFEST.json and require branch
   external-observer-grok-mcp-r12-20260827, commit
   e1a3ffae1e735ec3e7c310b147b2ee7d793e51c0, and tree
   3c2de63d326bcd4ca62dfcf43a5bd8a5496d8db5.
3. Read the operator-provided redacted LOCAL_DISABLED_MODE_VERIFICATION.json.
4. Require the exact Worker name, account ID, Worker version ID, workers.dev
   origin, and five connector URLs returned by DEPLOY_GATEWAY.ps1.
5. Never request, receive, display, or persist a connector token or GitHub
   credential.
6. Passively verify five authenticated initialize calls, five tools/list calls,
   five fixed publish-tool identities, all three common read tools, and five
   PUBLICATION_MODE_DISABLED results using provider-held connector bindings.
7. Require zero issues, workflows, observations, repository commits, permanent
   pages, latest-pointer changes, index changes, specialist changes, D1 writes,
   R2 writes, authority changes, Signals changes, portfolio changes, wallet
   actions, orders, or execution.
8. Return exactly one bundled checkpoint and stop.

Successful classification:

EXTERNAL_OBSERVER_GROK_MCP_GATEWAY_READY —
FIVE_IDENTITY_BOUND_CONNECTORS_VERIFIED —
GROK_CONNECTOR_CONFIGURATION_APPROVAL_REQUIRED

This classification does not mean that Grok is configured, scheduled, or
monitoring, and it does not authorize publication mode beyond DISABLED.
