# PulseChain external Grok observer gateway — R12A Windows operator bundle

Classification:

EXTERNAL_OBSERVER_GATEWAY_OPERATOR_BUNDLE_READY —
EXACT_R12_SOURCE_PACKAGED —
MANUAL_WINDOWS_DEPLOYMENT_REQUIRED

This bundle exports the exact verified R12 gateway source. It does not contain
secret values and its creation did not deploy a Worker, log into Cloudflare,
create an issue, create an observation, configure Grok, or change live state.

## Exact source

- Branch: external-observer-grok-mcp-r12-20260827
- Commit: e1a3ffae1e735ec3e7c310b147b2ee7d793e51c0
- Tree: 3c2de63d326bcd4ca62dfcf43a5bd8a5496d8db5
- Parent: b4d7553be933b0cc364f576ea57b8b6e9dffe4b2
- Worker: pulsechain-external-observer-grok-mcp
- Entrypoint: src/worker.mjs
- Compatibility date: 2026-08-27
- Compatibility flag: nodejs_compat
- Publication mode: DISABLED
- Control Room origin:
  https://pulsechain-research-control-room.brohexphiat.chatgpt.site

The external_observer_grok_mcp_gateway directory contains the exact eleven Git
files from that commit. The two governed observation schemas are placed at the
bundle root because the immutable gateway source imports them two directories
above src. The gateway files themselves are unchanged.

The verified source did not contain package-lock.json. This export therefore
adds one operator-only root package-lock.json and matching root package.json.
They pin the exact tested Wrangler 4.92.0 resolution. They are not source-branch
changes and must not be committed back to the R12 branch.

## Provider destination

At the R12 checkpoint the Worker service did not yet exist. The operator selects
the Cloudflare account by supplying its exact 32-hex account ID. The expected
origin has this form:

    https://pulsechain-external-observer-grok-mcp.<account-subdomain>.workers.dev

No Cloudflare account ID or account subdomain is embedded in this bundle.

## Local prerequisites

- A local Windows computer.
- PowerShell 7.4 or later.
- Node.js 22.13.0 or later with npm and npx.
- An interactive browser available if Wrangler login is required.
- The approved Cloudflare account ID.
- Approved EXTERNAL_OBSERVER_GITHUB_ISSUES_TOKEN material available only to the
  local operator. Do not paste that value into chat.

Start from a fresh extraction of the ZIP. Compare the outer ZIP SHA-256 with the
release response before running any script. DEPLOY_GATEWAY.ps1 independently
checks SHA256SUMS.txt, SOURCE_MANIFEST.json, the exact gateway file set, every
source byte, Worker configuration, lock provenance, and the 8-of-8 gateway test
gate before authentication or secret handling.

## Exact local deployment command

Run from this extracted bundle directory:

    pwsh.exe -NoProfile -ExecutionPolicy Bypass -File .\DEPLOY_GATEWAY.ps1 -CloudflareAccountId "<32-hex Cloudflare account ID>"

The script:

1. installs the pinned operator toolchain from package-lock.json;
2. verifies Wrangler 4.92.0 and reruns the complete gateway validation;
3. runs Wrangler login only when whoami proves the operator is not authenticated;
4. requires the authenticated account to match the supplied account ID;
5. creates five independent cryptographic connector tokens;
6. stores each connector token under the current Windows user using DPAPI;
7. prompts locally and without echo for the GitHub issues token;
8. builds a current-user-only temporary secrets file;
9. performs exactly one Worker deployment while preserving DISABLED mode;
10. deletes the temporary secrets file in a finally block; and
11. runs VERIFY_GATEWAY_DISABLED.ps1.

The connector vault is outside the source directory:

    %LOCALAPPDATA%\PulseChain\ExternalObserverGateway\connector-tokens.dpapi.json

The disabled-mode report is written outside the source directory:

    %LOCALAPPDATA%\PulseChain\ExternalObserverGateway\LOCAL_DISABLED_MODE_VERIFICATION.json

Successful console output contains only the deployment result, Worker name,
Cloudflare account ID, Worker version ID, workers.dev origin, five connector
URLs, and verification status. It never prints a connector token or GitHub
credential.

## Disabled-mode verification

VERIFY_GATEWAY_DISABLED.ps1 initializes every Streamable HTTP connector, checks
tools/list and the exact discovery fingerprint, requires one fixed publish tool
and the three common read tools, rejects every cross-connector token, verifies
that observer_id and other server controls are absent from the model-visible
schema, reads the matching observer bootstrap, and makes one valid disabled
publication call per connector.

Each call must return PUBLICATION_MODE_DISABLED with null issue, workflow,
observation, commit, and permanent-page fields. Before and after checks require
zero GitHub issue, workflow, repository-head, observation, permanent-page,
latest-pointer, and index changes.

## Retrieve one connector token locally

Only after a successful deployment and verification, use one exact observer ID:

    pwsh.exe -NoProfile -ExecutionPolicy Bypass -File .\SHOW_GROK_CONNECTOR_TOKEN.ps1 grok-x-protocol

The script requires an unredirected local console and an explicit DISPLAY
confirmation. It decrypts and displays only the selected observer's token. Do
not paste that token into chat, a checkpoint, source, a log, or another
observer's connector.

## Stop point

Do not configure or schedule Grok from this bundle. Do not change
PUBLICATION_MODE. After the manual deployment and successful disabled
verification, use R13_POST_DEPLOYMENT_VERIFICATION_PROMPT.md as the separately
bounded next task.

Use REMOVE_OR_ROLLBACK_GATEWAY.md if the deploy or disabled verification fails.
