#Requires -Version 7.4

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [ValidatePattern("^https://pulsechain-external-observer-grok-mcp\.[a-z0-9-]+\.workers\.dev/?$")]
    [string]$WorkerOrigin,

    [Parameter(Mandatory = $false)]
    [Security.SecureString]$GitHubIssuesToken
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$VerbosePreference = "SilentlyContinue"
$DebugPreference = "SilentlyContinue"
$InformationPreference = "SilentlyContinue"

$BundleRoot = [IO.Path]::GetFullPath($PSScriptRoot)
. (Join-Path $BundleRoot "OPERATOR_COMMON.ps1")
Assert-WindowsOperator

$ControlRoomOrigin = "https://pulsechain-research-control-room.brohexphiat.chatgpt.site"
$Repository = "opus99999/pulsechain-mcp"
$ExpectedRuntimeHead = "f7c5427d505757fe101ea20ef1c402946152f3aa"
$ExpectedSnapshot = "sha256:4f633b3ee0446d7ebac272978bea106aae5ab9e55c9dd8b1ae7e8a673d4df18c"
$ExpectedCommonTools = @(
    "read_external_observer_bootstrap",
    "read_workstream_bootstrap",
    "read_external_observation"
)
$ownsGitHubSecure = $false
$githubPlain = $null
$report = $null
$verificationFailure = $null

function Invoke-GitHubJson {
    param(
        [Parameter(Mandatory = $true)][string]$Uri,
        [switch]$Anonymous
    )
    $headers = @{
        Accept = "application/vnd.github+json"
        "X-GitHub-Api-Version" = "2022-11-28"
        "User-Agent" = "pulsechain-r12a-disabled-verifier"
    }
    if (-not $Anonymous) {
        $headers.Authorization = "Bearer $githubPlain"
    }
    try {
        Invoke-RestMethod -Uri $Uri -Method Get -Headers $headers -TimeoutSec 30
    }
    catch {
        throw "A required GitHub read failed."
    }
}

function Get-GitHubFileBytes {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Head
    )
    $encodedPath = ($Path.Split("/") | ForEach-Object { [Uri]::EscapeDataString($_) }) -join "/"
    $uri = "https://api.github.com/repos/{0}/contents/{1}?ref={2}" -f $Repository, $encodedPath, $Head
    try {
        $value = Invoke-GitHubJson -Uri $uri
    }
    catch {
        $value = Invoke-GitHubJson -Uri $uri -Anonymous
    }
    if ($value.type -ne "file" -or [string]::IsNullOrWhiteSpace([string]$value.content)) {
        throw "A governed public-runtime file is unavailable."
    }
    [Convert]::FromBase64String(([string]$value.content -replace "\s", ""))
}

function Get-IssueCount {
    $quote = [char]34
    $queryText = "repo:$Repository in:title " + $quote + "EXTERNAL OBSERVER SUBMISSION —" + $quote
    $query = [Uri]::EscapeDataString($queryText)
    $value = Invoke-GitHubJson -Uri "https://api.github.com/search/issues?q=$query&per_page=1"
    [int64]$value.total_count
}

function Get-DisabledObservationIssueCount {
    $uri = "https://api.github.com/repos/$Repository/issues?state=all&sort=created&direction=desc&per_page=100"
    $value = Invoke-GitHubJson -Uri $uri
    $expectedTitles = @(
        Get-ConnectorDefinitions |
            ForEach-Object {
                "EXTERNAL OBSERVER SUBMISSION — $($_.observer_id) — $($_.observation_id)"
            }
    )
    @(
        $value |
            Where-Object {
                -not ($_.PSObject.Properties.Name -contains "pull_request") -and
                $expectedTitles -ccontains ([string]$_.title)
            }
    ).Count
}

function Get-WorkflowRunCount {
    $uri = "https://api.github.com/repos/$Repository/actions/workflows/trusted-team-external-observers.yml/runs?per_page=1"
    try {
        $value = Invoke-GitHubJson -Uri $uri
    }
    catch {
        $value = Invoke-GitHubJson -Uri $uri -Anonymous
    }
    [int64]$value.total_count
}

function Invoke-PublicJson {
    param([Parameter(Mandatory = $true)][string]$Path)
    try {
        $response = Invoke-WebRequest -Uri ($ControlRoomOrigin + $Path) -Method Get -Headers @{ Accept = "application/json" } -TimeoutSec 30
    }
    catch {
        throw "A required Control Room read failed."
    }
    if ([int]$response.StatusCode -ne 200) {
        throw "A required Control Room read did not return HTTP 200."
    }
    $response.Content | ConvertFrom-Json -Depth 40
}

function Test-UnavailablePermanentPage {
    param([Parameter(Mandatory = $true)][psobject]$Definition)
    $uri = "$ControlRoomOrigin/research/external-observers/$($Definition.observer_id)/observations/$($Definition.observation_id)"
    try {
        $response = Invoke-WebRequest -Uri $uri -Method Get -Headers @{ Accept = "text/html" } -SkipHttpErrorCheck -TimeoutSec 30
    }
    catch {
        throw "A permanent-page absence check failed."
    }
    if ($response.Content -notmatch "EXTERNAL_OBSERVATION_NOT_FOUND") {
        throw "A disabled verification observation has a permanent page."
    }
    [pscustomobject]@{
        observer_id = $Definition.observer_id
        observation_id = $Definition.observation_id
        unavailable = $true
    }
}

function Get-PublicState {
    $referenceUri = "https://api.github.com/repos/$Repository/git/ref/heads/main"
    try {
        $reference = Invoke-GitHubJson -Uri $referenceUri
    }
    catch {
        $reference = Invoke-GitHubJson -Uri $referenceUri -Anonymous
    }
    $head = [string]$reference.object.sha
    if ($head -notmatch "^[0-9a-f]{40}$") {
        throw "The public-runtime main head is invalid."
    }

    $root = Invoke-PublicJson -Path "/api/v1/external-observers"
    $feed = Invoke-PublicJson -Path "/api/v1/external-observers/observations"
    if (
        $root.ledger.repository_head -ne $head -or
        $root.ledger.fallback_used -ne $false -or
        $root.ledger.observer_snapshot_sha256 -notmatch "^sha256:[0-9a-f]{64}$"
    ) {
        throw "The live observer snapshot does not match public-runtime main."
    }

    $observerProjection = @(
        $root.observers |
            ForEach-Object {
                [pscustomobject][ordered]@{
                    observer_id = $_.observer_id
                    latest_observation_id = $_.latest_observation_id
                    observation_count = [int]$_.observation_count
                }
            }
    )
    $definitions = @(Get-ConnectorDefinitions)
    $expectedObserverIds = @($definitions.observer_id | Sort-Object)
    $actualObserverIds = @($observerProjection.observer_id | Sort-Object)
    if (
        $observerProjection.Count -ne 5 -or
        ($actualObserverIds -join [Environment]::NewLine) -cne ($expectedObserverIds -join [Environment]::NewLine)
    ) {
        throw "The live observer projection is incomplete or identity-mismatched."
    }
    $governedFiles = @()
    foreach ($definition in $definitions) {
        $latestPath = "external-observers/observers/$($definition.observer_id)/latest.json"
        $indexPath = "external-observers/observers/$($definition.observer_id)/index.json"
        [byte[]]$latestBytes = Get-GitHubFileBytes -Path $latestPath -Head $head
        [byte[]]$indexBytes = Get-GitHubFileBytes -Path $indexPath -Head $head
        try {
            $latest = [Text.Encoding]::UTF8.GetString($latestBytes) | ConvertFrom-Json -Depth 20
            $index = [Text.Encoding]::UTF8.GetString($indexBytes) | ConvertFrom-Json -Depth 20
            if ($latest.observer_id -ne $definition.observer_id -or $null -ne $latest.observation_id) {
                throw "An observer latest pointer is not empty."
            }
            if ($index.observer_id -ne $definition.observer_id -or @($index.observations).Count -ne 0) {
                throw "An observer index is not empty."
            }
            $governedFiles += [pscustomobject][ordered]@{
                observer_id = $definition.observer_id
                latest_sha256 = "sha256:" + (Get-Sha256Hex -Bytes $latestBytes)
                index_sha256 = "sha256:" + (Get-Sha256Hex -Bytes $indexBytes)
                latest_observation_id = $latest.observation_id
                index_count = @($index.observations).Count
            }
        }
        finally {
            [Array]::Clear($latestBytes, 0, $latestBytes.Length)
            [Array]::Clear($indexBytes, 0, $indexBytes.Length)
        }
    }
    $pages = @($definitions | ForEach-Object { Test-UnavailablePermanentPage -Definition $_ })
    [pscustomobject][ordered]@{
        public_runtime_main = $head
        observer_submission_issue_count = Get-IssueCount
        disabled_observation_issue_count = Get-DisabledObservationIssueCount
        observer_workflow_run_count = Get-WorkflowRunCount
        snapshot_commit = [string]$root.ledger.repository_head
        snapshot_sha256 = [string]$root.ledger.observer_snapshot_sha256
        observer_projection = $observerProjection
        observation_ids = @($feed.observations | ForEach-Object { $_.observation_id } | Sort-Object)
        governed_files = $governedFiles
        unavailable_pages = $pages
    }
}

function Invoke-Mcp {
    param(
        [Parameter(Mandatory = $true)][string]$Uri,
        [Parameter(Mandatory = $true)][string]$Token,
        [Parameter(Mandatory = $true)][psobject]$Message
    )
    $body = $Message | ConvertTo-Json -Depth 80 -Compress
    try {
        $response = Invoke-WebRequest -Uri $Uri -Method Post -Headers @{
            Authorization = "Bearer $Token"
            Accept = "application/json, text/event-stream"
            "Content-Type" = "application/json"
        } -Body $body -SkipHttpErrorCheck -TimeoutSec 30
    }
    catch {
        throw "A remote MCP request failed."
    }
    $parsed = $null
    if (-not [string]::IsNullOrWhiteSpace([string]$response.Content)) {
        try {
            $parsed = $response.Content | ConvertFrom-Json -Depth 80
        }
        catch {
            throw "A remote MCP response was not valid JSON."
        }
    }
    [pscustomobject]@{
        status = [int]$response.StatusCode
        body = $parsed
        fingerprint = [string]$response.Headers["X-PulseChain-Tool-Discovery-Fingerprint"]
    }
}

function New-RpcMessage {
    param(
        [Parameter(Mandatory = $true)][string]$Id,
        [Parameter(Mandatory = $true)][string]$Method,
        [Parameter(Mandatory = $false)][psobject]$Parameters
    )
    $message = [ordered]@{
        jsonrpc = "2.0"
        id = $Id
        method = $Method
    }
    if ($PSBoundParameters.ContainsKey("Parameters")) {
        $message.params = $Parameters
    }
    [pscustomobject]$message
}

try {
    $vault = Read-ConnectorVault -RequireOrigin
    if ([string]::IsNullOrWhiteSpace($WorkerOrigin)) {
        $WorkerOrigin = [string]$vault.worker_origin
    }
    if ($WorkerOrigin.TrimEnd("/") -cne ([string]$vault.worker_origin).TrimEnd("/")) {
        throw "The requested Worker origin does not match the local vault."
    }
    $WorkerOrigin = $WorkerOrigin.TrimEnd("/")
    if ($vault.publication_mode -ne "DISABLED") {
        throw "The local vault does not attest disabled publication mode."
    }

    if ($null -eq $GitHubIssuesToken) {
        $GitHubIssuesToken = Read-Host "Enter EXTERNAL_OBSERVER_GITHUB_ISSUES_TOKEN for read-only nonmutation checks" -AsSecureString
        $ownsGitHubSecure = $true
    }
    $githubPlain = ConvertFrom-LocalSecureString -SecureValue $GitHubIssuesToken
    if ([string]::IsNullOrWhiteSpace($githubPlain)) {
        throw "The GitHub read credential is unavailable."
    }

    $before = Get-PublicState
    if (
        $before.public_runtime_main -ne $ExpectedRuntimeHead -or
        $before.snapshot_commit -ne $ExpectedRuntimeHead -or
        $before.snapshot_sha256 -ne $ExpectedSnapshot -or
        $before.disabled_observation_issue_count -ne 0 -or
        @($before.observation_ids).Count -ne 0 -or
        @($before.observer_projection | Where-Object { $null -ne $_.latest_observation_id -or $_.observation_count -ne 0 }).Count -ne 0
    ) {
        throw "The disabled-mode entry state differs from the verified R12 state."
    }

    $definitions = @(Get-ConnectorDefinitions)
    $connectorResults = @()
    foreach ($definition in $definitions) {
        $token = Get-ConnectorToken -Vault $vault -ObserverId $definition.observer_id
        try {
            $connectorUri = $WorkerOrigin + $definition.path
            $initialize = Invoke-Mcp -Uri $connectorUri -Token $token -Message (New-RpcMessage -Id ("initialize-" + $definition.observer_id) -Method "initialize" -Parameters ([pscustomobject]@{
                protocolVersion = "2025-06-18"
                capabilities = [pscustomobject]@{}
                clientInfo = [pscustomobject]@{
                    name = "pulsechain-r12a-verifier"
                    version = "1.0.0"
                }
            }))
            if (
                $initialize.status -ne 200 -or
                $initialize.body.result.protocolVersion -ne "2025-06-18" -or
                $initialize.body.result.serverInfo.name -ne "pulsechain-$($definition.observer_id)-mcp" -or
                $initialize.body.result.serverInfo.version -ne "1.0.0" -or
                $initialize.body.result.capabilities.tools.listChanged -ne $false
            ) {
                throw "Streamable HTTP initialization failed."
            }

            $discovery = Invoke-Mcp -Uri $connectorUri -Token $token -Message (New-RpcMessage -Id ("tools-" + $definition.observer_id) -Method "tools/list")
            $tools = @($discovery.body.result.tools)
            $toolNames = @($tools | ForEach-Object { $_.name })
            $expectedNames = @($definition.publish_tool) + $ExpectedCommonTools
            if (
                $discovery.status -ne 200 -or
                $discovery.fingerprint -cne $definition.fingerprint -or
                ($toolNames -join [Environment]::NewLine) -cne ($expectedNames -join [Environment]::NewLine)
            ) {
                throw "Connector tool discovery is invalid."
            }
            $publishTools = @($tools | Where-Object { $_.name -like "publish_external_observation_*" })
            if ($publishTools.Count -ne 1 -or $publishTools[0].name -ne $definition.publish_tool) {
                throw "A connector exposed a foreign publish tool."
            }
            $schemaText = $publishTools[0].inputSchema | ConvertTo-Json -Depth 80 -Compress
            $schemaLower = $schemaText.ToLowerInvariant()
            foreach ($forbidden in @("observer_id", "repository", "workflow", "ledger path", "github credential", "connector credential", "publication mode")) {
                if ($schemaLower.Contains($forbidden)) {
                    throw "A server-selected control is model-visible."
                }
            }
            if ($publishTools[0].inputSchema.additionalProperties -ne $false) {
                throw "The publish input schema is not strict."
            }

            $foreignAuthPass = 0
            foreach ($foreign in @($definitions | Where-Object { $_.observer_id -ne $definition.observer_id })) {
                $foreignResponse = Invoke-Mcp -Uri ($WorkerOrigin + $foreign.path) -Token $token -Message (New-RpcMessage -Id ("foreign-" + $definition.observer_id + "-" + $foreign.observer_id) -Method "tools/list")
                if ($foreignResponse.status -ne 401) {
                    throw "A connector token authenticated to a foreign observer."
                }
                $foreignAuthPass += 1
            }

            $bootstrap = Invoke-Mcp -Uri $connectorUri -Token $token -Message (New-RpcMessage -Id ("bootstrap-" + $definition.observer_id) -Method "tools/call" -Parameters ([pscustomobject]@{
                name = "read_external_observer_bootstrap"
                arguments = [pscustomobject]@{}
            }))
            if (
                $bootstrap.status -ne 200 -or
                $bootstrap.body.result.structuredContent.observer_id -ne $definition.observer_id
            ) {
                throw "The observer bootstrap read is identity-mismatched."
            }

            $payloadText = @(& node (Join-Path $BundleRoot "OPERATOR_BUILD_DISABLED_PAYLOAD.mjs") $definition.observer_id 2>$null) -join ""
            if ($LASTEXITCODE -ne 0) {
                throw "The governed disabled payload could not be constructed."
            }
            $payload = $payloadText | ConvertFrom-Json -Depth 80
            if ($payload.PSObject.Properties.Name -contains "observer_id") {
                throw "The disabled payload contains a model-selected observer ID."
            }
            $disabled = Invoke-Mcp -Uri $connectorUri -Token $token -Message (New-RpcMessage -Id ("disabled-" + $definition.observer_id) -Method "tools/call" -Parameters ([pscustomobject]@{
                name = $definition.publish_tool
                arguments = $payload
            }))
            $result = $disabled.body.result
            $contentResult = $result.content[0].text | ConvertFrom-Json -Depth 20
            if (
                $disabled.status -ne 200 -or
                ($result.PSObject.Properties.Name -contains "isError") -or
                $result.structuredContent.accepted -ne $false -or
                $result.structuredContent.error_code -ne "PUBLICATION_MODE_DISABLED" -or
                $null -ne $result.structuredContent.issue_number -or
                $null -ne $result.structuredContent.workflow_run_id -or
                $null -ne $result.structuredContent.observation_id -or
                $null -ne $result.structuredContent.publication_commit -or
                $null -ne $result.structuredContent.permanent_url -or
                ($contentResult | ConvertTo-Json -Compress) -cne ($result.structuredContent | ConvertTo-Json -Compress)
            ) {
                throw "A disabled publication call returned an invalid receipt."
            }

            $connectorResults += [pscustomobject][ordered]@{
                observer_id = $definition.observer_id
                connector_url = $connectorUri
                initialize = "PASS"
                tools_list = "PASS"
                discovery_fingerprint = $definition.fingerprint
                fixed_publish_tool = $definition.publish_tool
                common_read_tools = $ExpectedCommonTools
                foreign_authentication_rejections = $foreignAuthPass
                observer_id_model_visible = $false
                observer_bootstrap_identity = "PASS"
                disabled_write_result = "PUBLICATION_MODE_DISABLED"
                issue_number = $null
                workflow_run_id = $null
                observation_id = $null
                publication_commit = $null
                permanent_url = $null
            }
        }
        finally {
            $token = $null
        }
    }

    $after = Get-PublicState
    $beforeCanonical = $before | ConvertTo-Json -Depth 40 -Compress
    $afterCanonical = $after | ConvertTo-Json -Depth 40 -Compress
    if ($beforeCanonical -cne $afterCanonical) {
        throw "Disabled connector calls changed public or repository state."
    }

    $report = [pscustomobject][ordered]@{
        schema_version = "pulsechain-r12a-local-disabled-mode-verification@1.0.0"
        generated_at_utc = [DateTime]::UtcNow.ToString("o")
        result = "PASS"
        worker_name = "pulsechain-external-observer-grok-mcp"
        worker_origin = $WorkerOrigin
        worker_version_id = $vault.current_version_id
        account_id = $vault.account_id
        source_branch = $vault.source_branch
        source_commit = $vault.source_commit
        source_tree = $vault.source_tree
        publication_mode = "DISABLED"
        streamable_http_protocol = "2025-06-18"
        connectors = $connectorResults
        nonmutation = [pscustomobject][ordered]@{
            public_runtime_main_before = $before.public_runtime_main
            public_runtime_main_after = $after.public_runtime_main
            repository_commit_delta = 0
            issue_count_before = $before.observer_submission_issue_count
            issue_count_after = $after.observer_submission_issue_count
            issue_delta = 0
            disabled_observation_issue_count_before = $before.disabled_observation_issue_count
            disabled_observation_issue_count_after = $after.disabled_observation_issue_count
            disabled_observation_issue_delta = 0
            workflow_run_count_before = $before.observer_workflow_run_count
            workflow_run_count_after = $after.observer_workflow_run_count
            workflow_run_delta = 0
            observation_delta = 0
            permanent_page_delta = 0
            latest_pointer_delta = 0
            index_delta = 0
            snapshot_sha256 = $before.snapshot_sha256
        }
        secrets_in_report = 0
    }
}
catch {
    $verificationFailure = "R12A disabled-mode verification failed. No secret value was printed."
    $report = [pscustomobject][ordered]@{
        schema_version = "pulsechain-r12a-local-disabled-mode-verification@1.0.0"
        generated_at_utc = [DateTime]::UtcNow.ToString("o")
        result = "FAIL"
        publication_mode = "DISABLED"
        error = "VERIFICATION_GATE_FAILED"
        secrets_in_report = 0
    }
}
finally {
    $githubPlain = $null
    if ($ownsGitHubSecure -and $null -ne $GitHubIssuesToken) {
        $GitHubIssuesToken.Dispose()
        $GitHubIssuesToken = $null
    }
    if ($null -ne $report) {
        Write-PrivateTextFile -Path (Get-VerificationReportPath) -Text (($report | ConvertTo-Json -Depth 50) + [Environment]::NewLine)
    }
}

if ($null -ne $verificationFailure) {
    throw $verificationFailure
}
Write-Output "VERIFICATION_STATUS=PASS"
