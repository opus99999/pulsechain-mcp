import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";

const testDirectory = dirname(fileURLToPath(import.meta.url));
const operatorDirectory = dirname(testDirectory);
const sourceLayer = operatorDirectory.endsWith("external_observer_grok_mcp_operator");
const read = (name) => readFile(join(operatorDirectory, name), "utf8");

test("source-template and rendered-package placeholder layers are exact", async () => {
  const scriptName = "UPDATE_EXISTING_GATEWAY_R12F.ps1";
  const [script, builder] = await Promise.all([
    read(scriptName),
    read("BUILD_R12F_UPDATE_BUNDLE.mjs"),
  ]);
  const tokens = script.match(/@@[A-Z0-9_]+@@/gu) ?? [];
  if (scriptName.endsWith(".in")) {
    assert.ok(tokens.length > 0);
    assert.equal(new Set(tokens).size, tokens.length, "each governed template placeholder occurs exactly once");
    for (const token of tokens) assert.ok(builder.includes(`"${token}"`), `renderer does not support ${token}`);
  } else {
    assert.equal(tokens.length, 0, "rendered executable contains no governed placeholder");
    assert.equal((builder.match(/@@[A-Z0-9_]+@@/gu) ?? []).length, 0, "packaged builder record contains no governed placeholder");
    for (const literal of [
      "pulsechain-external-observer-r12f-update-inventory@1.0.0",
      "pulsechain-external-observer-r12f-source-manifest@1.0.0",
      "pulsechain-external-observer-r12f-update-expectations@1.0.0",
    ]) assert.ok(script.includes(literal), `rendered executable missing ${literal}`);
  }
});

const exactFiveLabels = [
  "GROK_MCP_TOKEN_X_PROTOCOL",
  "GROK_MCP_TOKEN_INFRASTRUCTURE_INCIDENTS",
  "GROK_MCP_TOKEN_MARKET_LIQUIDITY",
  "GROK_MCP_TOKEN_IDENTITY_EVIDENCE",
  "GROK_MCP_TOKEN_RED_TEAM",
];

test("update script binds the exact existing Worker prestate", async () => {
  const script = await read("UPDATE_EXISTING_GATEWAY_R12F.ps1");
  for (const value of [
    "pulsechain-external-observer-grok-mcp",
    "dade45b2875ee5e98c74b5d06528cd9c",
    "c776a6e0-14b8-49bc-be9a-7aa0e63c5495",
    "e32f2b34-a572-404e-b969-44c0bf2c9088",
    "https://pulsechain-external-observer-grok-mcp.pulsechain-research-dade45b2.workers.dev",
    "https://pulsechain-research-control-room.brohexphiat.chatgpt.site",
    "2026-08-27",
    "nodejs_compat",
    "4.92.0",
    ...exactFiveLabels,
  ]) {
    assert.ok(script.includes(value), `missing fixed value ${value}`);
  }
  assert.match(script, /ValidateSet\("I_HAVE_EXCLUSIVE_CHANGE_FREEZE"\)/);
  assert.match(script, /UNDEPLOYED_DRAFT_VERSION_PRESENT/);
  assert.match(script, /FINAL_CHANGE_FREEZE_RECHECK/);
  assert.match(script, /Assert-ProductionUnchanged/);
});

test("update script has one controlled upload and one controlled deployment path", async () => {
  const script = await read("UPDATE_EXISTING_GATEWAY_R12F.ps1");
  assert.equal((script.match(/"versions", "upload"/g) ?? []).length, 1);
  assert.equal((script.match(/"versions", "deploy"/g) ?? []).length, 1);
  assert.match(script, /"--keep-vars"/);
  assert.match(script, /"--outfile", \$uploadFormPath/);
  assert.match(script, /\("\{0\}@100" -f \$newVersionId\)/);
  assert.match(script, /VERSION_UPLOAD_AMBIGUOUS_NO_RETRY/);
  assert.match(script, /DEPLOYMENT_AMBIGUOUS_NO_RETRY/);
  assert.doesNotMatch(script, /(?<!versions["'],\s*["'])wrangler\s+deploy/i);
  assert.doesNotMatch(script, /--force(?:-with-lease)?/i);
});

test("update script contains no secret or vault mutation mechanism", async () => {
  const script = await read("UPDATE_EXISTING_GATEWAY_R12F.ps1");
  for (const prohibited of [
    /--secrets-file/i,
    /["']secret["']\s*,\s*["'](?:put|bulk|delete)/i,
    /Write-ConnectorVault/,
    /Protect-ConnectorToken/,
    /New-ConnectorToken/,
    /Set-Content[^\n]*connector-tokens\.dpapi\.json/i,
  ]) {
    assert.doesNotMatch(script, prohibited);
  }
  assert.match(script, /Assert-VaultUnchanged/g);
  assert.match(script, /FINALIZED_VAULT_METADATA_MISMATCH/);
  assert.match(script, /UPDATE_VERIFIED_R13_HANDOFF_READY/);
});

test("bundle is validated before bundle code is dot-sourced", async () => {
  const script = await read("UPDATE_EXISTING_GATEWAY_R12F.ps1");
  const validateIndex = script.indexOf("    Assert-BundleIntegrity\n");
  const dotSourceIndex = script.indexOf('    . (Join-Path $BundleRoot "OPERATOR_COMMON.ps1")');
  assert.ok(validateIndex > 0);
  assert.ok(dotSourceIndex > validateIndex);
  for (const gate of [
    "BUNDLE_REPARSE_POINT_REJECTED",
    "BUNDLE_CASE_FOLD_COLLISION",
    "BUNDLE_PATH_UNSAFE",
    "BUNDLE_FORBIDDEN_MEMBER",
    "BUNDLE_CHECKSUM_MISMATCH",
    "BUNDLE_INVENTORY_INVALID",
  ]) assert.ok(script.includes(gate));
});

test("uploaded Version readback proves bindings and remote source bytes", async () => {
  const script = await read("UPDATE_EXISTING_GATEWAY_R12F.ps1");
  assert.match(script, /Assert-VersionBindingContract -Version \$newVersion/);
  assert.match(script, /Get-RemoteVersionContent -VersionId \$newVersionId/);
  assert.match(script, /local_remote_content_equal/);
  assert.match(script, /remote_source_map_count/);
  assert.match(script, /Assert-ExactSecrets/);
  assert.match(script, /secret_text/);
});

test("governed verifier runs once and rollback remains separately authorized", async () => {
  const script = await read("UPDATE_EXISTING_GATEWAY_R12F.ps1");
  assert.equal((script.match(/\$verifierInvocations \+= 1/g) ?? []).length, 1);
  assert.match(script, /PRESERVE_DEPLOYED_R12F_REPORT_EXTERNAL_BLOCKER/);
  assert.match(script, /R12F_EXTERNAL_UPSTREAM_BLOCKER_NO_ROLLBACK/);
  assert.match(script, /R12F_RELEASE_CRITICAL_FAILURE_SEPARATE_ROLLBACK_AUTHORIZATION_REQUIRED/);
  assert.doesNotMatch(script, /versions["'],\s*["']deploy["'][\s\S]{0,300}ExpectedPriorVersionId/);
});

test("Cloudflare helper is read-only and receives credentials only on stdin", async () => {
  const helper = await read("VERIFY_CLOUDFLARE_R12F.mjs");
  assert.match(helper, /process\.stdin/);
  assert.doesNotMatch(helper, /process\.env\.(?:CLOUDFLARE|CF_)/);
  assert.doesNotMatch(helper, /writeFile|appendFile|createWriteStream/);
  assert.match(helper, /method:\s*"GET"/);
  assert.doesNotMatch(helper, /method:\s*"(?:POST|PUT|PATCH|DELETE)"/);
  assert.match(helper, /redirect:\s*"error"/);
  assert.match(helper, /local_remote_content_equal/);
});

test("Cloudflare state helper has one intentional success-pipeline object", async () => {
  const script = await read("UPDATE_EXISTING_GATEWAY_R12F.ps1");
  const helper = script.slice(
    script.indexOf("function Invoke-CloudflareHelper"),
    script.indexOf("function Throw-CloudflareStateFieldFailure"),
  );
  for (const expression of [
    /\[void\]\$process\.StandardInput\.Write\(\$auth\.stdout\)/,
    /\[void\]\$process\.StandardInput\.Close\(\)/,
    /\[void\]\$process\.WaitForExitAsync\(\)\.GetAwaiter\(\)\.GetResult\(\)/,
    /\[void\]\$process\.Kill\(\$true\)/,
    /\[void\]\$process\.Dispose\(\)/,
  ]) assert.match(helper, expression);
  assert.equal((helper.match(/^\s*\$record\s*$/gmu) ?? []).length, 1);
  assert.doesNotMatch(helper, /^\s*\$process\.WaitForExitAsync\(\)\.GetAwaiter\(\)\.GetResult\(\)\s*$/mu);

  const reproducedOldOutput = [
    { runtime_type: "System.Threading.Tasks.VoidTaskResult" },
    { runtime_type: "System.Management.Automation.PSCustomObject", account_id: "synthetic" },
  ];
  assert.equal(reproducedOldOutput.length, 2);
  assert.equal(reproducedOldOutput[0].runtime_type, "System.Threading.Tasks.VoidTaskResult");
  assert.ok("account_id" in reproducedOldOutput[1]);
});

test("Get-CloudflareState enforces exact output cardinality and shape", async () => {
  const script = await read("UPDATE_EXISTING_GATEWAY_R12F.ps1");
  const stateFunction = script.slice(
    script.indexOf("function Throw-CloudflareStateFieldFailure"),
    script.indexOf("function Get-RemoteVersionContent"),
  );
  assert.match(stateFunction, /\$outputs = @\(Invoke-CloudflareHelper/);
  assert.match(stateFunction, /\$outputs\.Count -eq 0[\s\S]*CLOUDFLARE_STATE_UNAVAILABLE/);
  assert.match(stateFunction, /\$outputs\.Count -ne 1[\s\S]*CLOUDFLARE_STATE_OUTPUT_CARDINALITY_MISMATCH/);
  assert.match(stateFunction, /\$State -isnot \[pscustomobject\][\s\S]*CLOUDFLARE_STATE_TYPE_INVALID/);
  assert.match(stateFunction, /CLOUDFLARE_STATE_REQUIRED_FIELD_MISSING/);
  assert.match(stateFunction, /PulseChainFailedField/);
  assert.doesNotMatch(stateFunction, /Select-Object\s+-Last|\$outputs\[-1\]/i);
  for (const field of [
    "account_id",
    "worker_name",
    "account_subdomain",
    "workers_dev_enabled",
    "preview_urls_enabled",
    "worker_origin",
    "last_deployed_from",
    "service_script_tag",
    "script_settings_sha256",
  ]) assert.ok(stateFunction.includes(`"${field}"`), `missing state field ${field}`);
});

test("prestate failure reporting preserves sanitized ErrorRecord detail", async () => {
  const script = await read("UPDATE_EXISTING_GATEWAY_R12F.ps1");
  assert.match(script, /New-SanitizedOperatorFailureRecord -ErrorRecord \$ErrorRecord -Stage \$phase/);
  assert.match(script, /\$caughtFailureRecord = New-UpdateFailureRecord -ErrorRecord \$_/);
  assert.match(script, sourceLayer ? /R12F2C_UPDATE_FAILURE\.json/ : /R12F2E_UPDATE_FAILURE\.json/);
  assert.match(script, /PulseChainFailureRecord/);
  assert.match(script, /exception_type=\$exceptionType/);
  assert.match(script, /source_line=\$sourceLine/);
  assert.match(script, /failed_field=\$failedField/);
});

test("New-UpdateFailureRecord release bindings exactly equal Windows harness declarations", async () => {
  const [script, harness] = await Promise.all([
    read("UPDATE_EXISTING_GATEWAY_R12F.ps1"),
    read(sourceLayer
      ? "tests/cloudflare-state-single-object.test.mjs"
      : "operator-tests/cloudflare-state-single-object.test.mjs"),
  ]);
  const functionStart = script.indexOf("function New-UpdateFailureRecord");
  const functionEnd = script.indexOf("\n}\n\ntry {", functionStart);
  assert.ok(functionStart >= 0 && functionEnd > functionStart, "New-UpdateFailureRecord function boundaries missing");
  const functionBody = script.slice(functionStart, functionEnd);
  const bindingPattern = /\$Expected(R12F2[A-Z])BundleSource(Branch|Commit|Tree)\b/gu;
  const consumerMatches = [...functionBody.matchAll(bindingPattern)];
  const declarationPattern = /^\$Expected(R12F2[A-Z])BundleSource(Branch|Commit|Tree)\s*=/gmu;
  const declarationMatches = [...harness.matchAll(declarationPattern)];
  const names = (matches) => matches.map((match) => `Expected${match[1]}BundleSource${match[2]}`);
  const consumerNames = names(consumerMatches);
  const declarationNames = names(declarationMatches);
  const consumerSet = [...new Set(consumerNames)].sort();
  const declarationSet = [...new Set(declarationNames)].sort();
  assert.equal(consumerMatches.length, 3);
  assert.equal(declarationMatches.length, 3);
  assert.equal(consumerSet.length, 3);
  assert.equal(declarationSet.length, 3);
  assert.deepEqual([...new Set(consumerMatches.map((match) => match[2]))].sort(), ["Branch", "Commit", "Tree"]);
  assert.equal(new Set(consumerMatches.map((match) => match[1])).size, 1);
  assert.equal(new Set(declarationMatches.map((match) => match[1])).size, 1);
  assert.deepEqual(declarationSet, consumerSet);
});

test("operator documentation discloses residual provider limitations", async () => {
  const [readme, rollback, r13] = await Promise.all([
    read("OPERATOR_README.md"),
    read("ROLLBACK_R12F.md"),
    read("R13_POST_UPDATE_VERIFICATION_PROMPT.md"),
  ]);
  assert.match(readme, /does not expose a compare-and-swap/i);
  assert.match(readme, /may internally retry its mutation request/i);
  assert.match(readme, /exclusive change freeze/i);
  assert.match(readme, /do not rerun the command/i);
  assert.match(rollback, /only after.*release_critical: true/is);
  assert.match(rollback, /CONTROL_ROOM_UPSTREAM_UNAVAILABLE/);
  assert.match(r13, /Remain read-only/);
  assert.match(r13, /do not execute rollback/i);
});

test("R12F2E retains one exact R12F producer and consumer schema contract", async () => {
  const [script, builder, validator] = await Promise.all([
    read("UPDATE_EXISTING_GATEWAY_R12F.ps1"),
    read("BUILD_R12F_UPDATE_BUNDLE.mjs"),
    read("BUNDLE_CONTRACT_VALIDATION.mjs"),
  ]);
  for (const schema of [
    "pulsechain-external-observer-r12f-update-inventory@1.0.0",
    "pulsechain-external-observer-r12f-source-manifest@1.0.0",
    "pulsechain-external-observer-r12f-update-expectations@1.0.0",
  ]) assert.ok(validator.includes(schema));
  assert.match(builder, /schema_version: INVENTORY_SCHEMA/);
  assert.match(builder, /schema_version: SOURCE_MANIFEST_SCHEMA/);
  assert.match(builder, /schema_version: DEPLOYMENT_EXPECTATIONS_SCHEMA/);
  assert.ok(script.includes('$inventory.schema_version -cne "pulsechain-external-observer-r12f-update-inventory@1.0.0"'));
  assert.ok(script.includes('$source.schema_version -cne "pulsechain-external-observer-r12f-source-manifest@1.0.0"'));
  assert.ok(script.includes('$expectations.schema_version -cne "pulsechain-external-observer-r12f-update-expectations@1.0.0"'));
  assert.doesNotMatch(builder, /schema_version: "pulsechain-external-observer-r12f1-(?:update-inventory|source-manifest)@1\.0\.0"/);
});

test("deployment parent is the exact lowercase R12F runtime authority", async () => {
  const script = await read("UPDATE_EXISTING_GATEWAY_R12F.ps1");
  assert.match(script, /\$expectations\.source\.parent -cne \$ExpectedR12FSourceParent/);
  assert.doesNotMatch(script, /\$expectations\.source\.parent -(?:c)?ne \$ExpectedR12DSourceCommit/);
  assert.match(script, /\$expectations\.source\.parent -cnotmatch "\^\[0-9a-f\]\{40\}\$"/);
  assert.match(script, /\$source\.source\.commit -cnotmatch "\^\[0-9a-f\]\{40\}\$"/);
});

test("R12F2E builder preserves R12F2D as direct predecessor and consumes the exact R12F1 bundle", async () => {
  const builder = await read("BUILD_R12F_UPDATE_BUNDLE.mjs");
  for (const value of [
    "external-observer-grok-mcp-r12f2e-harness-release-binding-repair-20260829",
    "9a30f43f90096f2cecb99dbe217c155eaf4b9633",
    "3ca2102d8657f1ab6884f4bf8597170776b25f9c",
    "94fb48e8ee4edbe0e48bbbdd71b235c788f8ce8a",
    "748da99a2935d394d34cbc71d8589cedfda18c87",
    "e724d72adbeae653695d3198353d35ba173884f9",
    "b185d749737f83027d3a9573417e4a18cea1d61f",
    "d6db80436ab82a061161be99c53179d481eabfff",
    "a750a7da63ca1adbea3fe606c12c80bb9caebe3d",
    "f535c273c264f2c953ccd925a1d20c3f218c95a4",
    "2e9df9f68850ca588e4a4749db100ec760e57d7c",
    "75e3650f8e7f17af0ec2b2f312b920e15f96eb79",
    "ebef6c42a5eca2ad30669cf856e669a19e10edf9",
    "ec70832c69f847ea413666de095ce3d56534ea28",
    "PulseChain_External_Grok_Observer_Gateway_Update_Bundle_R12F1_20260828T183733Z.zip",
    "1b9b03d52dd346dd63addd100c1eadebb4537293560f106a4f2018af1567088d",
  ]) assert.ok(builder.includes(value));
  assert.match(builder, /Gateway_Update_Bundle_R12F2E_/);
  assert.match(builder, /CURRENT_RELEASE_ID = "R12F2E"/);
  assert.match(builder, /renderCurrentReleaseIdentity/);
  assert.match(builder, /renderR12F2EUpdateScript/);
  assert.match(builder, /ExpectedR12F2CPredecessorCommit/);
  assert.match(builder, /ExpectedR12F2DPredecessorCommit/);
  assert.match(builder, /r12f2e_bundle_source\.parent -cne \$ExpectedR12F2DPredecessorCommit/);
  assert.match(builder, /runtime_changed_file_count: 0/);
});

test("synthetic secret fixtures are assembled at runtime and governed source contains no complete credential pattern", async () => {
  const repositoryOrBundleRoot = sourceLayer ? dirname(operatorDirectory) : operatorDirectory;
  const governedPaths = sourceLayer
    ? [
      "external_observer_grok_mcp_operator/BUILD_R12F_UPDATE_BUNDLE.mjs",
      "external_observer_grok_mcp_gateway/tests/gateway.test.mjs",
      "external_observer_grok_mcp_gateway/tests/control-room-read-resilience.test.mjs",
      "external_observer_grok_mcp_operator/tests/node-verifier.test.mjs",
    ]
    : [
      "BUILD_R12F_UPDATE_BUNDLE.mjs",
      "external_observer_grok_mcp_gateway/tests/gateway.test.mjs",
      "external_observer_grok_mcp_gateway/tests/control-room-read-resilience.test.mjs",
      "operator-tests/node-verifier.test.mjs",
    ];
  const patterns = [
    /\bgh[opsu]_[A-Za-z0-9]{20,}\b/u,
    /\bgithub_pat_[A-Za-z0-9_]{20,}\b/u,
    /\bBearer\s+[A-Za-z0-9._~+/-]{20,}\b/iu,
  ];
  const assembledFixtures = [
    ["gh", "p_", "abcdefghijklmnopqrstuvwxyz", "1234567890"].join(""),
    ["Bea", "rer secret-value-", "abcdefghijklmnopqrstuvwxyz", " token=private-value"].join(""),
    ["Authorization: Bea", "rer not-the-current-", "governed-credential"].join(""),
  ];
  for (const fixture of assembledFixtures) assert.ok(patterns.some((pattern) => pattern.test(fixture)));
  for (const path of governedPaths) {
    const source = await readFile(join(repositoryOrBundleRoot, path), "utf8");
    for (const pattern of patterns) assert.doesNotMatch(source, pattern, `complete synthetic credential pattern remains in ${path}`);
  }
  const builder = await read("BUILD_R12F_UPDATE_BUNDLE.mjs");
  assert.doesNotMatch(builder, /text\.replaceAll\([^\n]*GOVERNED_SYNTHETIC/u);
});

test("future Windows preflight runs every packaged operator test", async () => {
  const script = await read("UPDATE_EXISTING_GATEWAY_R12F.ps1");
  assert.match(script, /Get-ChildItem[^\n]*operator-tests/);
  assert.match(script, /-Filter "\*\.test\.mjs"/);
  assert.match(script, /-File -Recurse -Force/);
  assert.match(script, /Sort-Object -Property FullName/);
  assert.match(script, /\$operatorTestArguments = @\("--test"\) \+ \$operatorTestPaths/);
  assert.doesNotMatch(script, /\$verifierTestPath/);
});
