# R12F separately authorized rollback

Rollback is not part of the normal R12F update and must never run automatically. It is allowed only after production traffic changed, the governed verifier recorded `release_critical: true`, and a separate Windows rollback prompt explicitly authorizes restoration of the exact prior Version.

Do not roll back for an ordinary verification failure or for a bounded Control Room outage classified as `CONTROL_ROOM_UPSTREAM_UNAVAILABLE`. Those cases preserve the deployed R12F Version and report the blocker.

## Fixed target and prerequisites

- Worker: `pulsechain-external-observer-grok-mcp`
- Account: `dade45b2875ee5e98c74b5d06528cd9c`
- Exact rollback Version: `e32f2b34-a572-404e-b969-44c0bf2c9088`
- R12F source: `e724d72adbeae653695d3198353d35ba173884f9` / `b185d749737f83027d3a9573417e4a18cea1d61f`

Before a separately authorized rollback, keep the exclusive Worker change freeze and read the current deployment, traffic allocation, variables, exact five secret bindings, workers.dev route, preview state, compatibility contract, and finalized vault. Require the release-critical report and preserve the R12F Version/deployment receipt. Abort on any identity, binding, vault, route, or concurrent-change mismatch.

After those gates pass, use pinned Wrangler 4.92.0 from this validated bundle and create one deployment that assigns exactly 100% to the fixed prior Version:

```powershell
npx --no-install wrangler versions deploy 'e32f2b34-a572-404e-b969-44c0bf2c9088@100' `
  --config .\external_observer_grok_mcp_gateway\wrangler.toml `
  --name 'pulsechain-external-observer-grok-mcp' `
  --message 'Separately authorized R12F release-critical rollback to e32f2b34-a572-404e-b969-44c0bf2c9088' `
  --yes
```

This command creates another deployment; it does not erase or conceal the R12F Version or its deployment. Do not use `wrangler rollback`, an implicit “latest” target, or a mutable branch reference. Do not rerun an ambiguous command response.

Read back the new rollback deployment immediately and require the exact target at 100%, the same two variables, exact five secret bindings, unchanged route and preview state, unchanged compatibility contract, and a byte/DACL-identical finalized vault. Record the rollback deployment ID separately. Perform no secret, vault, GitHub, Control Room, observer-runtime, D1, R2, specialist, Signals, portfolio, wallet, order, or execution mutation.
