import { createHash } from "node:crypto";

const CONNECTORS = Object.freeze({
  "grok-x-protocol": {
    observationId: "grok-x-protocol-r12c-disabled",
    target: "signals-platform",
  },
  "grok-infrastructure-incidents": {
    observationId: "grok-infrastructure-incidents-r12c-disabled",
    target: "validator-flows",
  },
  "grok-market-liquidity": {
    observationId: "grok-market-liquidity-r12c-disabled",
    target: "investor-intelligence",
  },
  "grok-identity-evidence": {
    observationId: "grok-identity-evidence-r12c-disabled",
    target: "identity-attribution",
  },
  "grok-red-team": {
    observationId: "grok-red-team-r12c-disabled",
    target: "signals-platform",
  },
});

function canonicalJson(value) {
  if (Array.isArray(value)) return "[" + value.map(canonicalJson).join(",") + "]";
  if (value && typeof value === "object") {
    return "{" + Object.keys(value).sort().map((key) => JSON.stringify(key) + ":" + canonicalJson(value[key])).join(",") + "}";
  }
  return JSON.stringify(value);
}

const observerId = process.argv[2];
const binding = CONNECTORS[observerId];
if (!binding || process.argv.length !== 3) {
  process.stderr.write("One registered observer ID is required.\n");
  process.exit(2);
}

const args = {
  schema_version: "pulsechain-external-observation@1.0.0",
  observation_id: binding.observationId,
  generated_at_utc: "2026-08-27T20:00:00Z",
  observed_window: {
    from_utc: "2026-08-27T19:55:00Z",
    to_utc: "2026-08-27T20:00:00Z",
  },
  source_class: "PUBLIC_SECONDARY_SOURCE",
  source_records: [{
    url: "https://example.com/synthetic-r12c-disabled",
    source_id: "synthetic-r12c-disabled-source",
    author_or_domain: "example.com",
    published_at_utc: null,
    retrieved_at_utc: "2026-08-27T20:00:00Z",
    content_sha256: "sha256:" + "1".repeat(64),
    primary_source: false,
    authenticated_source: false,
  }],
  claim_summary: "SYNTHETIC_CANARY — INFRASTRUCTURE ONLY. Invented disabled-mode validation payload.",
  what_changed: "Invented test bytes exercised validation only.",
  why_material: "Proves disabled remote MCP validation without publication.",
  materiality: "HIGH",
  confidence: "HIGH",
  evidence_state: "PROVISIONAL_EXTERNAL_SIGNAL",
  target_workstreams: [binding.target],
  related_assets: [],
  related_addresses: [],
  related_contracts: [],
  related_transactions: [],
  related_update_ids: [],
  specialist_questions: ["Does this synthetic payload remain nonactionable?"],
  prohibited_inferences: ["No real-world claim may be inferred."],
  duplicate_check: {
    checked_observation_ids: [],
    duplicate_of: null,
    canonical_duplicate_key: "sha256:" + "3".repeat(64),
  },
  recheck_at_utc: null,
  adjudication_state: "PENDING_SPECIALIST_REVIEW",
  synthetic_canary: true,
  public_safe: true,
  raw_sensitive_material_included: false,
};

const identity = { ...args, observer_id: observerId };
args.content_sha256 = "sha256:" + createHash("sha256").update(canonicalJson(identity)).digest("hex");
process.stdout.write(JSON.stringify(args));
