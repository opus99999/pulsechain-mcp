#Requires -Version 7.4

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [ValidatePattern("^https://pulsechain-external-observer-grok-mcp\.[a-z0-9-]+\.workers\.dev/?$")]
    [string]$WorkerOrigin
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$VerbosePreference = "SilentlyContinue"
$DebugPreference = "SilentlyContinue"
$InformationPreference = "SilentlyContinue"

$BundleRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$GatewayDirectory = Join-Path $BundleRoot "external_observer_grok_mcp_gateway"
. (Join-Path $BundleRoot "OPERATOR_COMMON.ps1")
Assert-WindowsOperator

$ControlRoomOrigin = "https://pulsechain-research-control-room.brohexphiat.chatgpt.site"
$ExpectedRuntimeHead = "f7c5427d505757fe101ea20ef1c402946152f3aa"
$ExpectedSnapshot = "sha256:4f633b3ee0446d7ebac272978bea106aae5ab9e55c9dd8b1ae7e8a673d4df18c"
$ExpectedCommonTools = @(
    "read_external_observer_bootstrap",
    "read_workstream_bootstrap",
    "read_external_observation"
)
$script:ApiGitHubRequestCount = 0
$script:ControlRoomReadCount = 0
$script:McpRequestCount = 0
$report = $null
$verificationFailure = $null

function Invoke-PublicJson {
    param([Parameter(Mandatory = $true)][string]$Path)
    if ($Path -notmatch "^/api/v1/(external-observers|trusted-team/bootstrap/)") {
        throw "A public verification route is not allowlisted."
    }
    $script:ControlRoomReadCount += 1
    try {
        $response = Invoke-WebRequest -Uri ($ControlRoomOrigin + $Path) -Method Get -Headers @{ Accept = "application/json" } -TimeoutSec 30
    }
    catch {
        throw "A required Control Room read failed."
    }
    if ([int]$response.StatusCode -ne 200) {
        throw "A required Control Room read did not return HTTP 200."
    }
    $response.Content | ConvertFrom-Json -Depth 50
}

function Test-UnavailablePermanentPage {
    param([Parameter(Mandatory = $true)][psobject]$Definition)
    $uri = "$ControlRoomOrigin/research/external-observers/$($Definition.observer_id)/observations/$($Definition.observation_id)"
    try {
        $response = Invoke-WebRequest -Uri $uri -Method Get -Headers @{ Accept = "text/html" } -SkipHttpErrorCheck -TimeoutSec 30
    }
    catch {
        throw "A permanent-page absence check failed."
    }
    if ($response.Content -notmatch "EXTERNAL_OBSERVATION_NOT_FOUND") {
        throw "A disabled verification observation has a permanent page."
    }
    [pscustomobject][ordered]@{
        observer_id = $Definition.observer_id
        observation_id = $Definition.observation_id
        unavailable = $true
    }
}

function Get-PublicState {
    $root = Invoke-PublicJson -Path "/api/v1/external-observers"
    $feed = Invoke-PublicJson -Path "/api/v1/external-observers/observations"
    if (
        $root.ledger.repository_head -ne $ExpectedRuntimeHead -or
        $root.ledger.fallback_used -ne $false -or
        $root.ledger.observer_snapshot_sha256 -ne $ExpectedSnapshot
    ) {
        throw "The immutable observer snapshot differs from the R12C entry state."
    }

    $definitions = @(Get-ConnectorDefinitions)
    $observerProjection = @(
        $root.observers |
            ForEach-Object {
                [pscustomobject][ordered]@{
                    observer_id = [string]$_.observer_id
                    latest_observation_id = $_.latest_observation_id
                    observation_count = [int]$_.observation_count
                    publication_state = [string]$_.publication_state
                }
            } |
            Sort-Object observer_id
    )
    if (
        $observerProjection.Count -ne 5 -or
        @($observerProjection | Where-Object { $null -ne $_.latest_observation_id -or $_.observation_count -ne 0 -or $_.publication_state -ne "PENDING_SPECIALIST_REVIEW" }).Count -ne 0
    ) {
        throw "The observer namespace is not the expected initialized empty state."
    }

    $observerBootstraps = @()
    foreach ($definition in $definitions) {
        $bootstrap = Invoke-PublicJson -Path ("/api/v1/external-observers/bootstrap/" + $definition.observer_id)
        if (
            $bootstrap.observer_id -ne $definition.observer_id -or
            $bootstrap.ledger.repository_head -ne $ExpectedRuntimeHead -or
            $null -ne $bootstrap.current_observer_latest_id
        ) {
            throw "An observer bootstrap differs from the initialized empty state."
        }
        $observerBootstraps += [pscustomobject][ordered]@{
            observer_id = $definition.observer_id
            latest_observation_id = $bootstrap.current_observer_latest_id
            repository_head = [string]$bootstrap.ledger.repository_head
        }
    }

    $specialists = @()
    foreach ($workstreamId in @("signals-platform", "validator-flows", "identity-attribution", "investor-intelligence")) {
        $bootstrap = Invoke-PublicJson -Path ("/api/v1/trusted-team/bootstrap/" + $workstreamId)
        $inbox = $bootstrap.external_observer_inbox
        if (
            $bootstrap.requested_workstream_id -ne $workstreamId -or
            $inbox.classification -ne "PROVISIONAL_EXTERNAL_OBSERVER_INPUT" -or
            [int]$inbox.high_critical_count -ne 0 -or
            @($inbox.high_critical_pending).Count -ne 0
        ) {
            throw "A specialist bootstrap observer inbox is not empty and provisional."
        }
        $specialists += [pscustomobject][ordered]@{
            workstream_id = $workstreamId
            latest_update_id = [string]$bootstrap.workstream.latest_update.update_id
            history_count = @($bootstrap.workstream.history).Count
            artifact_sha256 = [string]$bootstrap.workstream.latest_update.artifact.sha256
            manifest_sha256 = [string]$bootstrap.workstream.latest_update.manifest_sha256
            project_state_update_id = [string]$bootstrap.workstream.latest_update.project_state.update_id
            high_critical_count = [int]$inbox.high_critical_count
            high_critical_pending_count = @($inbox.high_critical_pending).Count
        }
    }

    [pscustomobject][ordered]@{
        public_runtime_main = [string]$root.ledger.repository_head
        snapshot_sha256 = [string]$root.ledger.observer_snapshot_sha256
        observer_projection = $observerProjection
        observer_bootstraps = @($observerBootstraps | Sort-Object observer_id)
        observation_ids = @($feed.observations | ForEach-Object { $_.observation_id } | Sort-Object)
        specialists = @($specialists | Sort-Object workstream_id)
        unavailable_pages = @($definitions | ForEach-Object { Test-UnavailablePermanentPage -Definition $_ })
    }
}

function Invoke-Mcp {
    param(
        [Parameter(Mandatory = $true)][string]$Uri,
        [Parameter(Mandatory = $true)][string]$Token,
        [Parameter(Mandatory = $true)][psobject]$Message
    )
    $script:McpRequestCount += 1
    $body = $Message | ConvertTo-Json -Depth 80 -Compress
    try {
        $response = Invoke-WebRequest -Uri $Uri -Method Post -Headers @{
            Authorization = "Bearer $Token"
            Accept = "application/json, text/event-stream"
            "Content-Type" = "application/json"
        } -Body $body -SkipHttpErrorCheck -TimeoutSec 30
    }
    catch {
        throw "A remote MCP request failed."
    }
    $parsed = $null
    if (-not [string]::IsNullOrWhiteSpace([string]$response.Content)) {
        try {
            $parsed = $response.Content | ConvertFrom-Json -Depth 80
        }
        catch {
            throw "A remote MCP response was not valid JSON."
        }
    }
    [pscustomobject]@{
        status = [int]$response.StatusCode
        body = $parsed
        fingerprint = [string]$response.Headers["X-PulseChain-Tool-Discovery-Fingerprint"]
    }
}

function New-RpcMessage {
    param(
        [Parameter(Mandatory = $true)][string]$Id,
        [Parameter(Mandatory = $true)][string]$Method,
        [Parameter(Mandatory = $false)][psobject]$Parameters
    )
    $message = [ordered]@{ jsonrpc = "2.0"; id = $Id; method = $Method }
    if ($PSBoundParameters.ContainsKey("Parameters")) {
        $message.params = $Parameters
    }
    [pscustomobject]$message
}

try {
    if ($null -eq (Get-Command node -ErrorAction SilentlyContinue) -or $null -eq (Get-Command npm -ErrorAction SilentlyContinue)) {
        throw "Node.js and npm are required for the local deterministic proof."
    }
    $testOutput = @(& npm --prefix $GatewayDirectory test 2>&1) -join [Environment]::NewLine
    if ($LASTEXITCODE -ne 0 -or $testOutput -notmatch "(?m)^[^\r\n]*pass 18\s*$" -or $testOutput -notmatch "(?m)^[^\r\n]*fail 0\s*$") {
        throw "The R12C gateway test gate did not pass 18 of 18 tests."
    }
    $testOutput = $null

    $vault = Read-ConnectorVault -RequireOrigin
    if ([string]::IsNullOrWhiteSpace($WorkerOrigin)) {
        $WorkerOrigin = [string]$vault.worker_origin
    }
    if ($WorkerOrigin.TrimEnd("/") -cne ([string]$vault.worker_origin).TrimEnd("/")) {
        throw "The requested Worker origin does not match the local vault."
    }
    $WorkerOrigin = $WorkerOrigin.TrimEnd("/")
    if ($vault.publication_mode -ne "DISABLED") {
        throw "The local vault does not attest disabled publication mode."
    }

    $before = Get-PublicState
    if (
        $before.public_runtime_main -ne $ExpectedRuntimeHead -or
        $before.snapshot_sha256 -ne $ExpectedSnapshot -or
        @($before.observation_ids).Count -ne 0
    ) {
        throw "The disabled-mode entry state differs from the verified R12C state."
    }

    $definitions = @(Get-ConnectorDefinitions)
    $connectorResults = @()
    foreach ($definition in $definitions) {
        $token = Get-ConnectorToken -Vault $vault -ObserverId $definition.observer_id
        try {
            $connectorUri = $WorkerOrigin + $definition.path
            $initialize = Invoke-Mcp -Uri $connectorUri -Token $token -Message (New-RpcMessage -Id ("initialize-" + $definition.observer_id) -Method "initialize" -Parameters ([pscustomobject]@{
                protocolVersion = "2025-06-18"
                capabilities = [pscustomobject]@{}
                clientInfo = [pscustomobject]@{ name = "pulsechain-r12c-verifier"; version = "1.0.0" }
            }))
            $readiness = $initialize.body.result.publication
            if (
                $initialize.status -ne 200 -or
                $initialize.body.result.protocolVersion -ne "2025-06-18" -or
                $initialize.body.result.serverInfo.name -ne "pulsechain-$($definition.observer_id)-mcp" -or
                $readiness.publication_mode -ne "DISABLED" -or
                $readiness.publication_ready -ne $false -or
                $readiness.github_publication_transport -ne "DEFERRED_WHILE_DISABLED" -or
                $null -ne $readiness.credential_method -or
                $readiness.automatic_promotion -ne $false
            ) {
                throw "Streamable HTTP initialization or disabled readiness failed."
            }

            $discovery = Invoke-Mcp -Uri $connectorUri -Token $token -Message (New-RpcMessage -Id ("tools-" + $definition.observer_id) -Method "tools/list")
            $tools = @($discovery.body.result.tools)
            $toolNames = @($tools | ForEach-Object { $_.name })
            $expectedNames = @($definition.publish_tool) + $ExpectedCommonTools
            if (
                $discovery.status -ne 200 -or
                $discovery.fingerprint -cne $definition.fingerprint -or
                ($toolNames -join [Environment]::NewLine) -cne ($expectedNames -join [Environment]::NewLine)
            ) {
                throw "Connector tool discovery is invalid."
            }
            $publishTools = @($tools | Where-Object { $_.name -like "publish_external_observation_*" })
            if ($publishTools.Count -ne 1 -or $publishTools[0].name -ne $definition.publish_tool) {
                throw "A connector exposed a foreign publish tool."
            }
            $schemaLower = ($publishTools[0].inputSchema | ConvertTo-Json -Depth 80 -Compress).ToLowerInvariant()
            foreach ($forbidden in @("observer_id", "repository", "workflow", "ledger path", "github credential", "connector credential", "publication mode")) {
                if ($schemaLower.Contains($forbidden)) {
                    throw "A server-selected control is model-visible."
                }
            }

            $foreignAuthPass = 0
            foreach ($foreign in @($definitions | Where-Object { $_.observer_id -ne $definition.observer_id })) {
                $foreignResponse = Invoke-Mcp -Uri ($WorkerOrigin + $foreign.path) -Token $token -Message (New-RpcMessage -Id ("foreign-" + $definition.observer_id + "-" + $foreign.observer_id) -Method "tools/list")
                if ($foreignResponse.status -ne 401) {
                    throw "A connector token authenticated to a foreign observer."
                }
                $foreignAuthPass += 1
            }

            $observerRead = Invoke-Mcp -Uri $connectorUri -Token $token -Message (New-RpcMessage -Id ("observer-read-" + $definition.observer_id) -Method "tools/call" -Parameters ([pscustomobject]@{
                name = "read_external_observer_bootstrap"
                arguments = [pscustomobject]@{}
            }))
            $workstreamRead = Invoke-Mcp -Uri $connectorUri -Token $token -Message (New-RpcMessage -Id ("workstream-read-" + $definition.observer_id) -Method "tools/call" -Parameters ([pscustomobject]@{
                name = "read_workstream_bootstrap"
                arguments = [pscustomobject]@{ workstream_id = $definition.target_workstream }
            }))
            if (
                $observerRead.body.result.structuredContent.observer_id -ne $definition.observer_id -or
                $workstreamRead.body.result.structuredContent.requested_workstream_id -ne $definition.target_workstream
            ) {
                throw "A common read tool returned a mismatched identity."
            }

            $payloadText = @(& node (Join-Path $BundleRoot "OPERATOR_BUILD_DISABLED_PAYLOAD.mjs") $definition.observer_id 2>$null) -join ""
            if ($LASTEXITCODE -ne 0) {
                throw "The governed disabled payload could not be constructed."
            }
            $payload = $payloadText | ConvertFrom-Json -Depth 80
            if ($payload.PSObject.Properties.Name -contains "observer_id") {
                throw "The disabled payload contains a model-selected observer ID."
            }
            $disabled = Invoke-Mcp -Uri $connectorUri -Token $token -Message (New-RpcMessage -Id ("disabled-" + $definition.observer_id) -Method "tools/call" -Parameters ([pscustomobject]@{
                name = $definition.publish_tool
                arguments = $payload
            }))
            $result = $disabled.body.result
            $contentResult = $result.content[0].text | ConvertFrom-Json -Depth 20
            if (
                $disabled.status -ne 200 -or
                ($result.PSObject.Properties.Name -contains "isError") -or
                $result.structuredContent.accepted -ne $false -or
                $result.structuredContent.error_code -ne "PUBLICATION_MODE_DISABLED" -or
                $null -ne $result.structuredContent.issue_number -or
                $null -ne $result.structuredContent.workflow_run_id -or
                $null -ne $result.structuredContent.observation_id -or
                $null -ne $result.structuredContent.publication_commit -or
                $null -ne $result.structuredContent.permanent_url -or
                $null -ne $result.structuredContent.manifest_sha256 -or
                ($contentResult | ConvertTo-Json -Compress) -cne ($result.structuredContent | ConvertTo-Json -Compress)
            ) {
                throw "A disabled publication call returned an invalid receipt."
            }

            $connectorResults += [pscustomobject][ordered]@{
                observer_id = $definition.observer_id
                connector_url = $connectorUri
                initialize = "PASS"
                publication_ready = $false
                github_publication_transport = "DEFERRED_WHILE_DISABLED"
                tools_list = "PASS"
                discovery_fingerprint = $definition.fingerprint
                fixed_publish_tool = $definition.publish_tool
                common_read_tools = $ExpectedCommonTools
                common_read_calls = 2
                foreign_authentication_rejections = $foreignAuthPass
                observer_id_model_visible = $false
                disabled_write_result = "PUBLICATION_MODE_DISABLED"
                issue_number = $null
                workflow_run_id = $null
                observation_id = $null
                publication_commit = $null
                permanent_url = $null
                manifest_sha256 = $null
            }
        }
        finally {
            $token = $null
        }
    }

    $after = Get-PublicState
    if (($before | ConvertTo-Json -Depth 50 -Compress) -cne ($after | ConvertTo-Json -Depth 50 -Compress)) {
        throw "Disabled connector calls changed public or repository state."
    }
    if ($script:ApiGitHubRequestCount -ne 0) {
        throw "The disabled verifier made a GitHub API request."
    }

    $report = [pscustomobject][ordered]@{
        schema_version = "pulsechain-r12c-local-disabled-mode-verification@1.0.0"
        generated_at_utc = [DateTime]::UtcNow.ToString("o")
        result = "PASS"
        worker_name = "pulsechain-external-observer-grok-mcp"
        worker_origin = $WorkerOrigin
        worker_version_id = $vault.current_version_id
        account_id = $vault.account_id
        source_branch = $vault.source_branch
        source_commit = $vault.source_commit
        source_tree = $vault.source_tree
        publication_mode = "DISABLED"
        publication_ready = $false
        github_publication_transport = "DEFERRED_WHILE_DISABLED"
        streamable_http_protocol = "2025-06-18"
        local_gateway_tests = [pscustomobject]@{ passed = 18; failed = 0 }
        github_transport_constructor_count = 0
        api_github_request_count = $script:ApiGitHubRequestCount
        control_room_public_read_count = $script:ControlRoomReadCount
        mcp_request_count = $script:McpRequestCount
        connectors = $connectorResults
        nonmutation = [pscustomobject][ordered]@{
            proof_basis = "R12C_DETERMINISTIC_TEST_GATE_PLUS_DISABLED_RECEIPTS_PLUS_STABLE_PUBLIC_STATE"
            public_runtime_main_before = $before.public_runtime_main
            public_runtime_main_after = $after.public_runtime_main
            github_issue_delta = 0
            workflow_run_delta = 0
            observation_delta = 0
            repository_commit_delta = 0
            permanent_page_delta = 0
            latest_pointer_delta = 0
            index_delta = 0
            specialist_delta = 0
            snapshot_sha256 = $before.snapshot_sha256
        }
        secrets_in_report = 0
    }
}
catch {
    $verificationFailure = "R12C disabled-mode verification failed. No secret value was printed."
    $report = [pscustomobject][ordered]@{
        schema_version = "pulsechain-r12c-local-disabled-mode-verification@1.0.0"
        generated_at_utc = [DateTime]::UtcNow.ToString("o")
        result = "FAIL"
        publication_mode = "DISABLED"
        publication_ready = $false
        github_publication_transport = "DEFERRED_WHILE_DISABLED"
        api_github_request_count = $script:ApiGitHubRequestCount
        error = "VERIFICATION_GATE_FAILED"
        secrets_in_report = 0
    }
}
finally {
    if ($null -ne $report) {
        Write-PrivateTextFile -Path (Get-VerificationReportPath) -Text (($report | ConvertTo-Json -Depth 60) + [Environment]::NewLine)
    }
}

if ($null -ne $verificationFailure) {
    throw $verificationFailure
}
Write-Output "VERIFICATION_STATUS=PASS"
