#Requires -Version 7.4

[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$VerbosePreference = "SilentlyContinue"
$DebugPreference = "SilentlyContinue"
$InformationPreference = "SilentlyContinue"

$BundleRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$commonPath = Join-Path $BundleRoot "OPERATOR_COMMON.ps1"
$deployPath = Join-Path $BundleRoot "DEPLOY_GATEWAY.ps1"
$selfPath = [IO.Path]::GetFullPath($PSCommandPath)
$results = [Collections.Generic.List[object]]::new()
$state = [ordered]@{
    root = $null
    original_local_app_data = $env:LOCALAPPDATA
    source_hashes = [ordered]@{}
    tokens = [Collections.Generic.List[string]]::new()
    ciphertexts = [Collections.Generic.List[string]]::new()
    vault = $null
    vault_path = $null
    private_file = $null
    intentional_failure_path = $null
    temporary_paths = [Collections.Generic.List[string]]::new()
}

function Add-TestResult {
    param([string]$Id, [bool]$Passed, [AllowNull()][string]$ExceptionClass = $null)
    [void]$results.Add([pscustomobject][ordered]@{
        id = $Id
        passed = $Passed
        exception_class = $ExceptionClass
    })
}

function Invoke-AclCase {
    param([string]$Id, [scriptblock]$Body)
    try {
        $null = & $Body
        Add-TestResult -Id $Id -Passed $true
    }
    catch {
        Add-TestResult -Id $Id -Passed $false -ExceptionClass $_.Exception.GetType().FullName
    }
}

function Assert-Condition {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw [InvalidOperationException]::new($Message) }
}

function New-SyntheticConnectorToken {
    [byte[]]$bytes = [byte[]]::new(32)
    [Security.Cryptography.RandomNumberGenerator]::Fill($bytes)
    try {
        [Convert]::ToBase64String($bytes).TrimEnd("=").Replace("+", "-").Replace("/", "_")
    }
    finally {
        [Array]::Clear($bytes, 0, $bytes.Length)
    }
}

function Get-ExplicitRules {
    param([string]$Path)
    $info = [IO.FileInfo]::new([IO.Path]::GetFullPath($Path))
    $security = [IO.FileSystemAclExtensions]::GetAccessControl(
        $info,
        [Security.AccessControl.AccessControlSections]::Access
    )
    @($security.GetAccessRules($true, $false, [Security.Principal.SecurityIdentifier]))
}

if (-not $IsWindows) {
    Add-TestResult -Id "ACL-01" -Passed $false -ExceptionClass "System.PlatformNotSupportedException"
}
elseif ($PSVersionTable.PSVersion -lt [Version]"7.4.0") {
    Add-TestResult -Id "ACL-01" -Passed $false -ExceptionClass "System.NotSupportedException"
}
else {
    . $commonPath
    try {
        $sumPath = Join-Path $BundleRoot "SHA256SUMS.txt"
        $expectedPaths = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
        foreach ($line in Get-Content -LiteralPath $sumPath -Encoding utf8) {
            if ($line -notmatch "^([0-9a-f]{64})  ([A-Za-z0-9._/-]+)$") {
                throw "SHA256SUMS contains an invalid line."
            }
            $expectedHash = $Matches[1]
            $relativePath = $Matches[2]
            if (-not $expectedPaths.Add($relativePath)) {
                throw "SHA256SUMS contains a duplicate path."
            }
            if ([IO.Path]::IsPathRooted($relativePath) -or @($relativePath.Split("/") | Where-Object { $_ -in @("", ".", "..") }).Count -ne 0) {
                throw "SHA256SUMS contains an unsafe path."
            }
            $resolved = [IO.Path]::GetFullPath((Join-Path $BundleRoot $relativePath))
            $prefix = $BundleRoot.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
            if (-not $resolved.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
                throw "A governed path escaped the bundle root."
            }
            $state.source_hashes[$resolved] = $expectedHash
        }
        $actualPaths = @(
            Get-ChildItem -LiteralPath $BundleRoot -File -Recurse |
                ForEach-Object { [IO.Path]::GetRelativePath($BundleRoot, $_.FullName).Replace("\", "/") } |
                Where-Object { $_ -notin @("SHA256SUMS.txt", "ARTIFACT_INVENTORY.json") } |
                Sort-Object
        )
        if (($actualPaths -join [Environment]::NewLine) -cne (@($expectedPaths | Sort-Object) -join [Environment]::NewLine)) {
            throw "The governed source file set differs from SHA256SUMS."
        }
    }
    catch {
        Add-TestResult -Id "ACL-25" -Passed $false -ExceptionClass $_.Exception.GetType().FullName
    }

    try {
        Invoke-AclCase "ACL-01" {
            $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
            try {
                $principal = [Security.Principal.WindowsPrincipal]::new($identity)
                Assert-Condition (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) "Run the preflight as a normal non-elevated user."
            }
            finally { $identity.Dispose() }
            $source = [IO.File]::ReadAllText($commonPath) + [IO.File]::ReadAllText($deployPath)
            Assert-Condition ($source -notmatch "(?i)SeSecurityPrivilege|Set-Acl|Get-Acl|SetAuditRule|SetOwner|takeown") "A privileged descriptor operation is present."
        }

        Invoke-AclCase "ACL-02" {
            $state.root = Join-Path ([IO.Path]::GetTempPath()) ("PulseChain ACL Test " + [Guid]::NewGuid().ToString("N"))
            [void][IO.Directory]::CreateDirectory($state.root)
            Set-PrivateDirectoryAcl $state.root
            $state.private_file = Join-Path $state.root "synthetic-private.txt"
            [IO.File]::WriteAllText($state.private_file, "synthetic", [Text.UTF8Encoding]::new($false))
            Assert-Condition (Test-Path -LiteralPath $state.private_file -PathType Leaf) "Synthetic write failed."
        }

        Invoke-AclCase "ACL-03" {
            Set-PrivateFileAcl $state.private_file
            Assert-PrivateFileAcl $state.private_file
        }

        Invoke-AclCase "ACL-04" {
            $source = [IO.File]::ReadAllText($commonPath)
            Assert-Condition ($source -notmatch "(?i)AccessControlSections\]::Audit|SetAuditRule|AddAuditRule|GetAuditRules|\.Audit") "A SACL operation is present."
        }

        Invoke-AclCase "ACL-05" {
            $source = [IO.File]::ReadAllText($commonPath)
            Assert-Condition ($source -notmatch "(?i)SetOwner|AccessControlSections\]::Owner|\.Owner\s*=") "An owner operation is present."
        }

        Invoke-AclCase "ACL-06" {
            $info = [IO.FileInfo]::new($state.private_file)
            $security = [IO.FileSystemAclExtensions]::GetAccessControl($info, [Security.AccessControl.AccessControlSections]::Access)
            Assert-Condition $security.AreAccessRulesProtected "Inheritance remains enabled."
        }

        Invoke-AclCase "ACL-07" {
            $sid = Get-CurrentWindowsUserSid
            $rules = @(Get-ExplicitRules $state.private_file)
            $match = @($rules | Where-Object {
                $_.IdentityReference.Value -ceq $sid.Value -and
                $_.AccessControlType -eq [Security.AccessControl.AccessControlType]::Allow -and
                (($_.FileSystemRights -band [Security.AccessControl.FileSystemRights]::FullControl) -eq [Security.AccessControl.FileSystemRights]::FullControl)
            })
            Assert-Condition ($match.Count -eq 1) "Current-user FullControl is missing."
        }

        Invoke-AclCase "ACL-08" {
            $rules = @(Get-ExplicitRules $state.private_file)
            Assert-Condition (@($rules | Where-Object { $_.IdentityReference.Value -ceq "S-1-1-0" -and $_.AccessControlType -eq [Security.AccessControl.AccessControlType]::Allow }).Count -eq 0) "Everyone has explicit allow access."
        }

        Invoke-AclCase "ACL-09" {
            $rules = @(Get-ExplicitRules $state.private_file)
            Assert-Condition (@($rules | Where-Object { $_.IdentityReference.Value -ceq "S-1-5-32-545" -and $_.AccessControlType -eq [Security.AccessControl.AccessControlType]::Allow }).Count -eq 0) "Users has explicit allow access."
        }

        Invoke-AclCase "ACL-10" {
            $rules = @(Get-ExplicitRules $state.private_file)
            Assert-Condition (@($rules | Where-Object { $_.IdentityReference.Value -ceq "S-1-5-11" -and $_.AccessControlType -eq [Security.AccessControl.AccessControlType]::Allow }).Count -eq 0) "Authenticated Users has explicit allow access."
        }

        Invoke-AclCase "ACL-11" {
            Assert-Condition ([IO.File]::ReadAllText($state.private_file) -ceq "synthetic") "Read failed."
        }

        Invoke-AclCase "ACL-12" {
            [IO.File]::WriteAllText($state.private_file, "replacement", [Text.UTF8Encoding]::new($false))
            Assert-Condition ([IO.File]::ReadAllText($state.private_file) -ceq "replacement") "Replace failed."
        }

        Invoke-AclCase "ACL-13" {
            $probe = Join-Path $state.root "delete-probe.txt"
            [IO.File]::WriteAllText($probe, "delete", [Text.UTF8Encoding]::new($false))
            Set-PrivateFileAcl $probe
            [IO.File]::Delete($probe)
            Assert-Condition (-not (Test-Path -LiteralPath $probe)) "Delete failed."
        }

        Invoke-AclCase "ACL-14" {
            $token = New-SyntheticConnectorToken
            $state.tokens.Add($token)
            $ciphertext = Protect-ConnectorToken $token
            $state.ciphertexts.Add($ciphertext)
            $roundtrip = Unprotect-ConnectorToken $ciphertext
            Assert-Condition ($roundtrip -ceq $token) "DPAPI CurrentUser round trip failed."
            $roundtrip = $null
            $token = $null
            $ciphertext = $null
        }

        Invoke-AclCase "ACL-15" {
            while ($state.tokens.Count -lt 5) {
                $candidate = New-SyntheticConnectorToken
                if (-not $state.tokens.Contains($candidate)) { $state.tokens.Add($candidate) }
            }
            $vaultTokens = [ordered]@{}
            $definitions = @(Get-ConnectorDefinitions)
            for ($index = 0; $index -lt $definitions.Count; $index += 1) {
                $ciphertext = Protect-ConnectorToken $state.tokens[$index]
                $state.ciphertexts.Add($ciphertext)
                $vaultTokens[$definitions[$index].observer_id] = [ordered]@{
                    secret_label = $definitions[$index].token_label
                    ciphertext_base64 = $ciphertext
                }
            }
            $state.vault = [pscustomobject][ordered]@{
                schema_version = "pulsechain-external-observer-connector-vault@1.0.0"
                worker_name = "pulsechain-external-observer-grok-mcp"
                account_id = "00000000000000000000000000000000"
                worker_origin = $null
                prior_version_id = $null
                current_version_id = $null
                source_branch = "external-observer-grok-mcp-r12d-windows-acl-repair-20260828"
                source_commit = "ec70832c69f847ea413666de095ce3d56534ea28"
                source_tree = "35e17b896403d02d160f3a4d902ea2e66845799c"
                publication_mode = "DISABLED"
                created_at_utc = [DateTime]::UtcNow.ToString("o")
                deployed_at_utc = $null
                tokens = [pscustomobject]$vaultTokens
            }
            $serialized = ConvertTo-ConnectorVaultJson $state.vault
            Assert-Condition (-not [string]::IsNullOrWhiteSpace($serialized)) "Vault serialization failed."
            $serialized = $null
        }

        Invoke-AclCase "ACL-16" {
            $env:LOCALAPPDATA = Join-Path $state.root "Local App Data Ω"
            Write-ConnectorVault $state.vault
            $state.vault_path = Get-ConnectorVaultPath
            Assert-Condition (Test-Path -LiteralPath $state.vault_path -PathType Leaf) "Five-token vault write failed."
        }

        Invoke-AclCase "ACL-17" {
            Assert-PrivateDirectoryAcl (Split-Path -Parent $state.vault_path)
            Assert-PrivateFileAcl $state.vault_path
        }

        Invoke-AclCase "ACL-18" {
            $readVault = Read-ConnectorVault
            $definitions = @(Get-ConnectorDefinitions)
            for ($index = 0; $index -lt $definitions.Count; $index += 1) {
                $decrypted = Get-ConnectorToken -Vault $readVault -ObserverId $definitions[$index].observer_id
                Assert-Condition ($decrypted -ceq $state.tokens[$index]) "Synthetic vault decrypt failed."
                $decrypted = $null
            }
            $readVault = $null
        }

        Invoke-AclCase "ACL-19" {
            $failurePath = Join-Path $state.root "intentional-acl-failure.txt"
            $original = ${function:Set-PrivateFileAcl}
            try {
                Set-Item -LiteralPath Function:\Set-PrivateFileAcl -Value { throw [UnauthorizedAccessException]::new("synthetic ACL denial") }
                try {
                    Write-PrivateTextFile -Path $failurePath -Text "synthetic"
                    throw [InvalidOperationException]::new("Intentional ACL failure was not raised.")
                }
                catch {
                    Assert-Condition ($_.FullyQualifiedErrorId -match "^CONNECTOR_VAULT_ACL_HARDENING_FAILED") "ACL failure classification is incorrect."
                }
            }
            finally {
                Set-Item -LiteralPath Function:\Set-PrivateFileAcl -Value $original
            }
            $state.intentional_failure_path = $failurePath
        }

        Invoke-AclCase "ACL-20" {
            Assert-Condition (-not (Test-Path -LiteralPath $state.intentional_failure_path)) "Intentional ACL failure left a partial file."
        }

        Invoke-AclCase "ACL-23" {
            $path = Join-Path ([IO.Path]::GetTempPath()) ("PulseChain ACL Space " + [Guid]::NewGuid().ToString("N"))
            $state.temporary_paths.Add($path)
            try {
                [void][IO.Directory]::CreateDirectory($path)
                Set-PrivateDirectoryAcl $path
                $file = Join-Path $path "private file.txt"
                [IO.File]::WriteAllText($file, "synthetic", [Text.UTF8Encoding]::new($false))
                Set-PrivateFileAcl $file
                Assert-PrivateFileAcl $file
            }
            finally {
                if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force -Recurse }
            }
        }

        Invoke-AclCase "ACL-24" {
            $path = Join-Path ([IO.Path]::GetTempPath()) ("PulseChain ACL Ω " + [Guid]::NewGuid().ToString("N"))
            $state.temporary_paths.Add($path)
            try {
                [void][IO.Directory]::CreateDirectory($path)
                Set-PrivateDirectoryAcl $path
                $file = Join-Path $path "private-λ.txt"
                [IO.File]::WriteAllText($file, "synthetic", [Text.UTF8Encoding]::new($false))
                Set-PrivateFileAcl $file
                Assert-PrivateFileAcl $file
            }
            finally {
                if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force -Recurse }
            }
        }

        if (@($results | Where-Object { $_.id -ceq "ACL-25" }).Count -eq 0) {
            Invoke-AclCase "ACL-25" {
                foreach ($entry in $state.source_hashes.GetEnumerator()) {
                    $actual = (Get-FileHash -LiteralPath $entry.Key -Algorithm SHA256).Hash.ToLowerInvariant()
                    Assert-Condition ($actual -ceq $entry.Value) "A governed source file changed during testing."
                }
            }
        }

        Invoke-AclCase "ACL-22" {
            $env:LOCALAPPDATA = $state.original_local_app_data
            if ($null -ne $state.root -and (Test-Path -LiteralPath $state.root)) {
                Remove-Item -LiteralPath $state.root -Force -Recurse
            }
            Assert-Condition ($null -eq $state.root -or -not (Test-Path -LiteralPath $state.root)) "Primary temporary data remains."
            foreach ($path in $state.temporary_paths) {
                Assert-Condition (-not (Test-Path -LiteralPath $path)) "A path-specific temporary directory remains."
            }
        }

        Invoke-AclCase "ACL-21" {
            $prospectiveResults = @($results) + @([pscustomobject][ordered]@{ id = "ACL-21"; passed = $true; exception_class = $null })
            $prospectiveOrdered = @($prospectiveResults | Sort-Object id)
            $prospectivePassed = @($prospectiveOrdered | Where-Object { $_.passed }).Count
            $prospective = @($prospectiveOrdered | ForEach-Object {
                if ($_.passed) { "$($_.id) PASS" } else { "$($_.id) FAIL $($_.exception_class)" }
            }) + @("TOTAL=25 PASS=$prospectivePassed FAIL=$(25 - $prospectivePassed)")
            $prospectiveText = $prospective -join [Environment]::NewLine
            foreach ($value in @($state.tokens) + @($state.ciphertexts)) {
                if (-not [string]::IsNullOrEmpty($value)) {
                    Assert-Condition (-not $prospectiveText.Contains($value, [StringComparison]::Ordinal)) "Sensitive test material reached output."
                    $hash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($value))).ToLowerInvariant()
                    Assert-Condition (-not $prospectiveText.Contains($hash, [StringComparison]::OrdinalIgnoreCase)) "Sensitive hash reached output."
                    Assert-Condition (-not $prospectiveText.Contains($value.Substring(0, 8), [StringComparison]::Ordinal)) "Sensitive prefix reached output."
                    Assert-Condition (-not $prospectiveText.Contains($value.Substring($value.Length - 8), [StringComparison]::Ordinal)) "Sensitive suffix reached output."
                }
            }
            Assert-Condition ($prospectiveText -notmatch "(?i)authorization\s*:|github_pat_|gh[opsu]_") "Credential pattern reached output."
            $prospectiveText = $null
            $prospective = $null
        }
    }
    finally {
        $env:LOCALAPPDATA = $state.original_local_app_data
        if ($null -ne $state.root -and (Test-Path -LiteralPath $state.root)) {
            Remove-Item -LiteralPath $state.root -Force -Recurse -ErrorAction SilentlyContinue
        }
        foreach ($path in $state.temporary_paths) {
            if (Test-Path -LiteralPath $path) {
                Remove-Item -LiteralPath $path -Force -Recurse -ErrorAction SilentlyContinue
            }
        }
        for ($index = 0; $index -lt $state.tokens.Count; $index += 1) { $state.tokens[$index] = $null }
        for ($index = 0; $index -lt $state.ciphertexts.Count; $index += 1) { $state.ciphertexts[$index] = $null }
        $state.tokens.Clear()
        $state.ciphertexts.Clear()
    }
}

$expectedIds = 1..25 | ForEach-Object { "ACL-{0:d2}" -f $_ }
foreach ($id in $expectedIds) {
    if (@($results | Where-Object { $_.id -ceq $id }).Count -eq 0) {
        Add-TestResult -Id $id -Passed $false -ExceptionClass "System.InvalidOperationException"
    }
}

$ordered = @($results | Sort-Object id)
foreach ($result in $ordered) {
    if ($result.passed) { Write-Output "$($result.id) PASS" }
    else { Write-Output "$($result.id) FAIL $($result.exception_class)" }
}
$passed = @($ordered | Where-Object { $_.passed }).Count
$failed = 25 - $passed
Write-Output "TOTAL=25 PASS=$passed FAIL=$failed"
if ($failed -ne 0) { exit 1 }
