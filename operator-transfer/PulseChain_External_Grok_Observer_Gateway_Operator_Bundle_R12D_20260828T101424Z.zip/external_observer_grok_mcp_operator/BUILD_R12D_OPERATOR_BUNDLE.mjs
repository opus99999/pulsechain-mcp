#!/usr/bin/env node
import { createHash } from "node:crypto";
import {
  cpSync,
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  rmSync,
  statSync,
  unlinkSync,
  writeFileSync,
} from "node:fs";
import { basename, dirname, join, relative, resolve, sep } from "node:path";
import { spawnSync } from "node:child_process";

const SOURCE_BRANCH = "external-observer-grok-mcp-r12d-windows-acl-repair-20260828";
const R12C_COMMIT = "2a5e33681b5bf4eed5e422baafc6fee923017b86";
const R12C_TREE = "18818626f9e529be058130ccc0fda83aceca00b2";
const R12_PARENT = "e1a3ffae1e735ec3e7c310b147b2ee7d793e51c0";
const WORKER = "pulsechain-external-observer-grok-mcp";
const WRANGLER_INTEGRITY = "sha512-/DKpQHPxkuZbQsO9dFW2700VTD/4DSZMHjy92fO/frNoDRi/zQsFCAd2ONCV6TGqcUoXcP3D8Bo2gj/L4M0qQQ==";
const CONTROL_ROOM_ORIGIN = "https://pulsechain-research-control-room.brohexphiat.chatgpt.site";

const [baseArgument, outputArgument, expectedCommit, expectedTree] = process.argv.slice(2);
if (!baseArgument || !outputArgument || !expectedCommit || !expectedTree) {
  throw new Error("Usage: node BUILD_R12D_OPERATOR_BUNDLE.mjs <R12C-extracted-dir> <output.zip> <commit> <tree>");
}

function command(...args) {
  const result = spawnSync(args[0], args.slice(1), {
    cwd: repoRoot,
    encoding: "utf8",
    maxBuffer: 16 * 1024 * 1024,
  });
  if (result.status !== 0) {
    throw new Error(`Command failed: ${args.join(" ")}`);
  }
  return result.stdout.trim();
}

function sha256Bytes(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

function sha256File(path) {
  return sha256Bytes(readFileSync(path));
}

function listFiles(root) {
  const output = [];
  function visit(directory) {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const absolute = join(directory, entry.name);
      if (entry.isSymbolicLink()) throw new Error("Symbolic links are prohibited.");
      if (entry.isDirectory()) visit(absolute);
      else if (entry.isFile()) output.push(relative(root, absolute).split(sep).join("/"));
      else throw new Error("Unsupported bundle member.");
    }
  }
  visit(root);
  return output.sort();
}

function safePath(path) {
  return (
    path.length > 0 &&
    !path.startsWith("/") &&
    !path.includes("\\") &&
    !path.includes(":") &&
    path.split("/").every((segment) => segment !== "" && segment !== "." && segment !== "..")
  );
}

function writeJson(path, value) {
  writeFileSync(path, JSON.stringify(value, null, 2) + "\n", "utf8");
}

function replaceIdentity(text, bundleName = null) {
  let rendered = text
    .replaceAll("@@R12D_SOURCE_BRANCH@@", SOURCE_BRANCH)
    .replaceAll("@@R12D_SOURCE_COMMIT@@", expectedCommit)
    .replaceAll("@@R12D_SOURCE_TREE@@", expectedTree);
  if (bundleName) {
    rendered = rendered.replace(
      /PulseChain_External_Grok_Observer_Gateway_Operator_Bundle_R12C_[0-9TZ]+\.zip/g,
      bundleName,
    );
  }
  return rendered;
}

function replaceR13Identity(text, bundleName) {
  return text
    .replaceAll("external-observer-grok-mcp-r12c-disabled-credential-defer-20260827", SOURCE_BRANCH)
    .replaceAll(R12C_COMMIT, expectedCommit)
    .replaceAll(R12C_TREE, expectedTree)
    .replaceAll("R12C", "R12D")
    .replace(
      /PulseChain_External_Grok_Observer_Gateway_Operator_Bundle_R12D_[0-9TZ]+\.zip/g,
      bundleName,
    );
}

const scriptPath = resolve(process.argv[1]);
const operatorSourceDirectory = dirname(scriptPath);
const repoRoot = resolve(operatorSourceDirectory, "..");
const baseDirectory = resolve(baseArgument);
const outputZip = resolve(outputArgument);
const stage = outputZip + ".stage";
const generatedAt = new Date().toISOString();

if (!existsSync(baseDirectory)) throw new Error("The exact R12C extracted input is unavailable.");
if (command("git", "branch", "--show-current") !== SOURCE_BRANCH) throw new Error("Source branch mismatch.");
if (command("git", "rev-parse", "HEAD") !== expectedCommit) throw new Error("Source commit mismatch.");
if (command("git", "show", "-s", "--format=%T", "HEAD") !== expectedTree) throw new Error("Source tree mismatch.");
if (command("git", "show", "-s", "--format=%P", "HEAD") !== R12C_COMMIT) throw new Error("R12C is not the direct parent.");
if (command("git", "merge-base", "--is-ancestor", R12C_COMMIT, "HEAD") !== "") {
  // merge-base --is-ancestor is silent; successful command already proves ancestry.
}
if (command("git", "diff", "--name-only", R12C_COMMIT, "HEAD", "--", "external_observer_grok_mcp_gateway") !== "") {
  throw new Error("Gateway runtime changed in R12D.");
}
if (command("git", "status", "--porcelain", "--untracked-files=no") !== "") throw new Error("Tracked source is dirty.");
const expectedSourcePaths = [
  "external_observer_grok_mcp_operator/BUILD_R12D_OPERATOR_BUNDLE.mjs",
  "external_observer_grok_mcp_operator/DEPLOY_GATEWAY.ps1.in",
  "external_observer_grok_mcp_operator/OPERATOR_COMMON.ps1.in",
  "external_observer_grok_mcp_operator/OPERATOR_README.md.in",
  "external_observer_grok_mcp_operator/TEST_WINDOWS_OPERATOR_ACL.ps1.in",
];
const actualSourcePaths = command("git", "diff", "--name-only", R12C_COMMIT, "HEAD").split("\n").filter(Boolean).sort();
if (JSON.stringify(actualSourcePaths) !== JSON.stringify(expectedSourcePaths)) throw new Error("R12D source-path scope mismatch.");
for (const path of [...expectedSourcePaths, ...command("git", "ls-tree", "-r", "--name-only", "HEAD", "external_observer_grok_mcp_gateway").split("\n").filter(Boolean)]) {
  if (command("git", "hash-object", path) !== command("git", "rev-parse", `HEAD:${path}`)) throw new Error(`Working-tree byte mismatch: ${path}`);
}
const committedGatewayPaths = command("git", "ls-tree", "-r", "--name-only", "HEAD", "external_observer_grok_mcp_gateway").split("\n").filter(Boolean).sort();
const workingGatewayPaths = listFiles(join(repoRoot, "external_observer_grok_mcp_gateway")).map((path) => `external_observer_grok_mcp_gateway/${path}`);
if (committedGatewayPaths.length !== 11 || JSON.stringify(committedGatewayPaths) !== JSON.stringify(workingGatewayPaths)) throw new Error("Gateway working-tree file set mismatch.");
if (basename(outputZip).match(/^PulseChain_External_Grok_Observer_Gateway_Operator_Bundle_R12D_\d{8}T\d{6}Z\.zip$/) === null) {
  throw new Error("R12D output filename is invalid.");
}

const expectedInput = {
  "package-lock.json": "4686199f5b2e56e40ebd6c619ff9adae7df38748bf6c69358171d261947f0e44",
  "package.json": "415ca3e6275e7a221bc75447e444b145ac38c34c44913ea85cc9dfac0fe7e5d3",
  "BOUND_OBSERVATION_INPUT_SCHEMA.json": "7d9d7878ea4b4ce434c21dd6f8b0dedce9b1ee327653f9b79f2cb8d8c021e630",
  "OBSERVATION_SCHEMA.json": "4683a6b7b531bb69182f5a9b109e6c4649ad8809ce8fbf8e19efb063b76a4fd2",
  "OPERATOR_BUILD_DISABLED_PAYLOAD.mjs": "691029c146e2c0d7777130ba7400f427abb18e015c995767012f75d450cfa296",
  "SHOW_GROK_CONNECTOR_TOKEN.ps1": "5836e5da451bbe7d4da53f7f9274a8092b719518baa819522ac02ebe479befc8",
};
const inputInventoryPath = join(baseDirectory, "ARTIFACT_INVENTORY.json");
if (!existsSync(inputInventoryPath)) throw new Error("R12C inventory is missing.");
const inputInventory = JSON.parse(readFileSync(inputInventoryPath, "utf8"));
if (inputInventory.artifact_count_excluding_inventory !== 27 || inputInventory.artifacts.length !== 27) throw new Error("R12C inventory count mismatch.");
const inputMembers = listFiles(baseDirectory);
if (inputMembers.length !== 28 || new Set(inputMembers).size !== 28 || inputMembers.some((path) => !safePath(path))) throw new Error("R12C path safety failed.");
const inputInventoryPaths = inputInventory.artifacts.map((entry) => entry.path).sort();
if (JSON.stringify(inputInventoryPaths) !== JSON.stringify(inputMembers.filter((path) => path !== "ARTIFACT_INVENTORY.json"))) throw new Error("R12C inventory paths mismatch.");
for (const entry of inputInventory.artifacts) {
  const input = join(baseDirectory, entry.path);
  if (statSync(input).size !== entry.byte_size || sha256File(input) !== entry.sha256) throw new Error(`R12C inventory identity mismatch: ${entry.path}`);
}
for (const [path, expected] of Object.entries(expectedInput)) {
  const input = join(baseDirectory, path);
  if (!existsSync(input) || sha256File(input) !== expected) throw new Error(`R12C input identity mismatch: ${path}`);
}

rmSync(stage, { recursive: true, force: true });
mkdirSync(stage, { recursive: true });
mkdirSync(dirname(outputZip), { recursive: true });
if (existsSync(outputZip)) unlinkSync(outputZip);

cpSync(join(repoRoot, "external_observer_grok_mcp_gateway"), join(stage, "external_observer_grok_mcp_gateway"), { recursive: true });
for (const path of Object.keys(expectedInput)) cpSync(join(baseDirectory, path), join(stage, path));

const bundleName = basename(outputZip);
const rendered = {
  "OPERATOR_COMMON.ps1": replaceIdentity(readFileSync(join(operatorSourceDirectory, "OPERATOR_COMMON.ps1.in"), "utf8")),
  "DEPLOY_GATEWAY.ps1": replaceIdentity(readFileSync(join(operatorSourceDirectory, "DEPLOY_GATEWAY.ps1.in"), "utf8")),
  "TEST_WINDOWS_OPERATOR_ACL.ps1": replaceIdentity(readFileSync(join(operatorSourceDirectory, "TEST_WINDOWS_OPERATOR_ACL.ps1.in"), "utf8")),
  "OPERATOR_README.md": replaceIdentity(readFileSync(join(operatorSourceDirectory, "OPERATOR_README.md.in"), "utf8")),
  "VERIFY_GATEWAY_DISABLED.ps1": readFileSync(join(baseDirectory, "VERIFY_GATEWAY_DISABLED.ps1"), "utf8"),
  "REMOVE_OR_ROLLBACK_GATEWAY.md": readFileSync(join(baseDirectory, "REMOVE_OR_ROLLBACK_GATEWAY.md"), "utf8"),
  "R13_POST_DEPLOYMENT_VERIFICATION_PROMPT.md": replaceR13Identity(readFileSync(join(baseDirectory, "R13_POST_DEPLOYMENT_VERIFICATION_PROMPT.md"), "utf8"), bundleName),
};
for (const [path, text] of Object.entries(rendered)) writeFileSync(join(stage, path), text, "utf8");
if (!rendered["R13_POST_DEPLOYMENT_VERIFICATION_PROMPT.md"].includes(bundleName)) throw new Error("R13 exact bundle identity was not rendered.");

const sourceExport = join(stage, "external_observer_grok_mcp_operator");
mkdirSync(sourceExport, { recursive: true });
for (const path of [
  "OPERATOR_COMMON.ps1.in",
  "DEPLOY_GATEWAY.ps1.in",
  "TEST_WINDOWS_OPERATOR_ACL.ps1.in",
  "OPERATOR_README.md.in",
  "BUILD_R12D_OPERATOR_BUNDLE.mjs",
]) {
  cpSync(join(operatorSourceDirectory, path), join(sourceExport, path));
}

const connectors = [
  ["grok-x-protocol", "/mcp/external-observers/grok-x-protocol", "publish_external_observation_grok_x_protocol", "GROK_MCP_TOKEN_X_PROTOCOL"],
  ["grok-infrastructure-incidents", "/mcp/external-observers/grok-infrastructure-incidents", "publish_external_observation_grok_infrastructure_incidents", "GROK_MCP_TOKEN_INFRASTRUCTURE_INCIDENTS"],
  ["grok-market-liquidity", "/mcp/external-observers/grok-market-liquidity", "publish_external_observation_grok_market_liquidity", "GROK_MCP_TOKEN_MARKET_LIQUIDITY"],
  ["grok-identity-evidence", "/mcp/external-observers/grok-identity-evidence", "publish_external_observation_grok_identity_evidence", "GROK_MCP_TOKEN_IDENTITY_EVIDENCE"],
  ["grok-red-team", "/mcp/external-observers/grok-red-team", "publish_external_observation_grok_red_team", "GROK_MCP_TOKEN_RED_TEAM"],
];

writeJson(join(stage, "REQUIRED_SECRET_LABELS.json"), {
  schema_version: "pulsechain-external-observer-r12d-secret-labels@1.0.0",
  publication_mode: "DISABLED",
  required_secret_count: 5,
  connector_secrets: connectors.map(([observer_id, , , label]) => ({
    observer_id,
    label,
    generated_locally: true,
    persistent_local_copy: "WINDOWS_CURRENT_USER_DPAPI",
  })),
  github_publication_credentials: {
    required: false,
    requested: false,
    bound: false,
    deferred_until_separate_writable_mode_release: true,
  },
  secret_values_present: false,
});

writeJson(join(stage, "DEPLOYMENT_EXPECTATIONS.json"), {
  schema_version: "pulsechain-external-observer-r12d-deployment-expectations@1.0.0",
  source: {
    branch: SOURCE_BRANCH,
    commit: expectedCommit,
    tree: expectedTree,
    parent: R12C_COMMIT,
    r12_ancestor: R12_PARENT,
  },
  worker: {
    name: WORKER,
    entrypoint: "src/worker.mjs",
    compatibility_date: "2026-08-27",
    compatibility_flags: ["nodejs_compat"],
    publication_mode: "DISABLED",
    control_room_origin: CONTROL_ROOM_ORIGIN,
  },
  windows_operator: {
    normal_non_elevated_user_required: true,
    powershell_minimum: "7.4.0",
    access_control_sections: ["Access"],
    current_user_sid_binding: true,
    sacl_operations: 0,
    owner_operations: 0,
    se_security_privilege_required: false,
    acl_preflight_script: "TEST_WINDOWS_OPERATOR_ACL.ps1",
    acl_preflight_required_total: "TOTAL=25 PASS=25 FAIL=0",
    validation_status: "WINDOWS_RUNTIME_VALIDATION_REQUIRED_BEFORE_DEPLOYMENT",
  },
  credential_contract: {
    connector_secret_count: 5,
    github_secret_count: 0,
    github_transport_constructor_count_disabled: 0,
    api_github_request_count_disabled: 0,
  },
  connectors: connectors.map(([observer_id, path, publish_tool]) => ({ observer_id, path, publish_tool })),
});

let initialFiles = listFiles(stage);
const manifestFiles = initialFiles.map((path) => {
  let role = "R12D_OPERATOR_BUNDLE_INPUT";
  if (path.startsWith("external_observer_grok_mcp_gateway/")) role = "R12D_GATEWAY_RUNTIME";
  else if (path.startsWith("external_observer_grok_mcp_operator/")) role = "R12D_AUTHORITATIVE_OPERATOR_SOURCE";
  else if (path.endsWith(".ps1")) role = "R12D_RENDERED_WINDOWS_OPERATOR";
  const sourcePath = path.startsWith("external_observer_grok_mcp_gateway/") || path.startsWith("external_observer_grok_mcp_operator/") ? path : null;
  return {
    path,
    byte_size: statSync(join(stage, path)).size,
    sha256: sha256File(join(stage, path)),
    role,
    origin: sourcePath ? "GIT_OBJECT" : "R12D_OPERATOR_BUILD",
    ...(sourcePath ? {
      git_blob: command("git", "rev-parse", `HEAD:${sourcePath}`),
      git_mode: command("git", "ls-tree", "HEAD", sourcePath).split(/\s+/)[0],
    } : {}),
  };
});

writeJson(join(stage, "SOURCE_MANIFEST.json"), {
  schema_version: "pulsechain-external-observer-r12d-source-manifest@1.0.0",
  generated_at_utc: generatedAt,
  source: {
    repository_provider: "SITES_SOURCE_REPOSITORY",
    branch: SOURCE_BRANCH,
    commit: expectedCommit,
    tree: expectedTree,
    parent: R12C_COMMIT,
    r12_ancestor: R12_PARENT,
    directory: "external_observer_grok_mcp_gateway/",
    gateway_file_count: 11,
    gateway_runtime_byte_identical_to_r12c: true,
  },
  worker: {
    name: WORKER,
    entrypoint: "src/worker.mjs",
    compatibility_date: "2026-08-27",
    compatibility_flags: ["nodejs_compat"],
    publication_mode: "DISABLED",
    publication_ready: false,
    github_publication_transport: "DEFERRED_WHILE_DISABLED",
    control_room_origin: CONTROL_ROOM_ORIGIN,
  },
  operator_lock: {
    origin: "R12A_OPERATOR_REUSED_EXACT_TESTED_RESOLUTION",
    wrangler_version: "4.92.0",
    wrangler_integrity: WRANGLER_INTEGRITY,
    package_lock_sha256: expectedInput["package-lock.json"],
    reproducibility: "PASS",
  },
  windows_validation: {
    provider_available_during_build: false,
    status: "WINDOWS_RUNTIME_VALIDATION_REQUIRED_BEFORE_DEPLOYMENT",
    preflight_test_count: 25,
  },
  validation: {
    gateway_tests: { passed: 18, failed: 0 },
    control_room_regression: { passed: 60, failed: 0 },
    build: "PASS",
    typecheck: "PASS",
    lint_errors: 0,
    migration_integrity: "PASS",
    security_scan: "PASS",
    secret_scan: "PASS",
    source_map_count: 0,
    gateway_runtime_diff_count: 0,
  },
  files: manifestFiles,
});

const checksumFiles = listFiles(stage).filter((path) => !["SHA256SUMS.txt", "ARTIFACT_INVENTORY.json"].includes(path));
writeFileSync(
  join(stage, "SHA256SUMS.txt"),
  checksumFiles.map((path) => `${sha256File(join(stage, path))}  ${path}`).join("\n") + "\n",
  "utf8",
);
for (const line of readFileSync(join(stage, "SHA256SUMS.txt"), "utf8").trim().split(/\r?\n/)) {
  const match = line.match(/^([0-9a-f]{64})  ([A-Za-z0-9._/-]+)$/);
  if (!match || sha256File(join(stage, match[2])) !== match[1]) throw new Error("R12D SHA256SUMS validation failed.");
}

const inventoryPaths = listFiles(stage).filter((path) => path !== "ARTIFACT_INVENTORY.json");
writeJson(join(stage, "ARTIFACT_INVENTORY.json"), {
  schema_version: "pulsechain-external-observer-r12d-operator-inventory@1.0.0",
  generated_at_utc: generatedAt,
  artifact_count_excluding_inventory: inventoryPaths.length,
  artifacts: inventoryPaths.map((path) => ({
    path,
    byte_size: statSync(join(stage, path)).size,
    sha256: sha256File(join(stage, path)),
  })),
});

const finalPaths = listFiles(stage);
if (finalPaths.some((path) => !safePath(path))) throw new Error("Bundle path safety failed.");
const zip = spawnSync("zip", ["-X", "-q", outputZip, ...finalPaths], {
  cwd: stage,
  encoding: "utf8",
  maxBuffer: 16 * 1024 * 1024,
});
if (zip.status !== 0) throw new Error("ZIP creation failed.");
const test = spawnSync("unzip", ["-tqq", outputZip], { encoding: "utf8" });
if (test.status !== 0) throw new Error("ZIP integrity failed.");
const zipList = spawnSync("unzip", ["-Z1", outputZip], { encoding: "utf8" });
if (zipList.status !== 0) throw new Error("ZIP inventory readback failed.");
const remotePaths = zipList.stdout.trim().split(/\r?\n/).filter(Boolean).sort();
if (JSON.stringify(remotePaths) !== JSON.stringify(finalPaths)) throw new Error("ZIP member readback mismatch.");
for (const path of finalPaths) {
  const member = spawnSync("unzip", ["-p", outputZip, path], { encoding: null, maxBuffer: 16 * 1024 * 1024 });
  if (member.status !== 0 || !member.stdout.equals(readFileSync(join(stage, path)))) throw new Error(`ZIP byte readback mismatch: ${path}`);
}
const writtenInventory = JSON.parse(readFileSync(join(stage, "ARTIFACT_INVENTORY.json"), "utf8"));
if (writtenInventory.artifact_count_excluding_inventory !== finalPaths.length - 1 || writtenInventory.artifacts.length !== finalPaths.length - 1) throw new Error("R12D inventory count mismatch.");
for (const entry of writtenInventory.artifacts) {
  if (statSync(join(stage, entry.path)).size !== entry.byte_size || sha256File(join(stage, entry.path)) !== entry.sha256) throw new Error(`R12D inventory identity mismatch: ${entry.path}`);
}

const output = {
  filename: basename(outputZip),
  byte_size: statSync(outputZip).size,
  member_count: finalPaths.length,
  sha256: sha256File(outputZip),
  zip_integrity: "PASS",
  inventory_validation: "PASS",
  path_safety: "PASS",
  source_branch: SOURCE_BRANCH,
  source_commit: expectedCommit,
  source_tree: expectedTree,
  windows_runtime_validation: "REQUIRED_BEFORE_DEPLOYMENT",
};
process.stdout.write(JSON.stringify(output, null, 2) + "\n");
rmSync(stage, { recursive: true, force: true });
