# Remove or roll back the isolated gateway

These are operator recovery instructions. Nothing in this file runs
automatically.

## Before recovery

1. Stop. Do not configure Grok and do not change PUBLICATION_MODE.
2. Preserve LOCAL_DISABLED_MODE_VERIFICATION.json and the console's nonsecret
   Worker version ID.
3. Read prior_version_id from the local vault metadata. Connector values remain
   DPAPI ciphertext and must not be decrypted for rollback.
4. Reauthenticate with the same Cloudflare account and set
   CLOUDFLARE_ACCOUNT_ID only in the current PowerShell process.
5. Run npm ci from a fresh bundle extraction and require Wrangler 4.92.0.

## Existing Worker with an explicit prior version

Only when the vault contains a non-null prior_version_id, roll back to that exact
version:

    npx wrangler rollback <prior-version-id> --name pulsechain-external-observer-grok-mcp --message "R12C disabled-gateway rollback"

Do not use an implicit previous or latest version. Read deployments status after
rollback and require the exact prior version at 100 percent.

## First deployment with no prior version

There is no version rollback target. After explicit local confirmation, remove
the isolated Worker through the Cloudflare dashboard or:

    npx wrangler delete --name pulsechain-external-observer-grok-mcp

Worker deletion is destructive. Confirm the exact Worker name and Cloudflare
account before approving it.

## Secret cleanup

Source rollback or Worker version rollback does not remove newly bound secrets.
After provider rollback or removal is verified:

1. delete the five Worker secret labels listed in REQUIRED_SECRET_LABELS.json or
   remove the Worker;
2. do not search for or remove a GitHub publication credential because R12C
   never binds one;
3. remove the local connector vault only after provider cleanup is confirmed;
4. clear any local terminal scrollback that displayed a selected connector
   token; and
5. preserve only redacted verification and deployment identities.

Never place a secret value in a support ticket, chat message, checkpoint, page,
source file, or rollback log.
