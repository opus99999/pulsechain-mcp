# PulseChain external Grok observer gateway — R12D Windows operator bundle

Classification:

EXTERNAL_OBSERVER_GROK_MCP_R12D_SOURCE_READY —
WINDOWS_ACL_PREFLIGHT_REQUIRED —
MANUAL_WINDOWS_DEPLOYMENT_REQUIRED

This bundle contains the exact R12D operator repair from:

- Branch: external-observer-grok-mcp-r12d-windows-acl-repair-20260828
- Commit: ec70832c69f847ea413666de095ce3d56534ea28
- Tree: 35e17b896403d02d160f3a4d902ea2e66845799c
- Parent: 2a5e33681b5bf4eed5e422baafc6fee923017b86

The gateway runtime is byte-identical to R12C. R12D changes only the Windows
private-file DACL path, operator failure-stage reporting, the Windows ACL
preflight, and supporting operator records.

## Mandatory local environment

Use a normal, non-elevated Windows 11 PowerShell 7.4 or later session.

Do not run as administrator. Do not enable SeSecurityPrivilege. The preflight
must pass all 25 tests before connector-token generation, temporary-secret
creation, Wrangler authentication, or deployment can begin.

R12C is superseded for deployment. Use only this R12D bundle.

## Preserved controls

- Worker: pulsechain-external-observer-grok-mcp
- Entrypoint: src/worker.mjs
- Compatibility date: 2026-08-27
- Compatibility flag: nodejs_compat
- Publication mode: DISABLED
- Control Room origin:
  https://pulsechain-research-control-room.brohexphiat.chatgpt.site
- Connector secrets: exactly five, generated locally
- GitHub credentials: zero
- GitHub credential prompts: zero
- Publishing: unavailable
- Grok monitoring: not started

The five connector tokens remain protected with Windows CurrentUser DPAPI.
The vault and its parent directory receive an access-only DACL bound to the
current Windows user SID. Inheritance is removed. No SACL, audit rule, owner,
group, elevation, broad local-user grant, or privileged descriptor operation
is used.

## Exact local command

From a fresh extraction of this ZIP:

    pwsh.exe -NoProfile -ExecutionPolicy Bypass -File .\DEPLOY_GATEWAY.ps1 -CloudflareAccountId "<32-hex Cloudflare account ID>"

DEPLOY_GATEWAY.ps1 validates every governed bundle byte, then runs:

    pwsh.exe -NoLogo -NoProfile -NonInteractive -File .\TEST_WINDOWS_OPERATOR_ACL.ps1

The required preflight result is:

    TOTAL=25 PASS=25 FAIL=0

If any test fails, deployment stops with
WINDOWS_OPERATOR_ACL_PREFLIGHT_FAILED before tokens, vault, temporary secrets,
Wrangler, or Worker deployment.

After the preflight, the deployment script reruns the 18-test gateway gate,
selects the supplied Cloudflare account, generates five connector tokens,
stores the DPAPI vault outside the source directory, deploys exactly once, and
runs VERIFY_GATEWAY_DISABLED.ps1. No GitHub publication credential is required
or accepted while PUBLICATION_MODE is DISABLED.

The connector vault is:

    %LOCALAPPDATA%\PulseChain\ExternalObserverGateway\connector-tokens.dpapi.json

The disabled verification report is:

    %LOCALAPPDATA%\PulseChain\ExternalObserverGateway\LOCAL_DISABLED_MODE_VERIFICATION.json

Do not configure or schedule Grok from this bundle. A separate provider
configuration change, one complete GitHub publication credential method, a
fresh readiness check, and a separately authorized canary are required before
SYNTHETIC_ONLY or PROVISIONAL_LIVE.
