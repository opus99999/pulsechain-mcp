#Requires -Version 7.4

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateSet(
        "grok-x-protocol",
        "grok-infrastructure-incidents",
        "grok-market-liquidity",
        "grok-identity-evidence",
        "grok-red-team"
    )]
    [string]$ObserverId
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$VerbosePreference = "SilentlyContinue"
$DebugPreference = "SilentlyContinue"
$InformationPreference = "SilentlyContinue"

. (Join-Path $PSScriptRoot "OPERATOR_COMMON.ps1")
Assert-WindowsOperator

if ([Console]::IsInputRedirected -or [Console]::IsOutputRedirected -or [Console]::IsErrorRedirected) {
    throw "Token display requires a local interactive console with no redirection."
}

$vault = Read-ConnectorVault -RequireOrigin
[Console]::Write("Type DISPLAY to reveal the selected connector token in this local terminal: ")
$confirmation = [Console]::ReadLine()
if ($confirmation -cne "DISPLAY") {
    throw "Token display was cancelled."
}

$token = Get-ConnectorToken -Vault $vault -ObserverId $ObserverId
try {
    [Console]::WriteLine($token)
}
finally {
    $token = $null
}
