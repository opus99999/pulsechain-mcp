import { existsSync, readFileSync, readdirSync, realpathSync, statSync } from "node:fs";
import { dirname, relative, resolve, sep } from "node:path";

export const SOURCE_CONTRACTS_IMPORT = "../../external_observer_grok_mcp_gateway/src/contracts.mjs";
export const BUNDLE_CONTRACTS_IMPORT = "../external_observer_grok_mcp_gateway/src/contracts.mjs";
const RELOCATED_OPERATOR_FILENAMES = new Map([
  ["UPDATE_EXISTING_GATEWAY_R12F.ps1.in", "UPDATE_EXISTING_GATEWAY_R12F.ps1"],
  ["OPERATOR_README_R12F.md.in", "OPERATOR_README.md"],
]);

const STATIC_FROM = /\b(?:import|export)\s+(?:[^"']*?\s+from\s+)?["']([^"']+)["']/gu;
const DYNAMIC_IMPORT = /\bimport\s*\(\s*["']([^"']+)["']\s*\)/gu;

function listFiles(root) {
  const files = [];
  function visit(directory) {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const absolute = resolve(directory, entry.name);
      if (entry.isSymbolicLink()) throw new Error(`IMPORT_CONTAINMENT_SYMLINK:${absolute}`);
      if (entry.isDirectory()) visit(absolute);
      else if (entry.isFile()) files.push(absolute);
    }
  }
  visit(root);
  return files.sort();
}

function underRoot(root, target) {
  return target === root || target.startsWith(`${root}${sep}`);
}

export function rewriteOperatorTestForBundle(path, sourceText) {
  let emitted = sourceText;
  if (path === "node-verifier.test.mjs") {
    const occurrences = emitted.split(SOURCE_CONTRACTS_IMPORT).length - 1;
    if (occurrences !== 1) throw new Error(`BUNDLE_IMPORT_REWRITE_SOURCE_COUNT:${occurrences}`);
    emitted = emitted.replace(SOURCE_CONTRACTS_IMPORT, BUNDLE_CONTRACTS_IMPORT);
    if (emitted.includes(SOURCE_CONTRACTS_IMPORT)) throw new Error("BUNDLE_IMPORT_REWRITE_INCOMPLETE");
  }
  if (path === "update-bundle-contract.test.mjs") {
    for (const [sourceName, bundleName] of RELOCATED_OPERATOR_FILENAMES) {
      if (!emitted.includes(sourceName)) throw new Error(`BUNDLE_TEST_FILENAME_SOURCE_MISSING:${sourceName}`);
      emitted = emitted.replaceAll(sourceName, bundleName);
      if (emitted.includes(sourceName)) throw new Error(`BUNDLE_TEST_FILENAME_REWRITE_INCOMPLETE:${sourceName}`);
    }
  }
  return emitted;
}

export function validateBundleImports(bundleRoot) {
  const canonicalRoot = realpathSync(bundleRoot);
  const modules = listFiles(canonicalRoot).filter((path) => /\.(?:m?js)$/u.test(path));
  const imports = [];
  for (const importer of modules) {
    const source = readFileSync(importer, "utf8");
    const specifiers = [
      ...source.matchAll(STATIC_FROM),
      ...source.matchAll(DYNAMIC_IMPORT),
    ].map((match) => match[1]).filter((specifier) => specifier.startsWith("./") || specifier.startsWith("../"));
    for (const specifier of specifiers) {
      const lexicalTarget = resolve(dirname(importer), specifier.split(/[?#]/u, 1)[0]);
      if (!underRoot(canonicalRoot, lexicalTarget)) throw new Error(`IMPORT_OUTSIDE_BUNDLE_ROOT:${relative(canonicalRoot, importer)}:${specifier}`);
      if (!existsSync(lexicalTarget) || !statSync(lexicalTarget).isFile()) throw new Error(`IMPORT_TARGET_MISSING:${relative(canonicalRoot, importer)}:${specifier}`);
      const canonicalTarget = realpathSync(lexicalTarget);
      if (!underRoot(canonicalRoot, canonicalTarget)) throw new Error(`IMPORT_REALPATH_OUTSIDE_BUNDLE_ROOT:${relative(canonicalRoot, importer)}:${specifier}`);
      imports.push({
        importer: relative(canonicalRoot, importer).split(sep).join("/"),
        specifier,
        target: relative(canonicalRoot, canonicalTarget).split(sep).join("/"),
      });
    }
  }
  return {
    javascript_module_count: modules.length,
    relative_local_import_count: imports.length,
    outside_root_import_count: 0,
    missing_target_count: 0,
    imports,
    result: "PASS",
  };
}
