# PulseChain external Grok observer gateway — R12C Windows operator bundle

Classification:

EXTERNAL_OBSERVER_GROK_MCP_DISABLED_MODE_READY —
GITHUB_CREDENTIAL_DEFERRED_FAIL_CLOSED —
MANUAL_WINDOWS_DEPLOYMENT_REQUIRED

This bundle exports the exact verified R12C gateway source. It does not contain
secret values and its creation did not deploy a Worker, log into Cloudflare,
create an issue, create an observation, configure Grok, or change live state.

## Exact source

- Branch: external-observer-grok-mcp-r12c-disabled-credential-defer-20260827
- Commit: 2a5e33681b5bf4eed5e422baafc6fee923017b86
- Tree: 18818626f9e529be058130ccc0fda83aceca00b2
- Parent: e1a3ffae1e735ec3e7c310b147b2ee7d793e51c0
- Worker: pulsechain-external-observer-grok-mcp
- Entrypoint: src/worker.mjs
- Compatibility date: 2026-08-27
- Compatibility flag: nodejs_compat
- Publication mode: DISABLED
- Control Room origin:
  https://pulsechain-research-control-room.brohexphiat.chatgpt.site

The external_observer_grok_mcp_gateway directory contains the exact eleven Git
files from that commit. The two governed observation schemas are placed at the
bundle root because the immutable gateway source imports them two directories
above src. The gateway files themselves are unchanged.

The verified source did not contain package-lock.json. This export therefore
adds one operator-only root package-lock.json and matching root package.json.
They pin the exact tested Wrangler 4.92.0 resolution. They are not source-branch
changes and must not be committed back to the R12C branch.

## Provider destination

At the R12 checkpoint the Worker service did not yet exist. The operator selects
the Cloudflare account by supplying its exact 32-hex account ID. The expected
origin has this form:

    https://pulsechain-external-observer-grok-mcp.<account-subdomain>.workers.dev

No Cloudflare account ID or account subdomain is embedded in this bundle.

## Local prerequisites

- A local Windows computer.
- PowerShell 7.4 or later.
- Node.js 22.13.0 or later with npm and npx.
- An interactive browser available if Wrangler login is required.
- The approved Cloudflare account ID.

No GitHub credential is required or accepted by this R12C disabled deployment.
Publishing remains unavailable. A complete GitHub App credential set or the
approved issues-only fallback must be bound in a separate release before
SYNTHETIC_ONLY or PROVISIONAL_LIVE can pass readiness.

Start from a fresh extraction of the ZIP. Compare the outer ZIP SHA-256 with the
release response before running any script. DEPLOY_GATEWAY.ps1 independently
checks SHA256SUMS.txt, SOURCE_MANIFEST.json, the exact gateway file set, every
source byte, Worker configuration, lock provenance, and the 18-of-18 gateway test
gate before authentication or secret handling.

## Exact local deployment command

Run from this extracted bundle directory:

    pwsh.exe -NoProfile -ExecutionPolicy Bypass -File .\DEPLOY_GATEWAY.ps1 -CloudflareAccountId "<32-hex Cloudflare account ID>"

The script:

1. installs the pinned operator toolchain from package-lock.json;
2. verifies Wrangler 4.92.0 and reruns the complete gateway validation;
3. runs Wrangler login only when whoami proves the operator is not authenticated;
4. requires the authenticated account to match the supplied account ID;
5. safely recognizes the exact undeployed R12A vault left by the failed local
   credential capture, requires explicit local confirmation, and otherwise
   preserves any unmatched vault fail-closed;
6. creates five independent cryptographic connector tokens;
7. stores each connector token under the current Windows user using DPAPI;
8. builds a current-user-only temporary file containing exactly those five
   connector secrets;
9. performs exactly one Worker deployment while preserving DISABLED mode;
10. deletes the temporary secrets file in a finally block; and
11. runs VERIFY_GATEWAY_DISABLED.ps1 without a GitHub credential.

The connector vault is outside the source directory:

    %LOCALAPPDATA%\PulseChain\ExternalObserverGateway\connector-tokens.dpapi.json

The disabled-mode report is written outside the source directory:

    %LOCALAPPDATA%\PulseChain\ExternalObserverGateway\LOCAL_DISABLED_MODE_VERIFICATION.json

Successful console output contains only the deployment result, Worker name,
Cloudflare account ID, Worker version ID, workers.dev origin, five connector
URLs, and verification status. It never prints a connector token and never
requests, receives, or binds a GitHub credential.

## Disabled-mode verification

VERIFY_GATEWAY_DISABLED.ps1 initializes every Streamable HTTP connector, checks
tools/list and the exact discovery fingerprint, requires one fixed publish tool
and the three common read tools, rejects every cross-connector token, verifies
that observer_id and other server controls are absent from the model-visible
schema, reads the matching observer bootstrap, and makes one valid disabled
publication call per connector.

Each call must return PUBLICATION_MODE_DISABLED with null issue, workflow,
observation, commit, permanent-page, and manifest fields. The local tests prove
zero GitHub transport construction. The verifier makes zero api.github.com
requests and requires zero issue, workflow, repository-head, observation,
permanent-page, latest-pointer, index, or specialist changes.

## Retrieve one connector token locally

Only after a successful deployment and verification, use one exact observer ID:

    pwsh.exe -NoProfile -ExecutionPolicy Bypass -File .\SHOW_GROK_CONNECTOR_TOKEN.ps1 grok-x-protocol

The script requires an unredirected local console and an explicit DISPLAY
confirmation. It decrypts and displays only the selected observer's token. Do
not paste that token into chat, a checkpoint, source, a log, or another
observer's connector.

## Stop point

Grok connectors can be connected in DISABLED mode, but publishing is unavailable.
Do not configure or schedule monitoring from this bundle and do not change
PUBLICATION_MODE. A separate credential-binding release, fresh readiness check,
and separately authorized canary are mandatory before SYNTHETIC_ONLY. No real
monitoring begins in R12C. After the manual deployment and successful disabled
verification, use R13_POST_DEPLOYMENT_VERIFICATION_PROMPT.md as the bounded next
read-only task.

Use REMOVE_OR_ROLLBACK_GATEWAY.md if the deploy or disabled verification fails.
