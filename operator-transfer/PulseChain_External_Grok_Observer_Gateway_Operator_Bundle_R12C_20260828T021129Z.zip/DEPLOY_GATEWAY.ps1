#Requires -Version 7.4

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern("^[0-9A-Fa-f]{32}$")]
    [string]$CloudflareAccountId
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$VerbosePreference = "SilentlyContinue"
$DebugPreference = "SilentlyContinue"
$InformationPreference = "SilentlyContinue"
$PSNativeCommandUseErrorActionPreference = $false

$BundleRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$CloudflareAccountId = $CloudflareAccountId.ToLowerInvariant()
$GatewayDirectory = Join-Path $BundleRoot "external_observer_grok_mcp_gateway"
$WorkerName = "pulsechain-external-observer-grok-mcp"
$ExpectedOriginPattern = "^https://pulsechain-external-observer-grok-mcp\.[a-z0-9-]+\.workers\.dev/?$"
$ExpectedCommit = "2a5e33681b5bf4eed5e422baafc6fee923017b86"
$ExpectedTree = "18818626f9e529be058130ccc0fda83aceca00b2"
$phase = "initial validation"
$operatorTemp = $null
$secretTempDirectory = $null
$secretTempFile = $null
$plainTokens = $null
$secretJson = $null
$priorAccountEnvironment = $env:CLOUDFLARE_ACCOUNT_ID
$priorPath = $env:PATH
$priorNoColor = $env:NO_COLOR
$priorForceColor = $env:FORCE_COLOR
$priorNpmOffline = $env:npm_config_offline
$deploymentInvocations = 0
$deploymentSucceeded = $false
$cleanupFailed = $false
$finalOutput = @()
$failureMessage = $null

function Get-SafeBundlePath {
    param([Parameter(Mandatory = $true)][string]$RelativePath)
    if (
        [string]::IsNullOrWhiteSpace($RelativePath) -or
        [IO.Path]::IsPathRooted($RelativePath) -or
        $RelativePath.Contains("\") -or
        $RelativePath.Contains(":")
    ) {
        throw "The bundle contains an unsafe relative path."
    }
    $segments = $RelativePath.Split("/")
    if ($segments | Where-Object { $_ -in @("", ".", "..") }) {
        throw "The bundle contains an unsafe path segment."
    }
    $resolved = [IO.Path]::GetFullPath((Join-Path $BundleRoot $RelativePath))
    $prefix = $BundleRoot.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    if (-not $resolved.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw "The bundle path escaped the bundle root."
    }
    $resolved
}

function Get-FileSha256 {
    param([Parameter(Mandatory = $true)][string]$Path)
    $bytes = [IO.File]::ReadAllBytes($Path)
    try {
        [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()
    }
    finally {
        [Array]::Clear($bytes, 0, $bytes.Length)
    }
}

function Assert-BundleIntegrity {
    $sumFile = Join-Path $BundleRoot "SHA256SUMS.txt"
    $manifestFile = Join-Path $BundleRoot "SOURCE_MANIFEST.json"
    if (-not (Test-Path -LiteralPath $sumFile -PathType Leaf) -or -not (Test-Path -LiteralPath $manifestFile -PathType Leaf)) {
        throw "The source manifest or SHA256SUMS is missing."
    }

    $expectedPaths = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    foreach ($line in Get-Content -LiteralPath $sumFile -Encoding utf8) {
        if ($line -notmatch "^([0-9a-f]{64})  ([A-Za-z0-9._/-]+)$") {
            throw "SHA256SUMS contains an invalid line."
        }
        $expectedHash = $Matches[1]
        $relativePath = $Matches[2]
        if (-not $expectedPaths.Add($relativePath)) {
            throw "SHA256SUMS contains a duplicate path."
        }
        $path = Get-SafeBundlePath -RelativePath $relativePath
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            throw "A file governed by SHA256SUMS is missing."
        }
        if ((Get-FileSha256 -Path $path) -cne $expectedHash) {
            throw "A SHA256SUMS file identity is mismatched."
        }
    }

    $actualPaths = @(
        Get-ChildItem -LiteralPath $BundleRoot -File -Recurse |
            ForEach-Object {
                [IO.Path]::GetRelativePath($BundleRoot, $_.FullName).Replace("\", "/")
            } |
            Where-Object { $_ -notin @("SHA256SUMS.txt", "ARTIFACT_INVENTORY.json") } |
            Sort-Object
    )
    $expectedSorted = @($expectedPaths | Sort-Object)
    if (($actualPaths -join [Environment]::NewLine) -cne ($expectedSorted -join [Environment]::NewLine)) {
        throw "The extracted bundle file set differs from SHA256SUMS."
    }

    $manifest = Get-Content -LiteralPath $manifestFile -Raw -Encoding utf8 | ConvertFrom-Json -Depth 30
    if (
        $manifest.schema_version -ne "pulsechain-external-observer-r12c-source-manifest@1.0.0" -or
        $manifest.source.branch -ne "external-observer-grok-mcp-r12c-disabled-credential-defer-20260827" -or
        $manifest.source.commit -ne $ExpectedCommit -or
        $manifest.source.tree -ne $ExpectedTree -or
        $manifest.source.directory -ne "external_observer_grok_mcp_gateway/" -or
        $manifest.worker.name -ne $WorkerName -or
        $manifest.worker.entrypoint -ne "src/worker.mjs" -or
        $manifest.worker.compatibility_date -ne "2026-08-27" -or
        @($manifest.worker.compatibility_flags).Count -ne 1 -or
        $manifest.worker.compatibility_flags[0] -ne "nodejs_compat" -or
        $manifest.worker.publication_mode -ne "DISABLED"
    ) {
        throw "SOURCE_MANIFEST identity or configuration is invalid."
    }
    if (
        $manifest.operator_lock.wrangler_version -ne "4.92.0" -or
        $manifest.operator_lock.wrangler_integrity -ne "sha512-/DKpQHPxkuZbQsO9dFW2700VTD/4DSZMHjy92fO/frNoDRi/zQsFCAd2ONCV6TGqcUoXcP3D8Bo2gj/L4M0qQQ==" -or
        $manifest.operator_lock.reproducibility -ne "PASS"
    ) {
        throw "The operator dependency lock provenance is invalid."
    }

    $manifestPaths = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    foreach ($entry in @($manifest.files)) {
        if (-not $manifestPaths.Add([string]$entry.path)) {
            throw "SOURCE_MANIFEST contains a duplicate file."
        }
        $path = Get-SafeBundlePath -RelativePath $entry.path
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            throw "A SOURCE_MANIFEST file is missing."
        }
        $info = Get-Item -LiteralPath $path
        if ([int64]$entry.byte_size -ne $info.Length -or [string]$entry.sha256 -cne (Get-FileSha256 -Path $path)) {
            throw "A SOURCE_MANIFEST file identity is mismatched."
        }
    }
    $gatewayManifestPaths = @(
        $manifest.files |
            Where-Object { $_.role -eq "R12C_GATEWAY_SOURCE" } |
            ForEach-Object { $_.path } |
            Sort-Object
    )
    $gatewayActualPaths = @(
        Get-ChildItem -LiteralPath $GatewayDirectory -File -Recurse |
            ForEach-Object {
                [IO.Path]::GetRelativePath($BundleRoot, $_.FullName).Replace("\", "/")
            } |
            Sort-Object
    )
    if ($gatewayManifestPaths.Count -ne 11 -or ($gatewayManifestPaths -join [Environment]::NewLine) -cne ($gatewayActualPaths -join [Environment]::NewLine)) {
        throw "The exact R12C gateway directory is incomplete or contains extra files."
    }

    $config = Get-Content -LiteralPath (Join-Path $GatewayDirectory "wrangler.toml") -Raw -Encoding utf8
    $requiredConfigLines = @(
        'name = "pulsechain-external-observer-grok-mcp"',
        'main = "src/worker.mjs"',
        'compatibility_date = "2026-08-27"',
        'compatibility_flags = ["nodejs_compat"]',
        'PUBLICATION_MODE = "DISABLED"',
        'CONTROL_ROOM_ORIGIN = "https://pulsechain-research-control-room.brohexphiat.chatgpt.site"'
    )
    foreach ($line in $requiredConfigLines) {
        if (-not $config.Contains($line, [StringComparison]::Ordinal)) {
            throw "The immutable Worker configuration is invalid."
        }
    }
}

function Invoke-NpxCaptured {
    param(
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$WorkingDirectory
    )
    $errorFile = Join-Path $operatorTemp ("native-" + [Guid]::NewGuid().ToString("N") + ".err")
    Push-Location $WorkingDirectory
    try {
        $stdout = @(& npx @Arguments 2> $errorFile)
        $code = $LASTEXITCODE
        $stderr = if (Test-Path -LiteralPath $errorFile) {
            Get-Content -LiteralPath $errorFile -Raw -Encoding utf8
        }
        else {
            ""
        }
        [pscustomobject]@{
            exit_code = $code
            stdout = $stdout -join [Environment]::NewLine
            stderr = $stderr
        }
    }
    finally {
        Pop-Location
        if (Test-Path -LiteralPath $errorFile) {
            Remove-Item -LiteralPath $errorFile -Force
        }
    }
}

function New-ConnectorToken {
    $bytes = [byte[]]::new(32)
    [Security.Cryptography.RandomNumberGenerator]::Fill($bytes)
    try {
        $token = [Convert]::ToBase64String($bytes).TrimEnd("=").Replace("+", "-").Replace("/", "_")
        if ($token -notmatch "^[A-Za-z0-9_-]{43}$") {
            throw "Connector token generation failed."
        }
        $token
    }
    finally {
        [Array]::Clear($bytes, 0, $bytes.Length)
    }
}

try {
    if (-not $IsWindows) {
        throw "This script may run only on the operator's Windows computer."
    }
    if ($PSVersionTable.PSVersion -lt [Version]"7.4.0") {
        throw "PowerShell 7.4 or later is required."
    }

    Assert-BundleIntegrity

    $phase = "operator runtime validation"
    . (Join-Path $BundleRoot "OPERATOR_COMMON.ps1")
    Assert-WindowsOperator
    foreach ($command in @("node", "npm", "npx")) {
        if ($null -eq (Get-Command $command -ErrorAction SilentlyContinue)) {
            throw "Node.js and npm are required."
        }
    }
    $nodeText = (& node --version 2>$null).Trim().TrimStart("v")
    if ($LASTEXITCODE -ne 0 -or [Version]$nodeText -lt [Version]"22.13.0") {
        throw "Node.js 22.13.0 or later is required."
    }

    $stateDirectory = Get-OperatorStateDirectory
    Initialize-PrivateDirectory -Path $stateDirectory
    if ((Get-ConnectorVaultPath).StartsWith($BundleRoot, [StringComparison]::OrdinalIgnoreCase)) {
        throw "The connector vault must be outside the bundle source."
    }
    $existingVaultPath = Get-ConnectorVaultPath

    $operatorTemp = Join-Path ([IO.Path]::GetTempPath()) ("pulsechain-r12c-" + [Guid]::NewGuid().ToString("N"))
    [void][IO.Directory]::CreateDirectory($operatorTemp)
    Set-PrivateDirectoryAcl -Path $operatorTemp

    $phase = "pinned dependency installation"
    $npmError = Join-Path $operatorTemp "npm-ci.err"
    $npmOutput = @(& npm --prefix $BundleRoot ci --ignore-scripts --no-audit --no-fund 2> $npmError)
    if ($LASTEXITCODE -ne 0) {
        throw "The operator dependency lock could not be installed."
    }
    $wranglerPackage = Get-Content -LiteralPath (Join-Path $BundleRoot "node_modules\wrangler\package.json") -Raw -Encoding utf8 | ConvertFrom-Json
    if ($wranglerPackage.version -ne "4.92.0") {
        throw "The installed Wrangler version differs from the tested resolution."
    }
    $env:PATH = (Join-Path $BundleRoot "node_modules\.bin") + [IO.Path]::PathSeparator + $env:PATH
    $env:npm_config_offline = "true"
    $wranglerVersion = (& npx wrangler --version 2>$null).Trim()
    if ($LASTEXITCODE -ne 0 -or $wranglerVersion -ne "4.92.0") {
        throw "The pinned Wrangler executable is unavailable."
    }

    $phase = "gateway test gate"
    $gatewayError = Join-Path $operatorTemp "gateway-tests.err"
    $gatewayOutput = @(& npm --prefix $GatewayDirectory run validate 2> $gatewayError) -join [Environment]::NewLine
    if ($LASTEXITCODE -ne 0 -or $gatewayOutput -notmatch "(?m)^[^\r\n]*pass 18\s*$" -or $gatewayOutput -notmatch "(?m)^[^\r\n]*fail 0\s*$") {
        throw "The exact R12C gateway validation did not pass 18 of 18 tests."
    }

    $env:NO_COLOR = "1"
    $env:FORCE_COLOR = "0"
    $phase = "Cloudflare authentication"
    $whoami = Invoke-NpxCaptured -Arguments @("wrangler", "whoami", "--json") -WorkingDirectory $GatewayDirectory
    if ($whoami.exit_code -ne 0) {
        Push-Location $GatewayDirectory
        try {
            & npx wrangler login 1>$null 2>$null
            if ($LASTEXITCODE -ne 0) {
                throw "Cloudflare login did not complete."
            }
        }
        finally {
            Pop-Location
        }
        $whoami = Invoke-NpxCaptured -Arguments @("wrangler", "whoami", "--json") -WorkingDirectory $GatewayDirectory
    }
    if ($whoami.exit_code -ne 0) {
        throw "Cloudflare authentication is unavailable."
    }
    $whoamiJson = $whoami.stdout | ConvertFrom-Json -Depth 20
    $matchingAccounts = @($whoamiJson.accounts | Where-Object { ([string]$_.id).ToLowerInvariant() -ceq $CloudflareAccountId })
    if (-not $whoamiJson.loggedIn -or $matchingAccounts.Count -ne 1) {
        throw "The authenticated Cloudflare account does not match -CloudflareAccountId."
    }
    $whoami = $null
    $whoamiJson = $null
    $matchingAccounts = $null
    $env:CLOUDFLARE_ACCOUNT_ID = $CloudflareAccountId

    $phase = "existing Worker preflight"
    $priorVersionId = $null
    $workerExists = $false
    $status = Invoke-NpxCaptured -Arguments @("wrangler", "deployments", "status", "--name", $WorkerName, "--json") -WorkingDirectory $GatewayDirectory
    if ($status.exit_code -eq 0) {
        $workerExists = $true
        $statusJson = $status.stdout | ConvertFrom-Json -Depth 20
        $activeVersions = @($statusJson.versions)
        if ($activeVersions.Count -ne 1 -or [decimal]$activeVersions[0].percentage -ne 100 -or [string]$activeVersions[0].version_id -notmatch "^[0-9a-fA-F-]{36}$") {
            throw "The existing Worker has no single safe rollback version."
        }
        $priorVersionId = [string]$activeVersions[0].version_id
        $secretList = Invoke-NpxCaptured -Arguments @("wrangler", "secret", "list", "--name", $WorkerName, "--format", "json") -WorkingDirectory $GatewayDirectory
        if ($secretList.exit_code -ne 0) {
            throw "Existing Worker secret labels could not be inspected."
        }
        $secretListJson = $secretList.stdout | ConvertFrom-Json -Depth 10
        $allowedLabels = @((Get-ConnectorDefinitions).token_label)
        $unexpectedLabels = @($secretListJson | ForEach-Object { $_.name } | Where-Object { $_ -notin $allowedLabels })
        if ($unexpectedLabels.Count -ne 0) {
            throw "The existing Worker contains an unexpected secret label."
        }
    }
    elseif ($status.stderr -notmatch "(?i)(no deployments|not found|does not exist)") {
        throw "The existing Worker state could not be determined safely."
    }

    if (Test-Path -LiteralPath $existingVaultPath -PathType Leaf) {
        if ($workerExists) {
            throw "A connector vault already exists for a deployed Worker. Use the rollback guide before another deployment."
        }
        $abandoned = Get-Content -LiteralPath $existingVaultPath -Raw -Encoding utf8 | ConvertFrom-Json -Depth 20
        $expectedObservers = @((Get-ConnectorDefinitions).observer_id | Sort-Object)
        $actualObservers = @($abandoned.tokens.PSObject.Properties.Name | Sort-Object)
        if (
            $abandoned.schema_version -ne "pulsechain-external-observer-connector-vault@1.0.0" -or
            $abandoned.worker_name -ne $WorkerName -or
            ([string]$abandoned.account_id).ToLowerInvariant() -cne $CloudflareAccountId -or
            $abandoned.source_branch -ne "external-observer-grok-mcp-r12-20260827" -or
            $abandoned.source_commit -ne "e1a3ffae1e735ec3e7c310b147b2ee7d793e51c0" -or
            $abandoned.source_tree -ne "3c2de63d326bcd4ca62dfcf43a5bd8a5496d8db5" -or
            $abandoned.publication_mode -ne "DISABLED" -or
            $null -ne $abandoned.worker_origin -or
            $null -ne $abandoned.current_version_id -or
            $null -ne $abandoned.deployed_at_utc -or
            $null -ne $abandoned.prior_version_id -or
            ($expectedObservers -join [Environment]::NewLine) -cne ($actualObservers -join [Environment]::NewLine)
        ) {
            throw "An existing connector vault is not the exact undeployed R12A credential-capture remnant. It was preserved."
        }
        foreach ($definition in @(Get-ConnectorDefinitions)) {
            $record = $abandoned.tokens.($definition.observer_id)
            if ($record.secret_label -ne $definition.token_label -or [string]::IsNullOrWhiteSpace([string]$record.ciphertext_base64)) {
                throw "The undeployed R12A connector vault is incomplete and was preserved."
            }
        }
        if ([Console]::IsInputRedirected -or [Console]::IsOutputRedirected) {
            throw "Removal of the exact undeployed R12A vault requires a local interactive console."
        }
        [Console]::Write("Type REMOVE_ABANDONED_R12A_VAULT to remove the exact undeployed credential-capture remnant: ")
        if ([Console]::ReadLine() -cne "REMOVE_ABANDONED_R12A_VAULT") {
            throw "The undeployed R12A vault was preserved."
        }
        Remove-Item -LiteralPath $existingVaultPath -Force
        if (Test-Path -LiteralPath $existingVaultPath) {
            throw "The exact undeployed R12A vault could not be removed."
        }
        $abandoned = $null
    }
    elseif (Test-Path -LiteralPath $existingVaultPath) {
        throw "The connector vault path is not a regular file."
    }

    $phase = "connector token generation"
    $definitions = @(Get-ConnectorDefinitions)
    $plainTokens = [ordered]@{}
    $vaultTokens = [ordered]@{}
    foreach ($definition in $definitions) {
        $token = New-ConnectorToken
        if ($plainTokens.Values -contains $token) {
            throw "Connector token uniqueness failed."
        }
        $plainTokens[$definition.observer_id] = $token
        $vaultTokens[$definition.observer_id] = [ordered]@{
            secret_label = $definition.token_label
            ciphertext_base64 = Protect-ConnectorToken -Token $token
        }
    }
    $vault = [pscustomobject][ordered]@{
        schema_version = "pulsechain-external-observer-connector-vault@1.0.0"
        worker_name = $WorkerName
        account_id = $CloudflareAccountId
        worker_origin = $null
        prior_version_id = $priorVersionId
        current_version_id = $null
        source_branch = "external-observer-grok-mcp-r12c-disabled-credential-defer-20260827"
        source_commit = $ExpectedCommit
        source_tree = $ExpectedTree
        publication_mode = "DISABLED"
        created_at_utc = [DateTime]::UtcNow.ToString("o")
        deployed_at_utc = $null
        tokens = [pscustomobject]$vaultTokens
    }
    Write-ConnectorVault -Vault $vault

    $phase = "temporary secret staging"
    $secretTempDirectory = Join-Path ([IO.Path]::GetTempPath()) ("pulsechain-r12c-secrets-" + [Guid]::NewGuid().ToString("N"))
    [void][IO.Directory]::CreateDirectory($secretTempDirectory)
    Set-PrivateDirectoryAcl -Path $secretTempDirectory
    $secretTempFile = Join-Path $secretTempDirectory "wrangler-secrets.json"
    $stream = [IO.File]::Open($secretTempFile, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    $stream.Dispose()
    Set-PrivateFileAcl -Path $secretTempFile
    $secrets = [ordered]@{}
    foreach ($definition in $definitions) {
        $secrets[$definition.token_label] = $plainTokens[$definition.observer_id]
    }
    if ($secrets.Count -ne 5) {
        throw "The temporary secret set is invalid."
    }
    $secretJson = $secrets | ConvertTo-Json -Compress
    [IO.File]::WriteAllText($secretTempFile, $secretJson, [Text.UTF8Encoding]::new($false))
    foreach ($key in @($plainTokens.Keys)) {
        $plainTokens[$key] = $null
    }
    $plainTokens.Clear()
    $plainTokens = $null
    $secretJson = $null
    $secrets.Clear()
    $secrets = $null

    $phase = "single Worker deployment"
    Push-Location $GatewayDirectory
    try {
        $deploymentInvocations += 1
        $deploymentOutput = @(& npx wrangler deploy --config wrangler.toml --secrets-file $secretTempFile 2>&1) -join [Environment]::NewLine
        $deploymentExitCode = $LASTEXITCODE
    }
    finally {
        Pop-Location
        if ($null -ne $secretTempFile -and (Test-Path -LiteralPath $secretTempFile)) {
            Remove-Item -LiteralPath $secretTempFile -Force -ErrorAction SilentlyContinue
        }
        if ($null -ne $secretTempFile -and (Test-Path -LiteralPath $secretTempFile)) {
            throw "The temporary deployment secret file could not be deleted."
        }
        if ($null -ne $secretTempDirectory -and (Test-Path -LiteralPath $secretTempDirectory)) {
            Remove-Item -LiteralPath $secretTempDirectory -Force -Recurse -ErrorAction SilentlyContinue
        }
        if ($null -ne $secretTempDirectory -and (Test-Path -LiteralPath $secretTempDirectory)) {
            throw "The temporary deployment secret directory could not be deleted."
        }
    }
    if ($deploymentInvocations -ne 1 -or $deploymentExitCode -ne 0) {
        throw "The single Worker deployment did not succeed."
    }

    $originMatch = [Text.RegularExpressions.Regex]::Match(
        $deploymentOutput,
        "https://pulsechain-external-observer-grok-mcp\.[a-z0-9-]+\.workers\.dev/?",
        [Text.RegularExpressions.RegexOptions]::IgnoreCase
    )
    $versionMatch = [Text.RegularExpressions.Regex]::Match(
        $deploymentOutput,
        "(?:Worker\s+)?Version ID:\s*([0-9a-fA-F-]{36})",
        [Text.RegularExpressions.RegexOptions]::IgnoreCase
    )
    $origin = if ($originMatch.Success) { $originMatch.Value.TrimEnd("/") } else { $null }
    $currentVersionId = if ($versionMatch.Success) { $versionMatch.Groups[1].Value } else { $null }
    $deploymentOutput = $null
    if ([string]::IsNullOrWhiteSpace($currentVersionId)) {
        $afterStatus = Invoke-NpxCaptured -Arguments @("wrangler", "deployments", "status", "--name", $WorkerName, "--json") -WorkingDirectory $GatewayDirectory
        if ($afterStatus.exit_code -eq 0) {
            $afterStatusJson = $afterStatus.stdout | ConvertFrom-Json -Depth 20
            $afterVersions = @($afterStatusJson.versions)
            if ($afterVersions.Count -eq 1 -and [decimal]$afterVersions[0].percentage -eq 100) {
                $currentVersionId = [string]$afterVersions[0].version_id
            }
        }
    }
    if ($origin -notmatch $ExpectedOriginPattern -or $currentVersionId -notmatch "^[0-9a-fA-F-]{36}$") {
        throw "The Worker origin or deployment identity could not be verified."
    }

    $vault.worker_origin = $origin
    $vault.current_version_id = $currentVersionId
    $vault.deployed_at_utc = [DateTime]::UtcNow.ToString("o")
    Write-ConnectorVault -Vault $vault
    $deploymentSucceeded = $true

    $phase = "disabled-mode verification"
    & (Join-Path $BundleRoot "VERIFY_GATEWAY_DISABLED.ps1") -WorkerOrigin $origin 1>$null
    $reportPath = Get-VerificationReportPath
    if (-not (Test-Path -LiteralPath $reportPath -PathType Leaf)) {
        throw "The disabled-mode verification report is missing."
    }
    $report = Get-Content -LiteralPath $reportPath -Raw -Encoding utf8 | ConvertFrom-Json -Depth 30
    if (
        $report.result -ne "PASS" -or
        $report.publication_mode -ne "DISABLED" -or
        $report.publication_ready -ne $false -or
        $report.github_publication_transport -ne "DEFERRED_WHILE_DISABLED" -or
        [int]$report.github_transport_constructor_count -ne 0 -or
        [int]$report.api_github_request_count -ne 0
    ) {
        throw "The disabled-mode verification did not pass."
    }

    $finalOutput = @(
        "DEPLOYMENT_RESULT=SUCCESS",
        "WORKER_NAME=$WorkerName",
        "CLOUDFLARE_ACCOUNT_ID=$CloudflareAccountId",
        "WORKER_VERSION_ID=$currentVersionId",
        "WORKERS_DEV_ORIGIN=$origin"
    )
    foreach ($definition in $definitions) {
        $finalOutput += "CONNECTOR_URL_$($definition.observer_id)=$origin$($definition.path)"
    }
    $finalOutput += "VERIFICATION_STATUS=PASS"
}
catch {
    $failureMessage = "R12C operator deployment stopped during $phase. No secret value was printed."
}
finally {
    $secretJson = $null
    if ($null -ne $plainTokens) {
        foreach ($key in @($plainTokens.Keys)) {
            $plainTokens[$key] = $null
        }
        $plainTokens.Clear()
        $plainTokens = $null
    }
    if ($null -ne $secretTempFile -and (Test-Path -LiteralPath $secretTempFile)) {
        Remove-Item -LiteralPath $secretTempFile -Force -ErrorAction SilentlyContinue
    }
    if ($null -ne $secretTempFile -and (Test-Path -LiteralPath $secretTempFile)) {
        $cleanupFailed = $true
    }
    if ($null -ne $secretTempDirectory -and (Test-Path -LiteralPath $secretTempDirectory)) {
        Remove-Item -LiteralPath $secretTempDirectory -Force -Recurse -ErrorAction SilentlyContinue
    }
    if ($null -ne $secretTempDirectory -and (Test-Path -LiteralPath $secretTempDirectory)) {
        $cleanupFailed = $true
    }
    if ($null -ne $operatorTemp -and (Test-Path -LiteralPath $operatorTemp)) {
        Remove-Item -LiteralPath $operatorTemp -Force -Recurse -ErrorAction SilentlyContinue
    }
    $env:CLOUDFLARE_ACCOUNT_ID = $priorAccountEnvironment
    $env:PATH = $priorPath
    $env:NO_COLOR = $priorNoColor
    $env:FORCE_COLOR = $priorForceColor
    $env:npm_config_offline = $priorNpmOffline
}

if ($cleanupFailed) {
    throw "R12C operator deployment stopped because temporary-secret cleanup could not be proven."
}
if ($null -ne $failureMessage) {
    throw $failureMessage
}
if (-not $deploymentSucceeded) {
    throw "R12C operator deployment did not complete."
}
$finalOutput | Write-Output
