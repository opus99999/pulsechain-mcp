#Requires -Version 7.4

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern("^[0-9A-Fa-f]{32}$")]
    [string]$CloudflareAccountId,

    [Parameter(Mandatory = $true)]
    [ValidateSet("I_HAVE_EXCLUSIVE_CHANGE_FREEZE")]
    [string]$ChangeFreezeConfirmation
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$VerbosePreference = "SilentlyContinue"
$DebugPreference = "SilentlyContinue"
$InformationPreference = "SilentlyContinue"
$PSNativeCommandUseErrorActionPreference = $false

$BundleRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$GatewayDirectory = Join-Path $BundleRoot "external_observer_grok_mcp_gateway"
$WorkerName = "pulsechain-external-observer-grok-mcp"
$ExpectedAccountId = "dade45b2875ee5e98c74b5d06528cd9c"
$ExpectedOrigin = "https://pulsechain-external-observer-grok-mcp.pulsechain-research-dade45b2.workers.dev"
$ExpectedAccountSubdomain = "pulsechain-research-dade45b2"
$ExpectedControlRoomOrigin = "https://pulsechain-research-control-room.brohexphiat.chatgpt.site"
$ExpectedPriorDeploymentId = "c776a6e0-14b8-49bc-be9a-7aa0e63c5495"
$ExpectedPriorVersionId = "e32f2b34-a572-404e-b969-44c0bf2c9088"
$ExpectedR12DSourceBranch = "external-observer-grok-mcp-r12d-windows-acl-repair-20260828"
$ExpectedR12DSourceCommit = "ec70832c69f847ea413666de095ce3d56534ea28"
$ExpectedR12DSourceTree = "35e17b896403d02d160f3a4d902ea2e66845799c"
$ExpectedR12FSourceBranch = "external-observer-grok-mcp-r12f-control-room-read-resilience-20260828"
$ExpectedR12FSourceCommit = "ebef6c42a5eca2ad30669cf856e669a19e10edf9"
$ExpectedR12FSourceTree = "e4db0de410f89b32a9dca0f3bd1388c0272664e7"
$ExpectedR12FSourceParent = "ec70832c69f847ea413666de095ce3d56534ea28"
$ExpectedBundleFilename = "PulseChain_External_Grok_Observer_Gateway_Update_Bundle_R12F_20260828T145225Z.zip"
$ExpectedCompatibilityDate = "2026-08-27"
$ExpectedCompatibilityFlags = @("nodejs_compat")
$ExpectedWranglerVersion = "4.92.0"
$ExpectedSecretLabels = @(
    "GROK_MCP_TOKEN_X_PROTOCOL",
    "GROK_MCP_TOKEN_INFRASTRUCTURE_INCIDENTS",
    "GROK_MCP_TOKEN_MARKET_LIQUIDITY",
    "GROK_MCP_TOKEN_IDENTITY_EVIDENCE",
    "GROK_MCP_TOKEN_RED_TEAM"
) | Sort-Object
$VersionTag = "r12f-" + $ExpectedR12FSourceCommit.Substring(0, 12)
$VersionMessage = "R12F branch=$ExpectedR12FSourceBranch commit=$ExpectedR12FSourceCommit tree=$ExpectedR12FSourceTree"
$DeploymentMessage = "R12F bounded Control Room read resilience $ExpectedR12FSourceCommit"
$WindowsReservedName = "^(?i:(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?)$"
$phase = "BUNDLE_VALIDATION"
$operatorTemp = $null
$vaultBaseline = $null
$newVersionId = $null
$newDeploymentId = $null
$uploadInvocations = 0
$deploymentInvocations = 0
$verifierInvocations = 0
$trafficChanged = $false
$uploadOccurred = $false
$updateSucceeded = $false
$caughtFailure = $null
$preUpdate = $null
$preVersionIds = @()
$upload = $null
$deployment = $null
$priorAccountEnvironment = $env:CLOUDFLARE_ACCOUNT_ID
$priorPath = $env:PATH
$priorNoColor = $env:NO_COLOR
$priorForceColor = $env:FORCE_COLOR
$priorNpmOffline = $env:npm_config_offline
$priorWranglerOutputPath = $env:WRANGLER_OUTPUT_FILE_PATH
$priorWranglerMetrics = $env:WRANGLER_SEND_METRICS

function Set-UpdatePhase {
    param([Parameter(Mandatory = $true)][string]$Name)
    $script:phase = $Name
    if (Get-Command Set-OperatorPhase -ErrorAction SilentlyContinue) {
        Set-OperatorPhase -Name $Name
    }
}

function Get-FileSha256 {
    param([Parameter(Mandatory = $true)][string]$Path)
    [byte[]]$bytes = [IO.File]::ReadAllBytes($Path)
    try {
        [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()
    }
    finally {
        [Array]::Clear($bytes, 0, $bytes.Length)
    }
}

function Resolve-SafeBundlePath {
    param([Parameter(Mandatory = $true)][string]$RelativePath)
    if (
        [string]::IsNullOrWhiteSpace($RelativePath) -or
        $RelativePath.Length -gt 240 -or
        [IO.Path]::IsPathRooted($RelativePath) -or
        $RelativePath.Contains("\") -or
        $RelativePath.Contains(":") -or
        $RelativePath.EndsWith("/")
    ) {
        throw "BUNDLE_PATH_UNSAFE"
    }
    foreach ($segment in $RelativePath.Split("/")) {
        if (
            $segment -in @("", ".", "..") -or
            $segment.EndsWith(".") -or
            $segment.EndsWith(" ") -or
            $segment -match $WindowsReservedName
        ) {
            throw "BUNDLE_PATH_UNSAFE"
        }
    }
    $resolved = [IO.Path]::GetFullPath((Join-Path $BundleRoot $RelativePath))
    $prefix = $BundleRoot.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    if (-not $resolved.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw "BUNDLE_PATH_ESCAPE"
    }
    $resolved
}

function Assert-BundleIntegrity {
    if ((Split-Path -Leaf $BundleRoot) -cne [IO.Path]::GetFileNameWithoutExtension($ExpectedBundleFilename)) {
        throw "BUNDLE_DIRECTORY_IDENTITY_MISMATCH"
    }
    $sumPath = Join-Path $BundleRoot "SHA256SUMS.txt"
    $inventoryPath = Join-Path $BundleRoot "ARTIFACT_INVENTORY.json"
    $sourceManifestPath = Join-Path $BundleRoot "SOURCE_MANIFEST.json"
    $expectationsPath = Join-Path $BundleRoot "DEPLOYMENT_EXPECTATIONS.json"
    foreach ($required in @($sumPath, $inventoryPath, $sourceManifestPath, $expectationsPath)) {
        if (-not (Test-Path -LiteralPath $required -PathType Leaf)) {
            throw "BUNDLE_GOVERNANCE_FILE_MISSING"
        }
    }

    $allItems = @(Get-ChildItem -LiteralPath $BundleRoot -Force -Recurse)
    $rootItem = Get-Item -LiteralPath $BundleRoot -Force
    if (($rootItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw "BUNDLE_REPARSE_POINT_REJECTED"
    }
    foreach ($item in $allItems) {
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "BUNDLE_REPARSE_POINT_REJECTED"
        }
    }

    $actualPaths = @(
        $allItems |
            Where-Object { -not $_.PSIsContainer } |
            ForEach-Object { [IO.Path]::GetRelativePath($BundleRoot, $_.FullName).Replace("\", "/") } |
            Sort-Object
    )
    $caseFolded = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($relativePath in $actualPaths) {
        [void](Resolve-SafeBundlePath -RelativePath $relativePath)
        if (-not $caseFolded.Add($relativePath)) {
            throw "BUNDLE_CASE_FOLD_COLLISION"
        }
        if (
            $relativePath -match "(?i)(?:^|/)(?:node_modules|\.git|\.wrangler)(?:/|$)" -or
            $relativePath -match "(?i)(?:^|/)(?:\.env(?:\..*)?|connector-tokens\.dpapi\.json|LOCAL_DISABLED_MODE_VERIFICATION(?:_R12F)?\.json)$" -or
            $relativePath -match "(?i)\.(?:log|map|pem|key|pfx|p12)$" -or
            $relativePath -match "(?i)(?:^|/)SHOW_GROK_CONNECTOR_TOKEN\.ps1$"
        ) {
            throw "BUNDLE_FORBIDDEN_MEMBER"
        }
    }

    $checksumPaths = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    foreach ($line in Get-Content -LiteralPath $sumPath -Encoding utf8) {
        if ($line -notmatch "^([0-9a-f]{64})  ([A-Za-z0-9._/-]+)$") {
            throw "BUNDLE_CHECKSUM_LINE_INVALID"
        }
        $expectedHash = $Matches[1]
        $relativePath = $Matches[2]
        if (-not $checksumPaths.Add($relativePath)) {
            throw "BUNDLE_CHECKSUM_PATH_DUPLICATE"
        }
        $path = Resolve-SafeBundlePath -RelativePath $relativePath
        if (-not (Test-Path -LiteralPath $path -PathType Leaf) -or (Get-FileSha256 -Path $path) -cne $expectedHash) {
            throw "BUNDLE_CHECKSUM_MISMATCH"
        }
    }
    $expectedChecksumPaths = @($actualPaths | Where-Object { $_ -notin @("SHA256SUMS.txt", "ARTIFACT_INVENTORY.json") })
    if (($expectedChecksumPaths -join "`n") -cne (@($checksumPaths | Sort-Object) -join "`n")) {
        throw "BUNDLE_CHECKSUM_FILE_SET_MISMATCH"
    }

    $inventory = Get-Content -LiteralPath $inventoryPath -Raw -Encoding utf8 | ConvertFrom-Json -Depth 100
    $inventoryEntries = @($inventory.artifacts)
    $expectedInventoryPaths = @($actualPaths | Where-Object { $_ -cne "ARTIFACT_INVENTORY.json" })
    if (
        $inventory.schema_version -ne "pulsechain-external-observer-r12f-update-inventory@1.0.0" -or
        [int]$inventory.artifact_count_excluding_inventory -ne $expectedInventoryPaths.Count -or
        $inventoryEntries.Count -ne $expectedInventoryPaths.Count -or
        (@($inventoryEntries.path | Sort-Object) -join "`n") -cne ($expectedInventoryPaths -join "`n")
    ) {
        throw "BUNDLE_INVENTORY_INVALID"
    }
    foreach ($entry in $inventoryEntries) {
        $path = Resolve-SafeBundlePath -RelativePath ([string]$entry.path)
        $info = Get-Item -LiteralPath $path
        if ([int64]$entry.byte_size -ne $info.Length -or [string]$entry.sha256 -cne (Get-FileSha256 -Path $path)) {
            throw "BUNDLE_INVENTORY_IDENTITY_MISMATCH"
        }
    }
    if (
        $inventory.scans.security_scan -ne "PASS" -or
        $inventory.scans.secret_scan -ne "PASS" -or
        [int]$inventory.scans.source_map_count -ne 0 -or
        $inventory.scans.path_safety -ne "PASS"
    ) {
        throw "BUNDLE_EXECUTABLE_SCAN_ATTESTATION_INVALID"
    }

    $source = Get-Content -LiteralPath $sourceManifestPath -Raw -Encoding utf8 | ConvertFrom-Json -Depth 100
    if (
        $source.schema_version -ne "pulsechain-external-observer-r12f-source-manifest@1.0.0" -or
        $source.source.branch -ne $ExpectedR12FSourceBranch -or
        $source.source.commit -ne $ExpectedR12FSourceCommit -or
        $source.source.tree -ne $ExpectedR12FSourceTree -or
        $source.source.parent -ne $ExpectedR12FSourceParent -or
        $source.worker.name -ne $WorkerName -or
        $source.worker.origin -ne $ExpectedOrigin -or
        $source.worker.publication_mode -ne "DISABLED" -or
        $source.worker.control_room_origin -ne $ExpectedControlRoomOrigin -or
        $source.worker.compatibility_date -ne $ExpectedCompatibilityDate -or
        @($source.worker.compatibility_flags).Count -ne 1 -or
        $source.worker.compatibility_flags[0] -ne "nodejs_compat"
    ) {
        throw "BUNDLE_SOURCE_MANIFEST_INVALID"
    }

    $expectations = Get-Content -LiteralPath $expectationsPath -Raw -Encoding utf8 | ConvertFrom-Json -Depth 100
    $expectedLabels = @($expectations.exact_pre_update_state.connector_secret_labels | Sort-Object)
    if (
        $expectations.schema_version -ne "pulsechain-external-observer-r12f-update-expectations@1.0.0" -or
        $expectations.source.commit -ne $ExpectedR12FSourceCommit -or
        $expectations.source.tree -ne $ExpectedR12FSourceTree -or
        $expectations.source.parent -ne $ExpectedR12DSourceCommit -or
        $expectations.exact_pre_update_state.account_id -ne $ExpectedAccountId -or
        $expectations.exact_pre_update_state.worker_name -ne $WorkerName -or
        $expectations.exact_pre_update_state.worker_origin -ne $ExpectedOrigin -or
        $expectations.exact_pre_update_state.active_deployment_id -ne $ExpectedPriorDeploymentId -or
        $expectations.exact_pre_update_state.active_version_id -ne $ExpectedPriorVersionId -or
        [decimal]$expectations.exact_pre_update_state.traffic_percent -ne 100 -or
        $expectations.exact_pre_update_state.variables.PUBLICATION_MODE -ne "DISABLED" -or
        $expectations.exact_pre_update_state.variables.CONTROL_ROOM_ORIGIN -ne $ExpectedControlRoomOrigin -or
        ($expectedLabels -join "`n") -cne ($ExpectedSecretLabels -join "`n") -or
        [int]$expectations.exact_pre_update_state.github_secret_count -ne 0 -or
        $expectations.exact_pre_update_state.workers_dev_enabled -ne $true -or
        $expectations.exact_pre_update_state.preview_urls_enabled -ne $false -or
        $expectations.update.wrangler_version -ne $ExpectedWranglerVersion -or
        $expectations.update.secret_file_used -ne $false -or
        [int]$expectations.update.secret_mutations -ne 0 -or
        $expectations.update.rollback_version_id -ne $ExpectedPriorVersionId
    ) {
        throw "BUNDLE_DEPLOYMENT_EXPECTATIONS_INVALID"
    }

    foreach ($requiredRelativePath in @(
        "OPERATOR_COMMON.ps1",
        "TEST_WINDOWS_OPERATOR_ACL.ps1",
        "VERIFY_GATEWAY_DISABLED_R12F.mjs",
        "VERIFY_GATEWAY_DISABLED_R12F.ps1",
        "VERIFY_CLOUDFLARE_R12F.mjs",
        "R13_POST_UPDATE_VERIFICATION_PROMPT.md",
        "ROLLBACK_R12F.md",
        "external_observer_grok_mcp_gateway/wrangler.toml",
        "external_observer_grok_mcp_gateway/package.json"
    )) {
        if (-not (Test-Path -LiteralPath (Resolve-SafeBundlePath -RelativePath $requiredRelativePath) -PathType Leaf)) {
            throw "BUNDLE_REQUIRED_MEMBER_MISSING"
        }
    }
}

function Invoke-NativeCaptured {
    param(
        [Parameter(Mandatory = $true)][string]$FilePath,
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$WorkingDirectory
    )
    $errorPath = Join-Path $operatorTemp ("native-" + [Guid]::NewGuid().ToString("N") + ".err")
    Push-Location $WorkingDirectory
    try {
        $stdout = @(& $FilePath @Arguments 2> $errorPath)
        $exitCode = $LASTEXITCODE
        $stderr = if (Test-Path -LiteralPath $errorPath -PathType Leaf) {
            Get-Content -LiteralPath $errorPath -Raw -Encoding utf8
        }
        else { "" }
        [pscustomobject]@{
            exit_code = $exitCode
            stdout = $stdout -join [Environment]::NewLine
            stderr = $stderr
        }
    }
    finally {
        Pop-Location
        if (Test-Path -LiteralPath $errorPath) {
            Remove-Item -LiteralPath $errorPath -Force -ErrorAction SilentlyContinue
        }
    }
}

function Invoke-WranglerCaptured {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)
    Invoke-NativeCaptured -FilePath "npx" -Arguments (@("--no-install", "wrangler") + $Arguments) -WorkingDirectory $GatewayDirectory
}

function Invoke-WranglerJson {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)
    $result = Invoke-WranglerCaptured -Arguments $Arguments
    if ($result.exit_code -ne 0 -or [string]::IsNullOrWhiteSpace($result.stdout)) {
        throw "WRANGLER_READ_FAILED"
    }
    try {
        $result.stdout | ConvertFrom-Json -Depth 100
    }
    catch {
        throw "WRANGLER_JSON_INVALID"
    }
}

function Invoke-WranglerWithReceipt {
    param(
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$ReceiptPath
    )
    if (Test-Path -LiteralPath $ReceiptPath) {
        Remove-Item -LiteralPath $ReceiptPath -Force
    }
    $saved = $env:WRANGLER_OUTPUT_FILE_PATH
    $env:WRANGLER_OUTPUT_FILE_PATH = $ReceiptPath
    try {
        $native = Invoke-WranglerCaptured -Arguments $Arguments
    }
    finally {
        $env:WRANGLER_OUTPUT_FILE_PATH = $saved
    }
    $receipts = @()
    if (Test-Path -LiteralPath $ReceiptPath -PathType Leaf) {
        Set-PrivateFileAcl -Path $ReceiptPath
        Assert-PrivateFileAcl -Path $ReceiptPath
        foreach ($line in Get-Content -LiteralPath $ReceiptPath -Encoding utf8) {
            if (-not [string]::IsNullOrWhiteSpace($line)) {
                try { $receipts += ($line | ConvertFrom-Json -Depth 30) }
                catch { throw "WRANGLER_RECEIPT_INVALID" }
            }
        }
    }
    [pscustomobject]@{ native = $native; receipts = @($receipts) }
}

function Get-AccessSddl {
    param([Parameter(Mandatory = $true)][string]$Path, [switch]$Directory)
    $sections = [Security.AccessControl.AccessControlSections]::Access
    $security = if ($Directory) {
        [IO.FileSystemAclExtensions]::GetAccessControl([IO.DirectoryInfo]::new($Path), $sections)
    }
    else {
        [IO.FileSystemAclExtensions]::GetAccessControl([IO.FileInfo]::new($Path), $sections)
    }
    $security.GetSecurityDescriptorSddlForm($sections)
}

function Get-VaultBaseline {
    $vaultPath = Get-ConnectorVaultPath
    if (-not (Test-Path -LiteralPath $vaultPath -PathType Leaf)) {
        throw "FINALIZED_VAULT_MISSING"
    }
    $stateDirectory = Split-Path -Parent $vaultPath
    Assert-PrivateDirectoryAcl -Path $stateDirectory
    Assert-PrivateFileAcl -Path $vaultPath
    [byte[]]$vaultBytes = [IO.File]::ReadAllBytes($vaultPath)
    try {
        $vaultText = [Text.Encoding]::UTF8.GetString($vaultBytes)
        $vault = $vaultText | ConvertFrom-Json -Depth 30
        $definitions = @(Get-ConnectorDefinitions)
        $observers = @($vault.tokens.PSObject.Properties.Name | Sort-Object)
        $expectedObservers = @($definitions.observer_id | Sort-Object)
        if (
            $vault.schema_version -ne "pulsechain-external-observer-connector-vault@1.0.0" -or
            $vault.worker_name -ne $WorkerName -or
            ([string]$vault.account_id).ToLowerInvariant() -cne $ExpectedAccountId -or
            $vault.worker_origin -ne $ExpectedOrigin -or
            $vault.current_version_id -ne $ExpectedPriorVersionId -or
            $null -ne $vault.prior_version_id -or
            $vault.source_branch -ne $ExpectedR12DSourceBranch -or
            $vault.source_commit -ne $ExpectedR12DSourceCommit -or
            $vault.source_tree -ne $ExpectedR12DSourceTree -or
            $vault.publication_mode -ne "DISABLED" -or
            [string]::IsNullOrWhiteSpace([string]$vault.created_at_utc) -or
            [string]::IsNullOrWhiteSpace([string]$vault.deployed_at_utc) -or
            ($observers -join "`n") -cne ($expectedObservers -join "`n")
        ) {
            throw "FINALIZED_VAULT_METADATA_MISMATCH"
        }
        [void][DateTimeOffset]::Parse([string]$vault.created_at_utc, [Globalization.CultureInfo]::InvariantCulture)
        [void][DateTimeOffset]::Parse([string]$vault.deployed_at_utc, [Globalization.CultureInfo]::InvariantCulture)
        foreach ($definition in $definitions) {
            $record = $vault.tokens.($definition.observer_id)
            if ($record.secret_label -ne $definition.token_label -or [string]::IsNullOrWhiteSpace([string]$record.ciphertext_base64)) {
                throw "FINALIZED_VAULT_RECORD_MISMATCH"
            }
            [byte[]]$cipher = [Convert]::FromBase64String([string]$record.ciphertext_base64)
            try {
                if ($cipher.Length -lt 32) { throw "FINALIZED_VAULT_CIPHERTEXT_INVALID" }
            }
            finally { [Array]::Clear($cipher, 0, $cipher.Length) }
        }
        $info = Get-Item -LiteralPath $vaultPath
        [pscustomobject][ordered]@{
            path = $vaultPath
            byte_size = $info.Length
            sha256 = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($vaultBytes)).ToLowerInvariant()
            last_write_ticks = $info.LastWriteTimeUtc.Ticks
            file_access_sddl = Get-AccessSddl -Path $vaultPath
            directory_access_sddl = Get-AccessSddl -Path $stateDirectory -Directory
        }
    }
    finally {
        $vault = $null
        $vaultText = $null
        [Array]::Clear($vaultBytes, 0, $vaultBytes.Length)
    }
}

function Assert-VaultUnchanged {
    param([Parameter(Mandatory = $true)][psobject]$Baseline)
    $current = Get-VaultBaseline
    foreach ($field in @("path", "byte_size", "sha256", "last_write_ticks", "file_access_sddl", "directory_access_sddl")) {
        if ([string]$current.$field -cne [string]$Baseline.$field) {
            throw "FINALIZED_VAULT_CHANGED"
        }
    }
}

function Invoke-CloudflareHelper {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)
    $auth = Invoke-WranglerCaptured -Arguments @("auth", "token", "--json")
    if ($auth.exit_code -ne 0 -or [string]::IsNullOrWhiteSpace($auth.stdout)) {
        throw "CLOUDFLARE_AUTH_HANDOFF_FAILED"
    }
    $nodePath = (Get-Command node -ErrorAction Stop).Source
    $helperPath = Join-Path $BundleRoot "VERIFY_CLOUDFLARE_R12F.mjs"
    $startInfo = [Diagnostics.ProcessStartInfo]::new()
    $startInfo.FileName = $nodePath
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardInput = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    [void]$startInfo.ArgumentList.Add($helperPath)
    foreach ($argument in $Arguments) { [void]$startInfo.ArgumentList.Add($argument) }
    foreach ($unsafeName in @("NODE_OPTIONS", "NODE_DEBUG", "NODE_INSPECT_RESUME_ON_START", "NODE_V8_COVERAGE")) {
        [void]$startInfo.Environment.Remove($unsafeName)
    }
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $startInfo
    $processStarted = $false
    try {
        if (-not $process.Start()) { throw "CLOUDFLARE_HELPER_START_FAILED" }
        $processStarted = $true
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        $process.StandardInput.Write($auth.stdout)
        $process.StandardInput.Close()
        $process.WaitForExitAsync().GetAwaiter().GetResult()
        $stdout = $stdoutTask.GetAwaiter().GetResult()
        $stderr = $stderrTask.GetAwaiter().GetResult()
        if ($process.ExitCode -ne 0 -or -not [string]::IsNullOrWhiteSpace($stderr) -or $stdout.Length -gt 4MB) {
            throw "CLOUDFLARE_HELPER_FAILED"
        }
        try { $record = $stdout | ConvertFrom-Json -Depth 100 }
        catch { throw "CLOUDFLARE_HELPER_JSON_INVALID" }
        if ($record.result -ne "PASS") { throw "CLOUDFLARE_HELPER_REPORTED_FAILURE" }
        $record
    }
    finally {
        $auth.stdout = $null
        $auth = $null
        if ($processStarted -and -not $process.HasExited) { $process.Kill($true) }
        $process.Dispose()
    }
}

function Get-CloudflareState {
    Invoke-CloudflareHelper -Arguments @("state", "--account-id", $ExpectedAccountId, "--worker-name", $WorkerName)
}

function Get-RemoteVersionContent {
    param([Parameter(Mandatory = $true)][string]$VersionId, [Parameter(Mandatory = $true)][string]$LocalUploadForm)
    Invoke-CloudflareHelper -Arguments @(
        "content", "--account-id", $ExpectedAccountId, "--worker-name", $WorkerName,
        "--version-id", $VersionId, "--local-upload-form", $LocalUploadForm
    )
}

function Get-RemoteSnapshot {
    param([Parameter(Mandatory = $true)][string]$ActiveVersionId)
    [pscustomobject][ordered]@{
        status = Invoke-WranglerJson -Arguments @("deployments", "status", "--name", $WorkerName, "--json")
        deployments = @(Invoke-WranglerJson -Arguments @("deployments", "list", "--name", $WorkerName, "--json"))
        versions = @(Invoke-WranglerJson -Arguments @("versions", "list", "--name", $WorkerName, "--json"))
        active_version = Invoke-WranglerJson -Arguments @("versions", "view", $ActiveVersionId, "--name", $WorkerName, "--json")
        secrets = @(Invoke-WranglerJson -Arguments @("secret", "list", "--name", $WorkerName, "--format", "json"))
        cloudflare = Get-CloudflareState
    }
}

function Get-Ids {
    param([AllowEmptyCollection()][object[]]$Records)
    @($Records | ForEach-Object { [string]$_.id } | Where-Object { $_ -match "^[0-9a-f-]{36}$" } | Sort-Object -Unique)
}

function Assert-VersionBindingContract {
    param(
        [Parameter(Mandatory = $true)][psobject]$Version,
        [Parameter(Mandatory = $true)][string]$ExpectedVersionId,
        [switch]$RequireR12FIdentity
    )
    if (
        $Version.id -ne $ExpectedVersionId -or
        $Version.resources.script_runtime.compatibility_date -ne $ExpectedCompatibilityDate -or
        @($Version.resources.script_runtime.compatibility_flags).Count -ne 1 -or
        $Version.resources.script_runtime.compatibility_flags[0] -ne "nodejs_compat" -or
        @($Version.resources.script.handlers).Count -ne 1 -or
        $Version.resources.script.handlers[0] -ne "fetch"
    ) {
        throw "WORKER_VERSION_RUNTIME_MISMATCH"
    }
    $projection = [Collections.Generic.List[string]]::new()
    foreach ($binding in @($Version.resources.bindings)) {
        if ($binding.type -eq "plain_text") {
            [void]$projection.Add("plain_text|$($binding.name)|$($binding.text)")
        }
        elseif ($binding.type -eq "secret_text") {
            [void]$projection.Add("secret_text|$($binding.name)")
        }
        else {
            throw "UNEXPECTED_WORKER_BINDING"
        }
    }
    $expectedProjection = @(
        "plain_text|CONTROL_ROOM_ORIGIN|$ExpectedControlRoomOrigin",
        "plain_text|PUBLICATION_MODE|DISABLED"
    ) + @($ExpectedSecretLabels | ForEach-Object { "secret_text|$_" })
    if ((@($projection | Sort-Object) -join "`n") -cne (@($expectedProjection | Sort-Object) -join "`n")) {
        throw "WORKER_BINDING_SET_MISMATCH"
    }
    if ($RequireR12FIdentity) {
        if (
            $Version.metadata.source -ne "wrangler" -or
            $Version.annotations."workers/tag" -ne $VersionTag -or
            $Version.annotations."workers/message" -ne $VersionMessage
        ) {
            throw "UPLOADED_SOURCE_IDENTITY_MISMATCH"
        }
    }
}

function Assert-ExactSecrets {
    param([Parameter(Mandatory = $true)][object[]]$Secrets)
    $names = @($Secrets | ForEach-Object { [string]$_.name } | Sort-Object)
    if ($Secrets.Count -ne 5 -or ($names -join "`n") -cne ($ExpectedSecretLabels -join "`n")) {
        throw "WORKER_SECRET_LABEL_SET_MISMATCH"
    }
    if (@($Secrets | Where-Object { $_.type -and $_.type -ne "secret_text" }).Count -ne 0) {
        throw "WORKER_SECRET_TYPE_MISMATCH"
    }
}

function Assert-CloudflareExpectedState {
    param([Parameter(Mandatory = $true)][psobject]$State)
    if (
        $State.account_id -ne $ExpectedAccountId -or
        $State.worker_name -ne $WorkerName -or
        $State.account_subdomain -ne $ExpectedAccountSubdomain -or
        $State.workers_dev_enabled -ne $true -or
        $State.preview_urls_enabled -ne $false -or
        $State.worker_origin -ne $ExpectedOrigin -or
        $State.last_deployed_from -ne "wrangler" -or
        [string]::IsNullOrWhiteSpace([string]$State.service_script_tag) -or
        [string]$State.script_settings_sha256 -notmatch "^[0-9a-f]{64}$"
    ) {
        throw "CLOUDFLARE_WORKER_STATE_MISMATCH"
    }
}

function Assert-ExactProductionState {
    param(
        [Parameter(Mandatory = $true)][psobject]$Snapshot,
        [Parameter(Mandatory = $true)][string]$DeploymentId,
        [Parameter(Mandatory = $true)][string]$VersionId
    )
    $traffic = @($Snapshot.status.versions)
    if (
        $Snapshot.status.id -ne $DeploymentId -or
        $traffic.Count -ne 1 -or
        $traffic[0].version_id -ne $VersionId -or
        [decimal]$traffic[0].percentage -ne 100
    ) {
        throw "PRODUCTION_TRAFFIC_STATE_MISMATCH"
    }
    if (@($Snapshot.deployments | Where-Object { $_.id -eq $DeploymentId }).Count -ne 1) {
        throw "DEPLOYMENT_ID_NOT_IN_HISTORY"
    }
    Assert-VersionBindingContract -Version $Snapshot.active_version -ExpectedVersionId $VersionId -RequireR12FIdentity:($VersionId -ne $ExpectedPriorVersionId)
    Assert-ExactSecrets -Secrets $Snapshot.secrets
    Assert-CloudflareExpectedState -State $Snapshot.cloudflare
}

function Assert-ProductionUnchanged {
    param([Parameter(Mandatory = $true)][psobject]$Baseline, [Parameter(Mandatory = $true)][psobject]$Candidate)
    Assert-ExactProductionState -Snapshot $Candidate -DeploymentId $ExpectedPriorDeploymentId -VersionId $ExpectedPriorVersionId
    if (
        (@(Get-Ids $Baseline.deployments) -join "`n") -cne (@(Get-Ids $Candidate.deployments) -join "`n") -or
        $Candidate.cloudflare.service_script_tag -cne $Baseline.cloudflare.service_script_tag -or
        $Candidate.cloudflare.script_settings_sha256 -cne $Baseline.cloudflare.script_settings_sha256
    ) {
        throw "PROTECTED_REMOTE_STATE_CHANGED"
    }
}

function Assert-OneAddedId {
    param(
        [Parameter(Mandatory = $true)][string[]]$Before,
        [Parameter(Mandatory = $true)][string[]]$After,
        [Parameter(Mandatory = $true)][string]$ExpectedAddedId
    )
    $added = @($After | Where-Object { $_ -notin $Before } | Sort-Object -Unique)
    if ($added.Count -ne 1 -or $added[0] -ne $ExpectedAddedId) {
        throw "REMOTE_MUTATION_DELTA_MISMATCH"
    }
    if ($Before.Count -lt 10 -and @($Before | Where-Object { $_ -notin $After }).Count -ne 0) {
        throw "REMOTE_HISTORY_REMOVAL_DETECTED"
    }
}

function Write-PrivateOperatorFile {
    param([Parameter(Mandatory = $true)][string]$Path, [Parameter(Mandatory = $true)][string]$Text)
    $directory = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $directory -PathType Container)) {
        throw "OPERATOR_STATE_DIRECTORY_MISSING"
    }
    $temporary = Join-Path $directory (".r12f-" + [Guid]::NewGuid().ToString("N"))
    try {
        [IO.File]::WriteAllText($temporary, $Text, [Text.UTF8Encoding]::new($false))
        Set-PrivateFileAcl -Path $temporary
        Assert-PrivateFileAcl -Path $temporary
        [IO.File]::Move($temporary, $Path, $true)
        Set-PrivateFileAcl -Path $Path
        Assert-PrivateFileAcl -Path $Path
    }
    finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue }
    }
}

function Write-UpdateReceipt {
    param([Parameter(Mandatory = $true)][string]$Status, [AllowNull()][string]$VerifierResult = $null)
    $receipt = [pscustomobject][ordered]@{
        schema_version = "pulsechain-external-observer-r12f-update-receipt@1.0.0"
        status = $Status
        recorded_at_utc = [DateTime]::UtcNow.ToString("o")
        account_id = $ExpectedAccountId
        worker_name = $WorkerName
        worker_origin = $ExpectedOrigin
        source_branch = $ExpectedR12FSourceBranch
        source_commit = $ExpectedR12FSourceCommit
        source_tree = $ExpectedR12FSourceTree
        prior_deployment_id = $ExpectedPriorDeploymentId
        prior_version_id = $ExpectedPriorVersionId
        uploaded_version_id = $newVersionId
        deployment_id = $newDeploymentId
        traffic_changed = $trafficChanged
        verifier_result = $VerifierResult
        connector_vault_modified = $false
        secret_mutations = 0
    }
    $path = Join-Path (Get-OperatorStateDirectory) "R12F_UPDATE_RECEIPT.json"
    Write-PrivateOperatorFile -Path $path -Text (($receipt | ConvertTo-Json -Depth 20) + [Environment]::NewLine)
}

try {
    if (-not $IsWindows) { throw "WINDOWS_REQUIRED" }
    if ($PSVersionTable.PSVersion -lt [Version]"7.4.0") { throw "POWERSHELL_7_4_REQUIRED" }
    if ($CloudflareAccountId.ToLowerInvariant() -cne $ExpectedAccountId) { throw "CLOUDFLARE_ACCOUNT_ID_MISMATCH" }
    if ($ChangeFreezeConfirmation -cne "I_HAVE_EXCLUSIVE_CHANGE_FREEZE") { throw "EXCLUSIVE_CHANGE_FREEZE_REQUIRED" }

    Assert-BundleIntegrity
    . (Join-Path $BundleRoot "OPERATOR_COMMON.ps1")
    Assert-WindowsOperator

    Set-UpdatePhase "WINDOWS_ACL_PREFLIGHT"
    $powerShellPath = (Get-Process -Id $PID).Path
    $aclOutput = @(& $powerShellPath -NoLogo -NoProfile -NonInteractive -File (Join-Path $BundleRoot "TEST_WINDOWS_OPERATOR_ACL.ps1") 2>&1)
    $aclFinal = if ($aclOutput.Count) { [string]$aclOutput[-1] } else { "" }
    if ($LASTEXITCODE -ne 0 -or $aclFinal -cne "TOTAL=25 PASS=25 FAIL=0") {
        throw "WINDOWS_OPERATOR_ACL_PREFLIGHT_FAILED"
    }
    $aclOutput = $null

    foreach ($commandName in @("node", "npm", "npx")) {
        if ($null -eq (Get-Command $commandName -ErrorAction SilentlyContinue)) { throw "NODE_RUNTIME_REQUIRED" }
    }
    $nodeVersion = (& node --version 2>$null).Trim().TrimStart("v")
    if ($LASTEXITCODE -ne 0 -or [Version]$nodeVersion -lt [Version]"22.13.0") { throw "NODE_VERSION_UNSUPPORTED" }

    Set-UpdatePhase "FINALIZED_VAULT_PREFLIGHT"
    $vaultBaseline = Get-VaultBaseline

    $operatorTemp = Join-Path ([IO.Path]::GetTempPath()) ("pulsechain-r12f-update-" + [Guid]::NewGuid().ToString("N"))
    [void][IO.Directory]::CreateDirectory($operatorTemp)
    Set-PrivateDirectoryAcl -Path $operatorTemp
    Assert-PrivateDirectoryAcl -Path $operatorTemp

    Set-UpdatePhase "PINNED_DEPENDENCY_INSTALL"
    $npmResult = Invoke-NativeCaptured -FilePath "npm" -Arguments @("--prefix", $BundleRoot, "ci", "--ignore-scripts", "--no-audit", "--no-fund") -WorkingDirectory $BundleRoot
    if ($npmResult.exit_code -ne 0) { throw "PINNED_DEPENDENCY_INSTALL_FAILED" }
    $wranglerPackage = Get-Content -LiteralPath (Join-Path $BundleRoot "node_modules\wrangler\package.json") -Raw -Encoding utf8 | ConvertFrom-Json
    if ($wranglerPackage.version -ne $ExpectedWranglerVersion) { throw "WRANGLER_PACKAGE_VERSION_MISMATCH" }
    $env:PATH = (Join-Path $BundleRoot "node_modules\.bin") + [IO.Path]::PathSeparator + $env:PATH
    $env:npm_config_offline = "true"
    $env:NO_COLOR = "1"
    $env:FORCE_COLOR = "0"
    $env:WRANGLER_SEND_METRICS = "false"
    $wranglerVersion = (& npx --no-install wrangler --version 2>$null).Trim()
    if ($LASTEXITCODE -ne 0 -or $wranglerVersion -ne $ExpectedWranglerVersion) { throw "PINNED_WRANGLER_UNAVAILABLE" }
    $env:CLOUDFLARE_ACCOUNT_ID = $ExpectedAccountId

    Set-UpdatePhase "LOCAL_SOURCE_TESTS"
    $gatewayTests = Invoke-NativeCaptured -FilePath "npm" -Arguments @("--prefix", $GatewayDirectory, "run", "validate") -WorkingDirectory $GatewayDirectory
    if ($gatewayTests.exit_code -ne 0) { throw "GATEWAY_VALIDATION_FAILED" }
    $verifierTestPath = @(
        (Join-Path $BundleRoot "operator-tests\node-verifier.test.mjs"),
        (Join-Path $BundleRoot "tests\node-verifier.test.mjs")
    ) | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
    if ([string]::IsNullOrWhiteSpace([string]$verifierTestPath)) { throw "NODE_VERIFIER_TEST_MISSING" }
    $verifierTests = Invoke-NativeCaptured -FilePath "node" -Arguments @("--test", $verifierTestPath) -WorkingDirectory $BundleRoot
    if ($verifierTests.exit_code -ne 0) { throw "NODE_VERIFIER_TEST_FAILED" }

    Set-UpdatePhase "CLOUDFLARE_AUTHENTICATION"
    $whoami = Invoke-WranglerJson -Arguments @("whoami", "--json")
    $matchingAccounts = @($whoami.accounts | Where-Object { ([string]$_.id).ToLowerInvariant() -ceq $ExpectedAccountId })
    if ($whoami.loggedIn -ne $true -or $matchingAccounts.Count -ne 1) { throw "CLOUDFLARE_AUTHENTICATED_ACCOUNT_MISMATCH" }

    Set-UpdatePhase "EXACT_PRE_UPDATE_STATE"
    $preUpdate = Get-RemoteSnapshot -ActiveVersionId $ExpectedPriorVersionId
    Assert-ExactProductionState -Snapshot $preUpdate -DeploymentId $ExpectedPriorDeploymentId -VersionId $ExpectedPriorVersionId
    $preVersionIds = @(Get-Ids $preUpdate.versions)
    $latestPreVersion = @($preUpdate.versions | Sort-Object { [DateTimeOffset]::Parse([string]$_.metadata.created_on) } -Descending | Select-Object -First 1)
    if ($latestPreVersion.Count -ne 1 -or $latestPreVersion[0].id -ne $ExpectedPriorVersionId) {
        throw "UNDEPLOYED_DRAFT_VERSION_PRESENT"
    }
    Assert-VaultUnchanged -Baseline $vaultBaseline

    Set-UpdatePhase "VERSION_UPLOAD"
    $uploadReceiptPath = Join-Path $operatorTemp "wrangler-version-upload.jsonl"
    $uploadFormPath = Join-Path $operatorTemp "r12f-worker-upload-form.bin"
    $uploadInvocations += 1
    $upload = Invoke-WranglerWithReceipt -ReceiptPath $uploadReceiptPath -Arguments @(
        "versions", "upload",
        "--config", "wrangler.toml",
        "--name", $WorkerName,
        "--keep-vars",
        "--compatibility-date", $ExpectedCompatibilityDate,
        "--compatibility-flag", "nodejs_compat",
        "--tag", $VersionTag,
        "--message", $VersionMessage,
        "--outfile", $uploadFormPath
    )
    if ($uploadInvocations -ne 1) { throw "VERSION_UPLOAD_INVOCATION_COUNT_INVALID" }
    if ($upload.native.exit_code -ne 0) {
        throw "VERSION_UPLOAD_AMBIGUOUS_NO_RETRY"
    }
    $uploadReceipts = @($upload.receipts | Where-Object { $_.type -eq "version-upload" -and [int]$_.version -eq 1 })
    if (
        $uploadReceipts.Count -ne 1 -or
        $uploadReceipts[0].worker_name -ne $WorkerName -or
        $uploadReceipts[0].worker_name_overridden -eq $true -or
        [string]$uploadReceipts[0].preview_url -ne "" -or
        [string]$uploadReceipts[0].preview_alias_url -ne "" -or
        [string]$uploadReceipts[0].version_id -notmatch "^[0-9a-f-]{36}$"
    ) {
        throw "VERSION_UPLOAD_RECEIPT_MISMATCH"
    }
    $newVersionId = [string]$uploadReceipts[0].version_id
    $uploadOccurred = $true
    if (-not (Test-Path -LiteralPath $uploadFormPath -PathType Leaf)) { throw "LOCAL_UPLOAD_FORM_MISSING" }
    Set-PrivateFileAcl -Path $uploadFormPath
    Assert-PrivateFileAcl -Path $uploadFormPath

    Set-UpdatePhase "UPLOADED_VERSION_READBACK"
    $afterUpload = Get-RemoteSnapshot -ActiveVersionId $ExpectedPriorVersionId
    Assert-ProductionUnchanged -Baseline $preUpdate -Candidate $afterUpload
    Assert-OneAddedId -Before $preVersionIds -After @(Get-Ids $afterUpload.versions) -ExpectedAddedId $newVersionId
    $newVersion = Invoke-WranglerJson -Arguments @("versions", "view", $newVersionId, "--name", $WorkerName, "--json")
    Assert-VersionBindingContract -Version $newVersion -ExpectedVersionId $newVersionId -RequireR12FIdentity
    $contentReadback = Get-RemoteVersionContent -VersionId $newVersionId -LocalUploadForm $uploadFormPath
    if (
        $contentReadback.local_remote_content_equal -ne $true -or
        [int]$contentReadback.local_source_map_count -ne 0 -or
        [int]$contentReadback.remote_source_map_count -ne 0 -or
        [string]::IsNullOrWhiteSpace([string]$contentReadback.local_entrypoint) -or
        $contentReadback.local_entrypoint -cne $contentReadback.remote_entrypoint
    ) {
        throw "UPLOADED_SOURCE_BYTE_READBACK_MISMATCH"
    }
    Assert-VaultUnchanged -Baseline $vaultBaseline
    Write-UpdateReceipt -Status "VERSION_UPLOADED_NOT_DEPLOYED"

    Set-UpdatePhase "FINAL_CHANGE_FREEZE_RECHECK"
    $preDeploy = Get-RemoteSnapshot -ActiveVersionId $ExpectedPriorVersionId
    Assert-ProductionUnchanged -Baseline $preUpdate -Candidate $preDeploy
    if ((@(Get-Ids $preDeploy.versions) -join "`n") -cne (@(Get-Ids $afterUpload.versions) -join "`n")) {
        throw "CONCURRENT_VERSION_CHANGE_DETECTED"
    }
    $newVersionPreDeploy = Invoke-WranglerJson -Arguments @("versions", "view", $newVersionId, "--name", $WorkerName, "--json")
    Assert-VersionBindingContract -Version $newVersionPreDeploy -ExpectedVersionId $newVersionId -RequireR12FIdentity
    Assert-VaultUnchanged -Baseline $vaultBaseline

    Set-UpdatePhase "SINGLE_PRODUCTION_DEPLOYMENT"
    $deploymentReceiptPath = Join-Path $operatorTemp "wrangler-version-deploy.jsonl"
    $deploymentInvocations += 1
    $deployment = Invoke-WranglerWithReceipt -ReceiptPath $deploymentReceiptPath -Arguments @(
        "versions", "deploy", ("{0}@100" -f $newVersionId),
        "--config", "wrangler.toml",
        "--name", $WorkerName,
        "--message", $DeploymentMessage,
        "--yes"
    )
    if ($deploymentInvocations -ne 1) { throw "DEPLOYMENT_INVOCATION_COUNT_INVALID" }
    if ($deployment.native.exit_code -ne 0) {
        throw "DEPLOYMENT_AMBIGUOUS_NO_RETRY"
    }
    $deploymentReceipts = @($deployment.receipts | Where-Object { $_.type -eq "version-deploy" -and [int]$_.version -eq 1 })
    if (
        $deploymentReceipts.Count -ne 1 -or
        $deploymentReceipts[0].worker_name -ne $WorkerName -or
        [string]$deploymentReceipts[0].deployment_id -notmatch "^[0-9a-f-]{36}$"
    ) {
        throw "DEPLOYMENT_RECEIPT_MISMATCH"
    }
    $newDeploymentId = [string]$deploymentReceipts[0].deployment_id
    $trafficChanged = $true

    Set-UpdatePhase "POST_DEPLOYMENT_READBACK"
    $postDeploy = Get-RemoteSnapshot -ActiveVersionId $newVersionId
    Assert-ExactProductionState -Snapshot $postDeploy -DeploymentId $newDeploymentId -VersionId $newVersionId
    Assert-OneAddedId -Before @(Get-Ids $preUpdate.deployments) -After @(Get-Ids $postDeploy.deployments) -ExpectedAddedId $newDeploymentId
    $rollbackVersion = Invoke-WranglerJson -Arguments @("versions", "view", $ExpectedPriorVersionId, "--name", $WorkerName, "--json")
    Assert-VersionBindingContract -Version $rollbackVersion -ExpectedVersionId $ExpectedPriorVersionId
    $contentAfterDeploy = Get-RemoteVersionContent -VersionId $newVersionId -LocalUploadForm $uploadFormPath
    if ($contentAfterDeploy.local_remote_content_equal -ne $true -or [int]$contentAfterDeploy.remote_source_map_count -ne 0) {
        throw "DEPLOYED_SOURCE_BYTE_READBACK_MISMATCH"
    }
    Assert-VaultUnchanged -Baseline $vaultBaseline
    Write-UpdateReceipt -Status "DEPLOYED_PENDING_GOVERNED_VERIFICATION"

    Set-UpdatePhase "GOVERNED_DISABLED_MODE_VERIFICATION"
    $verifierInvocations += 1
    $verifierErrorPath = Join-Path $operatorTemp "governed-verifier.err"
    $verifierOutput = @(& (Join-Path $BundleRoot "VERIFY_GATEWAY_DISABLED_R12F.ps1") -WorkerOrigin $ExpectedOrigin 2> $verifierErrorPath)
    $verifierExitCode = $LASTEXITCODE
    $verifierError = if (Test-Path -LiteralPath $verifierErrorPath -PathType Leaf) {
        Get-Content -LiteralPath $verifierErrorPath -Raw -Encoding utf8
    }
    else { "" }
    if ($verifierInvocations -ne 1) { throw "GOVERNED_VERIFIER_INVOCATION_COUNT_INVALID" }
    $verificationReportPath = Join-Path (Get-OperatorStateDirectory) "LOCAL_DISABLED_MODE_VERIFICATION_R12F.json"
    if (-not (Test-Path -LiteralPath $verificationReportPath -PathType Leaf)) {
        throw "GOVERNED_VERIFICATION_REPORT_MISSING"
    }
    Assert-PrivateFileAcl -Path $verificationReportPath
    $verificationReport = Get-Content -LiteralPath $verificationReportPath -Raw -Encoding utf8 | ConvertFrom-Json -Depth 100
    Assert-VaultUnchanged -Baseline $vaultBaseline

    if (
        $verifierExitCode -eq 0 -and
        [string]::IsNullOrWhiteSpace($verifierError) -and
        $verifierOutput.Count -eq 1 -and
        [string]$verifierOutput[0] -ceq "VERIFICATION_STATUS=PASS" -and
        $verificationReport.result -eq "PASS" -and
        $verificationReport.release_critical -eq $false -and
        $verificationReport.recommended_release_action -eq "R13_HANDOFF_READY"
    ) {
        $r13Source = Join-Path $BundleRoot "R13_POST_UPDATE_VERIFICATION_PROMPT.md"
        $r13Target = Join-Path (Get-OperatorStateDirectory) "R13_POST_UPDATE_VERIFICATION_PROMPT.md"
        Write-PrivateOperatorFile -Path $r13Target -Text ([IO.File]::ReadAllText($r13Source, [Text.Encoding]::UTF8))
        Write-UpdateReceipt -Status "UPDATE_VERIFIED_R13_HANDOFF_READY" -VerifierResult "PASS"
        $updateSucceeded = $true
    }
    elseif (
        $verificationReport.external_upstream_blocker_only -eq $true -and
        $verificationReport.release_critical -eq $false -and
        $verificationReport.recommended_release_action -eq "PRESERVE_DEPLOYED_R12F_REPORT_EXTERNAL_BLOCKER"
    ) {
        Write-UpdateReceipt -Status "DEPLOYED_CONTROL_ROOM_UPSTREAM_BLOCKED" -VerifierResult "CONTROL_ROOM_UPSTREAM_UNAVAILABLE"
        throw "R12F_EXTERNAL_UPSTREAM_BLOCKER_NO_ROLLBACK"
    }
    elseif ($verificationReport.release_critical -eq $true) {
        Write-UpdateReceipt -Status "DEPLOYED_RELEASE_CRITICAL_FAILURE_SEPARATE_ROLLBACK_AUTHORIZATION_REQUIRED" -VerifierResult ([string]$verificationReport.result)
        throw "R12F_RELEASE_CRITICAL_FAILURE_SEPARATE_ROLLBACK_AUTHORIZATION_REQUIRED"
    }
    else {
        Write-UpdateReceipt -Status "DEPLOYED_ORDINARY_VERIFICATION_FAILURE" -VerifierResult ([string]$verificationReport.result)
        throw "R12F_ORDINARY_VERIFICATION_FAILURE_NO_AUTOMATIC_ROLLBACK"
    }
}
catch {
    $caughtFailure = $_

    # A nonzero CLI result is never retried. Perform only a bounded read-only
    # reconciliation so an accepted-but-interrupted mutation is not concealed.
    if ($phase -in @("VERSION_UPLOAD", "SINGLE_PRODUCTION_DEPLOYMENT") -and $null -ne $preUpdate) {
        try {
            if ($null -eq $newVersionId -and $null -ne $upload) {
                $ambiguousUploadReceipts = @($upload.receipts | Where-Object {
                    $_.type -eq "version-upload" -and [string]$_.version_id -match "^[0-9a-f-]{36}$"
                })
                if ($ambiguousUploadReceipts.Count -eq 1) {
                    $newVersionId = [string]$ambiguousUploadReceipts[0].version_id
                    $uploadOccurred = $true
                }
            }
            if ($null -eq $newDeploymentId -and $null -ne $deployment) {
                $ambiguousDeploymentReceipts = @($deployment.receipts | Where-Object {
                    $_.type -eq "version-deploy" -and [string]$_.deployment_id -match "^[0-9a-f-]{36}$"
                })
                if ($ambiguousDeploymentReceipts.Count -eq 1) {
                    $newDeploymentId = [string]$ambiguousDeploymentReceipts[0].deployment_id
                }
            }

            $ambiguityVersions = @(Invoke-WranglerJson -Arguments @("versions", "list", "--name", $WorkerName, "--json"))
            $addedVersionIds = @((Get-Ids $ambiguityVersions) | Where-Object { $_ -notin $preVersionIds })
            if ($null -eq $newVersionId -and $addedVersionIds.Count -eq 1) {
                $newVersionId = $addedVersionIds[0]
                $uploadOccurred = $true
            }

            $ambiguityStatus = Invoke-WranglerJson -Arguments @("deployments", "status", "--name", $WorkerName, "--json")
            if ($ambiguityStatus.id -ne $ExpectedPriorDeploymentId) {
                $newDeploymentId = [string]$ambiguityStatus.id
                $trafficChanged = $true
            }
            Write-UpdateReceipt -Status "AMBIGUOUS_MUTATION_NO_RETRY_READBACK_RECORDED"
        }
        catch {
            # The final terminal record remains explicit that mutation state is
            # unresolved. It never retries either mutation command.
        }
    }
}
finally {
    if ($null -ne $vaultBaseline) {
        try { Assert-VaultUnchanged -Baseline $vaultBaseline }
        catch { $updateSucceeded = $false }
    }
    if ($null -ne $operatorTemp -and (Test-Path -LiteralPath $operatorTemp -PathType Container)) {
        Remove-Item -LiteralPath $operatorTemp -Force -Recurse -ErrorAction SilentlyContinue
    }
    $env:CLOUDFLARE_ACCOUNT_ID = $priorAccountEnvironment
    $env:PATH = $priorPath
    $env:NO_COLOR = $priorNoColor
    $env:FORCE_COLOR = $priorForceColor
    $env:npm_config_offline = $priorNpmOffline
    $env:WRANGLER_OUTPUT_FILE_PATH = $priorWranglerOutputPath
    $env:WRANGLER_SEND_METRICS = $priorWranglerMetrics
}

if ($null -ne $caughtFailure -or -not $updateSucceeded) {
    $failureCode = if (
        $null -ne $caughtFailure -and
        [string]$caughtFailure.Exception.Message -match "^[A-Z0-9_]+$"
    ) { [string]$caughtFailure.Exception.Message } else { "UNCLASSIFIED_STAGE_FAILURE" }
    throw "R12F_UPDATE_DID_NOT_COMPLETE failure_code=$failureCode phase=$phase upload_occurred=$uploadOccurred traffic_changed=$trafficChanged uploaded_version_id=$newVersionId deployment_id=$newDeploymentId"
}

@(
    "UPDATE_RESULT=SUCCESS",
    "WORKER_NAME=$WorkerName",
    "WORKER_ORIGIN=$ExpectedOrigin",
    "PRIOR_VERSION_ID=$ExpectedPriorVersionId",
    "NEW_VERSION_ID=$newVersionId",
    "NEW_DEPLOYMENT_ID=$newDeploymentId",
    "TRAFFIC_PERCENT=100",
    "PUBLICATION_MODE=DISABLED",
    "CONNECTOR_VAULT_MODIFIED=FALSE",
    "SECRET_MUTATIONS=0",
    "GOVERNED_VERIFICATION=PASS",
    "R13_HANDOFF=READY"
) | Write-Output
