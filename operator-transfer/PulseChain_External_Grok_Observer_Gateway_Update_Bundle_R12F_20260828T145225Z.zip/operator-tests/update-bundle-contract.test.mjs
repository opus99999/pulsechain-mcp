import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";

const testDirectory = dirname(fileURLToPath(import.meta.url));
const operatorDirectory = dirname(testDirectory);
const read = (name) => readFile(join(operatorDirectory, name), "utf8");

const exactFiveLabels = [
  "GROK_MCP_TOKEN_X_PROTOCOL",
  "GROK_MCP_TOKEN_INFRASTRUCTURE_INCIDENTS",
  "GROK_MCP_TOKEN_MARKET_LIQUIDITY",
  "GROK_MCP_TOKEN_IDENTITY_EVIDENCE",
  "GROK_MCP_TOKEN_RED_TEAM",
];

test("update script binds the exact existing Worker prestate", async () => {
  const script = await read("UPDATE_EXISTING_GATEWAY_R12F.ps1.in");
  for (const value of [
    "pulsechain-external-observer-grok-mcp",
    "dade45b2875ee5e98c74b5d06528cd9c",
    "c776a6e0-14b8-49bc-be9a-7aa0e63c5495",
    "e32f2b34-a572-404e-b969-44c0bf2c9088",
    "https://pulsechain-external-observer-grok-mcp.pulsechain-research-dade45b2.workers.dev",
    "https://pulsechain-research-control-room.brohexphiat.chatgpt.site",
    "2026-08-27",
    "nodejs_compat",
    "4.92.0",
    ...exactFiveLabels,
  ]) {
    assert.ok(script.includes(value), `missing fixed value ${value}`);
  }
  assert.match(script, /ValidateSet\("I_HAVE_EXCLUSIVE_CHANGE_FREEZE"\)/);
  assert.match(script, /UNDEPLOYED_DRAFT_VERSION_PRESENT/);
  assert.match(script, /FINAL_CHANGE_FREEZE_RECHECK/);
  assert.match(script, /Assert-ProductionUnchanged/);
});

test("update script has one controlled upload and one controlled deployment path", async () => {
  const script = await read("UPDATE_EXISTING_GATEWAY_R12F.ps1.in");
  assert.equal((script.match(/"versions", "upload"/g) ?? []).length, 1);
  assert.equal((script.match(/"versions", "deploy"/g) ?? []).length, 1);
  assert.match(script, /"--keep-vars"/);
  assert.match(script, /"--outfile", \$uploadFormPath/);
  assert.match(script, /\("\{0\}@100" -f \$newVersionId\)/);
  assert.match(script, /VERSION_UPLOAD_AMBIGUOUS_NO_RETRY/);
  assert.match(script, /DEPLOYMENT_AMBIGUOUS_NO_RETRY/);
  assert.doesNotMatch(script, /(?<!versions["'],\s*["'])wrangler\s+deploy/i);
  assert.doesNotMatch(script, /--force(?:-with-lease)?/i);
});

test("update script contains no secret or vault mutation mechanism", async () => {
  const script = await read("UPDATE_EXISTING_GATEWAY_R12F.ps1.in");
  for (const prohibited of [
    /--secrets-file/i,
    /["']secret["']\s*,\s*["'](?:put|bulk|delete)/i,
    /Write-ConnectorVault/,
    /Protect-ConnectorToken/,
    /New-ConnectorToken/,
    /Set-Content[^\n]*connector-tokens\.dpapi\.json/i,
  ]) {
    assert.doesNotMatch(script, prohibited);
  }
  assert.match(script, /Assert-VaultUnchanged/g);
  assert.match(script, /FINALIZED_VAULT_METADATA_MISMATCH/);
  assert.match(script, /UPDATE_VERIFIED_R13_HANDOFF_READY/);
});

test("bundle is validated before bundle code is dot-sourced", async () => {
  const script = await read("UPDATE_EXISTING_GATEWAY_R12F.ps1.in");
  const validateIndex = script.indexOf("    Assert-BundleIntegrity\n");
  const dotSourceIndex = script.indexOf('    . (Join-Path $BundleRoot "OPERATOR_COMMON.ps1")');
  assert.ok(validateIndex > 0);
  assert.ok(dotSourceIndex > validateIndex);
  for (const gate of [
    "BUNDLE_REPARSE_POINT_REJECTED",
    "BUNDLE_CASE_FOLD_COLLISION",
    "BUNDLE_PATH_UNSAFE",
    "BUNDLE_FORBIDDEN_MEMBER",
    "BUNDLE_CHECKSUM_MISMATCH",
    "BUNDLE_INVENTORY_INVALID",
  ]) assert.ok(script.includes(gate));
});

test("uploaded Version readback proves bindings and remote source bytes", async () => {
  const script = await read("UPDATE_EXISTING_GATEWAY_R12F.ps1.in");
  assert.match(script, /Assert-VersionBindingContract -Version \$newVersion/);
  assert.match(script, /Get-RemoteVersionContent -VersionId \$newVersionId/);
  assert.match(script, /local_remote_content_equal/);
  assert.match(script, /remote_source_map_count/);
  assert.match(script, /Assert-ExactSecrets/);
  assert.match(script, /secret_text/);
});

test("governed verifier runs once and rollback remains separately authorized", async () => {
  const script = await read("UPDATE_EXISTING_GATEWAY_R12F.ps1.in");
  assert.equal((script.match(/\$verifierInvocations \+= 1/g) ?? []).length, 1);
  assert.match(script, /PRESERVE_DEPLOYED_R12F_REPORT_EXTERNAL_BLOCKER/);
  assert.match(script, /R12F_EXTERNAL_UPSTREAM_BLOCKER_NO_ROLLBACK/);
  assert.match(script, /R12F_RELEASE_CRITICAL_FAILURE_SEPARATE_ROLLBACK_AUTHORIZATION_REQUIRED/);
  assert.doesNotMatch(script, /versions["'],\s*["']deploy["'][\s\S]{0,300}ExpectedPriorVersionId/);
});

test("Cloudflare helper is read-only and receives credentials only on stdin", async () => {
  const helper = await read("VERIFY_CLOUDFLARE_R12F.mjs");
  assert.match(helper, /process\.stdin/);
  assert.doesNotMatch(helper, /process\.env\.(?:CLOUDFLARE|CF_)/);
  assert.doesNotMatch(helper, /writeFile|appendFile|createWriteStream/);
  assert.match(helper, /method:\s*"GET"/);
  assert.doesNotMatch(helper, /method:\s*"(?:POST|PUT|PATCH|DELETE)"/);
  assert.match(helper, /redirect:\s*"error"/);
  assert.match(helper, /local_remote_content_equal/);
});

test("operator documentation discloses residual provider limitations", async () => {
  const [readme, rollback, r13] = await Promise.all([
    read("OPERATOR_README_R12F.md.in"),
    read("ROLLBACK_R12F.md"),
    read("R13_POST_UPDATE_VERIFICATION_PROMPT.md"),
  ]);
  assert.match(readme, /does not expose a compare-and-swap/i);
  assert.match(readme, /may internally retry its mutation request/i);
  assert.match(readme, /exclusive change freeze/i);
  assert.match(readme, /do not rerun the command/i);
  assert.match(rollback, /only after.*release_critical: true/is);
  assert.match(rollback, /CONTROL_ROOM_UPSTREAM_UNAVAILABLE/);
  assert.match(r13, /Remain read-only/);
  assert.match(r13, /do not execute rollback/i);
});
