import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

import {
  BUNDLE_CONTRACTS_IMPORT,
  SOURCE_CONTRACTS_IMPORT,
  renderOperatorTestForBundle,
  rewriteOperatorTestForBundle,
  validateBundleImports,
} from "../BUNDLE_IMPORT_CONTAINMENT.mjs";

function fixture(name) {
  const root = mkdtempSync(join(tmpdir(), `r12f1 ${name} é `));
  mkdirSync(join(root, "operator-tests"), { recursive: true });
  mkdirSync(join(root, "external_observer_grok_mcp_gateway", "src"), { recursive: true });
  writeFileSync(join(root, "external_observer_grok_mcp_gateway", "src", "contracts.mjs"), "export const marker = 'contained';\n", "utf8");
  return root;
}

test("bundle relocation rewrites exactly the one governed contracts import", () => {
  const source = `import { marker } from "${SOURCE_CONTRACTS_IMPORT}";\n`;
  const emitted = rewriteOperatorTestForBundle("node-verifier.test.mjs", source);
  assert.equal(emitted, `import { marker } from "${BUNDLE_CONTRACTS_IMPORT}";\n`);
  assert.equal(rewriteOperatorTestForBundle("other.test.mjs", source), source);
});

test("bundle relocation binds operator contract tests to rendered filenames", () => {
  const source = `const a = "UPDATE_EXISTING_GATEWAY_R12F.ps1.in";\nconst b = "OPERATOR_README_R12F.md.in";\n`;
  const emitted = rewriteOperatorTestForBundle("update-bundle-contract.test.mjs", source);
  assert.equal(emitted, `const a = "UPDATE_EXISTING_GATEWAY_R12F.ps1";\nconst b = "OPERATOR_README.md";\n`);
});

test("source-template and rendered-package operator tests use distinct lifecycle values", () => {
  const placeholder = "@" + "@R12F_INVENTORY_SCHEMA@" + "@";
  const source = `const a = "UPDATE_EXISTING_GATEWAY_R12F.ps1.in";\nconst expected = "${placeholder}";\n` +
    'const sourceExpected = "' + ("@" + "@R12F_SOURCE_MANIFEST_SCHEMA@" + "@") + '";\n' +
    'const deploymentExpected = "' + ("@" + "@R12F_DEPLOYMENT_EXPECTATIONS_SCHEMA@" + "@") + '";\n' +
    'const readme = "OPERATOR_README_R12F.md.in";\n';
  assert.ok(source.includes(placeholder));
  const emitted = renderOperatorTestForBundle("update-bundle-contract.test.mjs", source, {
    [placeholder]: "pulsechain-external-observer-r12f-update-inventory@1.0.0",
    ["@" + "@R12F_SOURCE_MANIFEST_SCHEMA@" + "@"]: "pulsechain-external-observer-r12f-source-manifest@1.0.0",
    ["@" + "@R12F_DEPLOYMENT_EXPECTATIONS_SCHEMA@" + "@"]: "pulsechain-external-observer-r12f-update-expectations@1.0.0",
  });
  assert.match(emitted, /UPDATE_EXISTING_GATEWAY_R12F\.ps1/);
  assert.match(emitted, /OPERATOR_README\.md/);
  assert.match(emitted, /pulsechain-external-observer-r12f-update-inventory@1\.0\.0/);
  assert.doesNotMatch(emitted, /@@[A-Z0-9_]+@@/u);
});

test("unrepaired relocated import is rejected as outside the extraction root", () => {
  const root = fixture("outside root");
  try {
    writeFileSync(join(root, "operator-tests", "node-verifier.test.mjs"), `import "${SOURCE_CONTRACTS_IMPORT}";\n`, "utf8");
    assert.throws(() => validateBundleImports(root), /IMPORT_OUTSIDE_BUNDLE_ROOT/);
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});

test("corrected relocated import resolves to the bundle-contained runtime member", () => {
  const root = fixture("contained target");
  try {
    writeFileSync(join(root, "operator-tests", "node-verifier.test.mjs"), `import "${BUNDLE_CONTRACTS_IMPORT}";\n`, "utf8");
    const result = validateBundleImports(root);
    assert.equal(result.outside_root_import_count, 0);
    assert.equal(result.missing_target_count, 0);
    assert.deepEqual(result.imports, [{
      importer: "operator-tests/node-verifier.test.mjs",
      specifier: BUNDLE_CONTRACTS_IMPORT,
      target: "external_observer_grok_mcp_gateway/src/contracts.mjs",
    }]);
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});

test("contained test runs from root, operator directory, and unrelated directory", () => {
  const root = fixture("cwd matrix");
  const testPath = join(root, "operator-tests", "node-verifier.test.mjs");
  try {
    writeFileSync(testPath, `import assert from "node:assert/strict";\nimport test from "node:test";\nimport { marker } from "${BUNDLE_CONTRACTS_IMPORT}";\ntest("contained", () => assert.equal(marker, "contained"));\n`, "utf8");
    for (const cwd of [root, join(root, "operator-tests"), tmpdir()]) {
      const result = spawnSync(process.execPath, ["--test", testPath], { cwd, encoding: "utf8" });
      assert.equal(result.status, 0, `${cwd}: ${result.stderr}`);
    }
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});

test("spaces and non-ASCII extraction paths preserve import containment", () => {
  const root = fixture("spaces and unicode");
  try {
    writeFileSync(join(root, "operator-tests", "node-verifier.test.mjs"), `import "${BUNDLE_CONTRACTS_IMPORT}";\n`, "utf8");
    assert.equal(validateBundleImports(root).result, "PASS");
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});
