import assert from "node:assert/strict";
import test from "node:test";

import {
  CONNECTORS as GATEWAY_CONNECTORS,
  toolsFor as gatewayToolsFor,
} from "../external_observer_grok_mcp_gateway/src/contracts.mjs";

import {
  BRIDGE_PROTOCOL,
  COMMON_READ_TOOLS,
  CONNECTORS,
  CONTROL_ROOM_ORIGIN,
  PROTOCOL_VERSION,
  STAGE_TIMEOUT_MS,
  WORKER_ORIGIN,
  canonicalJson,
  decodeCredentialFrame,
  parseEventStream,
  sanitizeText,
  verifyGateway,
} from "../VERIFY_GATEWAY_DISABLED_R12F.mjs";

const TOKENS = new Map(CONNECTORS.map((connector, index) => [connector.observerId, String.fromCharCode(65 + index).repeat(43)]));
const TOKEN_TO_CONNECTOR = new Map([...TOKENS].map(([observerId, token]) => [token, observerId]));
const SYNTHETIC_FOREIGN_BEARER_PATTERN = ["Authorization: Bea", "rer not-the-current-", "governed-credential"].join("");

function json(body, status = 200, headers = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", ...headers },
  });
}

function connectorFromPath(pathname) {
  return CONNECTORS.find((connector) => connector.path === pathname);
}

function toolsFor(connector) {
  const gatewayConnector = GATEWAY_CONNECTORS.find((entry) => entry.observerId === connector.observerId);
  return structuredClone(gatewayToolsFor(gatewayConnector));
}

function rpcResult(id, result) {
  return { jsonrpc: "2.0", id, result };
}

function toolContent(value, isError = false) {
  return { content: [{ type: "text", text: JSON.stringify(value) }], structuredContent: value, ...(isError ? { isError: true } : {}) };
}

function disabledReceipt() {
  return {
    accepted: false,
    error_code: "PUBLICATION_MODE_DISABLED",
    issue_number: null,
    workflow_run_id: null,
    observation_id: null,
    publication_commit: null,
    permanent_url: null,
    manifest_sha256: null,
  };
}

function stageOf(message) {
  if (message.method === "initialize") return "initialize";
  if (message.method === "notifications/initialized") return "notifications_initialized";
  if (message.method === "tools/list") return "tools_list";
  if (message.method === "tools/call") return message.params.name;
  return message.method;
}

function createMockFetch(overrides = {}) {
  const calls = [];
  const fetchImpl = async (input, init) => {
    const url = new URL(input);
    const message = JSON.parse(init.body);
    const pathConnector = connectorFromPath(url.pathname);
    const token = String(init.headers.Authorization ?? "").replace(/^Bearer /u, "");
    const authenticatedObserver = TOKEN_TO_CONNECTOR.get(token);
    const context = { url, init, message, pathConnector, authenticatedObserver, stage: stageOf(message), calls };
    calls.push(context);
    const custom = await overrides.respond?.(context);
    if (custom !== undefined) return custom;
    if (!pathConnector || authenticatedObserver !== pathConnector.observerId) return json({ error: "UNAUTHORIZED" }, 401);
    if (message.method === "notifications/initialized") return new Response(null, { status: 202 });
    if (message.method === "initialize") {
      return json(rpcResult(message.id, {
        protocolVersion: PROTOCOL_VERSION,
        capabilities: { tools: { listChanged: false } },
        serverInfo: { name: `pulsechain-${pathConnector.observerId}-mcp`, version: "1.0.0" },
        publication: {
          publication_mode: "DISABLED",
          publication_ready: false,
          github_publication_transport: "DEFERRED_WHILE_DISABLED",
          credential_method: null,
          error_code: null,
          automatic_promotion: false,
        },
      }), 200, overrides.sessionId ? { "Mcp-Session-Id": overrides.sessionId } : {});
    }
    if (message.method === "tools/list") {
      return json(rpcResult(message.id, { tools: toolsFor(pathConnector) }), 200, {
        "X-PulseChain-Tool-Discovery-Fingerprint": pathConnector.fingerprint,
      });
    }
    if (message.method === "tools/call" && message.params.name === "read_external_observer_bootstrap") {
      return json(rpcResult(message.id, toolContent({ observer_id: pathConnector.observerId, ledger: { repository_head: "f".repeat(40) } })));
    }
    if (message.method === "tools/call" && message.params.name === "read_workstream_bootstrap") {
      return json(rpcResult(message.id, toolContent({ requested_workstream_id: message.params.arguments.workstream_id })));
    }
    if (message.method === "tools/call" && message.params.name === "read_external_observation") {
      return json(rpcResult(message.id, toolContent({
        error: "CONTROL_ROOM_UPSTREAM_HTTP_ERROR",
        message: "Control Room returned HTTP 404",
        last_http_status: 404,
        attempt_count: 1,
        retry_count: 0,
      }, true)));
    }
    if (message.method === "tools/call" && message.params.name === pathConnector.publishTool) {
      return json(rpcResult(message.id, toolContent(disabledReceipt())));
    }
    return json({ error: "UNEXPECTED_TEST_REQUEST" }, 500);
  };
  fetchImpl.calls = calls;
  return fetchImpl;
}

const FIXED_PROJECTION = Object.freeze({
  runtime: { commit: "f".repeat(40), snapshot: `sha256:${"1".repeat(64)}` },
  observers: CONNECTORS.map((connector) => ({ observer_id: connector.observerId, latest: null, count: 0 })),
  specialists: ["signals-platform", "validator-flows", "identity-attribution", "investor-intelligence"],
  work_hub: { project_revision: 0, write_plane_state: "CANARY" },
});

function deterministicClock() {
  let value = 0;
  return {
    nowMs: () => value++,
    nowIso: () => "2026-08-28T00:00:00.000Z",
  };
}

function credentialProvider() {
  return async (connector) => new TextEncoder().encode(TOKENS.get(connector.observerId));
}

function verifierOptions(fetchImpl, overrides = {}) {
  return {
    fetchImpl,
    credentialProvider: credentialProvider(),
    publicProjectionProvider: async () => structuredClone(FIXED_PROJECTION),
    clock: deterministicClock(),
    ...overrides,
  };
}

function row(report, connectorId, stage) {
  return report.connector_stage_matrix.find((entry) => entry.connector_id === connectorId && entry.stage === stage);
}

test("fixed origins, protocol, bridge, timeout, and common tools are immutable", () => {
  assert.equal(WORKER_ORIGIN, "https://pulsechain-external-observer-grok-mcp.pulsechain-research-dade45b2.workers.dev");
  assert.equal(CONTROL_ROOM_ORIGIN, "https://pulsechain-research-control-room.brohexphiat.chatgpt.site");
  assert.equal(PROTOCOL_VERSION, "2025-06-18");
  assert.equal(BRIDGE_PROTOCOL, "pulsechain-r12f-verifier-bridge@1.0.0");
  assert.equal(STAGE_TIMEOUT_MS, 60_000);
  assert.deepEqual(COMMON_READ_TOOLS, ["read_external_observer_bootstrap", "read_workstream_bootstrap", "read_external_observation"]);
});

test("credential frame accepts only exact governed bytes", () => {
  const token = new TextEncoder().encode("A".repeat(43));
  const frame = new Uint8Array(51);
  frame.set(new TextEncoder().encode("R12F"));
  frame[4] = 1; frame[5] = 1; frame[6] = 43; frame[7] = 0; frame.set(token, 8);
  assert.equal(new TextDecoder().decode(decodeCredentialFrame(frame, 1)), "A".repeat(43));
  assert.throws(() => decodeCredentialFrame(frame, 2), /identity mismatch/u);
  frame[8] = 33;
  assert.throws(() => decodeCredentialFrame(frame, 1), /alphabet mismatch/u);
});

test("sanitizer removes bearer values, token-shaped values, and control bytes", () => {
  const secret = "A".repeat(43);
  const output = sanitizeText(`Authorization: Bearer ${secret}\n${secret}\u0000`);
  assert.equal(output.includes(secret), false);
  assert.equal(output.includes("\n"), false);
});

test("event-stream parser accepts one exact JSON-RPC response", () => {
  const parsed = parseEventStream(`: keepalive\nevent: message\ndata: {"jsonrpc":"2.0","id":"x",\ndata: "result":{"ok":true}}\n\n`, "x");
  assert.deepEqual(parsed, { jsonrpc: "2.0", id: "x", result: { ok: true } });
});

test("event-stream parser rejects malformed and duplicate final responses", () => {
  assert.throws(() => parseEventStream("data: {bad}\n\n", "x"), /MALFORMED_SSE/u);
  const twice = 'data: {"jsonrpc":"2.0","id":"x","result":{}}\n\ndata: {"jsonrpc":"2.0","id":"x","result":{}}\n\n';
  assert.throws(() => parseEventStream(twice, "x"), /MALFORMED_SSE/u);
});

test("all five sessionless connectors pass with a deterministic complete matrix", async () => {
  const fetchImpl = createMockFetch();
  const report = await verifyGateway(verifierOptions(fetchImpl));
  assert.equal(report.result, "PASS");
  assert.equal(report.connectors.length, 5);
  assert.equal(report.connectors.every((entry) => entry.result === "PASS" && entry.session_id_present === false), true);
  assert.equal(report.connector_stage_matrix.length, 65);
  assert.equal(report.transport_audit.mcp_request_count, 55);
  assert.equal(report.verifier_retry_count, 0);
});

test("all-five pass report is byte deterministic with an injected clock", async () => {
  const left = await verifyGateway(verifierOptions(createMockFetch()));
  const right = await verifyGateway(verifierOptions(createMockFetch()));
  assert.equal(canonicalJson(left), canonicalJson(right));
});

test("successful application/json MCP responses are parsed", async () => {
  const report = await verifyGateway(verifierOptions(createMockFetch()));
  assert.equal(row(report, CONNECTORS[0].observerId, "initialize").response_classification, "MCP_JSON_SUCCESS");
  assert.equal(row(report, CONNECTORS[0].observerId, "read_external_observer_bootstrap").response_classification, "MCP_READ_SUCCESS");
});

test("exact Streamable HTTP event-stream response is parsed", async () => {
  let used = false;
  const fetchImpl = createMockFetch({ respond: ({ message, pathConnector, stage }) => {
    if (!used && stage === "read_external_observer_bootstrap") {
      used = true;
      const body = rpcResult(message.id, toolContent({ observer_id: pathConnector.observerId }));
      return new Response(`event: message\ndata: ${JSON.stringify(body)}\n\n`, { status: 200, headers: { "Content-Type": "text/event-stream" } });
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  assert.equal(row(report, CONNECTORS[0].observerId, "read_external_observer_bootstrap").result, "PASS");
});

test("session ID presence is carried but its value is never reported", async () => {
  const session = "top-secret-session-value-that-must-not-appear";
  const fetchImpl = createMockFetch({ sessionId: session });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  assert.equal(report.connectors.every((entry) => entry.session_id_present), true);
  assert.equal(JSON.stringify(report).includes(session), false);
  const postInit = fetchImpl.calls.find((call) => call.stage === "tools_list" && call.authenticatedObserver === call.pathConnector.observerId);
  assert.equal(postInit.init.headers["Mcp-Session-Id"], session);
  assert.equal(postInit.init.headers["MCP-Protocol-Version"], PROTOCOL_VERSION);
  assert.equal(row(report, CONNECTORS[0].observerId, `foreign_path_isolation:${CONNECTORS[1].observerId}`).session_id_present, false);
});

test("authenticated POSTs use one fetch, fixed path, and redirect error", async () => {
  const fetchImpl = createMockFetch();
  await verifyGateway(verifierOptions(fetchImpl));
  for (const call of fetchImpl.calls) {
    assert.equal(call.url.origin, WORKER_ORIGIN);
    assert.equal(call.init.method, "POST");
    assert.equal(call.init.redirect, "error");
  }
});

test("one connector timeout records exact connector and stage with no retry", async () => {
  let timed = false;
  const fetchImpl = createMockFetch({ respond: ({ stage, pathConnector, init }) => {
    if (!timed && pathConnector === CONNECTORS[0] && stage === "initialize") {
      timed = true;
      return new Promise((resolve, reject) => init.signal.addEventListener("abort", () => reject(new DOMException("aborted", "AbortError")), { once: true }));
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl, { stageTimeoutMs: 5 }));
  const failure = row(report, CONNECTORS[0].observerId, "initialize");
  assert.equal(failure.result, "FAIL");
  assert.equal(failure.timeout, true);
  assert.equal(failure.transport_attempt_count, 1);
  assert.equal(report.stage_timeout_ms, 5);
  assert.equal(report.connectors[1].result, "PASS");
});

test("attempt timer is cleared on every completed stage", async () => {
  let created = 0; let cleared = 0;
  const timers = {
    setTimeout(fn, ms) { created += 1; return setTimeout(fn, ms); },
    clearTimeout(id) { cleared += 1; clearTimeout(id); },
  };
  const report = await verifyGateway(verifierOptions(createMockFetch(), { timers }));
  assert.equal(report.result, "PASS");
  assert.equal(cleared, created);
});

test("HTTP 401 records authentication failure and all five connectors complete", async () => {
  let rejected = false;
  const fetchImpl = createMockFetch({ respond: ({ pathConnector, stage }) => {
    if (!rejected && pathConnector === CONNECTORS[0] && stage === "initialize") { rejected = true; return json({ error: "UNAUTHORIZED" }, 401); }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  assert.equal(row(report, CONNECTORS[0].observerId, "initialize").response_classification, "HTTP_AUTHENTICATION_FAILURE");
  assert.equal(report.connectors.length, 5);
  assert.equal(report.connectors.slice(1).every((entry) => entry.result === "PASS"), true);
});

test("common read CONTROL_ROOM_UPSTREAM_UNAVAILABLE is parsed accurately", async () => {
  let failed = false;
  const fetchImpl = createMockFetch({ respond: ({ message, pathConnector, stage }) => {
    if (!failed && pathConnector === CONNECTORS[0] && stage === "read_external_observer_bootstrap") {
      failed = true;
      return json(rpcResult(message.id, toolContent({
        error: "CONTROL_ROOM_UPSTREAM_UNAVAILABLE",
        message: "Control Room public read is temporarily unavailable",
        tool_name: stage,
        fixed_observer_id: pathConnector.observerId,
        control_room_origin: CONTROL_ROOM_ORIGIN,
        target_path: `/api/v1/external-observers/bootstrap/${pathConnector.observerId}`,
        attempt_count: 3,
        retry_count: 2,
        total_elapsed_ms: 1000,
        last_http_status: 503,
        last_content_type: "application/json",
        last_error_class: "HttpStatusError",
        last_error_message: "Control Room returned HTTP 503",
        retry_after_observed: false,
        retry_after_applied_ms: 0,
        final_failure_stage: "HTTP_STATUS",
        upstream_request_id: "safe-request-1",
      }, true)));
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  const failure = row(report, CONNECTORS[0].observerId, "read_external_observer_bootstrap");
  assert.equal(failure.mcp_tool_error_code, "CONTROL_ROOM_UPSTREAM_UNAVAILABLE");
  assert.equal(failure.response_classification, "CONTROL_ROOM_UPSTREAM_UNAVAILABLE");
  assert.deepEqual(failure.upstream_failure, {
    tool_name: "read_external_observer_bootstrap",
    fixed_observer_id: CONNECTORS[0].observerId,
    target_workstream: null,
    control_room_origin: CONTROL_ROOM_ORIGIN,
    target_path: `/api/v1/external-observers/bootstrap/${CONNECTORS[0].observerId}`,
    attempt_count: 3,
    retry_count: 2,
    total_elapsed_ms: 1000,
    last_http_status: 503,
    last_content_type: "application/json",
    last_error_class: "HttpStatusError",
    sanitized_last_error_message: "Control Room returned HTTP 503",
    retry_after_observed: false,
    retry_after_applied_ms: 0,
    final_failure_stage: "HTTP_STATUS",
    upstream_request_id: "safe-request-1",
  });
  assert.equal(report.control_room_upstream_unavailable_count, 1);
  assert.equal(report.external_upstream_blocker_only, true);
});

test("MCP endpoint HTTP 503 remains distinct from gateway structured upstream failure", async () => {
  let failed = false;
  const fetchImpl = createMockFetch({ respond: ({ pathConnector, stage }) => {
    if (!failed && pathConnector === CONNECTORS[0] && stage === "read_workstream_bootstrap") { failed = true; return json({ error: "SERVICE_UNAVAILABLE" }, 503); }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  const failure = row(report, CONNECTORS[0].observerId, "read_workstream_bootstrap");
  assert.equal(failure.response_classification, "HTTP_503");
  assert.equal(failure.mcp_tool_error_code, null);
  assert.equal(report.external_upstream_blocker_only, false);
});

test("tools/list missing tool identifies the exact discovery stage", async () => {
  let mismatched = false;
  const fetchImpl = createMockFetch({ respond: ({ message, pathConnector, stage, authenticatedObserver }) => {
    if (!mismatched && pathConnector === CONNECTORS[0] && authenticatedObserver === pathConnector.observerId && stage === "tools_list") {
      mismatched = true;
      return json(rpcResult(message.id, { tools: toolsFor(pathConnector).slice(0, 3) }), 200, { "X-PulseChain-Tool-Discovery-Fingerprint": pathConnector.fingerprint });
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  const failure = row(report, CONNECTORS[0].observerId, "tools_list");
  assert.equal(failure.result, "FAIL");
  assert.equal(failure.response_classification, "TOOLS_LIST_MISMATCH");
  assert.match(failure.sanitized_exception_message, /tool list mismatch/u);
});

test("disabled result mismatch is field-specific ordinary failure", async () => {
  let mismatched = false;
  const fetchImpl = createMockFetch({ respond: ({ message, pathConnector, stage }) => {
    if (!mismatched && pathConnector === CONNECTORS[0] && stage === pathConnector.publishTool) {
      mismatched = true;
      const receipt = { ...disabledReceipt(), error_code: "WRONG_DISABLED_CODE" };
      return json(rpcResult(message.id, toolContent(receipt)));
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  const failure = row(report, CONNECTORS[0].observerId, "disabled_publication");
  assert.equal(failure.response_classification, "DISABLED_RECEIPT_MISMATCH");
  assert.equal(report.release_critical, false);
  assert.equal(report.connectors[1].result, "PASS");
});

test("actual publication identity is a release-critical immediate stop", async () => {
  let published = false;
  const fetchImpl = createMockFetch({ respond: ({ message, pathConnector, stage }) => {
    if (!published && pathConnector === CONNECTORS[0] && stage === pathConnector.publishTool) {
      published = true;
      const receipt = { ...disabledReceipt(), accepted: true, issue_number: 42 };
      return json(rpcResult(message.id, toolContent(receipt)));
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  assert.equal(report.result, "SECURITY_STOP");
  assert.equal(report.critical_stop.code, "DISABLED_PUBLICATION_OCCURRED");
  assert.equal(report.connectors.slice(1).every((entry) => entry.result === "SKIPPED"), true);
});

test("foreign authenticated result is a release-critical identity stop", async () => {
  let crossed = false;
  const fetchImpl = createMockFetch({ respond: ({ message, pathConnector, authenticatedObserver }) => {
    if (!crossed && pathConnector && authenticatedObserver && authenticatedObserver !== pathConnector.observerId) {
      crossed = true;
      return json(rpcResult(message.id, { tools: toolsFor(pathConnector) }), 200, { "X-PulseChain-Tool-Discovery-Fingerprint": pathConnector.fingerprint });
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  assert.equal(report.result, "SECURITY_STOP");
  assert.equal(report.critical_stop.code, "CROSS_OBSERVER_IDENTITY_EXPOSURE");
});

test("protected state mutation is release critical with exact projection stage", async () => {
  let count = 0;
  const report = await verifyGateway(verifierOptions(createMockFetch(), {
    publicProjectionProvider: async () => ({ ...structuredClone(FIXED_PROJECTION), marker: count++ }),
  }));
  assert.equal(report.result, "SECURITY_STOP");
  assert.equal(report.critical_stop.code, "PROTECTED_STATE_MUTATION");
  assert.equal(report.system_wide_mutation_audit.result, "MUTATED");
});

test("public projection failure is ordinary and never discarded by a generic wrapper", async () => {
  let count = 0;
  const report = await verifyGateway(verifierOptions(createMockFetch(), {
    publicProjectionProvider: async () => { if (count++ === 0) throw new TypeError("fetch failed with forbidden private detail"); return FIXED_PROJECTION; },
  }));
  assert.equal(report.result, "FAIL");
  assert.equal(report.release_critical, false);
  assert.equal(report.connector_stage_matrix.length, 65);
  assert.equal(report.system_wide_mutation_audit.before_failure.classification, "PUBLIC_PROJECTION_UNAVAILABLE");
});

test("malformed JSON is a one-attempt parse-stage failure", async () => {
  let malformed = false;
  const fetchImpl = createMockFetch({ respond: ({ pathConnector, stage }) => {
    if (!malformed && pathConnector === CONNECTORS[0] && stage === "read_external_observer_bootstrap") {
      malformed = true;
      return new Response("{", { status: 200, headers: { "Content-Type": "application/json" } });
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  const failure = row(report, CONNECTORS[0].observerId, "read_external_observer_bootstrap");
  assert.equal(failure.response_classification, "MALFORMED_JSON");
  assert.equal(failure.transport_attempt_count, 1);
});

test("wrong content type is a one-attempt fail-closed result", async () => {
  let wrong = false;
  const fetchImpl = createMockFetch({ respond: ({ pathConnector, stage }) => {
    if (!wrong && pathConnector === CONNECTORS[0] && stage === "read_workstream_bootstrap") {
      wrong = true;
      return new Response("ok", { status: 200, headers: { "Content-Type": "text/plain" } });
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  assert.equal(row(report, CONNECTORS[0].observerId, "read_workstream_bootstrap").response_classification, "INVALID_CONTENT_TYPE");
});

test("caller cancellation records cancellation and performs no verifier retry", async () => {
  const controller = new AbortController();
  controller.abort();
  const fetchImpl = createMockFetch();
  const report = await verifyGateway(verifierOptions(fetchImpl, { signal: controller.signal }));
  assert.equal(row(report, CONNECTORS[0].observerId, "initialize").response_classification, "CALLER_CANCELLATION");
  assert.equal(report.verifier_retry_count, 0);
});

test("secret echo triggers immediate stop without persisting the secret", async () => {
  const secret = TOKENS.get(CONNECTORS[0].observerId);
  let leaked = false;
  const fetchImpl = createMockFetch({ respond: ({ message, pathConnector, stage }) => {
    if (!leaked && pathConnector === CONNECTORS[0] && stage === "initialize") {
      leaked = true;
      return json(rpcResult(message.id, { echoed: secret }));
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  assert.equal(report.result, "SECURITY_STOP");
  assert.equal(report.critical_stop.code, "SECRET_EXPOSURE");
  assert.equal(JSON.stringify(report).includes(secret), false);
});

test("system-wide audit records direct and structural proof bases without overclaim", async () => {
  const report = await verifyGateway(verifierOptions(createMockFetch()));
  assert.equal(report.system_wide_mutation_audit.result, "UNCHANGED");
  assert.equal(report.system_wide_mutation_audit.directly_observed.includes("public_runtime_commit"), true);
  assert.equal(report.system_wide_mutation_audit.structural_zero_transport_only.includes("d1_table_and_write_delta"), true);
  assert.match(report.system_wide_mutation_audit.proof_basis_limitations, /not represented as directly measured/u);
});

test("GitHub and publication mutation audit counts remain exactly zero", async () => {
  const report = await verifyGateway(verifierOptions(createMockFetch()));
  assert.equal(report.transport_audit.api_github_request_count, 0);
  assert.equal(report.transport_audit.github_transport_constructor_count, 0);
  assert.equal(report.transport_audit.publication_mutation_count, 0);
  assert.deepEqual(report.transport_audit.outbound_hosts, [new URL(WORKER_ORIGIN).hostname]);
});

test("successful empty-ledger observation read uses exact structured 404 contract", async () => {
  const report = await verifyGateway(verifierOptions(createMockFetch()));
  const observation = row(report, CONNECTORS[0].observerId, "read_external_observation");
  assert.equal(observation.result, "PASS");
  assert.equal(observation.response_classification, "EXPECTED_EMPTY_LEDGER_NOT_FOUND");
});

test("HTTP failure cannot be promoted by a semantic observation not-found body", async () => {
  let injected = false;
  const fetchImpl = createMockFetch({ respond: ({ message, pathConnector, stage }) => {
    if (!injected && pathConnector === CONNECTORS[0] && stage === "read_external_observation") {
      injected = true;
      return json(rpcResult(message.id, toolContent({
        error: "CONTROL_ROOM_UPSTREAM_HTTP_ERROR", last_http_status: 404, attempt_count: 1, retry_count: 0,
      }, true)), 503);
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  assert.equal(row(report, CONNECTORS[0].observerId, "read_external_observation").response_classification, "HTTP_503");
});

test("HTTP failure cannot be promoted by an exact disabled receipt body", async () => {
  let injected = false;
  const fetchImpl = createMockFetch({ respond: ({ message, pathConnector, stage }) => {
    if (!injected && pathConnector === CONNECTORS[0] && stage === pathConnector.publishTool) {
      injected = true;
      return json(rpcResult(message.id, toolContent(disabledReceipt())), 502);
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  assert.equal(row(report, CONNECTORS[0].observerId, "disabled_publication").response_classification, "HTTP_502");
});

test("exact four-tool schema fingerprint rejects a changed common read schema", async () => {
  let injected = false;
  const fetchImpl = createMockFetch({ respond: ({ message, pathConnector, stage, authenticatedObserver }) => {
    if (!injected && pathConnector === CONNECTORS[0] && authenticatedObserver === pathConnector.observerId && stage === "tools_list") {
      injected = true;
      const tools = toolsFor(pathConnector);
      tools[2].inputSchema.properties.workstream_id.enum = ["signals-platform"];
      return json(rpcResult(message.id, { tools }), 200, { "X-PulseChain-Tool-Discovery-Fingerprint": pathConnector.fingerprint });
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  assert.equal(row(report, CONNECTORS[0].observerId, "tools_list").response_classification, "TOOLS_LIST_MISMATCH");
});

test("exact publish schema rejects a missing required model field", async () => {
  let injected = false;
  const fetchImpl = createMockFetch({ respond: ({ message, pathConnector, stage, authenticatedObserver }) => {
    if (!injected && pathConnector === CONNECTORS[0] && authenticatedObserver === pathConnector.observerId && stage === "tools_list") {
      injected = true;
      const tools = toolsFor(pathConnector);
      tools[0].inputSchema.required = tools[0].inputSchema.required.slice(1);
      return json(rpcResult(message.id, { tools }), 200, { "X-PulseChain-Tool-Discovery-Fingerprint": pathConnector.fingerprint });
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  assert.equal(row(report, CONNECTORS[0].observerId, "tools_list").response_classification, "TOOLS_LIST_MISMATCH");
});

test("active session echo is stopped before JSON parsing and never reported", async () => {
  const session = "governed-session-value-never-model-visible";
  let injected = false;
  const fetchImpl = createMockFetch({ sessionId: session, respond: ({ message, pathConnector, stage, authenticatedObserver }) => {
    if (!injected && pathConnector === CONNECTORS[0] && authenticatedObserver === pathConnector.observerId && stage === "tools_list") {
      injected = true;
      return json(rpcResult(message.id, { tools: toolsFor(pathConnector), echoed_session: session }));
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  assert.equal(report.result, "SECURITY_STOP");
  assert.equal(report.critical_stop.code, "SECRET_EXPOSURE");
  assert.equal(JSON.stringify(report).includes(session), false);
});

for (const [label, material] of [
  ["foreign bearer", SYNTHETIC_FOREIGN_BEARER_PATTERN],
  ["private key marker", "-----BEGIN PRIVATE KEY-----"],
  ["bare credential-shaped material", "Z".repeat(43)],
]) {
  test(`pre-parse scan rejects ${label}`, async () => {
    let injected = false;
    const fetchImpl = createMockFetch({ respond: ({ message, pathConnector, stage }) => {
      if (!injected && pathConnector === CONNECTORS[0] && stage === "initialize") {
        injected = true;
        return json(rpcResult(message.id, { material }));
      }
      return undefined;
    } });
    const report = await verifyGateway(verifierOptions(fetchImpl));
    assert.equal(report.critical_stop.code, "SECRET_EXPOSURE");
    assert.equal(JSON.stringify(report).includes(material), false);
  });
}

test("pre-parse scan rejects cookie response headers", async () => {
  let injected = false;
  const fetchImpl = createMockFetch({ respond: ({ message, pathConnector, stage }) => {
    if (!injected && pathConnector === CONNECTORS[0] && stage === "initialize") {
      injected = true;
      return json(rpcResult(message.id, {}), 200, { "Set-Cookie": "private=value" });
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  assert.equal(report.critical_stop.code, "SECRET_EXPOSURE");
});

test("fixed 43-character synthetic observation ID is governed public allowlist material", async () => {
  const connector = CONNECTORS[1];
  assert.equal(connector.observationId.length, 43);
  const fetchImpl = createMockFetch({ respond: ({ message, pathConnector, stage }) => {
    if (pathConnector === connector && stage === "read_external_observation") {
      return json(rpcResult(message.id, toolContent({ observation: { observation_id: connector.observationId } })));
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  assert.equal(row(report, connector.observerId, "read_external_observation").result, "PASS");
});

test("unrecognized structured error codes are never copied into the report", async () => {
  const rawCode = "INTERNAL_PROVIDER_DETAIL_NOT_GOVERNED";
  let injected = false;
  const fetchImpl = createMockFetch({ respond: ({ message, pathConnector, stage }) => {
    if (!injected && pathConnector === CONNECTORS[0] && stage === "read_workstream_bootstrap") {
      injected = true;
      return json(rpcResult(message.id, toolContent({ error_code: rawCode, message: "ordinary failure" }, true)));
    }
    return undefined;
  } });
  const report = await verifyGateway(verifierOptions(fetchImpl));
  const failure = row(report, CONNECTORS[0].observerId, "read_workstream_bootstrap");
  assert.equal(failure.mcp_tool_error_code, "UNRECOGNIZED_MCP_TOOL_ERROR");
  assert.equal(JSON.stringify(report).includes(rawCode), false);
});

test("governed credential buffers are wiped after every connector", async () => {
  const buffers = [];
  const provider = async (connector) => {
    const buffer = new TextEncoder().encode(TOKENS.get(connector.observerId));
    buffers.push(buffer);
    return buffer;
  };
  const report = await verifyGateway(verifierOptions(createMockFetch(), { credentialProvider: provider }));
  assert.equal(report.result, "PASS");
  assert.equal(buffers.every((buffer) => buffer.every((byte) => byte === 0)), true);
});
