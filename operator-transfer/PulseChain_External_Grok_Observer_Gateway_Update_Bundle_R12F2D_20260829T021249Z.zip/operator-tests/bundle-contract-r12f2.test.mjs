import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import test from "node:test";
import {
  DEPLOYMENT_EXPECTATIONS_SCHEMA,
  INVENTORY_SCHEMA,
  SOURCE_MANIFEST_SCHEMA,
  inspectBundleContract,
} from "../BUNDLE_CONTRACT_VALIDATION.mjs";

const R12D = "ec70832c69f847ea413666de095ce3d56534ea28";
const R12F = "ebef6c42a5eca2ad30669cf856e669a19e10edf9";
const R12F1 = "75e3650f8e7f17af0ec2b2f312b920e15f96eb79";
const R12F2 = "0123456789abcdef0123456789abcdef01234567";
const TREE = "89abcdef0123456789abcdef0123456789abcdef";
const FILENAME = "PulseChain_External_Grok_Observer_Gateway_Update_Bundle_R12F2_20260828T230000Z.zip";
const LEAF = FILENAME.slice(0, -4);

function sha256(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

function writeJson(path, value) {
  writeFileSync(path, `${JSON.stringify(value, null, 2)}\n`, "utf8");
}

function scriptText() {
  return [
    `$ExpectedR12FSourceCommit = "${R12F2}"`,
    `$ExpectedR12FSourceTree = "${TREE}"`,
    `$ExpectedR12FSourceParent = "${R12F}"`,
    `$ExpectedBundleFilename = "${FILENAME}"`,
    `$inventory.schema_version -cne "${INVENTORY_SCHEMA}"`,
    `$source.schema_version -cne "${SOURCE_MANIFEST_SCHEMA}"`,
    `$expectations.schema_version -cne "${DEPLOYMENT_EXPECTATIONS_SCHEMA}"`,
    "$source.source.parent -cne $ExpectedR12FSourceParent",
    "$expectations.source.parent -cne $ExpectedR12FSourceParent",
  ].join("\n") + "\n";
}

function reseal(root) {
  const governed = [
    "DEPLOYMENT_EXPECTATIONS.json",
    "SOURCE_MANIFEST.json",
    "UPDATE_EXISTING_GATEWAY_R12F.ps1",
    "payload.txt",
  ];
  writeFileSync(
    join(root, "SHA256SUMS.txt"),
    `${governed.map((path) => `${sha256(readFileSync(join(root, path)))}  ${path}`).join("\n")}\n`,
    "utf8",
  );
  const inventoryPaths = [...governed, "SHA256SUMS.txt"].sort();
  const inventory = JSON.parse(readFileSync(join(root, "ARTIFACT_INVENTORY.json"), "utf8"));
  inventory.artifact_count_excluding_inventory = inventoryPaths.length;
  inventory.artifacts = inventoryPaths.map((path) => {
    const bytes = readFileSync(join(root, path));
    return { path, byte_size: bytes.length, sha256: sha256(bytes) };
  });
  writeJson(join(root, "ARTIFACT_INVENTORY.json"), inventory);
}

function fixture({ parentName = "R12F2 Attempt é", leaf = LEAF } = {}) {
  const outer = mkdtempSync(join(tmpdir(), "pulsechain r12f2 contract "));
  const root = join(outer, parentName, leaf);
  mkdirSync(root, { recursive: true });
  writeFileSync(join(root, "UPDATE_EXISTING_GATEWAY_R12F.ps1"), scriptText(), "utf8");
  writeFileSync(join(root, "payload.txt"), "governed payload\n", "utf8");
  writeJson(join(root, "SOURCE_MANIFEST.json"), {
    schema_version: SOURCE_MANIFEST_SCHEMA,
    source: { commit: R12F2, tree: TREE, parent: R12F },
  });
  writeJson(join(root, "DEPLOYMENT_EXPECTATIONS.json"), {
    schema_version: DEPLOYMENT_EXPECTATIONS_SCHEMA,
    source: { commit: R12F2, tree: TREE, parent: R12F },
  });
  writeJson(join(root, "ARTIFACT_INVENTORY.json"), {
    schema_version: INVENTORY_SCHEMA,
    artifact_count_excluding_inventory: 0,
    artifacts: [],
  });
  reseal(root);
  return { outer, root };
}

function mutateJson(root, path, mutate, { resealBundle = true } = {}) {
  const value = JSON.parse(readFileSync(join(root, path), "utf8"));
  mutate(value);
  writeJson(join(root, path), value);
  if (resealBundle) reseal(root);
}

function codes(result) {
  return new Set(result.errors.map((entry) => entry.code));
}

test("exact leaf and a unique operator-selected parent pass", () => {
  const { outer, root } = fixture();
  try {
    assert.equal(inspectBundleContract(root).result, "PASS");
  } finally {
    rmSync(outer, { recursive: true, force: true });
  }
});

test("wrong leaf fails without constraining its parent", () => {
  const { outer, root } = fixture({ leaf: "R12F2-Update-20260828T230000Z" });
  try {
    assert.equal(inspectBundleContract(root).first_failure_code, "BUNDLE_DIRECTORY_IDENTITY_MISMATCH");
  } finally {
    rmSync(outer, { recursive: true, force: true });
  }
});

test("one modified governed byte fails despite the exact leaf", () => {
  const { outer, root } = fixture();
  try {
    writeFileSync(join(root, "payload.txt"), "modified payload\n", "utf8");
    const failures = codes(inspectBundleContract(root));
    assert.ok(failures.has("BUNDLE_CHECKSUM_MISMATCH"));
    assert.ok(failures.has("BUNDLE_INVENTORY_IDENTITY_MISMATCH"));
  } finally {
    rmSync(outer, { recursive: true, force: true });
  }
});

for (const schema of [
  "pulsechain-external-observer-r12f1-update-inventory@1.0.0",
  "pulsechain-external-observer-r12f2-update-inventory@1.0.0",
  undefined,
  null,
  "MALFORMED",
]) {
  test(`inventory schema rejects ${String(schema)}`, () => {
    const { outer, root } = fixture();
    try {
      mutateJson(root, "ARTIFACT_INVENTORY.json", (value) => { value.schema_version = schema; }, { resealBundle: false });
      assert.ok(codes(inspectBundleContract(root)).has("BUNDLE_INVENTORY_INVALID"));
    } finally {
      rmSync(outer, { recursive: true, force: true });
    }
  });
}

for (const schema of [
  "pulsechain-external-observer-r12f1-source-manifest@1.0.0",
  "pulsechain-external-observer-r12f2-source-manifest@1.0.0",
  undefined,
  null,
  "MALFORMED",
]) {
  test(`source-manifest schema rejects ${String(schema)}`, () => {
    const { outer, root } = fixture();
    try {
      mutateJson(root, "SOURCE_MANIFEST.json", (value) => { value.schema_version = schema; });
      assert.ok(codes(inspectBundleContract(root)).has("BUNDLE_SOURCE_MANIFEST_INVALID"));
    } finally {
      rmSync(outer, { recursive: true, force: true });
    }
  });
}

for (const [label, parent] of [
  ["R12D", R12D],
  ["R12F1 source", R12F1],
  ["null", null],
  ["malformed", "not-a-commit"],
  ["uppercase", R12F.toUpperCase()],
]) {
  test(`deployment parent rejects ${label}`, () => {
    const { outer, root } = fixture();
    try {
      mutateJson(root, "DEPLOYMENT_EXPECTATIONS.json", (value) => { value.source.parent = parent; });
      assert.ok(codes(inspectBundleContract(root)).has("BUNDLE_DEPLOYMENT_EXPECTATIONS_INVALID"));
    } finally {
      rmSync(outer, { recursive: true, force: true });
    }
  });
}

test("current package source and bound runtime parent remain separate", () => {
  const { outer, root } = fixture();
  try {
    const source = JSON.parse(readFileSync(join(root, "SOURCE_MANIFEST.json"), "utf8"));
    assert.equal(source.source.commit, R12F2);
    assert.equal(source.source.parent, R12F);
    assert.notEqual(source.source.commit, source.source.parent);
    assert.equal(inspectBundleContract(root).result, "PASS");
  } finally {
    rmSync(outer, { recursive: true, force: true });
  }
});
