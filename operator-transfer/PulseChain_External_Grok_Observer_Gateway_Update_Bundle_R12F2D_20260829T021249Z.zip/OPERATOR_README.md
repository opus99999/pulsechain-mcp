# PulseChain External Grok Observer Gateway R12F2D replacement update

This self-contained replacement supersedes the original R12F update ZIP, the R12F1 ZIP, the blocked R12F2 and R12F2A packaging attempts, and the R12F2B and R12F2C Windows bundles. R12F2D preserves the authoritative R12F2C operator-script repair and changes only the synthetic Windows test harness so its seven selected functions remain callable after import. All earlier evidence remains immutable. R12F2D does not alter the governed update-script template, gateway runtime bytes, Node verifier behavior, Worker settings, secrets, routes, or finalized connector vault.

## Bound source and rollback target

- Source branch: `external-observer-grok-mcp-r12f2d-windows-harness-scope-repair-20260829`
- Source commit: `9a30f43f90096f2cecb99dbe217c155eaf4b9633`
- Source tree: `3ca2102d8657f1ab6884f4bf8597170776b25f9c`
- Bound runtime authority / deployment parent: `ebef6c42a5eca2ad30669cf856e669a19e10edf9`
- R12F1 package-repair source: `75e3650f8e7f17af0ec2b2f312b920e15f96eb79`
- R12F2 predecessor commit: `f535c273c264f2c953ccd925a1d20c3f218c95a4`
- R12F2 predecessor tree: `2e9df9f68850ca588e4a4749db100ec760e57d7c`
- R12F2A predecessor commit: `d6db80436ab82a061161be99c53179d481eabfff`
- R12F2A predecessor tree: `a750a7da63ca1adbea3fe606c12c80bb9caebe3d`
- R12F2B predecessor commit: `e724d72adbeae653695d3198353d35ba173884f9`
- R12F2B predecessor tree: `b185d749737f83027d3a9573417e4a18cea1d61f`
- R12F2C predecessor commit: `94fb48e8ee4edbe0e48bbbdd71b235c788f8ce8a`
- R12F2C predecessor tree: `748da99a2935d394d34cbc71d8589cedfda18c87`
- Bundle: `PulseChain_External_Grok_Observer_Gateway_Update_Bundle_R12F2D_20260829T021249Z.zip`
- Existing Worker: `pulsechain-external-observer-grok-mcp`
- Existing deployment: `c776a6e0-14b8-49bc-be9a-7aa0e63c5495`
- Existing active Version: `e32f2b34-a572-404e-b969-44c0bf2c9088` at 100%
- Existing origin: `https://pulsechain-external-observer-grok-mcp.pulsechain-research-dade45b2.workers.dev`
- Rollback target: `e32f2b34-a572-404e-b969-44c0bf2c9088`

The update requires exactly five existing `GROK_MCP_TOKEN_*` secret bindings, no GitHub secret, `PUBLICATION_MODE=DISABLED`, and the fixed Control Room origin. It requires workers.dev enabled, preview URLs disabled, the exact compatibility date and flag, and no unexpected binding.

## Mandatory operator conditions

1. Create a unique attempt parent, then extract the ZIP so the bundle root's final leaf is exactly the ZIP filename without `.zip`. The required shape is `...\R12F2D-Attempt-<ATTEMPT_UTC>\<EXACT_R12F2D_ZIP_BASENAME>\`. Do not extract directly to `R12F2D-Update-<UTC>`, rename the extracted root, patch a prior extraction, or use an R12F, R12F1, blocked R12F2, blocked R12F2A, R12F2B, or R12F2C package.
2. Keep an exclusive Cloudflare change freeze for this Worker from the initial state read through the final deployment readback. No other operator or automation may upload a version, create a deployment, edit settings, or change secrets during this interval.
3. Use Windows PowerShell 7.4 or later as the same non-elevated CurrentUser that owns the finalized DPAPI vault.
4. Use the already authenticated Wrangler identity for Cloudflare account `dade45b2875ee5e98c74b5d06528cd9c`.
5. Ensure Node.js 22.13.0 or later is available. The lockfile pins Wrangler 4.92.0; the script uses only `npx --no-install wrangler` after `npm ci`.
6. Do not supply tokens, a secrets file, an environment credential, or a plaintext credential file. The governed verifier receives one token at a time only through its DPAPI bridge and protected child-process input.

From the extracted bundle root, run exactly:

```powershell
& .\UPDATE_EXISTING_GATEWAY_R12F.ps1 `
  -CloudflareAccountId 'dade45b2875ee5e98c74b5d06528cd9c' `
  -ChangeFreezeConfirmation 'I_HAVE_EXCLUSIVE_CHANGE_FREEZE'
```

Do not run `wrangler deploy`, `wrangler versions upload`, `wrangler versions deploy`, or the governed verifier separately. The script owns their required counts and ordering.

## Fail-closed sequence

The script validates every bundle member before dot-sourcing bundle code. It rejects a checksum or inventory mismatch, a reparse point, a path escape, a case-fold collision, a Windows reserved/trailing-dot path, source maps, credential material, logs, reports, `.env` files, and dependency directories.

It then:

1. runs the Windows ACL preflight and requires `TOTAL=25 PASS=25 FAIL=0`;
2. validates the finalized R12D DPAPI vault and snapshots its bytes, metadata, timestamps, and file/directory DACLs;
3. runs the complete gateway validation and every packaged deterministic operator test;
4. verifies the exact Worker, deployment, Version, traffic, variables, five secret names, bindings, route, preview state, compatibility contract, source identity, and absence of an undeployed draft;
5. uploads one separately controlled Version without changing production traffic;
6. reads the uploaded Version back, proves its five secret bindings and two exact variables, and compares its remotely stored module bytes with the local upload form;
7. repeats the complete production-state and vault comparison immediately before traffic change;
8. deploys that exact Version to 100% in exactly one deployment;
9. repeats the remote and vault readback; and
10. runs the governed disabled-mode verifier exactly once.

The finalized vault remains byte-for-byte and DACL-identical. Its R12D `current_version_id` is historical finalized metadata and is not retagged to R12F. A separate private update receipt records the uploaded Version and deployment IDs.

The R13 handoff is copied into the operator state directory only when the governed report is an exact PASS. A correctly classified `CONTROL_ROOM_UPSTREAM_UNAVAILABLE` preserves the deployed R12F Version, records the external blocker, and does not busy-loop or trigger rollback. An ordinary verifier failure also does not trigger rollback. A release-critical failure permits rollback only after separate authorization under [ROLLBACK_R12F.md](ROLLBACK_R12F.md).

## Provider limitations and stop conditions

Wrangler 4.92.0 does not expose a compare-and-swap or expected-active-deployment argument for `versions deploy`. The script therefore requires the exclusive change freeze and performs a complete immediate pre-deploy recheck; that narrows but cannot eliminate a provider-side race without operator exclusivity.

Wrangler's `versions upload` implementation may internally retry its mutation request. The script invokes the upload command only once and never retries an ambiguous upload itself, but the provider/CLI path cannot prove that an interrupted command created exactly zero or one Version until a readback succeeds. Likewise, an interrupted deployment response can be ambiguous. On either nonzero mutation result, do not rerun the command. Preserve the change freeze, inspect provider state read-only, record any Version or deployment that exists, and obtain a new separately reviewed recovery instruction.

Stop without traffic change on any pre-deploy mismatch. After traffic changes, do not conceal the new Version or deployment. Never alter or regenerate the connector vault, use a secret mutation command, or use the mutable transfer-branch URL as the controlling bundle download.

## Expected successful terminal record

Success reports the exact prior and new Version IDs, the one new deployment ID, 100% traffic, `PUBLICATION_MODE=DISABLED`, zero secret mutations, unchanged vault status, governed-verifier PASS, and R13 handoff readiness. Preserve the separate private update receipt and verifier report for the R13 checkpoint; never publish either file.
