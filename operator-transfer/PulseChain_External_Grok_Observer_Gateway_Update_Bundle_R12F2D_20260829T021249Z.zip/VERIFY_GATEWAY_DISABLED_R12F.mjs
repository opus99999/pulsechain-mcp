#!/usr/bin/env node

import { createHash } from "node:crypto";
import { pathToFileURL } from "node:url";

export const BRIDGE_PROTOCOL = "pulsechain-r12f-verifier-bridge@1.0.0";
export const PROTOCOL_VERSION = "2025-06-18";
export const WORKER_ORIGIN = "https://pulsechain-external-observer-grok-mcp.pulsechain-research-dade45b2.workers.dev";
export const CONTROL_ROOM_ORIGIN = "https://pulsechain-research-control-room.brohexphiat.chatgpt.site";
export const STAGE_TIMEOUT_MS = 60_000;
export const MAX_MCP_RESPONSE_BYTES = 8 * 1024 * 1024;
export const MAX_PUBLIC_RESPONSE_BYTES = 16 * 1024 * 1024;

export const COMMON_READ_TOOLS = Object.freeze([
  "read_external_observer_bootstrap",
  "read_workstream_bootstrap",
  "read_external_observation",
]);

export const CONNECTORS = Object.freeze([
  Object.freeze({
    observerId: "grok-x-protocol",
    path: "/mcp/external-observers/grok-x-protocol",
    publishTool: "publish_external_observation_grok_x_protocol",
    targetWorkstream: "signals-platform",
    observationId: "grok-x-protocol-r12c-disabled",
    fingerprint: "sha256:d19b907221f241a57a51c4fa0b0ad0fb57ed4ea3c50b7b488d53301384191355",
  }),
  Object.freeze({
    observerId: "grok-infrastructure-incidents",
    path: "/mcp/external-observers/grok-infrastructure-incidents",
    publishTool: "publish_external_observation_grok_infrastructure_incidents",
    targetWorkstream: "validator-flows",
    observationId: "grok-infrastructure-incidents-r12c-disabled",
    fingerprint: "sha256:0d00b2289ef749e625e91e52da4a611dce0685e6b47738d6d2ffe746fe9dc7ff",
  }),
  Object.freeze({
    observerId: "grok-market-liquidity",
    path: "/mcp/external-observers/grok-market-liquidity",
    publishTool: "publish_external_observation_grok_market_liquidity",
    targetWorkstream: "investor-intelligence",
    observationId: "grok-market-liquidity-r12c-disabled",
    fingerprint: "sha256:95a97b12f667cf05e3ebdf4621b1506ccaa451d422ebb96851536200c2e64dae",
  }),
  Object.freeze({
    observerId: "grok-identity-evidence",
    path: "/mcp/external-observers/grok-identity-evidence",
    publishTool: "publish_external_observation_grok_identity_evidence",
    targetWorkstream: "identity-attribution",
    observationId: "grok-identity-evidence-r12c-disabled",
    fingerprint: "sha256:a59ba28f8dcb8470b127f3a6ceefb139763678f4efe8714c005e463b88bc72dd",
  }),
  Object.freeze({
    observerId: "grok-red-team",
    path: "/mcp/external-observers/grok-red-team",
    publishTool: "publish_external_observation_grok_red_team",
    targetWorkstream: "signals-platform",
    observationId: "grok-red-team-r12c-disabled",
    fingerprint: "sha256:d7023e1fca3dbb0e7fc66461b87be07dd287c2aa8b3c84dc08be6a04f6190389",
  }),
]);

const FIXED_STAGE_NAMES = Object.freeze([
  "initialize",
  "notifications_initialized",
  "tools_list",
  "tool_contract_validation",
  "model_visible_identity_and_path_isolation",
  "read_external_observer_bootstrap",
  "read_workstream_bootstrap",
  "read_external_observation",
  "disabled_publication",
]);

const CRITICAL_CODES = new Set([
  "SECRET_EXPOSURE",
  "CROSS_OBSERVER_IDENTITY_EXPOSURE",
  "DISABLED_PUBLICATION_OCCURRED",
  "PROTECTED_STATE_MUTATION",
]);

const SAFE_MCP_TOOL_ERROR_CODES = new Set([
  "CONTROL_ROOM_UPSTREAM_UNAVAILABLE",
  "CONTROL_ROOM_UPSTREAM_NOT_FOUND",
  "CONTROL_ROOM_UPSTREAM_HTTP_ERROR",
  "PUBLICATION_MODE_DISABLED",
]);

const EXPECTED_OBSERVER_READ_SCHEMA = Object.freeze({
  type: "object",
  additionalProperties: false,
  properties: {},
});

const EXPECTED_WORKSTREAM_READ_SCHEMA = Object.freeze({
  type: "object",
  additionalProperties: false,
  required: ["workstream_id"],
  properties: {
    workstream_id: {
      enum: ["signals-platform", "validator-flows", "identity-attribution", "investor-intelligence"],
    },
  },
});

const EXPECTED_OBSERVATION_READ_SCHEMA = Object.freeze({
  type: "object",
  additionalProperties: false,
  required: ["observation_id"],
  properties: {
    observation_id: { type: "string", pattern: "^[a-z0-9-]{20,120}$" },
  },
});

const EXPECTED_PUBLISH_FIELDS = Object.freeze([
  "schema_version", "observation_id", "generated_at_utc", "observed_window",
  "source_class", "source_records", "claim_summary", "what_changed", "why_material",
  "materiality", "confidence", "evidence_state", "target_workstreams", "related_assets",
  "related_addresses", "related_contracts", "related_transactions", "related_update_ids",
  "specialist_questions", "prohibited_inferences", "duplicate_check", "recheck_at_utc",
  "adjudication_state", "synthetic_canary", "public_safe", "raw_sensitive_material_included",
  "content_sha256",
]);

// Only fixed public values owned by this verifier may satisfy the otherwise
// credential-shaped 43-byte canary check. The allowlist is deliberately not
// extensible through input, environment, response content, or connector frames.
const GOVERNED_PUBLIC_CREDENTIAL_SHAPE_ALLOWLIST = new Set(
  ["pulsechain-bound-external-observation-input", ...CONNECTORS.flatMap((connector) => [
    connector.observerId,
    connector.path,
    connector.publishTool,
    connector.targetWorkstream,
    connector.observationId,
  ])].filter((value) => /^[A-Za-z0-9_-]{43}$/u.test(value)),
);

class CriticalStop extends Error {
  constructor(code, stage, row = null) {
    super(code);
    this.name = "CriticalStop";
    this.code = code;
    this.stage = stage;
    this.row = row;
  }
}

export function canonicalJson(value) {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

export function sanitizeText(value, maximum = 320) {
  if (value === null || value === undefined) return null;
  let text = String(value).replace(/[\u0000-\u001f\u007f]+/gu, " ").trim();
  const replacements = [
    /authorization\s*[:=]\s*(?:bearer|basic)\s+[^\s,;]+/giu,
    /(?:token|secret|cookie|ciphertext|private[_ -]?key|session[_ -]?id)\s*[:=]\s*[^\s,;]+/giu,
    /-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----/gu,
    /\b(?:gh[opsu]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b/gu,
    /\b[A-Za-z0-9_-]{43}\b/gu,
  ];
  for (const pattern of replacements) text = text.replace(pattern, "[REDACTED]");
  return text.slice(0, maximum);
}

function containsForbiddenSecretMaterial(value, token = null, activeSessionId = null, governedRequestId = null) {
  const text = String(value ?? "");
  if (token && text.includes(token)) return true;
  if (activeSessionId && text.includes(activeSessionId)) return true;
  if (/\b(?:authorization|proxy-authorization)\s*[:=]\s*(?:bearer|basic)\s+[^\s,;]+/iu.test(text)) return true;
  if (/\bbearer\s+[A-Za-z0-9._~+/=-]{8,}/iu.test(text)) return true;
  if (/\b(?:set-cookie|cookie)\s*[:=]\s*[^\s,;]+/iu.test(text)) return true;
  if (/-----BEGIN [A-Z ]*PRIVATE KEY-----/u.test(text) || /-----END [A-Z ]*PRIVATE KEY-----/u.test(text)) return true;
  if (/\b(?:gh[opsu]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b/u.test(text)) return true;
  for (const match of text.matchAll(/(?<![A-Za-z0-9_-])([A-Za-z0-9_-]{43})(?![A-Za-z0-9_-])/gu)) {
    if (match[1] !== governedRequestId && !GOVERNED_PUBLIC_CREDENTIAL_SHAPE_ALLOWLIST.has(match[1])) return true;
  }
  return false;
}

function safeExceptionClass(error) {
  const name = error?.name;
  return ["AbortError", "TypeError", "SyntaxError", "RangeError", "Error"].includes(name) ? name : "Error";
}

function fixedExceptionMessage(classification) {
  const messages = {
    TIMEOUT: "The MCP stage exceeded its 60 second deadline",
    CALLER_CANCELLATION: "The verifier was cancelled",
    TRANSPORT_ERROR: "The MCP transport failed",
    INVALID_CONTENT_TYPE: "The MCP response content type was invalid",
    OVERSIZED_RESPONSE: "The MCP response exceeded the byte limit",
    MALFORMED_JSON: "The MCP response was not valid JSON",
    MALFORMED_SSE: "The MCP event stream was invalid",
    INTERNAL_VERIFIER_ERROR: "The verifier stage failed closed",
  };
  return messages[classification] ?? "The verifier stage failed closed";
}

function rpcMessage(id, method, params) {
  const message = { jsonrpc: "2.0", id, method };
  if (params !== undefined) message.params = params;
  return message;
}

function notification(method) {
  return { jsonrpc: "2.0", method };
}

function exactWorkerUrl(path) {
  const url = new URL(path, WORKER_ORIGIN);
  if (url.origin !== WORKER_ORIGIN || url.pathname !== path || url.search || url.hash) throw new Error("Fixed Worker path validation failed");
  return url.href;
}

function exactControlRoomUrl(path) {
  if (!path.startsWith("/") || path.includes("?") || path.includes("#")) throw new Error("Control Room path validation failed");
  const url = new URL(path, CONTROL_ROOM_ORIGIN);
  if (url.origin !== CONTROL_ROOM_ORIGIN || url.pathname !== path || url.search || url.hash) throw new Error("Fixed Control Room path validation failed");
  return url.href;
}

function defaultClock() {
  return { nowMs: () => performance.now(), nowIso: () => new Date().toISOString() };
}

function defaultTimers() {
  return { setTimeout: globalThis.setTimeout, clearTimeout: globalThis.clearTimeout };
}

function createRow(connector, ordinal, stage, state, requestMethod = "POST", safePath = connector.path, sessionIdPresent = Boolean(state.sessionId)) {
  return {
    connector_id: connector.observerId,
    connector_ordinal: ordinal,
    stage,
    request_method: requestMethod,
    safe_url_path: safePath,
    http_status: null,
    content_type: null,
    elapsed_ms: 0,
    response_classification: null,
    json_rpc_error_code: null,
    sanitized_json_rpc_error_message: null,
    mcp_tool_error_code: null,
    sanitized_mcp_tool_error_message: null,
    upstream_failure: null,
    mcp_protocol_version: state.protocolVersion,
    session_id_present: Boolean(sessionIdPresent),
    exception_class: null,
    sanitized_exception_message: null,
    timeout: false,
    authentication_passed: state.authenticationPassed,
    initialize_passed: state.initializePassed,
    tools_list_passed: state.toolsListPassed,
    disabled_write_attempted: state.disabledWriteAttempted,
    transport_attempt_count: requestMethod === null ? 0 : 1,
    result: "PENDING",
  };
}

function failRow(row, classification, message = null) {
  row.response_classification = classification;
  row.sanitized_exception_message = message ? sanitizeText(message) : row.sanitized_exception_message;
  row.result = "FAIL";
  return row;
}

function passRow(row, classification) {
  row.response_classification = classification;
  row.result = "PASS";
  return row;
}

function skippedRow(connector, ordinal, stage, state, reason) {
  const row = createRow(connector, ordinal, stage, state, null);
  row.response_classification = reason;
  row.result = "SKIPPED";
  return row;
}

function expectedStages(connector) {
  const foreign = CONNECTORS.filter((item) => item.observerId !== connector.observerId)
    .map((item) => `foreign_path_isolation:${item.observerId}`);
  return [...FIXED_STAGE_NAMES.slice(0, 5), ...foreign, ...FIXED_STAGE_NAMES.slice(5)];
}

async function readBoundedBody(response, maximumBytes) {
  const claimed = response.headers.get("content-length");
  if (claimed !== null && (!/^\d+$/u.test(claimed) || Number(claimed) > maximumBytes)) {
    try { await response.body?.cancel(); } catch { /* best effort */ }
    const error = new RangeError("OVERSIZED_RESPONSE");
    error.classification = "OVERSIZED_RESPONSE";
    throw error;
  }
  if (!response.body) return new Uint8Array();
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maximumBytes) {
        await reader.cancel();
        const error = new RangeError("OVERSIZED_RESPONSE");
        error.classification = "OVERSIZED_RESPONSE";
        throw error;
      }
      chunks.push(value);
    }
    const bytes = new Uint8Array(total);
    let offset = 0;
    for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
    return bytes;
  } finally {
    try { reader.releaseLock(); } catch { /* already released */ }
  }
}

function decodeUtf8(bytes) {
  try {
    return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    const error = new SyntaxError("MALFORMED_UTF8");
    error.classification = "MALFORMED_JSON";
    throw error;
  }
}

export function parseEventStream(text, expectedId) {
  const messages = [];
  for (const block of text.replace(/\r\n?/gu, "\n").split("\n\n")) {
    if (!block.trim()) continue;
    const data = [];
    for (const line of block.split("\n")) {
      if (!line || line.startsWith(":")) continue;
      const colon = line.indexOf(":");
      const field = colon < 0 ? line : line.slice(0, colon);
      let value = colon < 0 ? "" : line.slice(colon + 1);
      if (value.startsWith(" ")) value = value.slice(1);
      if (field === "data") data.push(value);
    }
    if (data.length === 0) continue;
    try { messages.push(JSON.parse(data.join("\n"))); } catch {
      const error = new SyntaxError("MALFORMED_SSE");
      error.classification = "MALFORMED_SSE";
      throw error;
    }
  }
  const finals = messages.filter((message) => message && message.jsonrpc === "2.0" && Object.hasOwn(message, "id") && message.id === expectedId);
  if (finals.length !== 1) {
    const error = new SyntaxError("MALFORMED_SSE");
    error.classification = "MALFORMED_SSE";
    throw error;
  }
  return finals[0];
}

function parseMcpBody(text, mediaType, expectedId) {
  if (mediaType === "application/json") {
    try { return JSON.parse(text); } catch {
      const error = new SyntaxError("MALFORMED_JSON");
      error.classification = "MALFORMED_JSON";
      throw error;
    }
  }
  if (mediaType === "text/event-stream") return parseEventStream(text, expectedId);
  const error = new TypeError("INVALID_CONTENT_TYPE");
  error.classification = "INVALID_CONTENT_TYPE";
  throw error;
}

function safeRpcDetails(row, body) {
  if (body?.error && typeof body.error === "object") {
    row.json_rpc_error_code = Number.isInteger(body.error.code) ? body.error.code : null;
    row.sanitized_json_rpc_error_message = sanitizeText(body.error.message);
  }
  const result = body?.result;
  const tool = result?.structuredContent;
  if (result?.isError === true && tool && typeof tool === "object") {
    const rawCode = typeof tool.error === "string" ? tool.error : typeof tool.error_code === "string" ? tool.error_code : null;
    const code = SAFE_MCP_TOOL_ERROR_CODES.has(rawCode) ? rawCode : rawCode === null ? null : "UNRECOGNIZED_MCP_TOOL_ERROR";
    row.mcp_tool_error_code = code;
    row.sanitized_mcp_tool_error_message = sanitizeText(tool.message);
    if (rawCode === "CONTROL_ROOM_UPSTREAM_UNAVAILABLE") {
      const safeString = (value, maximum = 320) => typeof value === "string" ? sanitizeText(value, maximum) : null;
      const safeNumber = (value) => Number.isSafeInteger(value) && value >= 0 ? value : null;
      const safeBoolean = (value) => typeof value === "boolean" ? value : null;
      const requestId = typeof tool.upstream_request_id === "string" && /^[A-Za-z0-9._:-]{1,128}$/u.test(tool.upstream_request_id)
        ? tool.upstream_request_id
        : null;
      row.upstream_failure = {
        tool_name: safeString(tool.tool_name, 96),
        fixed_observer_id: safeString(tool.fixed_observer_id, 96),
        target_workstream: safeString(tool.target_workstream, 96),
        control_room_origin: tool.control_room_origin === CONTROL_ROOM_ORIGIN ? CONTROL_ROOM_ORIGIN : null,
        target_path: typeof tool.target_path === "string" && /^\/api\/v1\/[A-Za-z0-9/_-]+$/u.test(tool.target_path) ? tool.target_path : null,
        attempt_count: safeNumber(tool.attempt_count),
        retry_count: safeNumber(tool.retry_count),
        total_elapsed_ms: safeNumber(tool.total_elapsed_ms),
        last_http_status: safeNumber(tool.last_http_status),
        last_content_type: safeString(tool.last_content_type, 128),
        last_error_class: safeString(tool.last_error_class, 96),
        sanitized_last_error_message: safeString(tool.last_error_message),
        retry_after_observed: safeBoolean(tool.retry_after_observed),
        retry_after_applied_ms: safeNumber(tool.retry_after_applied_ms),
        final_failure_stage: safeString(tool.final_failure_stage, 96),
        upstream_request_id: requestId,
      };
      row.response_classification = "CONTROL_ROOM_UPSTREAM_UNAVAILABLE";
    }
  }
}

async function invokeMcp({
  connector,
  ordinal,
  targetPath = connector.path,
  stage,
  message,
  token,
  sessionId = null,
  protocolVersion = null,
  notificationResponse = false,
  state,
  fetchImpl,
  clock,
  timers,
  stageTimeoutMs,
  signal,
  metrics,
}) {
  const row = createRow(connector, ordinal, stage, state, "POST", targetPath, Boolean(sessionId));
  const controller = new AbortController();
  let timedOut = false;
  let callerCancelled = false;
  let timer = null;
  let callerListener = null;
  const started = clock.nowMs();
  let response = null;
  let responseFingerprint = null;
  try {
    if (signal?.aborted) {
      callerCancelled = true;
      controller.abort();
    } else if (signal) {
      callerListener = () => { callerCancelled = true; controller.abort(); };
      signal.addEventListener("abort", callerListener, { once: true });
    }
    timer = timers.setTimeout(() => { timedOut = true; controller.abort(); }, stageTimeoutMs);
    if (callerCancelled) throw new DOMException("cancelled", "AbortError");
    const headers = {
      Authorization: `Bearer ${token}`,
      Accept: "application/json, text/event-stream",
      "Content-Type": "application/json",
    };
    if (protocolVersion) headers["MCP-Protocol-Version"] = protocolVersion;
    if (sessionId) headers["Mcp-Session-Id"] = sessionId;
    metrics.mcp_request_count += 1;
    metrics.outbound_hosts.add(new URL(WORKER_ORIGIN).hostname);
    response = await fetchImpl(exactWorkerUrl(targetPath), {
      method: "POST",
      headers,
      body: JSON.stringify(message),
      redirect: "error",
      signal: controller.signal,
    });
    row.http_status = response.status;
    row.content_type = sanitizeText(response.headers.get("content-type"), 128);
    responseFingerprint = response.headers.get("x-pulsechain-tool-discovery-fingerprint");
    for (const [name, value] of response.headers) {
      const isSessionHeader = name.toLowerCase() === "mcp-session-id";
      const unsafe = isSessionHeader
        ? Boolean(token && value.includes(token))
        : containsForbiddenSecretMaterial(`${name}: ${value}`, token, sessionId);
      if (unsafe) throw new CriticalStop("SECRET_EXPOSURE", stage, failRow(row, "SECRET_EXPOSURE"));
    }
    const bytes = await readBoundedBody(response, MAX_MCP_RESPONSE_BYTES);
    const text = decodeUtf8(bytes);
    bytes.fill(0);
    if (containsForbiddenSecretMaterial(text, token, sessionId, typeof message.id === "string" ? message.id : null)) {
      throw new CriticalStop("SECRET_EXPOSURE", stage, failRow(row, "SECRET_EXPOSURE"));
    }
    if (notificationResponse) {
      if (response.status !== 202 || text.length !== 0) return { row: failRow(row, "MCP_NOTIFICATION_REJECTED"), body: null, sessionId: null, responseFingerprint };
      return { row: passRow(row, "MCP_NOTIFICATION_ACCEPTED"), body: null, sessionId: null, responseFingerprint };
    }
    const mediaType = (response.headers.get("content-type") ?? "").split(";", 1)[0].trim().toLowerCase();
    let body = null;
    if (text.length > 0 && (mediaType === "application/json" || mediaType === "text/event-stream")) {
      body = parseMcpBody(text, mediaType, message.id);
      safeRpcDetails(row, body);
    }
    if (response.status === 401) return { row: failRow(row, "HTTP_AUTHENTICATION_FAILURE"), body, sessionId: null, responseFingerprint };
    if (response.status < 200 || response.status >= 300) return { row: failRow(row, `HTTP_${response.status}`), body, sessionId: null, responseFingerprint };
    if (mediaType !== "application/json" && mediaType !== "text/event-stream") throw Object.assign(new TypeError("INVALID_CONTENT_TYPE"), { classification: "INVALID_CONTENT_TYPE" });
    if (!body || body.jsonrpc !== "2.0" || body.id !== message.id) return { row: failRow(row, "INVALID_JSON_RPC_ENVELOPE"), body, sessionId: null, responseFingerprint };
    if (body.error) return { row: failRow(row, "JSON_RPC_ERROR"), body, sessionId: null, responseFingerprint };
    if (body.result?.isError === true) {
      const classification = row.mcp_tool_error_code === "CONTROL_ROOM_UPSTREAM_UNAVAILABLE" ? "CONTROL_ROOM_UPSTREAM_UNAVAILABLE" : "MCP_TOOL_ERROR";
      return { row: failRow(row, classification), body, sessionId: null, responseFingerprint, transportPassed: true };
    }
    const returnedSession = response.headers.get("mcp-session-id");
    if (returnedSession !== null && (returnedSession.length === 0 || returnedSession.length > 1024)) {
      return { row: failRow(row, "INVALID_SESSION_ID_HEADER"), body, sessionId: null, responseFingerprint };
    }
    if (sessionId && returnedSession && returnedSession !== sessionId) {
      return { row: failRow(row, "MCP_SESSION_ID_CHANGED"), body, sessionId: null, responseFingerprint };
    }
    return { row: passRow(row, mediaType === "text/event-stream" ? "MCP_SSE_SUCCESS" : "MCP_JSON_SUCCESS"), body, sessionId: returnedSession, responseFingerprint, transportPassed: true };
  } catch (error) {
    if (error instanceof CriticalStop) throw error;
    const classification = callerCancelled ? "CALLER_CANCELLATION" : timedOut ? "TIMEOUT" : error?.classification ?? "TRANSPORT_ERROR";
    row.timeout = timedOut;
    row.exception_class = safeExceptionClass(error);
    row.sanitized_exception_message = fixedExceptionMessage(classification);
    return { row: failRow(row, classification), body: null, sessionId: null, responseFingerprint };
  } finally {
    if (timer !== null) timers.clearTimeout(timer);
    if (callerListener) signal.removeEventListener("abort", callerListener);
    row.elapsed_ms = Math.max(0, Math.round(clock.nowMs() - started));
    response = null;
  }
}

function localStage(connector, ordinal, stage, state, validator) {
  const row = createRow(connector, ordinal, stage, state, null);
  try {
    validator();
    return passRow(row, "LOCAL_CONTRACT_PASS");
  } catch (error) {
    row.exception_class = safeExceptionClass(error);
    row.sanitized_exception_message = sanitizeText(error.message);
    if (error?.code === "CROSS_OBSERVER_IDENTITY_EXPOSURE") row.critical_code = error.code;
    return failRow(row, "LOCAL_CONTRACT_FAILURE");
  }
}

function validateInitialize(connector, body) {
  const result = body?.result;
  const publication = result?.publication;
  if (
    result?.protocolVersion !== PROTOCOL_VERSION ||
    result?.serverInfo?.name !== `pulsechain-${connector.observerId}-mcp` ||
    publication?.publication_mode !== "DISABLED" ||
    publication?.publication_ready !== false ||
    publication?.github_publication_transport !== "DEFERRED_WHILE_DISABLED" ||
    publication?.credential_method !== null ||
    publication?.automatic_promotion !== false
  ) throw new Error("Initialize result or disabled readiness is invalid");
}

function validateTools(connector, response) {
  const tools = response?.body?.result?.tools;
  if (!Array.isArray(tools)) throw new Error("tools/list did not return a tool array");
  const names = tools.map((tool) => tool?.name);
  const expected = [connector.publishTool, ...COMMON_READ_TOOLS];
  if (new Set(names).size !== names.length || canonicalJson(names) !== canonicalJson(expected)) throw new Error("Exact tool list mismatch");
  const publish = tools.filter((tool) => typeof tool?.name === "string" && tool.name.startsWith("publish_external_observation_"));
  if (publish.length !== 1 || publish[0].name !== connector.publishTool) throw new Error("Missing or foreign publish tool");
  for (const common of COMMON_READ_TOOLS) {
    if (tools.filter((tool) => tool?.name === common).length !== 1) throw new Error(`Missing common read tool: ${common}`);
  }
  assertNoModelSelectedControls(tools);
  validateExactToolSchemas(connector, tools);
  const calculatedFingerprint = `sha256:${createHash("sha256").update(canonicalJson(tools)).digest("hex")}`;
  if (calculatedFingerprint !== connector.fingerprint || response.fingerprint !== connector.fingerprint) {
    throw new Error("Exact four-tool schema fingerprint mismatch");
  }
  return tools;
}

function assertNoModelSelectedControls(tools) {
  const forbidden = new Set([
    "observerid", "fixedobserverid", "externalobserverid", "observeridentity",
    "repository", "workflow", "ledgerpath", "githubcredential", "connectorcredential",
    "publicationmode", "connectorpath", "workerorigin",
  ]);
  function visit(value, key = "") {
    const normalized = key.toLowerCase().replace(/[^a-z0-9]/gu, "");
    if (forbidden.has(normalized)) {
      const error = new Error(`Server-selected control is model-visible: ${key}`);
      error.code = "CROSS_OBSERVER_IDENTITY_EXPOSURE";
      throw error;
    }
    if (Array.isArray(value)) return value.forEach((entry) => visit(entry));
    if (value && typeof value === "object") return Object.entries(value).forEach(([nestedKey, nested]) => visit(nested, nestedKey));
  }
  for (const tool of tools) visit(tool?.inputSchema);
}

function validateExactToolSchemas(connector, tools) {
  const schemaFor = (name) => tools.find((tool) => tool.name === name)?.inputSchema;
  const publishSchema = schemaFor(connector.publishTool);
  if (
    !publishSchema ||
    publishSchema.type !== "object" ||
    publishSchema.additionalProperties !== false ||
    canonicalJson(publishSchema.required) !== canonicalJson(EXPECTED_PUBLISH_FIELDS) ||
    canonicalJson(Object.keys(publishSchema.properties ?? {})) !== canonicalJson(EXPECTED_PUBLISH_FIELDS)
  ) throw new Error("Exact publish tool schema mismatch");
  if (canonicalJson(schemaFor("read_external_observer_bootstrap")) !== canonicalJson(EXPECTED_OBSERVER_READ_SCHEMA)) {
    throw new Error("Exact observer read schema mismatch");
  }
  if (canonicalJson(schemaFor("read_workstream_bootstrap")) !== canonicalJson(EXPECTED_WORKSTREAM_READ_SCHEMA)) {
    throw new Error("Exact workstream read schema mismatch");
  }
  if (canonicalJson(schemaFor("read_external_observation")) !== canonicalJson(EXPECTED_OBSERVATION_READ_SCHEMA)) {
    throw new Error("Exact observation read schema mismatch");
  }
}

function validateModelVisibleControls(connector, tools) {
  assertNoModelSelectedControls(tools);
  validateExactToolSchemas(connector, tools);
  const observerRead = tools.find((tool) => tool.name === "read_external_observer_bootstrap");
  if (canonicalJson(observerRead?.inputSchema) !== canonicalJson(EXPECTED_OBSERVER_READ_SCHEMA)) {
    const error = new Error("Observer read schema permits model-selected scope");
    error.code = "CROSS_OBSERVER_IDENTITY_EXPOSURE";
    throw error;
  }
}

function buildDisabledPayload(connector) {
  const args = {
    schema_version: "pulsechain-external-observation@1.0.0",
    observation_id: connector.observationId,
    generated_at_utc: "2026-08-27T20:00:00Z",
    observed_window: { from_utc: "2026-08-27T19:55:00Z", to_utc: "2026-08-27T20:00:00Z" },
    source_class: "PUBLIC_SECONDARY_SOURCE",
    source_records: [{
      url: "https://example.com/synthetic-r12c-disabled",
      source_id: "synthetic-r12c-disabled-source",
      author_or_domain: "example.com",
      published_at_utc: null,
      retrieved_at_utc: "2026-08-27T20:00:00Z",
      content_sha256: `sha256:${"1".repeat(64)}`,
      primary_source: false,
      authenticated_source: false,
    }],
    claim_summary: "SYNTHETIC_CANARY — INFRASTRUCTURE ONLY. Invented disabled-mode validation payload.",
    what_changed: "Invented test bytes exercised validation only.",
    why_material: "Proves disabled remote MCP validation without publication.",
    materiality: "HIGH",
    confidence: "HIGH",
    evidence_state: "PROVISIONAL_EXTERNAL_SIGNAL",
    target_workstreams: [connector.targetWorkstream],
    related_assets: [], related_addresses: [], related_contracts: [], related_transactions: [], related_update_ids: [],
    specialist_questions: ["Does this synthetic payload remain nonactionable?"],
    prohibited_inferences: ["No real-world claim may be inferred."],
    duplicate_check: { checked_observation_ids: [], duplicate_of: null, canonical_duplicate_key: `sha256:${"3".repeat(64)}` },
    recheck_at_utc: null,
    adjudication_state: "PENDING_SPECIALIST_REVIEW",
    synthetic_canary: true,
    public_safe: true,
    raw_sensitive_material_included: false,
  };
  const identity = { ...args, observer_id: connector.observerId };
  args.content_sha256 = `sha256:${createHash("sha256").update(canonicalJson(identity)).digest("hex")}`;
  return args;
}

function readToolResult(response, expectedIdentity) {
  const result = response?.body?.result;
  if (!result || result.isError === true) return { ok: false, critical: false, classification: response?.row?.response_classification ?? "MCP_TOOL_ERROR" };
  const structured = result.structuredContent;
  if (!structured || typeof structured !== "object") return { ok: false, critical: false, classification: "MISSING_STRUCTURED_CONTENT" };
  if (expectedIdentity.kind === "observer" && structured.observer_id !== expectedIdentity.value) {
    return typeof structured.observer_id === "string"
      ? { ok: false, critical: true, classification: "CROSS_OBSERVER_IDENTITY_EXPOSURE" }
      : { ok: false, critical: false, classification: "OBSERVER_IDENTITY_FIELD_MISSING" };
  }
  if (expectedIdentity.kind === "workstream" && structured.requested_workstream_id !== expectedIdentity.value) {
    return typeof structured.requested_workstream_id === "string"
      ? { ok: false, critical: true, classification: "CROSS_OBSERVER_IDENTITY_EXPOSURE" }
      : { ok: false, critical: false, classification: "WORKSTREAM_IDENTITY_FIELD_MISSING" };
  }
  return { ok: true, critical: false, classification: "MCP_READ_SUCCESS" };
}

function observationResult(response, observationId) {
  const result = response?.body?.result;
  const structured = result?.structuredContent;
  if (result?.isError === true) {
    const code = structured?.error ?? structured?.error_code;
    const notFoundCode = code === "CONTROL_ROOM_UPSTREAM_NOT_FOUND" || code === "CONTROL_ROOM_UPSTREAM_HTTP_ERROR";
    if (notFoundCode && structured?.last_http_status === 404 && structured?.attempt_count === 1 && structured?.retry_count === 0) {
      return { ok: true, classification: "EXPECTED_EMPTY_LEDGER_NOT_FOUND" };
    }
    return { ok: false, classification: code === "CONTROL_ROOM_UPSTREAM_UNAVAILABLE" ? code : "UNEXPECTED_OBSERVATION_READ_ERROR" };
  }
  if (structured?.observation?.observation_id === observationId) return { ok: true, classification: "OBSERVATION_PRESENT" };
  return { ok: false, classification: "INVALID_OBSERVATION_READ_RESULT" };
}

function inspectDisabledReceipt(response) {
  const result = response?.body?.result;
  const structured = result?.structuredContent;
  const identityFields = ["issue_number", "workflow_run_id", "observation_id", "publication_commit", "permanent_url", "manifest_sha256"];
  if (structured?.accepted === true || identityFields.some((field) => structured?.[field] !== null && structured?.[field] !== undefined)) {
    return { ok: false, critical: true, classification: "DISABLED_PUBLICATION_OCCURRED" };
  }
  let content = null;
  try { content = JSON.parse(result?.content?.[0]?.text ?? ""); } catch { /* invalid receipt */ }
  const exact =
    result && result.isError !== true &&
    structured?.accepted === false &&
    structured?.error_code === "PUBLICATION_MODE_DISABLED" &&
    identityFields.every((field) => structured[field] === null) &&
    canonicalJson(content) === canonicalJson(structured);
  return { ok: exact, critical: false, classification: exact ? "PUBLICATION_MODE_DISABLED" : "DISABLED_RECEIPT_MISMATCH" };
}

function completeRows(connector, ordinal, rows, state, reason) {
  const seen = new Set(rows.map((row) => row.stage));
  for (const stage of expectedStages(connector)) {
    if (!seen.has(stage)) rows.push(skippedRow(connector, ordinal, stage, state, reason));
  }
  rows.sort((left, right) => expectedStages(connector).indexOf(left.stage) - expectedStages(connector).indexOf(right.stage));
}

async function verifyConnector(connector, ordinal, options) {
  const state = {
    protocolVersion: null,
    sessionId: null,
    authenticationPassed: false,
    initializePassed: false,
    toolsListPassed: false,
    disabledWriteAttempted: false,
  };
  const rows = [];
  let suppliedCredential = null;
  let tokenBytes = null;
  let token = null;
  let criticalStop = null;
  let tools = null;
  const request = (input) => invokeMcp({
    connector, ordinal, token, state, fetchImpl: options.fetchImpl, clock: options.clock,
    timers: options.timers, stageTimeoutMs: options.stageTimeoutMs, signal: options.signal,
    metrics: options.metrics, ...input,
  });
  try {
    suppliedCredential = await options.credentialProvider(connector, ordinal);
    if (!(suppliedCredential instanceof Uint8Array)) throw new TypeError("Connector credential handoff must be a binary frame payload");
    tokenBytes = suppliedCredential;
    token = new TextDecoder("utf-8", { fatal: true }).decode(tokenBytes);
    if (!/^[A-Za-z0-9_-]{43}$/u.test(token)) throw new Error("Connector credential frame is invalid");

    const initialize = await request({
      stage: "initialize",
      message: rpcMessage(`initialize-${connector.observerId}`, "initialize", {
        protocolVersion: PROTOCOL_VERSION,
        capabilities: {},
        clientInfo: { name: "pulsechain-r12f-verifier", version: "1.0.0" },
      }),
    });
    rows.push(initialize.row);
    if (initialize.row.result !== "PASS") {
      completeRows(connector, ordinal, rows, state, "DEPENDENCY_FAILED");
      return { connector, ordinal, rows, result: "FAIL", state, criticalStop };
    }
    state.authenticationPassed = true;
    try { validateInitialize(connector, initialize.body); } catch (error) {
      failRow(initialize.row, "INITIALIZE_CONTRACT_MISMATCH", error.message);
      completeRows(connector, ordinal, rows, state, "DEPENDENCY_FAILED");
      return { connector, ordinal, rows, result: "FAIL", state, criticalStop };
    }
    state.protocolVersion = PROTOCOL_VERSION;
    state.initializePassed = true;
    state.sessionId = initialize.sessionId || null;
    initialize.row.authentication_passed = true;
    initialize.row.initialize_passed = true;
    initialize.row.mcp_protocol_version = PROTOCOL_VERSION;
    initialize.row.session_id_present = Boolean(state.sessionId);

    const initialized = await request({
      stage: "notifications_initialized",
      message: notification("notifications/initialized"),
      sessionId: state.sessionId,
      protocolVersion: state.protocolVersion,
      notificationResponse: true,
    });
    rows.push(initialized.row);
    if (initialized.row.result !== "PASS") {
      completeRows(connector, ordinal, rows, state, "DEPENDENCY_FAILED");
      return { connector, ordinal, rows, result: "FAIL", state, criticalStop };
    }

    const discovery = await request({
      stage: "tools_list",
      message: rpcMessage(`tools-${connector.observerId}`, "tools/list"),
      sessionId: state.sessionId,
      protocolVersion: state.protocolVersion,
    });
    rows.push(discovery.row);
    discovery.fingerprint = discovery.responseFingerprint;
    try {
      tools = validateTools(connector, discovery);
      state.toolsListPassed = true;
      discovery.row.tools_list_passed = true;
    } catch (error) {
      const classification = error?.code === "CROSS_OBSERVER_IDENTITY_EXPOSURE"
        ? "CROSS_OBSERVER_IDENTITY_EXPOSURE"
        : "TOOLS_LIST_MISMATCH";
      failRow(discovery.row, classification, error.message);
      if (classification === "CROSS_OBSERVER_IDENTITY_EXPOSURE") {
        criticalStop = { code: classification, connector_id: connector.observerId, stage: discovery.row.stage };
        throw new CriticalStop(classification, discovery.row.stage, discovery.row);
      }
    }
    if (!state.toolsListPassed) {
      completeRows(connector, ordinal, rows, state, "DEPENDENCY_FAILED");
      return { connector, ordinal, rows, result: "FAIL", state, criticalStop };
    }

    const toolContract = localStage(connector, ordinal, "tool_contract_validation", state, () => validateTools(connector, discovery));
    rows.push(toolContract);
    const identityContract = localStage(connector, ordinal, "model_visible_identity_and_path_isolation", state, () => validateModelVisibleControls(connector, tools));
    rows.push(identityContract);
    if (identityContract.critical_code === "CROSS_OBSERVER_IDENTITY_EXPOSURE") {
      criticalStop = { code: "CROSS_OBSERVER_IDENTITY_EXPOSURE", connector_id: connector.observerId, stage: identityContract.stage };
      throw new CriticalStop(criticalStop.code, criticalStop.stage, identityContract);
    }

    for (const foreign of CONNECTORS.filter((item) => item.observerId !== connector.observerId)) {
      const stage = `foreign_path_isolation:${foreign.observerId}`;
      const foreignResult = await request({
        targetPath: foreign.path,
        stage,
        message: rpcMessage(`foreign-${connector.observerId}-${foreign.observerId}`, "tools/list"),
        protocolVersion: state.protocolVersion,
      });
      if (foreignResult.row.http_status === 401) passRow(foreignResult.row, "FOREIGN_AUTHENTICATION_REJECTED");
      else if (foreignResult.row.http_status === 200 && foreignResult.body?.result) {
        failRow(foreignResult.row, "CROSS_OBSERVER_IDENTITY_EXPOSURE");
        rows.push(foreignResult.row);
        criticalStop = { code: "CROSS_OBSERVER_IDENTITY_EXPOSURE", connector_id: connector.observerId, stage };
        throw new CriticalStop(criticalStop.code, stage, foreignResult.row);
      }
      rows.push(foreignResult.row);
    }

    const observerRead = await request({
      stage: "read_external_observer_bootstrap",
      message: rpcMessage(`observer-read-${connector.observerId}`, "tools/call", { name: "read_external_observer_bootstrap", arguments: {} }),
      sessionId: state.sessionId,
      protocolVersion: state.protocolVersion,
    });
    const observerCheck = readToolResult(observerRead, { kind: "observer", value: connector.observerId });
    if (observerRead.row.result === "PASS" && observerCheck.ok) passRow(observerRead.row, observerCheck.classification);
    else if (observerCheck.critical) {
      failRow(observerRead.row, observerCheck.classification);
      rows.push(observerRead.row);
      criticalStop = { code: observerCheck.classification, connector_id: connector.observerId, stage: observerRead.row.stage };
      throw new CriticalStop(criticalStop.code, observerRead.row.stage, observerRead.row);
    } else if (observerRead.row.result === "PASS") failRow(observerRead.row, observerCheck.classification);
    rows.push(observerRead.row);

    const workstreamRead = await request({
      stage: "read_workstream_bootstrap",
      message: rpcMessage(`workstream-read-${connector.observerId}`, "tools/call", { name: "read_workstream_bootstrap", arguments: { workstream_id: connector.targetWorkstream } }),
      sessionId: state.sessionId,
      protocolVersion: state.protocolVersion,
    });
    const workstreamCheck = readToolResult(workstreamRead, { kind: "workstream", value: connector.targetWorkstream });
    if (workstreamRead.row.result === "PASS" && workstreamCheck.ok) passRow(workstreamRead.row, workstreamCheck.classification);
    else if (workstreamCheck.critical) {
      failRow(workstreamRead.row, workstreamCheck.classification);
      rows.push(workstreamRead.row);
      criticalStop = { code: workstreamCheck.classification, connector_id: connector.observerId, stage: workstreamRead.row.stage };
      throw new CriticalStop(criticalStop.code, workstreamRead.row.stage, workstreamRead.row);
    } else if (workstreamRead.row.result === "PASS") failRow(workstreamRead.row, workstreamCheck.classification);
    rows.push(workstreamRead.row);

    const observationRead = await request({
      stage: "read_external_observation",
      message: rpcMessage(`observation-read-${connector.observerId}`, "tools/call", { name: "read_external_observation", arguments: { observation_id: connector.observationId } }),
      sessionId: state.sessionId,
      protocolVersion: state.protocolVersion,
    });
    const observationCheck = observationResult(observationRead, connector.observationId);
    if (observationRead.transportPassed === true && observationCheck.ok) passRow(observationRead.row, observationCheck.classification);
    else if (observationRead.row.result === "PASS") failRow(observationRead.row, observationCheck.classification);
    rows.push(observationRead.row);

    state.disabledWriteAttempted = true;
    const disabled = await request({
      stage: "disabled_publication",
      message: rpcMessage(`disabled-${connector.observerId}`, "tools/call", { name: connector.publishTool, arguments: buildDisabledPayload(connector) }),
      sessionId: state.sessionId,
      protocolVersion: state.protocolVersion,
    });
    disabled.row.disabled_write_attempted = true;
    if (disabled.row.result === "PASS") {
      const disabledCheck = inspectDisabledReceipt(disabled);
      if (disabledCheck.critical) {
        failRow(disabled.row, disabledCheck.classification);
        rows.push(disabled.row);
        criticalStop = { code: disabledCheck.classification, connector_id: connector.observerId, stage: disabled.row.stage };
        throw new CriticalStop(criticalStop.code, disabled.row.stage, disabled.row);
      }
      if (disabledCheck.ok) passRow(disabled.row, disabledCheck.classification);
      else failRow(disabled.row, disabledCheck.classification);
    }
    rows.push(disabled.row);
  } catch (error) {
    if (error instanceof CriticalStop) {
      criticalStop ??= { code: error.code, connector_id: connector.observerId, stage: error.stage };
      if (error.row && !rows.includes(error.row)) rows.push(error.row);
    } else {
      const stage = "credential_handoff";
      const row = createRow(connector, ordinal, stage, state, null);
      row.exception_class = safeExceptionClass(error);
      row.sanitized_exception_message = fixedExceptionMessage("INTERNAL_VERIFIER_ERROR");
      rows.push(failRow(row, "CREDENTIAL_HANDOFF_FAILED"));
    }
  } finally {
    if (tokenBytes) tokenBytes.fill(0);
    if (suppliedCredential instanceof Uint8Array && suppliedCredential !== tokenBytes) suppliedCredential.fill(0);
    suppliedCredential = null;
    tokenBytes = null;
    token = null;
    state.sessionId = null;
  }
  completeRows(connector, ordinal, rows, state, criticalStop ? "SECURITY_STOP" : "DEPENDENCY_FAILED");
  const result = criticalStop ? "SECURITY_STOP" : rows.every((row) => row.result === "PASS") ? "PASS" : "FAIL";
  return { connector, ordinal, rows, result, state: { ...state, sessionId: null }, criticalStop };
}

async function fetchPublicJson(path, options) {
  const controller = new AbortController();
  let timer = null;
  let callerListener = null;
  let callerCancelled = false;
  let timedOut = false;
  try {
    if (options.signal?.aborted) {
      callerCancelled = true;
      controller.abort();
    } else if (options.signal) {
      callerListener = () => { callerCancelled = true; controller.abort(); };
      options.signal.addEventListener("abort", callerListener, { once: true });
    }
    timer = options.timers.setTimeout(() => { timedOut = true; controller.abort(); }, options.stageTimeoutMs);
    if (callerCancelled) throw new DOMException("cancelled", "AbortError");
    options.metrics.control_room_public_read_count += 1;
    options.metrics.outbound_hosts.add(new URL(CONTROL_ROOM_ORIGIN).hostname);
    const response = await options.fetchImpl(exactControlRoomUrl(path), {
      method: "GET",
      headers: { Accept: "application/json" },
      cache: "no-store",
      redirect: "error",
      signal: controller.signal,
    });
    if (response.status !== 200) {
      try { await response.body?.cancel(); } catch { /* best effort */ }
      throw Object.assign(new Error(`HTTP_${response.status}`), { classification: `HTTP_${response.status}` });
    }
    const mediaType = (response.headers.get("content-type") ?? "").split(";", 1)[0].trim().toLowerCase();
    if (mediaType !== "application/json") {
      try { await response.body?.cancel(); } catch { /* best effort */ }
      throw Object.assign(new TypeError("INVALID_CONTENT_TYPE"), { classification: "INVALID_CONTENT_TYPE" });
    }
    const bytes = await readBoundedBody(response, MAX_PUBLIC_RESPONSE_BYTES);
    const text = decodeUtf8(bytes);
    bytes.fill(0);
    try { return JSON.parse(text); } catch {
      throw Object.assign(new SyntaxError("MALFORMED_JSON"), { classification: "MALFORMED_JSON" });
    }
  } catch (error) {
    if (callerCancelled) throw Object.assign(new Error("CALLER_CANCELLATION"), { classification: "CALLER_CANCELLATION" });
    if (timedOut) throw Object.assign(new Error("TIMEOUT"), { classification: "TIMEOUT" });
    throw error;
  } finally {
    if (timer !== null) options.timers.clearTimeout(timer);
    if (callerListener) options.signal.removeEventListener("abort", callerListener);
  }
}

function sha256Public(value) {
  return `sha256:${createHash("sha256").update(canonicalJson(value)).digest("hex")}`;
}

function specialistProjection(value) {
  const latest = value?.workstream?.latest_update;
  return {
    workstream_id: value?.requested_workstream_id ?? null,
    ledger_snapshot_sha256: value?.ledger?.ledger_snapshot_sha256 ?? null,
    pointer_stability: value?.ledger?.pointer_stability ?? null,
    latest_update_id: latest?.update_id ?? null,
    classification: latest?.classification ?? null,
    history: Array.isArray(value?.workstream?.history) ? value.workstream.history.map((entry) => ({
      update_id: entry?.update_id ?? null,
      classification: entry?.classification ?? null,
      manifest_sha256: entry?.manifest_sha256 ?? null,
      artifact_sha256: entry?.artifact_sha256 ?? null,
    })).sort((left, right) => String(left.update_id).localeCompare(String(right.update_id))) : [],
    artifact_sha256: latest?.artifact?.sha256 ?? null,
    manifest_sha256: latest?.manifest_sha256 ?? null,
    project_state_update_id: latest?.project_state?.update_id ?? null,
    next_work_handoff_sha256: latest?.next_work_handoff ? sha256Public(latest.next_work_handoff) : null,
    external_observer_inbox: {
      classification: value?.external_observer_inbox?.classification ?? null,
      high_critical_count: value?.external_observer_inbox?.high_critical_count ?? null,
      high_critical_pending_ids: Array.isArray(value?.external_observer_inbox?.high_critical_pending)
        ? value.external_observer_inbox.high_critical_pending.map((entry) => entry?.observation_id ?? null).sort()
        : [],
    },
    common_mission_sha256: sha256Public((value?.all_workstreams ?? []).map((entry) => ({
      workstream_id: entry?.workstream_id ?? null,
      latest_update_id: entry?.latest_update?.update_id ?? null,
      history_count: Array.isArray(entry?.history) ? entry.history.length : null,
    })).sort((left, right) => String(left.workstream_id).localeCompare(String(right.workstream_id)))),
    secure_v2_write_plane_activated: value?.secure_v2_write_plane_activated ?? null,
    research_authorization: value?.research_authorization ?? null,
  };
}

export async function readPublicProjection(options = {}) {
  const context = {
    fetchImpl: options.fetchImpl ?? globalThis.fetch,
    clock: options.clock ?? defaultClock(),
    timers: options.timers ?? defaultTimers(),
    stageTimeoutMs: options.stageTimeoutMs ?? STAGE_TIMEOUT_MS,
    signal: options.signal,
    metrics: options.metrics ?? { control_room_public_read_count: 0, outbound_hosts: new Set() },
  };
  const root = await fetchPublicJson("/api/v1/external-observers", context);
  const feed = await fetchPublicJson("/api/v1/external-observers/observations", context);
  const observerBootstraps = [];
  for (const connector of CONNECTORS) {
    const bootstrap = await fetchPublicJson(`/api/v1/external-observers/bootstrap/${connector.observerId}`, context);
    observerBootstraps.push({
      observer_id: bootstrap?.observer_id ?? null,
      repository_head: bootstrap?.ledger?.repository_head ?? null,
      observer_snapshot_sha256: bootstrap?.ledger?.observer_snapshot_sha256 ?? null,
      current_observer_latest_id: bootstrap?.current_observer_latest_id ?? null,
      all_observer_latest_ids: bootstrap?.all_observer_latest_ids ?? null,
      source_registry: bootstrap?.source_registry ? {
        revision: bootstrap.source_registry.revision ?? null,
        sha256: bootstrap.source_registry.sha256 ?? null,
      } : null,
      specialist_latest_update_ids: bootstrap?.specialist_latest_update_ids ?? null,
      pending_observation_ids: Array.isArray(bootstrap?.pending_observations)
        ? bootstrap.pending_observations.map((entry) => entry?.observation_id ?? null).sort()
        : [],
    });
  }
  const specialists = [];
  for (const workstream of ["signals-platform", "validator-flows", "identity-attribution", "investor-intelligence"]) {
    specialists.push(specialistProjection(await fetchPublicJson(`/api/v1/trusted-team/bootstrap/${workstream}`, context)));
  }
  const workHub = await fetchPublicJson("/api/v1/work-hub", context);
  const projectState = await fetchPublicJson("/api/v1/work-hub/project-state", context);
  return {
    public_runtime: {
      repository_head: root?.ledger?.repository_head ?? null,
      observer_snapshot_sha256: root?.ledger?.observer_snapshot_sha256 ?? null,
      fallback_used: root?.ledger?.fallback_used ?? null,
    },
    observers: Array.isArray(root?.observers) ? root.observers.map((entry) => ({
      observer_id: entry?.observer_id ?? null,
      latest_observation_id: entry?.latest_observation_id ?? null,
      observation_count: entry?.observation_count ?? null,
      publication_state: entry?.publication_state ?? null,
    })).sort((left, right) => String(left.observer_id).localeCompare(String(right.observer_id))) : [],
    observation_ids: Array.isArray(feed?.observations) ? feed.observations.map((entry) => entry?.observation_id ?? null).sort() : [],
    observer_bootstraps: observerBootstraps.sort((left, right) => String(left.observer_id).localeCompare(String(right.observer_id))),
    specialists: specialists.sort((left, right) => String(left.workstream_id).localeCompare(String(right.workstream_id))),
    work_hub: {
      authority_state: workHub?.authority_state ?? null,
      write_plane_state: workHub?.write_plane_state ?? null,
      existing_signals_database_connected: workHub?.existing_signals_database_connected ?? null,
      production_write_state: workHub?.production_write_state ?? null,
      project_revision: projectState?.project_revision ?? null,
      workstreams: Array.isArray(projectState?.workstreams) ? projectState.workstreams.map((entry) => ({
        workstream_id: entry?.workstream_id ?? null,
        current_revision: entry?.current_revision ?? null,
        latest_update_id: entry?.latest_authoritative_update?.update_id ?? null,
      })).sort((left, right) => String(left.workstream_id).localeCompare(String(right.workstream_id))) : [],
    },
  };
}

function emptyMetrics() {
  return {
    mcp_request_count: 0,
    control_room_public_read_count: 0,
    api_github_request_count: 0,
    github_transport_constructor_count: 0,
    publication_mutation_count: 0,
    outbound_hosts: new Set(),
  };
}

function safeAuditFailure(error) {
  return {
    classification: error?.classification ?? "PUBLIC_PROJECTION_UNAVAILABLE",
    exception_class: safeExceptionClass(error),
    sanitized_exception_message: fixedExceptionMessage(error?.classification ?? "INTERNAL_VERIFIER_ERROR"),
  };
}

export async function verifyGateway(options = {}) {
  if (options.workerOrigin !== undefined && options.workerOrigin !== WORKER_ORIGIN) throw new Error("Fixed Worker origin mismatch");
  const effectiveStageTimeoutMs = options.stageTimeoutMs ?? STAGE_TIMEOUT_MS;
  if (!Number.isFinite(effectiveStageTimeoutMs) || effectiveStageTimeoutMs <= 0 || effectiveStageTimeoutMs > STAGE_TIMEOUT_MS) {
    throw new RangeError("Effective MCP stage timeout must be within the governed 60 second maximum");
  }
  const clock = options.clock ?? defaultClock();
  const timers = options.timers ?? defaultTimers();
  const metrics = options.metrics ?? emptyMetrics();
  const fetchImpl = options.fetchImpl ?? globalThis.fetch;
  const credentialProvider = options.credentialProvider;
  if (typeof credentialProvider !== "function") throw new TypeError("A governed credential provider is required");
  const projectionProvider = options.publicProjectionProvider ?? (() => readPublicProjection({
    fetchImpl, clock, timers, stageTimeoutMs: effectiveStageTimeoutMs,
    signal: options.signal, metrics,
  }));
  let before = null;
  let after = null;
  let beforeFailure = null;
  let afterFailure = null;
  try { before = await projectionProvider("before"); } catch (error) { beforeFailure = safeAuditFailure(error); }

  const connectorResults = [];
  let criticalStop = null;
  for (let index = 0; index < CONNECTORS.length; index += 1) {
    const connector = CONNECTORS[index];
    if (criticalStop) {
      const state = { protocolVersion: null, sessionId: null, authenticationPassed: false, initializePassed: false, toolsListPassed: false, disabledWriteAttempted: false };
      const rows = expectedStages(connector).map((stage) => skippedRow(connector, index + 1, stage, state, "SECURITY_STOP"));
      connectorResults.push({ connector, ordinal: index + 1, rows, result: "SKIPPED", state, criticalStop: null });
      continue;
    }
    const result = await verifyConnector(connector, index + 1, {
      fetchImpl, credentialProvider, clock, timers,
      stageTimeoutMs: effectiveStageTimeoutMs,
      signal: options.signal, metrics,
    });
    connectorResults.push(result);
    await options.onConnectorComplete?.(connector, index + 1, result);
    if (result.criticalStop) criticalStop = result.criticalStop;
  }

  if (!criticalStop) {
    try { after = await projectionProvider("after"); } catch (error) { afterFailure = safeAuditFailure(error); }
    if (before && after && canonicalJson(before) !== canonicalJson(after)) {
      criticalStop = { code: "PROTECTED_STATE_MUTATION", connector_id: null, stage: "public_projection_after" };
    }
  }

  const matrix = connectorResults.flatMap((entry) => entry.rows);
  const failedRows = matrix.filter((row) => row.result === "FAIL");
  const controlRoomFailures = failedRows.filter((row) => row.response_classification === "CONTROL_ROOM_UPSTREAM_UNAVAILABLE");
  const auditResult = criticalStop?.code === "PROTECTED_STATE_MUTATION"
    ? "MUTATED"
    : beforeFailure || afterFailure || !before || !after
      ? "INDETERMINATE"
      : "UNCHANGED";
  const externalUpstreamBlockerOnly =
    !criticalStop && auditResult === "UNCHANGED" && failedRows.length > 0 && failedRows.length === controlRoomFailures.length;
  const connectorsPass = connectorResults.every((entry) => entry.result === "PASS");
  const pass = connectorsPass && auditResult === "UNCHANGED" && !criticalStop;
  const releaseCritical = Boolean(criticalStop && CRITICAL_CODES.has(criticalStop.code));
  const recommendedAction = pass
    ? "R13_HANDOFF_READY"
    : releaseCritical
      ? "ROLLBACK_ONLY_IF_SEPARATELY_AUTHORIZED"
      : externalUpstreamBlockerOnly
        ? "PRESERVE_DEPLOYED_R12F_REPORT_EXTERNAL_BLOCKER"
        : "PRESERVE_DEPLOYED_R12F_REPORT_VERIFICATION_FAILURE";

  return {
    schema_version: "pulsechain-r12f-local-disabled-mode-verification@1.0.0",
    generated_at_utc: clock.nowIso(),
    result: releaseCritical ? "SECURITY_STOP" : pass ? "PASS" : "FAIL",
    release_critical: releaseCritical,
    critical_stop: criticalStop,
    recommended_release_action: recommendedAction,
    worker_name: "pulsechain-external-observer-grok-mcp",
    worker_origin: WORKER_ORIGIN,
    control_room_origin: CONTROL_ROOM_ORIGIN,
    publication_mode: "DISABLED",
    publication_ready: false,
    github_publication_transport: "DEFERRED_WHILE_DISABLED",
    mcp_protocol_version: PROTOCOL_VERSION,
    stage_timeout_ms: effectiveStageTimeoutMs,
    verifier_retry_count: 0,
    connectors: connectorResults.map((entry) => ({
      connector_id: entry.connector.observerId,
      connector_ordinal: entry.ordinal,
      path: entry.connector.path,
      target_workstream: entry.connector.targetWorkstream,
      result: entry.result,
      authentication_passed: entry.state.authenticationPassed,
      initialize_passed: entry.state.initializePassed,
      tools_list_passed: entry.state.toolsListPassed,
      session_id_present: entry.rows.some((row) => row.session_id_present),
      disabled_write_attempted: entry.state.disabledWriteAttempted,
    })),
    connector_stage_matrix: matrix,
    control_room_upstream_unavailable_count: controlRoomFailures.length,
    external_upstream_blocker_only: externalUpstreamBlockerOnly,
    transport_audit: {
      mcp_request_count: metrics.mcp_request_count,
      control_room_public_read_count: metrics.control_room_public_read_count,
      api_github_request_count: metrics.api_github_request_count,
      github_transport_constructor_count: metrics.github_transport_constructor_count,
      publication_mutation_count: metrics.publication_mutation_count,
      outbound_hosts: [...metrics.outbound_hosts].sort(),
    },
    system_wide_mutation_audit: {
      result: auditResult,
      before_projection_available: Boolean(before),
      after_projection_available: Boolean(after),
      before_failure: beforeFailure,
      after_failure: afterFailure,
      directly_observed: [
        "public_runtime_commit", "observer_records", "five_observer_latest_pointers",
        "five_observer_indexes", "four_specialist_pointers_and_histories", "common_mission_projection",
        "work_hub_write_plane_state", "work_hub_project_and_workstream_revisions",
      ],
      structural_zero_transport_only: [
        "github_issue_and_workflow_delta", "d1_table_and_write_delta", "r2_object_delta",
        "authority_row_and_audit_head_delta", "signals_source_delta", "portfolio_delta",
        "wallet_delta", "order_delta", "execution_delta",
      ],
      proof_basis_limitations: "The structural-only domains have no public authoritative counter endpoint and are not represented as directly measured provider deltas.",
      before_projection_sha256: before ? sha256Public(before) : null,
      after_projection_sha256: after ? sha256Public(after) : null,
    },
    secrets_in_report: 0,
  };
}

export function decodeCredentialFrame(frame, expectedOrdinal) {
  const bytes = frame instanceof Uint8Array ? frame : new Uint8Array(frame);
  if (bytes.byteLength !== 51) throw new Error("Credential frame length mismatch");
  if (String.fromCharCode(...bytes.subarray(0, 4)) !== "R12F" || bytes[4] !== 1 || bytes[5] !== expectedOrdinal) {
    throw new Error("Credential frame identity mismatch");
  }
  const length = bytes[6] | (bytes[7] << 8);
  if (length !== 43) throw new Error("Credential length mismatch");
  const token = bytes.slice(8, 51);
  if (token.some((byte) => !((byte >= 65 && byte <= 90) || (byte >= 97 && byte <= 122) || (byte >= 48 && byte <= 57) || byte === 45 || byte === 95))) {
    token.fill(0);
    throw new Error("Credential byte alphabet mismatch");
  }
  return token;
}

class FrameReader {
  constructor(stream) {
    this.iterator = stream[Symbol.asyncIterator]();
    this.buffer = new Uint8Array();
  }
  async readExactly(length) {
    while (this.buffer.byteLength < length) {
      const next = await this.iterator.next();
      if (next.done) throw new Error("Credential input closed unexpectedly");
      const incoming = new Uint8Array(next.value);
      const combined = new Uint8Array(this.buffer.byteLength + incoming.byteLength);
      combined.set(this.buffer, 0);
      combined.set(incoming, this.buffer.byteLength);
      this.buffer.fill(0);
      this.buffer = combined;
    }
    const result = this.buffer.slice(0, length);
    const remaining = this.buffer.slice(length);
    this.buffer.fill(0);
    this.buffer = remaining;
    return result;
  }
}

async function bridgeWrite(value) {
  const line = `${JSON.stringify({ protocol: BRIDGE_PROTOCOL, ...value })}\n`;
  if (!process.stdout.write(line)) await new Promise((resolve) => process.stdout.once("drain", resolve));
}

export async function runLiveBridge() {
  const reader = new FrameReader(process.stdin);
  const credentialProvider = async (connector, ordinal) => {
    await bridgeWrite({ type: "credential_request", connector_ordinal: ordinal, observer_id: connector.observerId });
    const frame = await reader.readExactly(51);
    try { return decodeCredentialFrame(frame, ordinal); } finally { frame.fill(0); }
  };
  const report = await verifyGateway({
    credentialProvider,
    onConnectorComplete: async (connector, ordinal, result) => bridgeWrite({
      type: "connector_complete",
      connector_ordinal: ordinal,
      observer_id: connector.observerId,
      result: result.result === "PASS" ? "PASS" : "FAIL",
    }),
  });
  await bridgeWrite({ type: "final_report", report });
  return report;
}

const invokedPath = process.argv[1] ? pathToFileURL(process.argv[1]).href : null;
if (invokedPath === import.meta.url) {
  runLiveBridge().then((report) => {
    process.exitCode = report.result === "PASS" ? 0 : report.release_critical ? 2 : 1;
  }).catch(async () => {
    await bridgeWrite({
      type: "final_report",
      report: {
        schema_version: "pulsechain-r12f-local-disabled-mode-verification@1.0.0",
        generated_at_utc: new Date().toISOString(),
        result: "FAIL",
        release_critical: false,
        critical_stop: null,
        recommended_release_action: "PRESERVE_DEPLOYED_R12F_REPORT_VERIFICATION_FAILURE",
        error: "VERIFIER_PROCESS_FAILED_CLOSED",
        secrets_in_report: 0,
      },
    });
    process.exitCode = 1;
  });
}
