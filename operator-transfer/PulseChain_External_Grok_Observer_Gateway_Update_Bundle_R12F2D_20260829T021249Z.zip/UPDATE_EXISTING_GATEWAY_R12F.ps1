#Requires -Version 7.4

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern("^[0-9A-Fa-f]{32}$")]
    [string]$CloudflareAccountId,

    [Parameter(Mandatory = $true)]
    [ValidateSet("I_HAVE_EXCLUSIVE_CHANGE_FREEZE")]
    [string]$ChangeFreezeConfirmation
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$VerbosePreference = "SilentlyContinue"
$DebugPreference = "SilentlyContinue"
$InformationPreference = "SilentlyContinue"
$PSNativeCommandUseErrorActionPreference = $false

$BundleRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$GatewayDirectory = Join-Path $BundleRoot "external_observer_grok_mcp_gateway"
$WorkerName = "pulsechain-external-observer-grok-mcp"
$ExpectedAccountId = "dade45b2875ee5e98c74b5d06528cd9c"
$ExpectedOrigin = "https://pulsechain-external-observer-grok-mcp.pulsechain-research-dade45b2.workers.dev"
$ExpectedAccountSubdomain = "pulsechain-research-dade45b2"
$ExpectedControlRoomOrigin = "https://pulsechain-research-control-room.brohexphiat.chatgpt.site"
$ExpectedPriorDeploymentId = "c776a6e0-14b8-49bc-be9a-7aa0e63c5495"
$ExpectedPriorVersionId = "e32f2b34-a572-404e-b969-44c0bf2c9088"
$ExpectedR12DSourceBranch = "external-observer-grok-mcp-r12d-windows-acl-repair-20260828"
$ExpectedR12DSourceCommit = "ec70832c69f847ea413666de095ce3d56534ea28"
$ExpectedR12DSourceTree = "35e17b896403d02d160f3a4d902ea2e66845799c"
$ExpectedR12F2DBundleSourceBranch = "external-observer-grok-mcp-r12f2d-windows-harness-scope-repair-20260829"
$ExpectedR12F2DBundleSourceCommit = "9a30f43f90096f2cecb99dbe217c155eaf4b9633"
$ExpectedR12F2DBundleSourceTree = "3ca2102d8657f1ab6884f4bf8597170776b25f9c"
$ExpectedR12F2CPredecessorCommit = "94fb48e8ee4edbe0e48bbbdd71b235c788f8ce8a"
$ExpectedR12F2CPredecessorTree = "748da99a2935d394d34cbc71d8589cedfda18c87"
$ExpectedR12FSourceParent = "ebef6c42a5eca2ad30669cf856e669a19e10edf9"
$ExpectedR12F1BundleSourceCommit = "75e3650f8e7f17af0ec2b2f312b920e15f96eb79"
$ExpectedR12F1BundleSourceTree = "1c8bccc87df5abc07b9712a6f6fb839bc0b7c21a"
$ExpectedR12F2PredecessorCommit = "f535c273c264f2c953ccd925a1d20c3f218c95a4"
$ExpectedR12F2PredecessorTree = "2e9df9f68850ca588e4a4749db100ec760e57d7c"
$ExpectedR12F2APredecessorCommit = "d6db80436ab82a061161be99c53179d481eabfff"
$ExpectedR12F2APredecessorTree = "a750a7da63ca1adbea3fe606c12c80bb9caebe3d"
$ExpectedR12F2BPredecessorCommit = "e724d72adbeae653695d3198353d35ba173884f9"
$ExpectedR12F2BPredecessorTree = "b185d749737f83027d3a9573417e4a18cea1d61f"
$ExpectedR12FRuntimeCommit = "ebef6c42a5eca2ad30669cf856e669a19e10edf9"
$ExpectedR12FRuntimeTree = "e4db0de410f89b32a9dca0f3bd1388c0272664e7"
$ExpectedBundleFilename = "PulseChain_External_Grok_Observer_Gateway_Update_Bundle_R12F2D_20260829T021249Z.zip"
$ExpectedCompatibilityDate = "2026-08-27"
$ExpectedCompatibilityFlags = @("nodejs_compat")
$ExpectedWranglerVersion = "4.92.0"
$ExpectedSecretLabels = @(
    "GROK_MCP_TOKEN_X_PROTOCOL",
    "GROK_MCP_TOKEN_INFRASTRUCTURE_INCIDENTS",
    "GROK_MCP_TOKEN_MARKET_LIQUIDITY",
    "GROK_MCP_TOKEN_IDENTITY_EVIDENCE",
    "GROK_MCP_TOKEN_RED_TEAM"
) | Sort-Object
$VersionTag = "r12f2d-" + $ExpectedR12F2DBundleSourceCommit.Substring(0, 12)
$VersionMessage = "R12F2D package branch=$ExpectedR12F2DBundleSourceBranch commit=$ExpectedR12F2DBundleSourceCommit tree=$ExpectedR12F2DBundleSourceTree runtime=$ExpectedR12FRuntimeCommit"
$DeploymentMessage = "R12F runtime update through verified R12F2D package $ExpectedR12F2DBundleSourceCommit"
$WindowsReservedName = "^(?i:(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?)$"
$phase = "BUNDLE_VALIDATION"
$operatorTemp = $null
$vaultBaseline = $null
$newVersionId = $null
$newDeploymentId = $null
$uploadInvocations = 0
$deploymentInvocations = 0
$verifierInvocations = 0
$trafficChanged = $false
$uploadOccurred = $false
$updateSucceeded = $false
$caughtFailure = $null
$caughtFailureRecord = $null
$preUpdate = $null
$preVersionIds = @()
$upload = $null
$deployment = $null
$priorAccountEnvironment = $env:CLOUDFLARE_ACCOUNT_ID
$priorPath = $env:PATH
$priorNoColor = $env:NO_COLOR
$priorForceColor = $env:FORCE_COLOR
$priorNpmOffline = $env:npm_config_offline
$priorWranglerOutputPath = $env:WRANGLER_OUTPUT_FILE_PATH
$priorWranglerMetrics = $env:WRANGLER_SEND_METRICS

function Set-UpdatePhase {
    param([Parameter(Mandatory = $true)][string]$Name)
    $script:phase = $Name
    if (Get-Command Set-OperatorPhase -ErrorAction SilentlyContinue) {
        Set-OperatorPhase -Name $Name
    }
}

function Get-FileSha256 {
    param([Parameter(Mandatory = $true)][string]$Path)
    [byte[]]$bytes = [IO.File]::ReadAllBytes($Path)
    try {
        [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()
    }
    finally {
        [Array]::Clear($bytes, 0, $bytes.Length)
    }
}

function Resolve-SafeBundlePath {
    param([Parameter(Mandatory = $true)][string]$RelativePath)
    if (
        [string]::IsNullOrWhiteSpace($RelativePath) -or
        $RelativePath.Length -gt 240 -or
        [IO.Path]::IsPathRooted($RelativePath) -or
        $RelativePath.Contains("\") -or
        $RelativePath.Contains(":") -or
        $RelativePath.EndsWith("/")
    ) {
        throw "BUNDLE_PATH_UNSAFE"
    }
    foreach ($segment in $RelativePath.Split("/")) {
        if (
            $segment -in @("", ".", "..") -or
            $segment.EndsWith(".") -or
            $segment.EndsWith(" ") -or
            $segment -match $WindowsReservedName
        ) {
            throw "BUNDLE_PATH_UNSAFE"
        }
    }
    $resolved = [IO.Path]::GetFullPath((Join-Path $BundleRoot $RelativePath))
    $prefix = $BundleRoot.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    if (-not $resolved.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw "BUNDLE_PATH_ESCAPE"
    }
    $resolved
}

function Assert-BundleIntegrity {
    if ((Split-Path -Leaf $BundleRoot) -cne [IO.Path]::GetFileNameWithoutExtension($ExpectedBundleFilename)) {
        throw "BUNDLE_DIRECTORY_IDENTITY_MISMATCH"
    }
    $sumPath = Join-Path $BundleRoot "SHA256SUMS.txt"
    $inventoryPath = Join-Path $BundleRoot "ARTIFACT_INVENTORY.json"
    $sourceManifestPath = Join-Path $BundleRoot "SOURCE_MANIFEST.json"
    $expectationsPath = Join-Path $BundleRoot "DEPLOYMENT_EXPECTATIONS.json"
    foreach ($required in @($sumPath, $inventoryPath, $sourceManifestPath, $expectationsPath)) {
        if (-not (Test-Path -LiteralPath $required -PathType Leaf)) {
            throw "BUNDLE_GOVERNANCE_FILE_MISSING"
        }
    }

    $allItems = @(Get-ChildItem -LiteralPath $BundleRoot -Force -Recurse)
    $rootItem = Get-Item -LiteralPath $BundleRoot -Force
    if (($rootItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw "BUNDLE_REPARSE_POINT_REJECTED"
    }
    foreach ($item in $allItems) {
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "BUNDLE_REPARSE_POINT_REJECTED"
        }
    }

    $actualPaths = @(
        $allItems |
            Where-Object { -not $_.PSIsContainer } |
            ForEach-Object { [IO.Path]::GetRelativePath($BundleRoot, $_.FullName).Replace("\", "/") } |
            Sort-Object
    )
    $caseFolded = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($relativePath in $actualPaths) {
        [void](Resolve-SafeBundlePath -RelativePath $relativePath)
        if (-not $caseFolded.Add($relativePath)) {
            throw "BUNDLE_CASE_FOLD_COLLISION"
        }
        if (
            $relativePath -match "(?i)(?:^|/)(?:node_modules|\.git|\.wrangler)(?:/|$)" -or
            $relativePath -match "(?i)(?:^|/)(?:\.env(?:\..*)?|connector-tokens\.dpapi\.json|LOCAL_DISABLED_MODE_VERIFICATION(?:_R12F)?\.json)$" -or
            $relativePath -match "(?i)\.(?:log|map|pem|key|pfx|p12)$" -or
            $relativePath -match "(?i)(?:^|/)SHOW_GROK_CONNECTOR_TOKEN\.ps1$"
        ) {
            throw "BUNDLE_FORBIDDEN_MEMBER"
        }
    }

    $checksumPaths = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    foreach ($line in Get-Content -LiteralPath $sumPath -Encoding utf8) {
        if ($line -notmatch "^([0-9a-f]{64})  ([A-Za-z0-9._/-]+)$") {
            throw "BUNDLE_CHECKSUM_LINE_INVALID"
        }
        $expectedHash = $Matches[1]
        $relativePath = $Matches[2]
        if (-not $checksumPaths.Add($relativePath)) {
            throw "BUNDLE_CHECKSUM_PATH_DUPLICATE"
        }
        $path = Resolve-SafeBundlePath -RelativePath $relativePath
        if (-not (Test-Path -LiteralPath $path -PathType Leaf) -or (Get-FileSha256 -Path $path) -cne $expectedHash) {
            throw "BUNDLE_CHECKSUM_MISMATCH"
        }
    }
    $expectedChecksumPaths = @($actualPaths | Where-Object { $_ -notin @("SHA256SUMS.txt", "ARTIFACT_INVENTORY.json") })
    if (($expectedChecksumPaths -join "`n") -cne (@($checksumPaths | Sort-Object) -join "`n")) {
        throw "BUNDLE_CHECKSUM_FILE_SET_MISMATCH"
    }

    $inventory = Get-Content -LiteralPath $inventoryPath -Raw -Encoding utf8 | ConvertFrom-Json -Depth 100
    $inventoryEntries = @($inventory.artifacts)
    $expectedInventoryPaths = @($actualPaths | Where-Object { $_ -cne "ARTIFACT_INVENTORY.json" })
    if (
        $inventory.schema_version -cne "pulsechain-external-observer-r12f-update-inventory@1.0.0" -or
        [int]$inventory.artifact_count_excluding_inventory -ne $expectedInventoryPaths.Count -or
        $inventoryEntries.Count -ne $expectedInventoryPaths.Count -or
        (@($inventoryEntries.path | Sort-Object) -join "`n") -cne ($expectedInventoryPaths -join "`n")
    ) {
        throw "BUNDLE_INVENTORY_INVALID"
    }
    foreach ($entry in $inventoryEntries) {
        $path = Resolve-SafeBundlePath -RelativePath ([string]$entry.path)
        $info = Get-Item -LiteralPath $path
        if ([int64]$entry.byte_size -ne $info.Length -or [string]$entry.sha256 -cne (Get-FileSha256 -Path $path)) {
            throw "BUNDLE_INVENTORY_IDENTITY_MISMATCH"
        }
    }
    if (
        $inventory.scans.security_scan -ne "PASS" -or
        $inventory.scans.secret_scan -ne "PASS" -or
        [int]$inventory.scans.source_map_count -ne 0 -or
        $inventory.scans.path_safety -ne "PASS"
    ) {
        throw "BUNDLE_EXECUTABLE_SCAN_ATTESTATION_INVALID"
    }

    $source = Get-Content -LiteralPath $sourceManifestPath -Raw -Encoding utf8 | ConvertFrom-Json -Depth 100
    if (
        $source.schema_version -cne "pulsechain-external-observer-r12f-source-manifest@1.0.0" -or
        $source.source.branch -cne $ExpectedR12F2DBundleSourceBranch -or
        $source.source.commit -cne $ExpectedR12F2DBundleSourceCommit -or
        $source.source.tree -cne $ExpectedR12F2DBundleSourceTree -or
        $source.source.parent -cne $ExpectedR12FSourceParent -or
        $source.source.parent_role -cne "R12F_RUNTIME_AUTHORITY" -or
        $source.source.commit -cnotmatch "^[0-9a-f]{40}$" -or
        $source.source.tree -cnotmatch "^[0-9a-f]{40}$" -or
        $source.source.parent -cnotmatch "^[0-9a-f]{40}$" -or
        $source.lineage.runtime_source.commit -cne $ExpectedR12FRuntimeCommit -or
        $source.lineage.runtime_source.tree -cne $ExpectedR12FRuntimeTree -or
        $source.lineage.runtime_source.parent -cne $ExpectedR12DSourceCommit -or
        $source.lineage.r12f1_bundle_source.commit -cne $ExpectedR12F1BundleSourceCommit -or
        $source.lineage.r12f1_bundle_source.tree -cne $ExpectedR12F1BundleSourceTree -or
        $source.lineage.r12f1_bundle_source.parent -cne $ExpectedR12FSourceParent -or
        $source.lineage.r12f2_predecessor_source.commit -cne $ExpectedR12F2PredecessorCommit -or
        $source.lineage.r12f2_predecessor_source.tree -cne $ExpectedR12F2PredecessorTree -or
        $source.lineage.r12f2_predecessor_source.parent -cne $ExpectedR12F1BundleSourceCommit -or
        $source.lineage.r12f2a_predecessor_source.commit -cne $ExpectedR12F2APredecessorCommit -or
        $source.lineage.r12f2a_predecessor_source.tree -cne $ExpectedR12F2APredecessorTree -or
        $source.lineage.r12f2a_predecessor_source.parent -cne $ExpectedR12F2PredecessorCommit -or
        $source.lineage.r12f2b_predecessor_source.commit -cne $ExpectedR12F2BPredecessorCommit -or
        $source.lineage.r12f2b_predecessor_source.tree -cne $ExpectedR12F2BPredecessorTree -or
        $source.lineage.r12f2b_predecessor_source.parent -cne $ExpectedR12F2APredecessorCommit -or
        $source.lineage.r12f2c_predecessor_source.commit -cne $ExpectedR12F2CPredecessorCommit -or
        $source.lineage.r12f2c_predecessor_source.tree -cne $ExpectedR12F2CPredecessorTree -or
        $source.lineage.r12f2c_predecessor_source.parent -cne $ExpectedR12F2BPredecessorCommit -or
        $source.lineage.r12f2d_bundle_source.commit -cne $ExpectedR12F2DBundleSourceCommit -or
        $source.lineage.r12f2d_bundle_source.tree -cne $ExpectedR12F2DBundleSourceTree -or
        $source.lineage.r12f2d_bundle_source.parent -cne $ExpectedR12F2CPredecessorCommit -or
        $source.worker.name -cne $WorkerName -or
        $source.worker.origin -cne $ExpectedOrigin -or
        $source.worker.publication_mode -cne "DISABLED" -or
        $source.worker.control_room_origin -cne $ExpectedControlRoomOrigin -or
        $source.worker.compatibility_date -cne $ExpectedCompatibilityDate -or
        @($source.worker.compatibility_flags).Count -ne 1 -or
        $source.worker.compatibility_flags[0] -ne "nodejs_compat"
    ) {
        throw "BUNDLE_SOURCE_MANIFEST_INVALID"
    }

    $expectations = Get-Content -LiteralPath $expectationsPath -Raw -Encoding utf8 | ConvertFrom-Json -Depth 100
    $expectedLabels = @($expectations.exact_pre_update_state.connector_secret_labels | Sort-Object)
    if (
        $expectations.schema_version -cne "pulsechain-external-observer-r12f-update-expectations@1.0.0" -or
        $expectations.source.commit -cne $ExpectedR12F2DBundleSourceCommit -or
        $expectations.source.tree -cne $ExpectedR12F2DBundleSourceTree -or
        $expectations.source.parent -cne $ExpectedR12FSourceParent -or
        $expectations.source.parent_role -cne "R12F_RUNTIME_AUTHORITY" -or
        $expectations.source.commit -cnotmatch "^[0-9a-f]{40}$" -or
        $expectations.source.tree -cnotmatch "^[0-9a-f]{40}$" -or
        $expectations.source.parent -cnotmatch "^[0-9a-f]{40}$" -or
        $expectations.lineage.runtime_source.commit -cne $ExpectedR12FRuntimeCommit -or
        $expectations.lineage.runtime_source.parent -cne $ExpectedR12DSourceCommit -or
        $expectations.lineage.r12f1_bundle_source.commit -cne $ExpectedR12F1BundleSourceCommit -or
        $expectations.lineage.r12f2_predecessor_source.commit -cne $ExpectedR12F2PredecessorCommit -or
        $expectations.lineage.r12f2_predecessor_source.tree -cne $ExpectedR12F2PredecessorTree -or
        $expectations.lineage.r12f2_predecessor_source.parent -cne $ExpectedR12F1BundleSourceCommit -or
        $expectations.lineage.r12f2a_predecessor_source.commit -cne $ExpectedR12F2APredecessorCommit -or
        $expectations.lineage.r12f2a_predecessor_source.tree -cne $ExpectedR12F2APredecessorTree -or
        $expectations.lineage.r12f2a_predecessor_source.parent -cne $ExpectedR12F2PredecessorCommit -or
        $expectations.lineage.r12f2b_predecessor_source.commit -cne $ExpectedR12F2BPredecessorCommit -or
        $expectations.lineage.r12f2b_predecessor_source.tree -cne $ExpectedR12F2BPredecessorTree -or
        $expectations.lineage.r12f2b_predecessor_source.parent -cne $ExpectedR12F2APredecessorCommit -or
        $expectations.lineage.r12f2c_predecessor_source.commit -cne $ExpectedR12F2CPredecessorCommit -or
        $expectations.lineage.r12f2c_predecessor_source.tree -cne $ExpectedR12F2CPredecessorTree -or
        $expectations.lineage.r12f2c_predecessor_source.parent -cne $ExpectedR12F2BPredecessorCommit -or
        $expectations.lineage.r12f2d_bundle_source.commit -cne $ExpectedR12F2DBundleSourceCommit -or
        $expectations.lineage.r12f2d_bundle_source.tree -cne $ExpectedR12F2DBundleSourceTree -or
        $expectations.lineage.r12f2d_bundle_source.parent -cne $ExpectedR12F2CPredecessorCommit -or
        $expectations.exact_pre_update_state.account_id -cne $ExpectedAccountId -or
        $expectations.exact_pre_update_state.worker_name -cne $WorkerName -or
        $expectations.exact_pre_update_state.worker_origin -cne $ExpectedOrigin -or
        $expectations.exact_pre_update_state.active_deployment_id -cne $ExpectedPriorDeploymentId -or
        $expectations.exact_pre_update_state.active_version_id -cne $ExpectedPriorVersionId -or
        [decimal]$expectations.exact_pre_update_state.traffic_percent -ne 100 -or
        $expectations.exact_pre_update_state.variables.PUBLICATION_MODE -cne "DISABLED" -or
        $expectations.exact_pre_update_state.variables.CONTROL_ROOM_ORIGIN -cne $ExpectedControlRoomOrigin -or
        ($expectedLabels -join "`n") -cne ($ExpectedSecretLabels -join "`n") -or
        [int]$expectations.exact_pre_update_state.github_secret_count -ne 0 -or
        $expectations.exact_pre_update_state.workers_dev_enabled -ne $true -or
        $expectations.exact_pre_update_state.preview_urls_enabled -ne $false -or
        $expectations.update.wrangler_version -cne $ExpectedWranglerVersion -or
        $expectations.update.secret_file_used -ne $false -or
        [int]$expectations.update.secret_mutations -ne 0 -or
        $expectations.update.rollback_version_id -ne $ExpectedPriorVersionId
    ) {
        throw "BUNDLE_DEPLOYMENT_EXPECTATIONS_INVALID"
    }

    foreach ($requiredRelativePath in @(
        "OPERATOR_COMMON.ps1",
        "TEST_WINDOWS_OPERATOR_ACL.ps1",
        "VERIFY_GATEWAY_DISABLED_R12F.mjs",
        "VERIFY_GATEWAY_DISABLED_R12F.ps1",
        "VERIFY_CLOUDFLARE_R12F.mjs",
        "BUILD_R12F_UPDATE_BUNDLE.mjs",
        "BUNDLE_CONTRACT_VALIDATION.mjs",
        "ORIGINAL_R12F1_FAILURE_REPRODUCTION.json",
        "R12F2D_RUNTIME_BYTE_IDENTITY.json",
        "R12F2D_SCHEMA_COHERENCE_VALIDATION.json",
        "UNRESOLVED_PLACEHOLDER_SCAN.json",
        "R13_POST_UPDATE_VERIFICATION_PROMPT.md",
        "ROLLBACK_R12F.md",
        "external_observer_grok_mcp_gateway/wrangler.toml",
        "external_observer_grok_mcp_gateway/package.json"
    )) {
        if (-not (Test-Path -LiteralPath (Resolve-SafeBundlePath -RelativePath $requiredRelativePath) -PathType Leaf)) {
            throw "BUNDLE_REQUIRED_MEMBER_MISSING"
        }
    }
}

function Invoke-NativeCaptured {
    param(
        [Parameter(Mandatory = $true)][string]$FilePath,
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$WorkingDirectory
    )
    $errorPath = Join-Path $operatorTemp ("native-" + [Guid]::NewGuid().ToString("N") + ".err")
    Push-Location $WorkingDirectory
    try {
        $stdout = @(& $FilePath @Arguments 2> $errorPath)
        $exitCode = $LASTEXITCODE
        $stderr = if (Test-Path -LiteralPath $errorPath -PathType Leaf) {
            Get-Content -LiteralPath $errorPath -Raw -Encoding utf8
        }
        else { "" }
        [pscustomobject]@{
            exit_code = $exitCode
            stdout = $stdout -join [Environment]::NewLine
            stderr = $stderr
        }
    }
    finally {
        Pop-Location
        if (Test-Path -LiteralPath $errorPath) {
            Remove-Item -LiteralPath $errorPath -Force -ErrorAction SilentlyContinue
        }
    }
}

function Invoke-WranglerCaptured {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)
    Invoke-NativeCaptured -FilePath "npx" -Arguments (@("--no-install", "wrangler") + $Arguments) -WorkingDirectory $GatewayDirectory
}

function Invoke-WranglerJson {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)
    $result = Invoke-WranglerCaptured -Arguments $Arguments
    if ($result.exit_code -ne 0 -or [string]::IsNullOrWhiteSpace($result.stdout)) {
        throw "WRANGLER_READ_FAILED"
    }
    try {
        $result.stdout | ConvertFrom-Json -Depth 100
    }
    catch {
        throw "WRANGLER_JSON_INVALID"
    }
}

function Invoke-WranglerWithReceipt {
    param(
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$ReceiptPath
    )
    if (Test-Path -LiteralPath $ReceiptPath) {
        Remove-Item -LiteralPath $ReceiptPath -Force
    }
    $saved = $env:WRANGLER_OUTPUT_FILE_PATH
    $env:WRANGLER_OUTPUT_FILE_PATH = $ReceiptPath
    try {
        $native = Invoke-WranglerCaptured -Arguments $Arguments
    }
    finally {
        $env:WRANGLER_OUTPUT_FILE_PATH = $saved
    }
    $receipts = @()
    if (Test-Path -LiteralPath $ReceiptPath -PathType Leaf) {
        Set-PrivateFileAcl -Path $ReceiptPath
        Assert-PrivateFileAcl -Path $ReceiptPath
        foreach ($line in Get-Content -LiteralPath $ReceiptPath -Encoding utf8) {
            if (-not [string]::IsNullOrWhiteSpace($line)) {
                try { $receipts += ($line | ConvertFrom-Json -Depth 30) }
                catch { throw "WRANGLER_RECEIPT_INVALID" }
            }
        }
    }
    [pscustomobject]@{ native = $native; receipts = @($receipts) }
}

function Get-AccessSddl {
    param([Parameter(Mandatory = $true)][string]$Path, [switch]$Directory)
    $sections = [Security.AccessControl.AccessControlSections]::Access
    $security = if ($Directory) {
        [IO.FileSystemAclExtensions]::GetAccessControl([IO.DirectoryInfo]::new($Path), $sections)
    }
    else {
        [IO.FileSystemAclExtensions]::GetAccessControl([IO.FileInfo]::new($Path), $sections)
    }
    $security.GetSecurityDescriptorSddlForm($sections)
}

function Get-VaultBaseline {
    $vaultPath = Get-ConnectorVaultPath
    if (-not (Test-Path -LiteralPath $vaultPath -PathType Leaf)) {
        throw "FINALIZED_VAULT_MISSING"
    }
    $stateDirectory = Split-Path -Parent $vaultPath
    Assert-PrivateDirectoryAcl -Path $stateDirectory
    Assert-PrivateFileAcl -Path $vaultPath
    [byte[]]$vaultBytes = [IO.File]::ReadAllBytes($vaultPath)
    try {
        $vaultText = [Text.Encoding]::UTF8.GetString($vaultBytes)
        $vault = $vaultText | ConvertFrom-Json -Depth 30
        $definitions = @(Get-ConnectorDefinitions)
        $observers = @($vault.tokens.PSObject.Properties.Name | Sort-Object)
        $expectedObservers = @($definitions.observer_id | Sort-Object)
        if (
            $vault.schema_version -ne "pulsechain-external-observer-connector-vault@1.0.0" -or
            $vault.worker_name -ne $WorkerName -or
            ([string]$vault.account_id).ToLowerInvariant() -cne $ExpectedAccountId -or
            $vault.worker_origin -ne $ExpectedOrigin -or
            $vault.current_version_id -ne $ExpectedPriorVersionId -or
            $null -ne $vault.prior_version_id -or
            $vault.source_branch -ne $ExpectedR12DSourceBranch -or
            $vault.source_commit -ne $ExpectedR12DSourceCommit -or
            $vault.source_tree -ne $ExpectedR12DSourceTree -or
            $vault.publication_mode -ne "DISABLED" -or
            [string]::IsNullOrWhiteSpace([string]$vault.created_at_utc) -or
            [string]::IsNullOrWhiteSpace([string]$vault.deployed_at_utc) -or
            ($observers -join "`n") -cne ($expectedObservers -join "`n")
        ) {
            throw "FINALIZED_VAULT_METADATA_MISMATCH"
        }
        [void][DateTimeOffset]::Parse([string]$vault.created_at_utc, [Globalization.CultureInfo]::InvariantCulture)
        [void][DateTimeOffset]::Parse([string]$vault.deployed_at_utc, [Globalization.CultureInfo]::InvariantCulture)
        foreach ($definition in $definitions) {
            $record = $vault.tokens.($definition.observer_id)
            if ($record.secret_label -ne $definition.token_label -or [string]::IsNullOrWhiteSpace([string]$record.ciphertext_base64)) {
                throw "FINALIZED_VAULT_RECORD_MISMATCH"
            }
            [byte[]]$cipher = [Convert]::FromBase64String([string]$record.ciphertext_base64)
            try {
                if ($cipher.Length -lt 32) { throw "FINALIZED_VAULT_CIPHERTEXT_INVALID" }
            }
            finally { [Array]::Clear($cipher, 0, $cipher.Length) }
        }
        $info = Get-Item -LiteralPath $vaultPath
        [pscustomobject][ordered]@{
            path = $vaultPath
            byte_size = $info.Length
            sha256 = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($vaultBytes)).ToLowerInvariant()
            last_write_ticks = $info.LastWriteTimeUtc.Ticks
            file_access_sddl = Get-AccessSddl -Path $vaultPath
            directory_access_sddl = Get-AccessSddl -Path $stateDirectory -Directory
        }
    }
    finally {
        $vault = $null
        $vaultText = $null
        [Array]::Clear($vaultBytes, 0, $vaultBytes.Length)
    }
}

function Assert-VaultUnchanged {
    param([Parameter(Mandatory = $true)][psobject]$Baseline)
    $current = Get-VaultBaseline
    foreach ($field in @("path", "byte_size", "sha256", "last_write_ticks", "file_access_sddl", "directory_access_sddl")) {
        if ([string]$current.$field -cne [string]$Baseline.$field) {
            throw "FINALIZED_VAULT_CHANGED"
        }
    }
}

function Invoke-CloudflareHelper {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)
    $auth = Invoke-WranglerCaptured -Arguments @("auth", "token", "--json")
    if ($auth.exit_code -ne 0 -or [string]::IsNullOrWhiteSpace($auth.stdout)) {
        throw "CLOUDFLARE_AUTH_HANDOFF_FAILED"
    }
    $nodePath = (Get-Command node -ErrorAction Stop).Source
    $helperPath = Join-Path $BundleRoot "VERIFY_CLOUDFLARE_R12F.mjs"
    $startInfo = [Diagnostics.ProcessStartInfo]::new()
    $startInfo.FileName = $nodePath
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardInput = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    [void]$startInfo.ArgumentList.Add($helperPath)
    foreach ($argument in $Arguments) { [void]$startInfo.ArgumentList.Add($argument) }
    foreach ($unsafeName in @("NODE_OPTIONS", "NODE_DEBUG", "NODE_INSPECT_RESUME_ON_START", "NODE_V8_COVERAGE")) {
        [void]$startInfo.Environment.Remove($unsafeName)
    }
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $startInfo
    $processStarted = $false
    try {
        if (-not $process.Start()) { throw "CLOUDFLARE_HELPER_START_FAILED" }
        $processStarted = $true
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        [void]$process.StandardInput.Write($auth.stdout)
        [void]$process.StandardInput.Close()
        [void]$process.WaitForExitAsync().GetAwaiter().GetResult()
        $stdout = $stdoutTask.GetAwaiter().GetResult()
        $stderr = $stderrTask.GetAwaiter().GetResult()
        if ($process.ExitCode -ne 0 -or -not [string]::IsNullOrWhiteSpace($stderr) -or $stdout.Length -gt 4MB) {
            throw "CLOUDFLARE_HELPER_FAILED"
        }
        try { $record = $stdout | ConvertFrom-Json -Depth 100 }
        catch { throw "CLOUDFLARE_HELPER_JSON_INVALID" }
        if ($record.result -ne "PASS") { throw "CLOUDFLARE_HELPER_REPORTED_FAILURE" }
        $record
    }
    finally {
        $auth.stdout = $null
        $auth = $null
        if ($processStarted -and -not $process.HasExited) { [void]$process.Kill($true) }
        [void]$process.Dispose()
    }
}

function Throw-CloudflareStateFieldFailure {
    param([Parameter(Mandatory = $true)][string]$Field)
    $exception = [InvalidOperationException]::new("CLOUDFLARE_STATE_REQUIRED_FIELD_MISSING")
    $exception.Data["PulseChainFailedField"] = $Field
    throw $exception
}

function Assert-CloudflareStateShape {
    param([Parameter(Mandatory = $true)][psobject]$State)
    if ($State -isnot [pscustomobject]) {
        throw "CLOUDFLARE_STATE_TYPE_INVALID"
    }
    foreach ($field in @(
        "account_id",
        "worker_name",
        "account_subdomain",
        "workers_dev_enabled",
        "preview_urls_enabled",
        "worker_origin",
        "last_deployed_from",
        "service_script_tag",
        "script_settings_sha256"
    )) {
        if ($null -eq $State.PSObject.Properties[$field]) {
            Throw-CloudflareStateFieldFailure -Field $field
        }
    }
}

function Get-CloudflareState {
    $outputs = @(Invoke-CloudflareHelper -Arguments @("state", "--account-id", $ExpectedAccountId, "--worker-name", $WorkerName))
    if ($outputs.Count -eq 0) {
        throw "CLOUDFLARE_STATE_UNAVAILABLE"
    }
    if ($outputs.Count -ne 1) {
        throw "CLOUDFLARE_STATE_OUTPUT_CARDINALITY_MISMATCH"
    }
    $state = $outputs[0]
    Assert-CloudflareStateShape -State $state
    $state
}

function Get-RemoteVersionContent {
    param([Parameter(Mandatory = $true)][string]$VersionId, [Parameter(Mandatory = $true)][string]$LocalUploadForm)
    Invoke-CloudflareHelper -Arguments @(
        "content", "--account-id", $ExpectedAccountId, "--worker-name", $WorkerName,
        "--version-id", $VersionId, "--local-upload-form", $LocalUploadForm
    )
}

function Get-RemoteSnapshot {
    param([Parameter(Mandatory = $true)][string]$ActiveVersionId)
    [pscustomobject][ordered]@{
        status = Invoke-WranglerJson -Arguments @("deployments", "status", "--name", $WorkerName, "--json")
        deployments = @(Invoke-WranglerJson -Arguments @("deployments", "list", "--name", $WorkerName, "--json"))
        versions = @(Invoke-WranglerJson -Arguments @("versions", "list", "--name", $WorkerName, "--json"))
        active_version = Invoke-WranglerJson -Arguments @("versions", "view", $ActiveVersionId, "--name", $WorkerName, "--json")
        secrets = @(Invoke-WranglerJson -Arguments @("secret", "list", "--name", $WorkerName, "--format", "json"))
        cloudflare = Get-CloudflareState
    }
}

function Get-Ids {
    param([AllowEmptyCollection()][object[]]$Records)
    @($Records | ForEach-Object { [string]$_.id } | Where-Object { $_ -match "^[0-9a-f-]{36}$" } | Sort-Object -Unique)
}

function Assert-VersionBindingContract {
    param(
        [Parameter(Mandatory = $true)][psobject]$Version,
        [Parameter(Mandatory = $true)][string]$ExpectedVersionId,
        [switch]$RequireR12FIdentity
    )
    if (
        $Version.id -ne $ExpectedVersionId -or
        $Version.resources.script_runtime.compatibility_date -ne $ExpectedCompatibilityDate -or
        @($Version.resources.script_runtime.compatibility_flags).Count -ne 1 -or
        $Version.resources.script_runtime.compatibility_flags[0] -ne "nodejs_compat" -or
        @($Version.resources.script.handlers).Count -ne 1 -or
        $Version.resources.script.handlers[0] -ne "fetch"
    ) {
        throw "WORKER_VERSION_RUNTIME_MISMATCH"
    }
    $projection = [Collections.Generic.List[string]]::new()
    foreach ($binding in @($Version.resources.bindings)) {
        if ($binding.type -eq "plain_text") {
            [void]$projection.Add("plain_text|$($binding.name)|$($binding.text)")
        }
        elseif ($binding.type -eq "secret_text") {
            [void]$projection.Add("secret_text|$($binding.name)")
        }
        else {
            throw "UNEXPECTED_WORKER_BINDING"
        }
    }
    $expectedProjection = @(
        "plain_text|CONTROL_ROOM_ORIGIN|$ExpectedControlRoomOrigin",
        "plain_text|PUBLICATION_MODE|DISABLED"
    ) + @($ExpectedSecretLabels | ForEach-Object { "secret_text|$_" })
    if ((@($projection | Sort-Object) -join "`n") -cne (@($expectedProjection | Sort-Object) -join "`n")) {
        throw "WORKER_BINDING_SET_MISMATCH"
    }
    if ($RequireR12FIdentity) {
        if (
            $Version.metadata.source -ne "wrangler" -or
            $Version.annotations."workers/tag" -ne $VersionTag -or
            $Version.annotations."workers/message" -ne $VersionMessage
        ) {
            throw "UPLOADED_SOURCE_IDENTITY_MISMATCH"
        }
    }
}

function Assert-ExactSecrets {
    param([Parameter(Mandatory = $true)][object[]]$Secrets)
    $names = @($Secrets | ForEach-Object { [string]$_.name } | Sort-Object)
    if ($Secrets.Count -ne 5 -or ($names -join "`n") -cne ($ExpectedSecretLabels -join "`n")) {
        throw "WORKER_SECRET_LABEL_SET_MISMATCH"
    }
    if (@($Secrets | Where-Object { $_.type -and $_.type -ne "secret_text" }).Count -ne 0) {
        throw "WORKER_SECRET_TYPE_MISMATCH"
    }
}

function Assert-CloudflareExpectedState {
    param([Parameter(Mandatory = $true)][psobject]$State)
    Assert-CloudflareStateShape -State $State
    if (
        $State.account_id -ne $ExpectedAccountId -or
        $State.worker_name -ne $WorkerName -or
        $State.account_subdomain -ne $ExpectedAccountSubdomain -or
        $State.workers_dev_enabled -ne $true -or
        $State.preview_urls_enabled -ne $false -or
        $State.worker_origin -ne $ExpectedOrigin -or
        $State.last_deployed_from -ne "wrangler" -or
        [string]::IsNullOrWhiteSpace([string]$State.service_script_tag) -or
        [string]$State.script_settings_sha256 -notmatch "^[0-9a-f]{64}$"
    ) {
        throw "CLOUDFLARE_WORKER_STATE_MISMATCH"
    }
}

function Assert-ExactProductionState {
    param(
        [Parameter(Mandatory = $true)][psobject]$Snapshot,
        [Parameter(Mandatory = $true)][string]$DeploymentId,
        [Parameter(Mandatory = $true)][string]$VersionId
    )
    $traffic = @($Snapshot.status.versions)
    if (
        $Snapshot.status.id -ne $DeploymentId -or
        $traffic.Count -ne 1 -or
        $traffic[0].version_id -ne $VersionId -or
        [decimal]$traffic[0].percentage -ne 100
    ) {
        throw "PRODUCTION_TRAFFIC_STATE_MISMATCH"
    }
    if (@($Snapshot.deployments | Where-Object { $_.id -eq $DeploymentId }).Count -ne 1) {
        throw "DEPLOYMENT_ID_NOT_IN_HISTORY"
    }
    Assert-VersionBindingContract -Version $Snapshot.active_version -ExpectedVersionId $VersionId -RequireR12FIdentity:($VersionId -ne $ExpectedPriorVersionId)
    Assert-ExactSecrets -Secrets $Snapshot.secrets
    Assert-CloudflareExpectedState -State $Snapshot.cloudflare
}

function Assert-ProductionUnchanged {
    param([Parameter(Mandatory = $true)][psobject]$Baseline, [Parameter(Mandatory = $true)][psobject]$Candidate)
    Assert-ExactProductionState -Snapshot $Candidate -DeploymentId $ExpectedPriorDeploymentId -VersionId $ExpectedPriorVersionId
    if (
        (@(Get-Ids $Baseline.deployments) -join "`n") -cne (@(Get-Ids $Candidate.deployments) -join "`n") -or
        $Candidate.cloudflare.service_script_tag -cne $Baseline.cloudflare.service_script_tag -or
        $Candidate.cloudflare.script_settings_sha256 -cne $Baseline.cloudflare.script_settings_sha256
    ) {
        throw "PROTECTED_REMOTE_STATE_CHANGED"
    }
}

function Assert-OneAddedId {
    param(
        [Parameter(Mandatory = $true)][string[]]$Before,
        [Parameter(Mandatory = $true)][string[]]$After,
        [Parameter(Mandatory = $true)][string]$ExpectedAddedId
    )
    $added = @($After | Where-Object { $_ -notin $Before } | Sort-Object -Unique)
    if ($added.Count -ne 1 -or $added[0] -ne $ExpectedAddedId) {
        throw "REMOTE_MUTATION_DELTA_MISMATCH"
    }
    if ($Before.Count -lt 10 -and @($Before | Where-Object { $_ -notin $After }).Count -ne 0) {
        throw "REMOTE_HISTORY_REMOVAL_DETECTED"
    }
}

function Write-PrivateOperatorFile {
    param([Parameter(Mandatory = $true)][string]$Path, [Parameter(Mandatory = $true)][string]$Text)
    $directory = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $directory -PathType Container)) {
        throw "OPERATOR_STATE_DIRECTORY_MISSING"
    }
    $temporary = Join-Path $directory (".r12f-" + [Guid]::NewGuid().ToString("N"))
    try {
        [IO.File]::WriteAllText($temporary, $Text, [Text.UTF8Encoding]::new($false))
        Set-PrivateFileAcl -Path $temporary
        Assert-PrivateFileAcl -Path $temporary
        [IO.File]::Move($temporary, $Path, $true)
        Set-PrivateFileAcl -Path $Path
        Assert-PrivateFileAcl -Path $Path
    }
    finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue }
    }
}

function Write-UpdateReceipt {
    param([Parameter(Mandatory = $true)][string]$Status, [AllowNull()][string]$VerifierResult = $null)
    $receipt = [pscustomobject][ordered]@{
        schema_version = "pulsechain-external-observer-r12f-update-receipt@1.0.0"
        status = $Status
        recorded_at_utc = [DateTime]::UtcNow.ToString("o")
        account_id = $ExpectedAccountId
        worker_name = $WorkerName
        worker_origin = $ExpectedOrigin
        source_branch = $ExpectedR12F2DBundleSourceBranch
        source_commit = $ExpectedR12F2DBundleSourceCommit
        source_tree = $ExpectedR12F2DBundleSourceTree
        prior_deployment_id = $ExpectedPriorDeploymentId
        prior_version_id = $ExpectedPriorVersionId
        uploaded_version_id = $newVersionId
        deployment_id = $newDeploymentId
        traffic_changed = $trafficChanged
        verifier_result = $VerifierResult
        connector_vault_modified = $false
        secret_mutations = 0
    }
    $path = Join-Path (Get-OperatorStateDirectory) "R12F_UPDATE_RECEIPT.json"
    Write-PrivateOperatorFile -Path $path -Text (($receipt | ConvertTo-Json -Depth 20) + [Environment]::NewLine)
}

function New-UpdateFailureRecord {
    param([Parameter(Mandatory = $true)][Management.Automation.ErrorRecord]$ErrorRecord)
    $nativeExitCode = if (Get-Variable -Name LASTEXITCODE -ErrorAction SilentlyContinue) { $LASTEXITCODE } else { $null }
    $failure = New-SanitizedOperatorFailureRecord -ErrorRecord $ErrorRecord -Stage $phase -NativeExitCode $nativeExitCode
    $failedField = if ($ErrorRecord.Exception.Data.Contains("PulseChainFailedField")) {
        ConvertTo-SanitizedOperatorText -Value $ErrorRecord.Exception.Data["PulseChainFailedField"]
    }
    else { $null }
    $failure | Add-Member -NotePropertyName failed_field -NotePropertyValue $failedField
    [pscustomobject][ordered]@{
        schema_version = "pulsechain-external-observer-r12f2d-update-failure@1.0.0"
        recorded_at_utc = [DateTime]::UtcNow.ToString("o")
        source_branch = $ExpectedR12F2DBundleSourceBranch
        source_commit = $ExpectedR12F2DBundleSourceCommit
        source_tree = $ExpectedR12F2DBundleSourceTree
        failure = $failure
        provider_mutation_retry_performed = $false
    }
}

try {
    if (-not $IsWindows) { throw "WINDOWS_REQUIRED" }
    if ($PSVersionTable.PSVersion -lt [Version]"7.4.0") { throw "POWERSHELL_7_4_REQUIRED" }
    if ($CloudflareAccountId.ToLowerInvariant() -cne $ExpectedAccountId) { throw "CLOUDFLARE_ACCOUNT_ID_MISMATCH" }
    if ($ChangeFreezeConfirmation -cne "I_HAVE_EXCLUSIVE_CHANGE_FREEZE") { throw "EXCLUSIVE_CHANGE_FREEZE_REQUIRED" }

    Assert-BundleIntegrity
    . (Join-Path $BundleRoot "OPERATOR_COMMON.ps1")
    Assert-WindowsOperator

    Set-UpdatePhase "WINDOWS_ACL_PREFLIGHT"
    $powerShellPath = (Get-Process -Id $PID).Path
    $aclOutput = @(& $powerShellPath -NoLogo -NoProfile -NonInteractive -File (Join-Path $BundleRoot "TEST_WINDOWS_OPERATOR_ACL.ps1") 2>&1)
    $aclFinal = if ($aclOutput.Count) { [string]$aclOutput[-1] } else { "" }
    if ($LASTEXITCODE -ne 0 -or $aclFinal -cne "TOTAL=25 PASS=25 FAIL=0") {
        throw "WINDOWS_OPERATOR_ACL_PREFLIGHT_FAILED"
    }
    $aclOutput = $null

    foreach ($commandName in @("node", "npm", "npx")) {
        if ($null -eq (Get-Command $commandName -ErrorAction SilentlyContinue)) { throw "NODE_RUNTIME_REQUIRED" }
    }
    $nodeVersion = (& node --version 2>$null).Trim().TrimStart("v")
    if ($LASTEXITCODE -ne 0 -or [Version]$nodeVersion -lt [Version]"22.13.0") { throw "NODE_VERSION_UNSUPPORTED" }

    Set-UpdatePhase "FINALIZED_VAULT_PREFLIGHT"
    $vaultBaseline = Get-VaultBaseline

    $operatorTemp = Join-Path ([IO.Path]::GetTempPath()) ("pulsechain-r12f-update-" + [Guid]::NewGuid().ToString("N"))
    [void][IO.Directory]::CreateDirectory($operatorTemp)
    Set-PrivateDirectoryAcl -Path $operatorTemp
    Assert-PrivateDirectoryAcl -Path $operatorTemp

    Set-UpdatePhase "PINNED_DEPENDENCY_INSTALL"
    $npmResult = Invoke-NativeCaptured -FilePath "npm" -Arguments @("--prefix", $BundleRoot, "ci", "--ignore-scripts", "--no-audit", "--no-fund") -WorkingDirectory $BundleRoot
    if ($npmResult.exit_code -ne 0) { throw "PINNED_DEPENDENCY_INSTALL_FAILED" }
    $wranglerPackage = Get-Content -LiteralPath (Join-Path $BundleRoot "node_modules\wrangler\package.json") -Raw -Encoding utf8 | ConvertFrom-Json
    if ($wranglerPackage.version -ne $ExpectedWranglerVersion) { throw "WRANGLER_PACKAGE_VERSION_MISMATCH" }
    $env:PATH = (Join-Path $BundleRoot "node_modules\.bin") + [IO.Path]::PathSeparator + $env:PATH
    $env:npm_config_offline = "true"
    $env:NO_COLOR = "1"
    $env:FORCE_COLOR = "0"
    $env:WRANGLER_SEND_METRICS = "false"
    $wranglerVersion = (& npx --no-install wrangler --version 2>$null).Trim()
    if ($LASTEXITCODE -ne 0 -or $wranglerVersion -ne $ExpectedWranglerVersion) { throw "PINNED_WRANGLER_UNAVAILABLE" }
    $env:CLOUDFLARE_ACCOUNT_ID = $ExpectedAccountId

    Set-UpdatePhase "LOCAL_SOURCE_TESTS"
    $gatewayTests = Invoke-NativeCaptured -FilePath "npm" -Arguments @("--prefix", $GatewayDirectory, "run", "validate") -WorkingDirectory $GatewayDirectory
    if ($gatewayTests.exit_code -ne 0) { throw "GATEWAY_VALIDATION_FAILED" }
    $operatorTestPaths = @(
        Get-ChildItem -LiteralPath (Join-Path $BundleRoot "operator-tests") -Filter "*.test.mjs" -File -Recurse -Force |
            Sort-Object -Property FullName |
            Select-Object -ExpandProperty FullName
    )
    if ($operatorTestPaths.Count -lt 1) { throw "OPERATOR_TESTS_MISSING" }
    $operatorTestArguments = @("--test") + $operatorTestPaths
    $operatorTests = Invoke-NativeCaptured -FilePath "node" -Arguments $operatorTestArguments -WorkingDirectory $BundleRoot
    if ($operatorTests.exit_code -ne 0) { throw "OPERATOR_TESTS_FAILED" }

    Set-UpdatePhase "CLOUDFLARE_AUTHENTICATION"
    $whoami = Invoke-WranglerJson -Arguments @("whoami", "--json")
    $matchingAccounts = @($whoami.accounts | Where-Object { ([string]$_.id).ToLowerInvariant() -ceq $ExpectedAccountId })
    if ($whoami.loggedIn -ne $true -or $matchingAccounts.Count -ne 1) { throw "CLOUDFLARE_AUTHENTICATED_ACCOUNT_MISMATCH" }

    Set-UpdatePhase "EXACT_PRE_UPDATE_STATE"
    $preUpdate = Get-RemoteSnapshot -ActiveVersionId $ExpectedPriorVersionId
    Assert-ExactProductionState -Snapshot $preUpdate -DeploymentId $ExpectedPriorDeploymentId -VersionId $ExpectedPriorVersionId
    $preVersionIds = @(Get-Ids $preUpdate.versions)
    $latestPreVersion = @($preUpdate.versions | Sort-Object { [DateTimeOffset]::Parse([string]$_.metadata.created_on) } -Descending | Select-Object -First 1)
    if ($latestPreVersion.Count -ne 1 -or $latestPreVersion[0].id -ne $ExpectedPriorVersionId) {
        throw "UNDEPLOYED_DRAFT_VERSION_PRESENT"
    }
    Assert-VaultUnchanged -Baseline $vaultBaseline

    Set-UpdatePhase "VERSION_UPLOAD"
    $uploadReceiptPath = Join-Path $operatorTemp "wrangler-version-upload.jsonl"
    $uploadFormPath = Join-Path $operatorTemp "r12f-worker-upload-form.bin"
    $uploadInvocations += 1
    $upload = Invoke-WranglerWithReceipt -ReceiptPath $uploadReceiptPath -Arguments @(
        "versions", "upload",
        "--config", "wrangler.toml",
        "--name", $WorkerName,
        "--keep-vars",
        "--compatibility-date", $ExpectedCompatibilityDate,
        "--compatibility-flag", "nodejs_compat",
        "--tag", $VersionTag,
        "--message", $VersionMessage,
        "--outfile", $uploadFormPath
    )
    if ($uploadInvocations -ne 1) { throw "VERSION_UPLOAD_INVOCATION_COUNT_INVALID" }
    if ($upload.native.exit_code -ne 0) {
        throw "VERSION_UPLOAD_AMBIGUOUS_NO_RETRY"
    }
    $uploadReceipts = @($upload.receipts | Where-Object { $_.type -eq "version-upload" -and [int]$_.version -eq 1 })
    if (
        $uploadReceipts.Count -ne 1 -or
        $uploadReceipts[0].worker_name -ne $WorkerName -or
        $uploadReceipts[0].worker_name_overridden -eq $true -or
        [string]$uploadReceipts[0].preview_url -ne "" -or
        [string]$uploadReceipts[0].preview_alias_url -ne "" -or
        [string]$uploadReceipts[0].version_id -notmatch "^[0-9a-f-]{36}$"
    ) {
        throw "VERSION_UPLOAD_RECEIPT_MISMATCH"
    }
    $newVersionId = [string]$uploadReceipts[0].version_id
    $uploadOccurred = $true
    if (-not (Test-Path -LiteralPath $uploadFormPath -PathType Leaf)) { throw "LOCAL_UPLOAD_FORM_MISSING" }
    Set-PrivateFileAcl -Path $uploadFormPath
    Assert-PrivateFileAcl -Path $uploadFormPath

    Set-UpdatePhase "UPLOADED_VERSION_READBACK"
    $afterUpload = Get-RemoteSnapshot -ActiveVersionId $ExpectedPriorVersionId
    Assert-ProductionUnchanged -Baseline $preUpdate -Candidate $afterUpload
    Assert-OneAddedId -Before $preVersionIds -After @(Get-Ids $afterUpload.versions) -ExpectedAddedId $newVersionId
    $newVersion = Invoke-WranglerJson -Arguments @("versions", "view", $newVersionId, "--name", $WorkerName, "--json")
    Assert-VersionBindingContract -Version $newVersion -ExpectedVersionId $newVersionId -RequireR12FIdentity
    $contentReadback = Get-RemoteVersionContent -VersionId $newVersionId -LocalUploadForm $uploadFormPath
    if (
        $contentReadback.local_remote_content_equal -ne $true -or
        [int]$contentReadback.local_source_map_count -ne 0 -or
        [int]$contentReadback.remote_source_map_count -ne 0 -or
        [string]::IsNullOrWhiteSpace([string]$contentReadback.local_entrypoint) -or
        $contentReadback.local_entrypoint -cne $contentReadback.remote_entrypoint
    ) {
        throw "UPLOADED_SOURCE_BYTE_READBACK_MISMATCH"
    }
    Assert-VaultUnchanged -Baseline $vaultBaseline
    Write-UpdateReceipt -Status "VERSION_UPLOADED_NOT_DEPLOYED"

    Set-UpdatePhase "FINAL_CHANGE_FREEZE_RECHECK"
    $preDeploy = Get-RemoteSnapshot -ActiveVersionId $ExpectedPriorVersionId
    Assert-ProductionUnchanged -Baseline $preUpdate -Candidate $preDeploy
    if ((@(Get-Ids $preDeploy.versions) -join "`n") -cne (@(Get-Ids $afterUpload.versions) -join "`n")) {
        throw "CONCURRENT_VERSION_CHANGE_DETECTED"
    }
    $newVersionPreDeploy = Invoke-WranglerJson -Arguments @("versions", "view", $newVersionId, "--name", $WorkerName, "--json")
    Assert-VersionBindingContract -Version $newVersionPreDeploy -ExpectedVersionId $newVersionId -RequireR12FIdentity
    Assert-VaultUnchanged -Baseline $vaultBaseline

    Set-UpdatePhase "SINGLE_PRODUCTION_DEPLOYMENT"
    $deploymentReceiptPath = Join-Path $operatorTemp "wrangler-version-deploy.jsonl"
    $deploymentInvocations += 1
    $deployment = Invoke-WranglerWithReceipt -ReceiptPath $deploymentReceiptPath -Arguments @(
        "versions", "deploy", ("{0}@100" -f $newVersionId),
        "--config", "wrangler.toml",
        "--name", $WorkerName,
        "--message", $DeploymentMessage,
        "--yes"
    )
    if ($deploymentInvocations -ne 1) { throw "DEPLOYMENT_INVOCATION_COUNT_INVALID" }
    if ($deployment.native.exit_code -ne 0) {
        throw "DEPLOYMENT_AMBIGUOUS_NO_RETRY"
    }
    $deploymentReceipts = @($deployment.receipts | Where-Object { $_.type -eq "version-deploy" -and [int]$_.version -eq 1 })
    if (
        $deploymentReceipts.Count -ne 1 -or
        $deploymentReceipts[0].worker_name -ne $WorkerName -or
        [string]$deploymentReceipts[0].deployment_id -notmatch "^[0-9a-f-]{36}$"
    ) {
        throw "DEPLOYMENT_RECEIPT_MISMATCH"
    }
    $newDeploymentId = [string]$deploymentReceipts[0].deployment_id
    $trafficChanged = $true

    Set-UpdatePhase "POST_DEPLOYMENT_READBACK"
    $postDeploy = Get-RemoteSnapshot -ActiveVersionId $newVersionId
    Assert-ExactProductionState -Snapshot $postDeploy -DeploymentId $newDeploymentId -VersionId $newVersionId
    Assert-OneAddedId -Before @(Get-Ids $preUpdate.deployments) -After @(Get-Ids $postDeploy.deployments) -ExpectedAddedId $newDeploymentId
    $rollbackVersion = Invoke-WranglerJson -Arguments @("versions", "view", $ExpectedPriorVersionId, "--name", $WorkerName, "--json")
    Assert-VersionBindingContract -Version $rollbackVersion -ExpectedVersionId $ExpectedPriorVersionId
    $contentAfterDeploy = Get-RemoteVersionContent -VersionId $newVersionId -LocalUploadForm $uploadFormPath
    if ($contentAfterDeploy.local_remote_content_equal -ne $true -or [int]$contentAfterDeploy.remote_source_map_count -ne 0) {
        throw "DEPLOYED_SOURCE_BYTE_READBACK_MISMATCH"
    }
    Assert-VaultUnchanged -Baseline $vaultBaseline
    Write-UpdateReceipt -Status "DEPLOYED_PENDING_GOVERNED_VERIFICATION"

    Set-UpdatePhase "GOVERNED_DISABLED_MODE_VERIFICATION"
    $verifierInvocations += 1
    $verifierErrorPath = Join-Path $operatorTemp "governed-verifier.err"
    $verifierOutput = @(& (Join-Path $BundleRoot "VERIFY_GATEWAY_DISABLED_R12F.ps1") -WorkerOrigin $ExpectedOrigin 2> $verifierErrorPath)
    $verifierExitCode = $LASTEXITCODE
    $verifierError = if (Test-Path -LiteralPath $verifierErrorPath -PathType Leaf) {
        Get-Content -LiteralPath $verifierErrorPath -Raw -Encoding utf8
    }
    else { "" }
    if ($verifierInvocations -ne 1) { throw "GOVERNED_VERIFIER_INVOCATION_COUNT_INVALID" }
    $verificationReportPath = Join-Path (Get-OperatorStateDirectory) "LOCAL_DISABLED_MODE_VERIFICATION_R12F.json"
    if (-not (Test-Path -LiteralPath $verificationReportPath -PathType Leaf)) {
        throw "GOVERNED_VERIFICATION_REPORT_MISSING"
    }
    Assert-PrivateFileAcl -Path $verificationReportPath
    $verificationReport = Get-Content -LiteralPath $verificationReportPath -Raw -Encoding utf8 | ConvertFrom-Json -Depth 100
    Assert-VaultUnchanged -Baseline $vaultBaseline

    if (
        $verifierExitCode -eq 0 -and
        [string]::IsNullOrWhiteSpace($verifierError) -and
        $verifierOutput.Count -eq 1 -and
        [string]$verifierOutput[0] -ceq "VERIFICATION_STATUS=PASS" -and
        $verificationReport.result -eq "PASS" -and
        $verificationReport.release_critical -eq $false -and
        $verificationReport.recommended_release_action -eq "R13_HANDOFF_READY"
    ) {
        $r13Source = Join-Path $BundleRoot "R13_POST_UPDATE_VERIFICATION_PROMPT.md"
        $r13Target = Join-Path (Get-OperatorStateDirectory) "R13_POST_UPDATE_VERIFICATION_PROMPT.md"
        Write-PrivateOperatorFile -Path $r13Target -Text ([IO.File]::ReadAllText($r13Source, [Text.Encoding]::UTF8))
        Write-UpdateReceipt -Status "UPDATE_VERIFIED_R13_HANDOFF_READY" -VerifierResult "PASS"
        $updateSucceeded = $true
    }
    elseif (
        $verificationReport.external_upstream_blocker_only -eq $true -and
        $verificationReport.release_critical -eq $false -and
        $verificationReport.recommended_release_action -eq "PRESERVE_DEPLOYED_R12F_REPORT_EXTERNAL_BLOCKER"
    ) {
        Write-UpdateReceipt -Status "DEPLOYED_CONTROL_ROOM_UPSTREAM_BLOCKED" -VerifierResult "CONTROL_ROOM_UPSTREAM_UNAVAILABLE"
        throw "R12F_EXTERNAL_UPSTREAM_BLOCKER_NO_ROLLBACK"
    }
    elseif ($verificationReport.release_critical -eq $true) {
        Write-UpdateReceipt -Status "DEPLOYED_RELEASE_CRITICAL_FAILURE_SEPARATE_ROLLBACK_AUTHORIZATION_REQUIRED" -VerifierResult ([string]$verificationReport.result)
        throw "R12F_RELEASE_CRITICAL_FAILURE_SEPARATE_ROLLBACK_AUTHORIZATION_REQUIRED"
    }
    else {
        Write-UpdateReceipt -Status "DEPLOYED_ORDINARY_VERIFICATION_FAILURE" -VerifierResult ([string]$verificationReport.result)
        throw "R12F_ORDINARY_VERIFICATION_FAILURE_NO_AUTOMATIC_ROLLBACK"
    }
}
catch {
    $caughtFailure = $_
    if (Get-Command New-SanitizedOperatorFailureRecord -ErrorAction SilentlyContinue) {
        try { $caughtFailureRecord = New-UpdateFailureRecord -ErrorRecord $_ }
        catch { $caughtFailureRecord = $null }
    }

    # A nonzero CLI result is never retried. Perform only a bounded read-only
    # reconciliation so an accepted-but-interrupted mutation is not concealed.
    if ($phase -in @("VERSION_UPLOAD", "SINGLE_PRODUCTION_DEPLOYMENT") -and $null -ne $preUpdate) {
        try {
            if ($null -eq $newVersionId -and $null -ne $upload) {
                $ambiguousUploadReceipts = @($upload.receipts | Where-Object {
                    $_.type -eq "version-upload" -and [string]$_.version_id -match "^[0-9a-f-]{36}$"
                })
                if ($ambiguousUploadReceipts.Count -eq 1) {
                    $newVersionId = [string]$ambiguousUploadReceipts[0].version_id
                    $uploadOccurred = $true
                }
            }
            if ($null -eq $newDeploymentId -and $null -ne $deployment) {
                $ambiguousDeploymentReceipts = @($deployment.receipts | Where-Object {
                    $_.type -eq "version-deploy" -and [string]$_.deployment_id -match "^[0-9a-f-]{36}$"
                })
                if ($ambiguousDeploymentReceipts.Count -eq 1) {
                    $newDeploymentId = [string]$ambiguousDeploymentReceipts[0].deployment_id
                }
            }

            $ambiguityVersions = @(Invoke-WranglerJson -Arguments @("versions", "list", "--name", $WorkerName, "--json"))
            $addedVersionIds = @((Get-Ids $ambiguityVersions) | Where-Object { $_ -notin $preVersionIds })
            if ($null -eq $newVersionId -and $addedVersionIds.Count -eq 1) {
                $newVersionId = $addedVersionIds[0]
                $uploadOccurred = $true
            }

            $ambiguityStatus = Invoke-WranglerJson -Arguments @("deployments", "status", "--name", $WorkerName, "--json")
            if ($ambiguityStatus.id -ne $ExpectedPriorDeploymentId) {
                $newDeploymentId = [string]$ambiguityStatus.id
                $trafficChanged = $true
            }
            Write-UpdateReceipt -Status "AMBIGUOUS_MUTATION_NO_RETRY_READBACK_RECORDED"
        }
        catch {
            # The final terminal record remains explicit that mutation state is
            # unresolved. It never retries either mutation command.
        }
    }
}
finally {
    if ($null -ne $vaultBaseline) {
        try { Assert-VaultUnchanged -Baseline $vaultBaseline }
        catch { $updateSucceeded = $false }
    }
    if ($null -ne $operatorTemp -and (Test-Path -LiteralPath $operatorTemp -PathType Container)) {
        Remove-Item -LiteralPath $operatorTemp -Force -Recurse -ErrorAction SilentlyContinue
    }
    $env:CLOUDFLARE_ACCOUNT_ID = $priorAccountEnvironment
    $env:PATH = $priorPath
    $env:NO_COLOR = $priorNoColor
    $env:FORCE_COLOR = $priorForceColor
    $env:npm_config_offline = $priorNpmOffline
    $env:WRANGLER_OUTPUT_FILE_PATH = $priorWranglerOutputPath
    $env:WRANGLER_SEND_METRICS = $priorWranglerMetrics
}

if ($null -ne $caughtFailure -or -not $updateSucceeded) {
    $failureCode = if (
        $null -ne $caughtFailure -and
        [string]$caughtFailure.Exception.Message -match "^[A-Z0-9_]+$"
    ) { [string]$caughtFailure.Exception.Message } else { "UNCLASSIFIED_STAGE_FAILURE" }
    $failureReportName = "R12F2D_UPDATE_FAILURE.json"
    if ($null -ne $caughtFailureRecord -and (Get-Command Write-PrivateOperatorFile -ErrorAction SilentlyContinue)) {
        try {
            $failureReportPath = Join-Path (Get-OperatorStateDirectory) $failureReportName
            Write-PrivateOperatorFile -Path $failureReportPath -Text (($caughtFailureRecord | ConvertTo-Json -Depth 20) + [Environment]::NewLine)
        }
        catch { }
    }
    $exceptionType = if ($null -eq $caughtFailureRecord) { "unavailable" } else { [string]$caughtFailureRecord.failure.exception_type }
    $sourceLine = if ($null -eq $caughtFailureRecord) { 0 } else { [int]$caughtFailureRecord.failure.source_line }
    $failedField = if ($null -eq $caughtFailureRecord -or $null -eq $caughtFailureRecord.failure.failed_field) { "none" } else { [string]$caughtFailureRecord.failure.failed_field }
    $terminalException = [InvalidOperationException]::new("R12F_UPDATE_DID_NOT_COMPLETE failure_code=$failureCode phase=$phase upload_occurred=$uploadOccurred traffic_changed=$trafficChanged uploaded_version_id=$newVersionId deployment_id=$newDeploymentId exception_type=$exceptionType source_line=$sourceLine failed_field=$failedField failure_report=$failureReportName")
    if ($null -ne $caughtFailureRecord) {
        $terminalException.Data["PulseChainFailureRecord"] = ($caughtFailureRecord | ConvertTo-Json -Depth 20 -Compress)
    }
    throw $terminalException
}

@(
    "UPDATE_RESULT=SUCCESS",
    "WORKER_NAME=$WorkerName",
    "WORKER_ORIGIN=$ExpectedOrigin",
    "PRIOR_VERSION_ID=$ExpectedPriorVersionId",
    "NEW_VERSION_ID=$newVersionId",
    "NEW_DEPLOYMENT_ID=$newDeploymentId",
    "TRAFFIC_PERCENT=100",
    "PUBLICATION_MODE=DISABLED",
    "CONNECTOR_VAULT_MODIFIED=FALSE",
    "SECRET_MUTATIONS=0",
    "GOVERNED_VERIFICATION=PASS",
    "R13_HANDOFF=READY"
) | Write-Output
