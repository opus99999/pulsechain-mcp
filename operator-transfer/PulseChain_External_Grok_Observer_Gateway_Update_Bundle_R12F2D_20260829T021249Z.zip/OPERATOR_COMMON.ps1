#Requires -Version 7.4

# R12D authoritative template. Rendered commit and tree placeholders are bound after the repair commit exists.

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Assert-WindowsOperator {
    if (-not $IsWindows) {
        throw "This operator bundle may run only on Windows."
    }
    Add-Type -AssemblyName System.Security.Cryptography.ProtectedData -ErrorAction Stop
}

function Get-ConnectorDefinitions {
    @(
        [pscustomobject]@{
            observer_id = "grok-x-protocol"
            path = "/mcp/external-observers/grok-x-protocol"
            publish_tool = "publish_external_observation_grok_x_protocol"
            token_label = "GROK_MCP_TOKEN_X_PROTOCOL"
            target_workstream = "signals-platform"
            observation_id = "grok-x-protocol-r12c-disabled"
            fingerprint = "sha256:d19b907221f241a57a51c4fa0b0ad0fb57ed4ea3c50b7b488d53301384191355"
        }
        [pscustomobject]@{
            observer_id = "grok-infrastructure-incidents"
            path = "/mcp/external-observers/grok-infrastructure-incidents"
            publish_tool = "publish_external_observation_grok_infrastructure_incidents"
            token_label = "GROK_MCP_TOKEN_INFRASTRUCTURE_INCIDENTS"
            target_workstream = "validator-flows"
            observation_id = "grok-infrastructure-incidents-r12c-disabled"
            fingerprint = "sha256:0d00b2289ef749e625e91e52da4a611dce0685e6b47738d6d2ffe746fe9dc7ff"
        }
        [pscustomobject]@{
            observer_id = "grok-market-liquidity"
            path = "/mcp/external-observers/grok-market-liquidity"
            publish_tool = "publish_external_observation_grok_market_liquidity"
            token_label = "GROK_MCP_TOKEN_MARKET_LIQUIDITY"
            target_workstream = "investor-intelligence"
            observation_id = "grok-market-liquidity-r12c-disabled"
            fingerprint = "sha256:95a97b12f667cf05e3ebdf4621b1506ccaa451d422ebb96851536200c2e64dae"
        }
        [pscustomobject]@{
            observer_id = "grok-identity-evidence"
            path = "/mcp/external-observers/grok-identity-evidence"
            publish_tool = "publish_external_observation_grok_identity_evidence"
            token_label = "GROK_MCP_TOKEN_IDENTITY_EVIDENCE"
            target_workstream = "identity-attribution"
            observation_id = "grok-identity-evidence-r12c-disabled"
            fingerprint = "sha256:a59ba28f8dcb8470b127f3a6ceefb139763678f4efe8714c005e463b88bc72dd"
        }
        [pscustomobject]@{
            observer_id = "grok-red-team"
            path = "/mcp/external-observers/grok-red-team"
            publish_tool = "publish_external_observation_grok_red_team"
            token_label = "GROK_MCP_TOKEN_RED_TEAM"
            target_workstream = "signals-platform"
            observation_id = "grok-red-team-r12c-disabled"
            fingerprint = "sha256:d7023e1fca3dbb0e7fc66461b87be07dd287c2aa8b3c84dc08be6a04f6190389"
        }
    )
}

function Get-OperatorStateDirectory {
    if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
        throw "LOCALAPPDATA is unavailable."
    }
    [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA "PulseChain\ExternalObserverGateway"))
}

function Get-ConnectorVaultPath {
    Join-Path (Get-OperatorStateDirectory) "connector-tokens.dpapi.json"
}

function Get-VerificationReportPath {
    Join-Path (Get-OperatorStateDirectory) "LOCAL_DISABLED_MODE_VERIFICATION.json"
}

function Set-OperatorPhase {
    param([Parameter(Mandatory = $true)][string]$Name)
    $script:PulseChainOperatorPhase = $Name
}

function Get-OperatorPhase {
    if ([string]::IsNullOrWhiteSpace([string]$script:PulseChainOperatorPhase)) {
        "INITIAL_VALIDATION"
    }
    else {
        [string]$script:PulseChainOperatorPhase
    }
}

function ConvertTo-SanitizedOperatorText {
    param([AllowNull()][object]$Value)
    if ($null -eq $Value) {
        return $null
    }
    $text = [string]$Value
    $patterns = @(
        "(?i)Authorization\s*:\s*(?:Bearer|Basic)\s+\S+",
        "(?i)(?:token|secret|ciphertext|private[_ -]?key|authorization)\s*[:=]\s*[^\s,;]+",
        "-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----",
        "\b[A-Za-z0-9_-]{43}\b",
        "\b(?:gh[opsu]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b"
    )
    foreach ($pattern in $patterns) {
        $text = [Text.RegularExpressions.Regex]::Replace(
            $text,
            $pattern,
            "[REDACTED]",
            [Text.RegularExpressions.RegexOptions]::CultureInvariant
        )
    }
    $text
}

function New-SanitizedOperatorFailureRecord {
    param(
        [Parameter(Mandatory = $true)][Management.Automation.ErrorRecord]$ErrorRecord,
        [Parameter(Mandatory = $true)][string]$Stage,
        [AllowNull()][object]$NativeExitCode = $null
    )
    $inner = $ErrorRecord.Exception.InnerException
    [pscustomobject][ordered]@{
        schema_version = "pulsechain-r12d-operator-failure@1.0.0"
        stage = $Stage
        exception_type = $ErrorRecord.Exception.GetType().FullName
        sanitized_exception_message = ConvertTo-SanitizedOperatorText -Value $ErrorRecord.Exception.Message
        fully_qualified_error_id = ConvertTo-SanitizedOperatorText -Value $ErrorRecord.FullyQualifiedErrorId
        category_info = ConvertTo-SanitizedOperatorText -Value $ErrorRecord.CategoryInfo
        source_script = ConvertTo-SanitizedOperatorText -Value $ErrorRecord.InvocationInfo.ScriptName
        source_line = [int]$ErrorRecord.InvocationInfo.ScriptLineNumber
        position_message = ConvertTo-SanitizedOperatorText -Value $ErrorRecord.InvocationInfo.PositionMessage
        script_stack_trace = ConvertTo-SanitizedOperatorText -Value $ErrorRecord.ScriptStackTrace
        inner_exception_type = if ($null -eq $inner) { $null } else { $inner.GetType().FullName }
        sanitized_inner_exception_message = if ($null -eq $inner) { $null } else { ConvertTo-SanitizedOperatorText -Value $inner.Message }
        native_exit_code = $NativeExitCode
    }
}

function Throw-OperatorStageFailure {
    param(
        [Parameter(Mandatory = $true)][Management.Automation.ErrorRecord]$ErrorRecord,
        [Parameter(Mandatory = $true)][string]$Code,
        [Parameter(Mandatory = $true)][string]$Stage,
        [AllowNull()][object]$NativeExitCode = $null,
        [bool]$PartialFileRemoved = $true,
        [AllowNull()][Management.Automation.ErrorRecord]$CleanupErrorRecord = $null
    )
    $failure = New-SanitizedOperatorFailureRecord -ErrorRecord $ErrorRecord -Stage $Stage -NativeExitCode $NativeExitCode
    $failure | Add-Member -NotePropertyName partial_private_file_removed -NotePropertyValue $PartialFileRemoved
    $failure | Add-Member -NotePropertyName cleanup_failure -NotePropertyValue $(
        if ($null -eq $CleanupErrorRecord) {
            $null
        }
        else {
            New-SanitizedOperatorFailureRecord -ErrorRecord $CleanupErrorRecord -Stage "CLEANUP"
        }
    )
    $exception = [InvalidOperationException]::new($Code)
    $exception.Data["PulseChainFailureRecord"] = ($failure | ConvertTo-Json -Depth 8 -Compress)
    $record = [Management.Automation.ErrorRecord]::new(
        $exception,
        $Code,
        [Management.Automation.ErrorCategory]::SecurityError,
        $null
    )
    throw $record
}

function Get-CurrentWindowsUserSid {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    try {
        if ($null -eq $identity.User) {
            throw "The current Windows user SID is unavailable."
        }
        $identity.User
    }
    finally {
        $identity.Dispose()
    }
}

function Assert-PrivateAccessRules {
    param(
        [Parameter(Mandatory = $true)][Security.AccessControl.FileSystemSecurity]$Security,
        [Parameter(Mandatory = $true)][Security.Principal.SecurityIdentifier]$CurrentUserSid,
        [switch]$Directory
    )
    if (-not $Security.AreAccessRulesProtected) {
        throw "Private DACL inheritance remains enabled."
    }
    $rules = @($Security.GetAccessRules($true, $false, [Security.Principal.SecurityIdentifier]))
    if ($rules.Count -ne 1) {
        throw "The private DACL contains an unexpected explicit rule count."
    }
    $rule = $rules[0]
    if (
        $rule.IsInherited -or
        $rule.IdentityReference.Value -cne $CurrentUserSid.Value -or
        $rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow -or
        (($rule.FileSystemRights -band [Security.AccessControl.FileSystemRights]::FullControl) -ne [Security.AccessControl.FileSystemRights]::FullControl)
    ) {
        throw "The private DACL is not bound exclusively to the current user SID."
    }
    if ($Directory) {
        $required = [Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [Security.AccessControl.InheritanceFlags]::ObjectInherit
        if (($rule.InheritanceFlags -band $required) -ne $required) {
            throw "The private directory rule lacks required inheritance flags."
        }
    }
    elseif ($rule.InheritanceFlags -ne [Security.AccessControl.InheritanceFlags]::None) {
        throw "The private file rule has unexpected inheritance flags."
    }
}

function Set-PrivateDirectoryAcl {
    param([Parameter(Mandatory = $true)][string]$Path)
    $fullPath = [IO.Path]::GetFullPath($Path)
    $info = [IO.DirectoryInfo]::new($fullPath)
    if (-not $info.Exists) {
        throw "The private directory does not exist."
    }
    $sid = Get-CurrentWindowsUserSid
    $sections = [Security.AccessControl.AccessControlSections]::Access
    $security = [IO.FileSystemAclExtensions]::GetAccessControl($info, $sections)
    $security.SetAccessRuleProtection($true, $false)
    foreach ($existing in @($security.GetAccessRules($true, $false, [Security.Principal.SecurityIdentifier]))) {
        [void]$security.RemoveAccessRuleSpecific($existing)
    }
    $inheritance = [Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [Security.AccessControl.InheritanceFlags]::ObjectInherit
    $rule = [Security.AccessControl.FileSystemAccessRule]::new(
        $sid,
        [Security.AccessControl.FileSystemRights]::FullControl,
        $inheritance,
        [Security.AccessControl.PropagationFlags]::None,
        [Security.AccessControl.AccessControlType]::Allow
    )
    [void]$security.AddAccessRule($rule)
    [IO.FileSystemAclExtensions]::SetAccessControl($info, $security)
    $verified = [IO.FileSystemAclExtensions]::GetAccessControl($info, $sections)
    Assert-PrivateAccessRules -Security $verified -CurrentUserSid $sid -Directory
}

function Set-PrivateFileAcl {
    param([Parameter(Mandatory = $true)][string]$Path)
    $fullPath = [IO.Path]::GetFullPath($Path)
    $info = [IO.FileInfo]::new($fullPath)
    if (-not $info.Exists) {
        throw "The private file does not exist."
    }
    $sid = Get-CurrentWindowsUserSid
    $sections = [Security.AccessControl.AccessControlSections]::Access
    $security = [IO.FileSystemAclExtensions]::GetAccessControl($info, $sections)
    $security.SetAccessRuleProtection($true, $false)
    foreach ($existing in @($security.GetAccessRules($true, $false, [Security.Principal.SecurityIdentifier]))) {
        [void]$security.RemoveAccessRuleSpecific($existing)
    }
    $rule = [Security.AccessControl.FileSystemAccessRule]::new(
        $sid,
        [Security.AccessControl.FileSystemRights]::FullControl,
        [Security.AccessControl.AccessControlType]::Allow
    )
    [void]$security.AddAccessRule($rule)
    [IO.FileSystemAclExtensions]::SetAccessControl($info, $security)
    $verified = [IO.FileSystemAclExtensions]::GetAccessControl($info, $sections)
    Assert-PrivateAccessRules -Security $verified -CurrentUserSid $sid
}

function Assert-PrivateDirectoryAcl {
    param([Parameter(Mandatory = $true)][string]$Path)
    $info = [IO.DirectoryInfo]::new([IO.Path]::GetFullPath($Path))
    $sid = Get-CurrentWindowsUserSid
    $security = [IO.FileSystemAclExtensions]::GetAccessControl(
        $info,
        [Security.AccessControl.AccessControlSections]::Access
    )
    Assert-PrivateAccessRules -Security $security -CurrentUserSid $sid -Directory
}

function Assert-PrivateFileAcl {
    param([Parameter(Mandatory = $true)][string]$Path)
    $info = [IO.FileInfo]::new([IO.Path]::GetFullPath($Path))
    $sid = Get-CurrentWindowsUserSid
    $security = [IO.FileSystemAclExtensions]::GetAccessControl(
        $info,
        [Security.AccessControl.AccessControlSections]::Access
    )
    Assert-PrivateAccessRules -Security $security -CurrentUserSid $sid
}

function Initialize-PrivateDirectory {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        [void][IO.Directory]::CreateDirectory($Path)
    }
    Set-PrivateDirectoryAcl -Path $Path
    Assert-PrivateDirectoryAcl -Path $Path
}

function Get-DpapiEntropy {
    $bytes = [Text.Encoding]::UTF8.GetBytes("PulseChain.ExternalObserverGateway.R12C.v1")
    try {
        [Security.Cryptography.SHA256]::HashData($bytes)
    }
    finally {
        [Array]::Clear($bytes, 0, $bytes.Length)
    }
}

function Protect-ConnectorToken {
    param([Parameter(Mandatory = $true)][string]$Token)
    [byte[]]$plain = [Text.Encoding]::UTF8.GetBytes($Token)
    [byte[]]$entropy = Get-DpapiEntropy
    try {
        $cipher = [Security.Cryptography.ProtectedData]::Protect(
            $plain,
            $entropy,
            [Security.Cryptography.DataProtectionScope]::CurrentUser
        )
        try {
            [Convert]::ToBase64String($cipher)
        }
        finally {
            [Array]::Clear($cipher, 0, $cipher.Length)
        }
    }
    finally {
        [Array]::Clear($plain, 0, $plain.Length)
        [Array]::Clear($entropy, 0, $entropy.Length)
    }
}

function Unprotect-ConnectorToken {
    param([Parameter(Mandatory = $true)][string]$CiphertextBase64)
    [byte[]]$cipher = [Convert]::FromBase64String($CiphertextBase64)
    [byte[]]$entropy = Get-DpapiEntropy
    try {
        $plain = [Security.Cryptography.ProtectedData]::Unprotect(
            $cipher,
            $entropy,
            [Security.Cryptography.DataProtectionScope]::CurrentUser
        )
        try {
            [Text.Encoding]::UTF8.GetString($plain)
        }
        finally {
            [Array]::Clear($plain, 0, $plain.Length)
        }
    }
    finally {
        [Array]::Clear($cipher, 0, $cipher.Length)
        [Array]::Clear($entropy, 0, $entropy.Length)
    }
}

function Write-PrivateTextFile {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Text,
        [string]$WriteStage = "CONNECTOR_VAULT_FILE_WRITE",
        [string]$AclStage = "CONNECTOR_VAULT_ACL_HARDENING",
        [string]$ReadbackStage = "CONNECTOR_VAULT_READBACK",
        [string]$AclFailureCode = "CONNECTOR_VAULT_ACL_HARDENING_FAILED"
    )
    $fullPath = [IO.Path]::GetFullPath($Path)
    $directory = Split-Path -Parent $fullPath
    $temporary = Join-Path $directory (".tmp-" + [Guid]::NewGuid().ToString("N"))
    $backup = Join-Path $directory (".backup-" + [Guid]::NewGuid().ToString("N"))
    $destinationExisted = Test-Path -LiteralPath $fullPath -PathType Leaf
    $destinationReplaced = $false
    $destinationRestored = $false
    $backupSha256 = $null
    $success = $false
    try {
        Set-OperatorPhase -Name $AclStage
        Initialize-PrivateDirectory -Path $directory

        Set-OperatorPhase -Name $WriteStage
        $stream = [IO.File]::Open($temporary, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        $stream.Dispose()

        Set-OperatorPhase -Name $AclStage
        Set-PrivateFileAcl -Path $temporary

        Set-OperatorPhase -Name $WriteStage
        [IO.File]::WriteAllText($temporary, $Text, [Text.UTF8Encoding]::new($false))

        Set-OperatorPhase -Name $AclStage
        Set-PrivateFileAcl -Path $temporary
        Assert-PrivateFileAcl -Path $temporary

        if ($destinationExisted) {
            Set-OperatorPhase -Name $WriteStage
            [IO.File]::Copy($fullPath, $backup, $false)
            Set-OperatorPhase -Name $AclStage
            Set-PrivateFileAcl -Path $backup
            Assert-PrivateFileAcl -Path $backup
            [byte[]]$backupBytes = [IO.File]::ReadAllBytes($backup)
            try {
                $backupSha256 = Get-Sha256Hex -Bytes $backupBytes
            }
            finally {
                [Array]::Clear($backupBytes, 0, $backupBytes.Length)
            }
        }

        Set-OperatorPhase -Name $WriteStage
        [IO.File]::Move($temporary, $fullPath, $true)
        $destinationReplaced = $true

        Set-OperatorPhase -Name $AclStage
        Assert-PrivateFileAcl -Path $fullPath

        Set-OperatorPhase -Name $ReadbackStage
        $readback = [IO.File]::ReadAllText($fullPath, [Text.Encoding]::UTF8)
        if ($readback -cne $Text) {
            throw "The private file readback differs from the serialized bytes."
        }
        $readback = $null
        $success = $true
    }
    catch {
        $caught = $_
        $stageAtFailure = Get-OperatorPhase
        $cleanupErrorRecord = $null
        try {
            if (Test-Path -LiteralPath $temporary) {
                Remove-Item -LiteralPath $temporary -Force
            }
            if ($destinationReplaced) {
                if ($destinationExisted -and (Test-Path -LiteralPath $backup -PathType Leaf)) {
                    [IO.File]::Move($backup, $fullPath, $true)
                    Assert-PrivateFileAcl -Path $fullPath
                    [byte[]]$restoredBytes = [IO.File]::ReadAllBytes($fullPath)
                    try {
                        if ((Get-Sha256Hex -Bytes $restoredBytes) -cne $backupSha256) {
                            throw "The restored private file differs from the preserved original."
                        }
                    }
                    finally {
                        [Array]::Clear($restoredBytes, 0, $restoredBytes.Length)
                    }
                    $destinationRestored = $true
                }
                elseif (-not $destinationExisted -and (Test-Path -LiteralPath $fullPath)) {
                    Remove-Item -LiteralPath $fullPath -Force
                }
            }
            elseif ($destinationExisted) {
                $destinationRestored = Test-Path -LiteralPath $fullPath -PathType Leaf
            }
            if (Test-Path -LiteralPath $backup) {
                Remove-Item -LiteralPath $backup -Force
            }
        }
        catch {
            $cleanupErrorRecord = $_
        }
        $partialRemoved = (
            -not (Test-Path -LiteralPath $temporary) -and
            -not (Test-Path -LiteralPath $backup) -and
            $(if ($destinationExisted) {
                $destinationRestored -and (Test-Path -LiteralPath $fullPath -PathType Leaf)
            }
            else {
                -not (Test-Path -LiteralPath $fullPath)
            })
        )
        $code = if ($stageAtFailure -ceq $AclStage) { $AclFailureCode } else { "$($stageAtFailure)_FAILED" }
        Throw-OperatorStageFailure -ErrorRecord $caught -Code $code -Stage $stageAtFailure -PartialFileRemoved:$partialRemoved -CleanupErrorRecord $cleanupErrorRecord
    }
    finally {
        $Text = $null
        if (Test-Path -LiteralPath $temporary) {
            Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue
        }
        if ($success -and (Test-Path -LiteralPath $backup)) {
            Remove-Item -LiteralPath $backup -Force -ErrorAction SilentlyContinue
        }
    }
}

function ConvertTo-ConnectorVaultJson {
    param([Parameter(Mandatory = $true)][psobject]$Vault)
    Set-OperatorPhase -Name "CONNECTOR_VAULT_SERIALIZATION"
    $Vault | ConvertTo-Json -Depth 12
}

function Write-ConnectorVault {
    param([Parameter(Mandatory = $true)][psobject]$Vault)
    $json = $null
    try {
        $json = ConvertTo-ConnectorVaultJson -Vault $Vault
        Write-PrivateTextFile -Path (Get-ConnectorVaultPath) -Text ($json + [Environment]::NewLine)
        Set-OperatorPhase -Name "CONNECTOR_VAULT_READBACK"
        [void](Read-ConnectorVault)
    }
    finally {
        $json = $null
    }
}

function Assert-ConnectorVault {
    param(
        [Parameter(Mandatory = $true)][psobject]$Vault,
        [switch]$RequireOrigin
    )
    if ($Vault.schema_version -ne "pulsechain-external-observer-connector-vault@1.0.0") {
        throw "The connector vault schema is invalid."
    }
    if ($Vault.worker_name -ne "pulsechain-external-observer-grok-mcp") {
        throw "The connector vault Worker identity is invalid."
    }
    if ([string]$Vault.account_id -notmatch "^[0-9a-fA-F]{32}$") {
        throw "The connector vault account identity is invalid."
    }
    if (
        $Vault.source_branch -ne "external-observer-grok-mcp-r12d-windows-acl-repair-20260828" -or
        $Vault.source_commit -ne "ec70832c69f847ea413666de095ce3d56534ea28" -or
        $Vault.source_tree -ne "35e17b896403d02d160f3a4d902ea2e66845799c" -or
        $Vault.publication_mode -ne "DISABLED"
    ) {
        throw "The connector vault source or publication-mode identity is invalid."
    }
    if ($RequireOrigin -and [string]$Vault.worker_origin -notmatch "^https://pulsechain-external-observer-grok-mcp\.[a-z0-9-]+\.workers\.dev/?$") {
        throw "The connector vault Worker origin is invalid."
    }
    if ($RequireOrigin -and [string]$Vault.current_version_id -notmatch "^[0-9a-fA-F-]{36}$") {
        throw "The connector vault Worker version identity is invalid."
    }
    $definitions = @(Get-ConnectorDefinitions)
    $expected = @($definitions.observer_id | Sort-Object)
    $actual = @($Vault.tokens.PSObject.Properties.Name | Sort-Object)
    if (($expected -join [Environment]::NewLine) -ne ($actual -join [Environment]::NewLine)) {
        throw "The connector vault observer set is invalid."
    }
    foreach ($definition in $definitions) {
        $record = $Vault.tokens.($definition.observer_id)
        if ($record.secret_label -ne $definition.token_label) {
            throw "The connector vault secret-label map is invalid."
        }
        if ([string]::IsNullOrWhiteSpace([string]$record.ciphertext_base64)) {
            throw "The connector vault ciphertext is missing."
        }
    }
}

function Read-ConnectorVault {
    param([switch]$RequireOrigin)
    $path = Get-ConnectorVaultPath
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "The local connector vault is unavailable."
    }
    $vault = Get-Content -LiteralPath $path -Raw -Encoding utf8 | ConvertFrom-Json -Depth 20
    Assert-ConnectorVault -Vault $vault -RequireOrigin:$RequireOrigin
    $vault
}

function Get-ConnectorToken {
    param(
        [Parameter(Mandatory = $true)][psobject]$Vault,
        [Parameter(Mandatory = $true)][string]$ObserverId
    )
    $record = $Vault.tokens.$ObserverId
    if ($null -eq $record) {
        throw "The requested observer is not present in the connector vault."
    }
    Unprotect-ConnectorToken -CiphertextBase64 $record.ciphertext_base64
}

function Get-Sha256Hex {
    param([Parameter(Mandatory = $true)][byte[]]$Bytes)
    [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($Bytes)).ToLowerInvariant()
}
