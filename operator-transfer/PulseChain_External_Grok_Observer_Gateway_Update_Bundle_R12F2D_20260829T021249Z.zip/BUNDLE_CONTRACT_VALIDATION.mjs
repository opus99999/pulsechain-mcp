import { createHash } from "node:crypto";
import { lstatSync, readFileSync, readdirSync, statSync } from "node:fs";
import { basename, extname, join, relative, resolve, sep } from "node:path";

// These are the retained R12F runtime contract schemas. R12F1 changed only
// the producer labels; R12F2 restores exact producer/consumer agreement.
export const INVENTORY_SCHEMA = "pulsechain-external-observer-r12f-update-inventory@1.0.0";
export const SOURCE_MANIFEST_SCHEMA = "pulsechain-external-observer-r12f-source-manifest@1.0.0";
export const DEPLOYMENT_EXPECTATIONS_SCHEMA = "pulsechain-external-observer-r12f-update-expectations@1.0.0";

const COMMIT = /^[0-9a-f]{40}$/u;

function sha256(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

function listFiles(root) {
  const result = [];
  function visit(directory) {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const absolute = join(directory, entry.name);
      const info = lstatSync(absolute);
      if (info.isSymbolicLink()) throw new Error("BUNDLE_REPARSE_POINT_REJECTED");
      if (info.isDirectory()) visit(absolute);
      else if (info.isFile()) result.push(relative(root, absolute).split(sep).join("/"));
    }
  }
  visit(root);
  return result.sort();
}

function json(root, path) {
  try {
    return JSON.parse(readFileSync(join(root, path), "utf8"));
  } catch {
    return null;
  }
}

function assignment(script, name) {
  return script.match(new RegExp("^\\$" + name + ' = "([^"]*)"$', "mu"))?.[1] ?? null;
}

function escapeRegex(value) {
  return value.replace(/[.*+?^$()|[\]{}\\]/gu, "\\$&");
}

function comparisonLiteral(script, objectExpression) {
  return script.match(new RegExp(escapeRegex(objectExpression) + ' -(?:c)?ne "([^"]+)"', "u"))?.[1] ?? null;
}

function comparisonVariable(script, objectExpression) {
  return script.match(new RegExp(escapeRegex(objectExpression) + " -(?:c)?ne \\$([A-Za-z0-9_]+)", "u"))?.[1] ?? null;
}

function add(errors, code, detail) {
  if (!errors.some((entry) => entry.code === code && entry.detail === detail)) errors.push({ code, detail });
}

function inspectIntegrity(root, errors) {
  const files = listFiles(root);
  const checksumsText = readFileSync(join(root, "SHA256SUMS.txt"), "utf8");
  const checksumEntries = [];
  for (const line of checksumsText.trimEnd().split(/\r?\n/u)) {
    const match = /^([0-9a-f]{64})  ([A-Za-z0-9._/-]+)$/u.exec(line);
    if (!match) {
      add(errors, "BUNDLE_CHECKSUM_LINE_INVALID", line);
      continue;
    }
    checksumEntries.push({ sha256: match[1], path: match[2] });
  }
  const expectedChecksumPaths = files.filter((path) => !["SHA256SUMS.txt", "ARTIFACT_INVENTORY.json"].includes(path));
  if (JSON.stringify(checksumEntries.map((entry) => entry.path).sort()) !== JSON.stringify(expectedChecksumPaths)) {
    add(errors, "BUNDLE_CHECKSUM_FILE_SET_MISMATCH", "checksum file set");
  }
  for (const entry of checksumEntries) {
    try {
      if (sha256(readFileSync(join(root, entry.path))) !== entry.sha256) add(errors, "BUNDLE_CHECKSUM_MISMATCH", entry.path);
    } catch {
      add(errors, "BUNDLE_CHECKSUM_MISMATCH", entry.path);
    }
  }

  const inventory = json(root, "ARTIFACT_INVENTORY.json");
  if (!inventory) {
    add(errors, "BUNDLE_INVENTORY_INVALID", "malformed or missing inventory");
    return { files, inventory: null };
  }
  const expectedInventoryPaths = files.filter((path) => path !== "ARTIFACT_INVENTORY.json");
  const inventoryPaths = Array.isArray(inventory.artifacts) ? inventory.artifacts.map((entry) => entry.path).sort() : [];
  if (
    inventory.artifact_count_excluding_inventory !== expectedInventoryPaths.length ||
    inventoryPaths.length !== expectedInventoryPaths.length ||
    JSON.stringify(inventoryPaths) !== JSON.stringify(expectedInventoryPaths)
  ) {
    add(errors, "BUNDLE_INVENTORY_INVALID", "inventory file set");
  }
  for (const entry of inventory.artifacts ?? []) {
    try {
      const path = join(root, entry.path);
      if (statSync(path).size !== entry.byte_size || sha256(readFileSync(path)) !== entry.sha256) {
        add(errors, "BUNDLE_INVENTORY_IDENTITY_MISMATCH", entry.path);
      }
    } catch {
      add(errors, "BUNDLE_INVENTORY_IDENTITY_MISMATCH", entry.path);
    }
  }
  return { files, inventory };
}

export function inspectBundleContract(rootArgument) {
  const root = resolve(rootArgument);
  const errors = [];
  let script;
  try {
    script = readFileSync(join(root, "UPDATE_EXISTING_GATEWAY_R12F.ps1"), "utf8");
  } catch {
    return {
      result: "FAIL",
      first_failure_code: "BUNDLE_GOVERNANCE_FILE_MISSING",
      errors: [{ code: "BUNDLE_GOVERNANCE_FILE_MISSING", detail: "UPDATE_EXISTING_GATEWAY_R12F.ps1" }],
    };
  }

  const expectedFilename = assignment(script, "ExpectedBundleFilename");
  const expectedLeaf = expectedFilename ? basename(expectedFilename, extname(expectedFilename)) : null;
  if (!expectedLeaf || basename(root) !== expectedLeaf) {
    add(errors, "BUNDLE_DIRECTORY_IDENTITY_MISMATCH", basename(root) + " != " + expectedLeaf);
  }

  const integrity = inspectIntegrity(root, errors);
  const inventory = integrity.inventory;
  const source = json(root, "SOURCE_MANIFEST.json");
  const expectations = json(root, "DEPLOYMENT_EXPECTATIONS.json");
  const expectedInventorySchema = comparisonLiteral(script, "$inventory.schema_version");
  const expectedSourceSchema = comparisonLiteral(script, "$source.schema_version");
  const expectedExpectationsSchema = comparisonLiteral(script, "$expectations.schema_version");

  if (!inventory || inventory.schema_version !== expectedInventorySchema) {
    add(errors, "BUNDLE_INVENTORY_INVALID", String(inventory?.schema_version ?? "null") + " != " + expectedInventorySchema);
  }
  if (!source || source.schema_version !== expectedSourceSchema) {
    add(errors, "BUNDLE_SOURCE_MANIFEST_INVALID", String(source?.schema_version ?? "null") + " != " + expectedSourceSchema);
  }
  if (!expectations || expectations.schema_version !== expectedExpectationsSchema) {
    add(errors, "BUNDLE_DEPLOYMENT_EXPECTATIONS_INVALID", String(expectations?.schema_version ?? "null") + " != " + expectedExpectationsSchema);
  }

  const sourceParentVariable = comparisonVariable(script, "$source.source.parent");
  const deploymentParentVariable = comparisonVariable(script, "$expectations.source.parent");
  const expectedSourceParent = sourceParentVariable ? assignment(script, sourceParentVariable) : null;
  const expectedDeploymentParent = deploymentParentVariable ? assignment(script, deploymentParentVariable) : null;
  const actualSourceParent = source?.source?.parent ?? null;
  const actualDeploymentParent = expectations?.source?.parent ?? null;

  if (!COMMIT.test(actualSourceParent ?? "") || actualSourceParent !== expectedSourceParent) {
    add(errors, "BUNDLE_SOURCE_MANIFEST_INVALID", String(actualSourceParent) + " != " + expectedSourceParent);
  }
  if (
    deploymentParentVariable !== "ExpectedR12FSourceParent" ||
    !COMMIT.test(actualDeploymentParent ?? "") ||
    actualDeploymentParent !== expectedDeploymentParent
  ) {
    add(errors, "BUNDLE_DEPLOYMENT_EXPECTATIONS_INVALID", String(actualDeploymentParent) + " via " + deploymentParentVariable + " != " + expectedDeploymentParent);
  }

  return {
    result: errors.length ? "FAIL" : "PASS",
    first_failure_code: errors[0]?.code ?? null,
    errors,
    values: {
      root_leaf: basename(root),
      expected_leaf: expectedLeaf,
      expected_inventory_schema: expectedInventorySchema,
      actual_inventory_schema: inventory?.schema_version ?? null,
      expected_source_manifest_schema: expectedSourceSchema,
      actual_source_manifest_schema: source?.schema_version ?? null,
      expected_deployment_expectations_schema: expectedExpectationsSchema,
      actual_deployment_expectations_schema: expectations?.schema_version ?? null,
      source_parent_variable: sourceParentVariable,
      source_parent_expected: expectedSourceParent,
      source_parent_actual: actualSourceParent,
      deployment_parent_variable: deploymentParentVariable,
      deployment_parent_expected: expectedDeploymentParent,
      deployment_parent_actual: actualDeploymentParent,
    },
  };
}

export function assertBundleContract(root) {
  const result = inspectBundleContract(root);
  if (result.result !== "PASS") {
    const error = new Error(result.first_failure_code ?? "BUNDLE_CONTRACT_INVALID");
    error.contract = result;
    throw error;
  }
  return result;
}
