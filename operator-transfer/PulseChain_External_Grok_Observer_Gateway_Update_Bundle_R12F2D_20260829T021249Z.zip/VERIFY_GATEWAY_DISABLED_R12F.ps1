#Requires -Version 7.4

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [ValidatePattern("^https://pulsechain-external-observer-grok-mcp\.pulsechain-research-dade45b2\.workers\.dev/?$")]
    [string]$WorkerOrigin
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$VerbosePreference = "SilentlyContinue"
$DebugPreference = "SilentlyContinue"
$InformationPreference = "SilentlyContinue"

$BundleRoot = [IO.Path]::GetFullPath($PSScriptRoot)
. (Join-Path $BundleRoot "OPERATOR_COMMON.ps1")
Assert-WindowsOperator

$BridgeProtocol = "pulsechain-r12f-verifier-bridge@1.0.0"
$ExpectedWorkerOrigin = "https://pulsechain-external-observer-grok-mcp.pulsechain-research-dade45b2.workers.dev"
$ExpectedControlRoomOrigin = "https://pulsechain-research-control-room.brohexphiat.chatgpt.site"
$ExpectedAccountId = "dade45b2875ee5e98c74b5d06528cd9c"
$ExpectedVersionId = "e32f2b34-a572-404e-b969-44c0bf2c9088"
$ExpectedSourceBranch = "external-observer-grok-mcp-r12d-windows-acl-repair-20260828"
$ExpectedSourceCommit = "ec70832c69f847ea413666de095ce3d56534ea28"
$ExpectedSourceTree = "35e17b896403d02d160f3a4d902ea2e66845799c"
$R12FVerificationReportPath = Join-Path (Get-OperatorStateDirectory) "LOCAL_DISABLED_MODE_VERIFICATION_R12F.json"
$MaximumProtocolLineBytes = 4MB
$MaximumProtocolBytes = 8MB
$MaximumCapturedStderrBytes = 64KB
# The verifier can execute 55 sequential MCP requests plus 13 public-projection
# GETs before and 13 after: 81 * 60,000 ms = 4,860,000 ms. The 5,100,000 ms
# watchdog adds four minutes for framing, parsing, report serialization, and exit.
$NodeVerifierHardTimeoutMilliseconds = 5100000
$NodeExitGraceMilliseconds = 30000

if ($null -eq ("PulseChainR12FBoundedCapture" -as [type])) {
Add-Type -TypeDefinition @'
using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

public sealed class PulseChainR12FBoundedCapture : IDisposable
{
    private readonly object gate = new object();
    private readonly MemoryStream captured = new MemoryStream();
    private readonly int maximumBytes;
    private long totalBytes;
    private bool limitExceeded;

    public PulseChainR12FBoundedCapture(int maximumBytes)
    {
        if (maximumBytes < 1) throw new ArgumentOutOfRangeException(nameof(maximumBytes));
        this.maximumBytes = maximumBytes;
    }

    public async Task DrainAsync(Stream source)
    {
        byte[] buffer = new byte[4096];
        try
        {
            while (true)
            {
                int count = await source.ReadAsync(buffer, 0, buffer.Length).ConfigureAwait(false);
                if (count == 0) return;
                lock (gate)
                {
                    totalBytes += count;
                    int remaining = maximumBytes - checked((int)captured.Length);
                    int accepted = Math.Min(Math.Max(remaining, 0), count);
                    if (accepted > 0) captured.Write(buffer, 0, accepted);
                    if (accepted != count) limitExceeded = true;
                }
            }
        }
        finally
        {
            Array.Clear(buffer, 0, buffer.Length);
        }
    }

    public byte[] Snapshot()
    {
        lock (gate) return captured.ToArray();
    }

    public long TotalBytes
    {
        get { lock (gate) return totalBytes; }
    }

    public bool LimitExceeded
    {
        get { lock (gate) return limitExceeded; }
    }

    public void Dispose()
    {
        lock (gate)
        {
            byte[] buffer = captured.GetBuffer();
            Array.Clear(buffer, 0, buffer.Length);
            captured.Dispose();
        }
    }
}

public sealed class PulseChainR12FProcessWatchdog : IDisposable
{
    private readonly Process process;
    private readonly Timer timer;
    private int fired;

    public PulseChainR12FProcessWatchdog(Process process, int timeoutMilliseconds)
    {
        this.process = process ?? throw new ArgumentNullException(nameof(process));
        if (timeoutMilliseconds < 1) throw new ArgumentOutOfRangeException(nameof(timeoutMilliseconds));
        timer = new Timer(OnTimeout, null, timeoutMilliseconds, Timeout.Infinite);
    }

    private void OnTimeout(object state)
    {
        if (Interlocked.Exchange(ref fired, 1) != 0) return;
        try
        {
            if (!process.HasExited) process.Kill(true);
        }
        catch
        {
            // The launcher reports the bounded timeout; watchdog failures are never serialized.
        }
    }

    public bool Fired { get { return Volatile.Read(ref fired) != 0; } }

    public void Dispose()
    {
        timer.Dispose();
    }
}

public sealed class PulseChainR12FProtocolReader : IDisposable
{
    private readonly Stream source;
    private readonly byte[] buffer = new byte[8192];
    private int offset;
    private int count;
    private long totalBytes;

    public PulseChainR12FProtocolReader(Stream source)
    {
        this.source = source ?? throw new ArgumentNullException(nameof(source));
    }

    public byte[] ReadLine(int maximumLineBytes, long maximumTotalBytes)
    {
        if (maximumLineBytes < 1) throw new ArgumentOutOfRangeException(nameof(maximumLineBytes));
        if (maximumTotalBytes < 1) throw new ArgumentOutOfRangeException(nameof(maximumTotalBytes));
        using (MemoryStream line = new MemoryStream())
        {
            while (true)
            {
                if (offset == count)
                {
                    count = source.Read(buffer, 0, buffer.Length);
                    offset = 0;
                    if (count == 0)
                    {
                        if (line.Length == 0) return null;
                        throw new InvalidDataException("The Node verifier stdout ended with an incomplete protocol line.");
                    }
                }
                byte value = buffer[offset++];
                totalBytes += 1;
                if (totalBytes > maximumTotalBytes)
                    throw new InvalidDataException("The Node verifier stdout exceeded the total protocol byte limit.");
                if (value == 0x0A) break;
                if (line.Length >= maximumLineBytes)
                    throw new InvalidDataException("A Node verifier protocol line exceeded its byte limit.");
                line.WriteByte(value);
            }
            if (line.Length > 0)
            {
                byte[] body = line.GetBuffer();
                if (body[checked((int)line.Length - 1)] == 0x0D) line.SetLength(line.Length - 1);
            }
            return line.ToArray();
        }
    }

    public static bool ContainsSequence(byte[] bytes, byte[] sequence)
    {
        if (bytes == null) throw new ArgumentNullException(nameof(bytes));
        if (sequence == null || sequence.Length == 0 || bytes.Length < sequence.Length) return false;
        int lastStart = bytes.Length - sequence.Length;
        for (int start = 0; start <= lastStart; start += 1)
        {
            int offsetInSequence = 0;
            while (offsetInSequence < sequence.Length && bytes[start + offsetInSequence] == sequence[offsetInSequence])
                offsetInSequence += 1;
            if (offsetInSequence == sequence.Length) return true;
        }
        return false;
    }

    public void Dispose()
    {
        Array.Clear(buffer, 0, buffer.Length);
    }
}
'@ -Language CSharp -ErrorAction Stop
}

function Clear-ByteArray {
    param([AllowNull()][byte[]]$Bytes)
    if ($null -ne $Bytes) {
        [Array]::Clear($Bytes, 0, $Bytes.Length)
    }
}

function Test-ByteArraysEqual {
    param(
        [Parameter(Mandatory = $true)][byte[]]$Left,
        [Parameter(Mandatory = $true)][byte[]]$Right
    )
    if ($Left.Length -ne $Right.Length) {
        return $false
    }
    $difference = 0
    for ($index = 0; $index -lt $Left.Length; $index += 1) {
        $difference = $difference -bor ($Left[$index] -bxor $Right[$index])
    }
    $difference -eq 0
}

function Test-ContainsByteSequence {
    param(
        [Parameter(Mandatory = $true)][byte[]]$Bytes,
        [AllowNull()][byte[]]$Sequence
    )
    [PulseChainR12FProtocolReader]::ContainsSequence($Bytes, $Sequence)
}

function Assert-ConnectorTokenBytes {
    param([Parameter(Mandatory = $true)][byte[]]$Bytes)
    if ($Bytes.Length -ne 43) {
        throw "The decrypted connector credential length is invalid."
    }
    foreach ($value in $Bytes) {
        $allowed = (
            ($value -ge 0x41 -and $value -le 0x5A) -or
            ($value -ge 0x61 -and $value -le 0x7A) -or
            ($value -ge 0x30 -and $value -le 0x39) -or
            $value -eq 0x2D -or
            $value -eq 0x5F
        )
        if (-not $allowed) {
            throw "The decrypted connector credential format is invalid."
        }
    }
}

function New-ProtocolLineReader {
    param([Parameter(Mandatory = $true)][IO.Stream]$Stream)
    [PulseChainR12FProtocolReader]::new($Stream)
}

function Read-BoundedProtocolLine {
    param(
        [Parameter(Mandatory = $true)][PulseChainR12FProtocolReader]$Reader,
        [Parameter(Mandatory = $true)][int]$MaximumLineBytes,
        [Parameter(Mandatory = $true)][long]$MaximumTotalBytes
    )
    [byte[]]$bytes = $Reader.ReadLine($MaximumLineBytes, $MaximumTotalBytes)
    if ($null -eq $bytes) {
        return $null
    }
    return ,$bytes
}

function Assert-ExactProperties {
    param(
        [Parameter(Mandatory = $true)][psobject]$Value,
        [Parameter(Mandatory = $true)][string[]]$Expected
    )
    $actualNames = @($Value.PSObject.Properties.Name | Sort-Object)
    $expectedNames = @($Expected | Sort-Object)
    if (($actualNames -join "`n") -cne ($expectedNames -join "`n")) {
        throw "A Node verifier protocol message contained an unexpected property set."
    }
}

function Assert-RequiredProperties {
    param(
        [Parameter(Mandatory = $true)][psobject]$Value,
        [Parameter(Mandatory = $true)][string[]]$Required,
        [Parameter(Mandatory = $true)][string]$Context
    )
    $actualNames = @($Value.PSObject.Properties.Name)
    foreach ($name in $Required) {
        if ($actualNames -cnotcontains $name) {
            throw "The Node verifier $Context omitted a required property."
        }
    }
}

function Assert-FinalPassReport {
    param(
        [Parameter(Mandatory = $true)][psobject]$Report,
        [Parameter(Mandatory = $true)][Collections.Generic.List[object]]$ConnectorCompletions,
        [Parameter(Mandatory = $true)][object[]]$Definitions
    )
    Assert-RequiredProperties -Value $Report -Context "PASS report" -Required @(
        "schema_version",
        "generated_at_utc",
        "result",
        "release_critical",
        "critical_stop",
        "recommended_release_action",
        "worker_name",
        "worker_origin",
        "control_room_origin",
        "publication_mode",
        "publication_ready",
        "github_publication_transport",
        "mcp_protocol_version",
        "stage_timeout_ms",
        "verifier_retry_count",
        "connectors",
        "connector_stage_matrix",
        "control_room_upstream_unavailable_count",
        "external_upstream_blocker_only",
        "transport_audit",
        "system_wide_mutation_audit",
        "secrets_in_report"
    )
    if (
        [string]$Report.schema_version -cne "pulsechain-r12f-local-disabled-mode-verification@1.0.0" -or
        [string]::IsNullOrWhiteSpace([string]$Report.generated_at_utc) -or
        [string]$Report.result -cne "PASS" -or
        $Report.release_critical -isnot [bool] -or
        $Report.release_critical -ne $false -or
        $null -ne $Report.critical_stop -or
        [string]$Report.recommended_release_action -cne "R13_HANDOFF_READY" -or
        [string]$Report.worker_name -cne "pulsechain-external-observer-grok-mcp" -or
        ([string]$Report.worker_origin).TrimEnd("/") -cne $ExpectedWorkerOrigin -or
        ([string]$Report.control_room_origin).TrimEnd("/") -cne $ExpectedControlRoomOrigin -or
        [string]$Report.publication_mode -cne "DISABLED" -or
        $Report.publication_ready -isnot [bool] -or
        $Report.publication_ready -ne $false -or
        [string]$Report.github_publication_transport -cne "DEFERRED_WHILE_DISABLED" -or
        [string]$Report.mcp_protocol_version -cne "2025-06-18" -or
        [int64]$Report.stage_timeout_ms -ne 60000 -or
        $null -eq $Report.verifier_retry_count -or
        [int64]$Report.verifier_retry_count -ne 0 -or
        $null -eq $Report.control_room_upstream_unavailable_count -or
        [int64]$Report.control_room_upstream_unavailable_count -ne 0 -or
        $Report.external_upstream_blocker_only -isnot [bool] -or
        $Report.external_upstream_blocker_only -ne $false -or
        $null -eq $Report.secrets_in_report -or
        [int64]$Report.secrets_in_report -ne 0
    ) {
        throw "The Node verifier PASS report failed its required top-level invariants."
    }

    if ($Definitions.Count -ne 5 -or $ConnectorCompletions.Count -ne 5) {
        throw "The Node verifier PASS report lacks five governed connector completions."
    }
    $connectorSummaries = @($Report.connectors)
    if ($connectorSummaries.Count -ne 5) {
        throw "The Node verifier PASS report connector-summary count is invalid."
    }
    for ($index = 0; $index -lt 5; $index += 1) {
        $ordinal = $index + 1
        $definition = $Definitions[$index]
        $completion = $ConnectorCompletions[$index]
        $summary = $connectorSummaries[$index]
        Assert-RequiredProperties -Value $summary -Context "PASS connector summary" -Required @(
            "connector_id",
            "connector_ordinal",
            "path",
            "target_workstream",
            "result",
            "authentication_passed",
            "initialize_passed",
            "tools_list_passed",
            "session_id_present",
            "disabled_write_attempted"
        )
        if (
            [int]$completion.connector_ordinal -ne $ordinal -or
            [string]$completion.observer_id -cne [string]$definition.observer_id -or
            [string]$completion.result -cne "PASS" -or
            [int]$summary.connector_ordinal -ne $ordinal -or
            [string]$summary.connector_id -cne [string]$definition.observer_id -or
            [string]$summary.connector_id -cne [string]$completion.observer_id -or
            [string]$summary.path -cne [string]$definition.path -or
            [string]$summary.target_workstream -cne [string]$definition.target_workstream -or
            [string]$summary.result -cne "PASS" -or
            [string]$summary.result -cne [string]$completion.result -or
            $summary.authentication_passed -isnot [bool] -or
            $summary.authentication_passed -ne $true -or
            $summary.initialize_passed -isnot [bool] -or
            $summary.initialize_passed -ne $true -or
            $summary.tools_list_passed -isnot [bool] -or
            $summary.tools_list_passed -ne $true -or
            $summary.session_id_present -isnot [bool] -or
            $summary.disabled_write_attempted -isnot [bool] -or
            $summary.disabled_write_attempted -ne $true
        ) {
            throw "The Node verifier PASS connector summary does not match its governed completion."
        }
    }

    $matrix = @($Report.connector_stage_matrix)
    if ($matrix.Count -eq 0) {
        throw "The Node verifier PASS connector-stage matrix is empty."
    }
    $matrixOrdinals = [Collections.Generic.HashSet[int]]::new()
    foreach ($row in $matrix) {
        Assert-RequiredProperties -Value $row -Context "PASS matrix row" -Required @(
            "connector_id", "connector_ordinal", "stage", "result"
        )
        $rowOrdinal = [int]$row.connector_ordinal
        $rowDefinition = if ($rowOrdinal -ge 1 -and $rowOrdinal -le 5) {
            $Definitions[$rowOrdinal - 1]
        }
        else {
            $null
        }
        if (
            $rowOrdinal -lt 1 -or
            $rowOrdinal -gt 5 -or
            $null -eq $rowDefinition -or
            [string]$row.connector_id -cne [string]$rowDefinition.observer_id -or
            [string]::IsNullOrWhiteSpace([string]$row.stage) -or
            [string]$row.result -cne "PASS"
        ) {
            throw "The Node verifier PASS connector-stage matrix is inconsistent."
        }
        [void]$matrixOrdinals.Add($rowOrdinal)
    }
    if ($matrixOrdinals.Count -ne 5) {
        throw "The Node verifier PASS connector-stage matrix omits a connector."
    }

    Assert-RequiredProperties -Value $Report.transport_audit -Context "PASS transport audit" -Required @(
        "api_github_request_count",
        "github_transport_constructor_count",
        "publication_mutation_count"
    )
    if (
        $null -eq $Report.transport_audit.api_github_request_count -or
        [int64]$Report.transport_audit.api_github_request_count -ne 0 -or
        $null -eq $Report.transport_audit.github_transport_constructor_count -or
        [int64]$Report.transport_audit.github_transport_constructor_count -ne 0 -or
        $null -eq $Report.transport_audit.publication_mutation_count -or
        [int64]$Report.transport_audit.publication_mutation_count -ne 0
    ) {
        throw "The Node verifier PASS transport audit contains a forbidden mutation transport."
    }

    Assert-RequiredProperties -Value $Report.system_wide_mutation_audit -Context "PASS mutation audit" -Required @("result")
    if ([string]$Report.system_wide_mutation_audit.result -cne "UNCHANGED") {
        throw "The Node verifier PASS mutation audit is not unchanged."
    }
}

function Assert-NoSecretShapedText {
    param([Parameter(Mandatory = $true)][string]$Text)
    # This governed public observation ID is exactly 43 base64url-alphabet bytes;
    # remove only that fixed nonsecret value before applying the token-shape gate.
    $textToScan = $Text.Replace(
        "grok-infrastructure-incidents-r12c-disabled",
        "[FIXED_PUBLIC_OBSERVATION_ID]"
    )
    $patterns = @(
        "(?i)\bAuthorization\s*[:=]\s*(?:Bearer|Basic)\s+",
        "(?i)\bBearer\s+[A-Za-z0-9._~-]+",
        '"(?:token|ciphertext_base64|authorization|cookie)"\s*:',
        "(?<![A-Za-z0-9_-])[A-Za-z0-9_-]{43}(?![A-Za-z0-9_-])",
        "(?i)\b(?:gh[opsu]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b"
    )
    foreach ($pattern in $patterns) {
        if ([Text.RegularExpressions.Regex]::IsMatch(
            $textToScan,
            $pattern,
            [Text.RegularExpressions.RegexOptions]::CultureInvariant
        )) {
            throw "Secret-shaped material was present in Node verifier protocol output."
        }
    }
}

function ConvertFrom-VerifiedProtocolLine {
    param(
        [Parameter(Mandatory = $true)][byte[]]$Bytes,
        [AllowNull()][byte[]]$CurrentCredentialBytes
    )
    if (Test-ContainsByteSequence -Bytes $Bytes -Sequence $CurrentCredentialBytes) {
        throw "A connector credential was present in Node verifier stdout."
    }
    $strictUtf8 = [Text.UTF8Encoding]::new($false, $true)
    $text = $strictUtf8.GetString($Bytes)
    Assert-NoSecretShapedText -Text $text
    try {
        $value = $text | ConvertFrom-Json -Depth 100
    }
    catch {
        throw "A Node verifier protocol line was not valid JSON."
    }
    if ($null -eq $value -or $value -isnot [psobject]) {
        throw "A Node verifier protocol line was not a JSON object."
    }
    $value
}

function Assert-StderrEmptyAndSecretFree {
    param(
        [Parameter(Mandatory = $true)][PulseChainR12FBoundedCapture]$Capture,
        [AllowNull()][byte[]]$CurrentCredentialBytes
    )
    [byte[]]$snapshot = $null
    try {
        $snapshot = $Capture.Snapshot()
        if (Test-ContainsByteSequence -Bytes $snapshot -Sequence $CurrentCredentialBytes) {
            throw "A connector credential was present in Node verifier stderr."
        }
        if ($Capture.LimitExceeded) {
            throw "The Node verifier stderr exceeded its byte limit."
        }
        if ($Capture.TotalBytes -ne 0) {
            throw "The Node verifier wrote forbidden stderr output."
        }
    }
    finally {
        Clear-ByteArray -Bytes $snapshot
    }
}

function Assert-NormalNonElevatedWindowsProcess {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    try {
        $principal = [Security.Principal.WindowsPrincipal]::new($identity)
        if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
            throw "The governed verifier must run in a normal non-elevated Windows session."
        }
    }
    finally {
        $identity.Dispose()
    }
}

function Assert-ExactFinalizedVault {
    param([Parameter(Mandatory = $true)][psobject]$Vault)
    if (
        $Vault.worker_name -cne "pulsechain-external-observer-grok-mcp" -or
        ([string]$Vault.account_id).ToLowerInvariant() -cne $ExpectedAccountId -or
        ([string]$Vault.worker_origin).TrimEnd("/") -cne $ExpectedWorkerOrigin -or
        ([string]$Vault.current_version_id).ToLowerInvariant() -cne $ExpectedVersionId -or
        $Vault.source_branch -cne $ExpectedSourceBranch -or
        ([string]$Vault.source_commit).ToLowerInvariant() -cne $ExpectedSourceCommit -or
        ([string]$Vault.source_tree).ToLowerInvariant() -cne $ExpectedSourceTree -or
        $Vault.publication_mode -cne "DISABLED" -or
        [string]::IsNullOrWhiteSpace([string]$Vault.created_at_utc) -or
        [string]::IsNullOrWhiteSpace([string]$Vault.deployed_at_utc)
    ) {
        throw "The connector vault does not match the exact finalized R12D state."
    }
}

function Write-CredentialFrame {
    param(
        [Parameter(Mandatory = $true)][IO.Stream]$Stream,
        [Parameter(Mandatory = $true)][int]$Ordinal,
        [Parameter(Mandatory = $true)][byte[]]$CredentialBytes
    )
    if ($Ordinal -lt 1 -or $Ordinal -gt 5) {
        throw "The requested connector ordinal is invalid."
    }
    Assert-ConnectorTokenBytes -Bytes $CredentialBytes
    [byte[]]$header = @(0x52, 0x31, 0x32, 0x46, 0x01, [byte]$Ordinal, 0x2B, 0x00)
    try {
        $Stream.Write($header, 0, $header.Length)
        $Stream.Write($CredentialBytes, 0, $CredentialBytes.Length)
        $Stream.Flush()
    }
    finally {
        Clear-ByteArray -Bytes $header
    }
}

$vault = $null
$vaultPath = $null
[byte[]]$vaultBytesBefore = $null
[byte[]]$vaultBytesAfter = $null
[byte[]]$currentCredentialBytes = $null
$nodeProcess = $null
$stderrCapture = $null
$stderrTask = $null
$watchdog = $null
$reader = $null
$finalReport = $null
$safeFailureReport = $null
$failureCode = "NODE_VERIFIER_BRIDGE_FAILED"
$failureStage = "INITIAL_VALIDATION"
$currentOrdinal = $null
$currentObserverId = $null
$connectorCompletions = [Collections.Generic.List[object]]::new()
$stdinClosed = $false

try {
    Assert-NormalNonElevatedWindowsProcess
    $failureStage = "CONNECTOR_VAULT_VALIDATION"
    $vaultPath = Get-ConnectorVaultPath
    Assert-PrivateFileAcl -Path $vaultPath
    $vaultBytesBefore = [IO.File]::ReadAllBytes($vaultPath)
    $vault = Read-ConnectorVault -RequireOrigin
    Assert-ExactFinalizedVault -Vault $vault
    if ([string]::IsNullOrWhiteSpace($WorkerOrigin)) {
        $WorkerOrigin = $ExpectedWorkerOrigin
    }
    $WorkerOrigin = $WorkerOrigin.TrimEnd("/")
    if (
        $WorkerOrigin -cne $ExpectedWorkerOrigin -or
        $WorkerOrigin -cne ([string]$vault.worker_origin).TrimEnd("/")
    ) {
        throw "The requested Worker origin does not match the exact fixed origin and finalized vault."
    }

    $failureStage = "NODE_VERIFIER_VALIDATION"
    $nodeCommand = Get-Command node -CommandType Application -ErrorAction Stop | Select-Object -First 1
    $nodePath = [IO.Path]::GetFullPath([string]$nodeCommand.Source)
    $nodeVerifierPath = [IO.Path]::GetFullPath((Join-Path $BundleRoot "VERIFY_GATEWAY_DISABLED_R12F.mjs"))
    if (-not (Test-Path -LiteralPath $nodeVerifierPath -PathType Leaf)) {
        throw "The governed Node verifier is unavailable."
    }

    $startInfo = [Diagnostics.ProcessStartInfo]::new()
    $startInfo.FileName = $nodePath
    [void]$startInfo.ArgumentList.Add($nodeVerifierPath)
    $startInfo.WorkingDirectory = $BundleRoot
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardInput = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $minimalEnvironment = [ordered]@{}
    foreach ($name in @("SystemRoot", "WINDIR", "TEMP", "TMP")) {
        $value = [Environment]::GetEnvironmentVariable($name)
        if (-not [string]::IsNullOrWhiteSpace($value)) {
            $minimalEnvironment[$name] = $value
        }
    }
    $startInfo.Environment.Clear()
    foreach ($entry in $minimalEnvironment.GetEnumerator()) {
        $startInfo.Environment[$entry.Key] = [string]$entry.Value
    }

    $failureStage = "NODE_VERIFIER_START"
    $nodeProcess = [Diagnostics.Process]::new()
    $nodeProcess.StartInfo = $startInfo
    if (-not $nodeProcess.Start()) {
        throw "The governed Node verifier did not start."
    }
    $stderrCapture = [PulseChainR12FBoundedCapture]::new($MaximumCapturedStderrBytes)
    $stderrTask = $stderrCapture.DrainAsync($nodeProcess.StandardError.BaseStream)
    $watchdog = [PulseChainR12FProcessWatchdog]::new($nodeProcess, $NodeVerifierHardTimeoutMilliseconds)
    $reader = New-ProtocolLineReader -Stream $nodeProcess.StandardOutput.BaseStream
    $definitions = @(Get-ConnectorDefinitions)
    if ($definitions.Count -ne 5) {
        throw "The fixed connector definition count is invalid."
    }

    $expectedRequestOrdinal = 1
    $awaitingCompletion = $false
    $protocolComplete = $false
    while (-not $protocolComplete) {
        $failureStage = if ($awaitingCompletion) { "CONNECTOR_VERIFICATION" } else { "NODE_VERIFIER_PROTOCOL" }
        [byte[]]$lineBytes = $null
        try {
            $lineBytes = Read-BoundedProtocolLine -Reader $reader -MaximumLineBytes $MaximumProtocolLineBytes -MaximumTotalBytes $MaximumProtocolBytes
            if ($null -eq $lineBytes) {
                throw "The Node verifier stdout ended before the final report."
            }
            Assert-StderrEmptyAndSecretFree -Capture $stderrCapture -CurrentCredentialBytes $currentCredentialBytes
            $message = ConvertFrom-VerifiedProtocolLine -Bytes $lineBytes -CurrentCredentialBytes $currentCredentialBytes
        }
        finally {
            Clear-ByteArray -Bytes $lineBytes
        }

        if ([string]$message.protocol -cne $BridgeProtocol) {
            throw "The Node verifier protocol identity is invalid."
        }

        switch ([string]$message.type) {
            "credential_request" {
                Assert-ExactProperties -Value $message -Expected @("protocol", "type", "connector_ordinal", "observer_id")
                if ($awaitingCompletion -or $null -ne $currentCredentialBytes) {
                    throw "The Node verifier requested overlapping connector credentials."
                }
                $ordinal = [int]$message.connector_ordinal
                if ($ordinal -ne $expectedRequestOrdinal -or $ordinal -lt 1 -or $ordinal -gt 5) {
                    throw "The Node verifier requested a credential out of order."
                }
                $definition = $definitions[$ordinal - 1]
                if ([string]$message.observer_id -cne [string]$definition.observer_id) {
                    $failureCode = "CROSS_OBSERVER_IDENTITY_EXPOSURE"
                    throw "The Node verifier credential request crossed observer identity."
                }

                $failureStage = "CURRENT_USER_DPAPI_DECRYPT"
                $record = $vault.tokens.($definition.observer_id)
                [byte[]]$cipherBytes = $null
                [byte[]]$entropyBytes = $null
                try {
                    $cipherBytes = [Convert]::FromBase64String([string]$record.ciphertext_base64)
                    $entropyBytes = Get-DpapiEntropy
                    $currentCredentialBytes = [Security.Cryptography.ProtectedData]::Unprotect(
                        $cipherBytes,
                        $entropyBytes,
                        [Security.Cryptography.DataProtectionScope]::CurrentUser
                    )
                    Assert-ConnectorTokenBytes -Bytes $currentCredentialBytes
                    $failureStage = "CREDENTIAL_STDIN_HANDOFF"
                    Write-CredentialFrame -Stream $nodeProcess.StandardInput.BaseStream -Ordinal $ordinal -CredentialBytes $currentCredentialBytes
                    if ($ordinal -eq 5) {
                        $nodeProcess.StandardInput.Close()
                        $stdinClosed = $true
                    }
                }
                finally {
                    Clear-ByteArray -Bytes $cipherBytes
                    Clear-ByteArray -Bytes $entropyBytes
                }
                $currentOrdinal = $ordinal
                $currentObserverId = [string]$definition.observer_id
                $awaitingCompletion = $true
            }
            "connector_complete" {
                Assert-ExactProperties -Value $message -Expected @("protocol", "type", "connector_ordinal", "observer_id", "result")
                if (-not $awaitingCompletion -or $null -eq $currentCredentialBytes) {
                    throw "The Node verifier completed a connector without an active credential."
                }
                if (
                    [int]$message.connector_ordinal -ne [int]$currentOrdinal -or
                    [string]$message.observer_id -cne [string]$currentObserverId
                ) {
                    $failureCode = "CROSS_OBSERVER_IDENTITY_EXPOSURE"
                    throw "The Node verifier completion crossed observer identity."
                }
                if ([string]$message.result -cnotin @("PASS", "FAIL")) {
                    throw "The Node verifier connector result is invalid."
                }
                [void]$connectorCompletions.Add([pscustomobject][ordered]@{
                    connector_ordinal = [int]$currentOrdinal
                    observer_id = [string]$currentObserverId
                    result = [string]$message.result
                })
                if ([int]$currentOrdinal -lt 5) {
                    Clear-ByteArray -Bytes $currentCredentialBytes
                    $currentCredentialBytes = $null
                }
                $expectedRequestOrdinal += 1
                $awaitingCompletion = $false
                $currentOrdinal = $null
                $currentObserverId = $null
            }
            "final_report" {
                Assert-ExactProperties -Value $message -Expected @("protocol", "type", "report")
                if ($null -eq $message.report -or [string]$message.report.result -cnotin @("PASS", "FAIL", "SECURITY_STOP")) {
                    throw "The Node verifier final report result is invalid."
                }
                $normalCompletion = (
                    -not $awaitingCompletion -and
                    $connectorCompletions.Count -eq 5 -and
                    $expectedRequestOrdinal -eq 6
                )
                $securityStopCompletion = (
                    -not $awaitingCompletion -and
                    [string]$message.report.result -ceq "SECURITY_STOP" -and
                    $message.report.release_critical -eq $true -and
                    $connectorCompletions.Count -ge 1 -and
                    $connectorCompletions.Count -le 5
                )
                $reportHasError = $message.report.PSObject.Properties.Name -contains "error"
                $processFailureCompletion = (
                    [string]$message.report.result -ceq "FAIL" -and
                    $reportHasError -and
                    [string]$message.report.error -ceq "VERIFIER_PROCESS_FAILED_CLOSED"
                )
                if (-not $normalCompletion -and -not $securityStopCompletion -and -not $processFailureCompletion) {
                    throw "The Node verifier returned a final report before a permitted terminal state."
                }
                if ($normalCompletion -and $null -eq $currentCredentialBytes) {
                    throw "The normal final report was not scanned against the fifth connector credential."
                }
                if ([string]$message.report.result -ceq "PASS") {
                    Assert-FinalPassReport -Report $message.report -ConnectorCompletions $connectorCompletions -Definitions $definitions
                }
                Clear-ByteArray -Bytes $currentCredentialBytes
                $currentCredentialBytes = $null
                $awaitingCompletion = $false
                $currentOrdinal = $null
                $currentObserverId = $null
                $finalReport = $message.report
                $protocolComplete = $true
            }
            default {
                throw "The Node verifier emitted an unknown protocol message."
            }
        }
    }

    $failureStage = "NODE_VERIFIER_EXIT"
    if (-not $nodeProcess.WaitForExit($NodeExitGraceMilliseconds)) {
        $nodeProcess.Kill($true)
        throw "The Node verifier did not exit after its final report."
    }
    $stderrTask.GetAwaiter().GetResult()
    Assert-StderrEmptyAndSecretFree -Capture $stderrCapture -CurrentCredentialBytes $null
    [byte[]]$trailingLine = $null
    try {
        $trailingLine = Read-BoundedProtocolLine -Reader $reader -MaximumLineBytes $MaximumProtocolLineBytes -MaximumTotalBytes $MaximumProtocolBytes
        if ($null -ne $trailingLine) {
            throw "The Node verifier emitted output after its final report."
        }
    }
    finally {
        Clear-ByteArray -Bytes $trailingLine
    }
    if ($watchdog.Fired) {
        $failureCode = "NODE_VERIFIER_TIMEOUT"
        throw "The Node verifier exceeded its hard process deadline."
    }
    $expectedExitCode = switch ([string]$finalReport.result) {
        "PASS" { 0 }
        "FAIL" { 1 }
        "SECURITY_STOP" { 2 }
        default { -1 }
    }
    if ($nodeProcess.ExitCode -ne $expectedExitCode) {
        throw "The Node verifier process exit code did not match its final result."
    }

    $failureStage = "CONNECTOR_VAULT_PRESERVATION"
    Assert-PrivateFileAcl -Path $vaultPath
    $vaultBytesAfter = [IO.File]::ReadAllBytes($vaultPath)
    if (-not (Test-ByteArraysEqual -Left $vaultBytesBefore -Right $vaultBytesAfter)) {
        $failureCode = "CONNECTOR_VAULT_MUTATION_DETECTED"
        throw "The finalized connector vault changed during verification."
    }
}
catch {
    $caught = $_
    if ($failureCode -eq "NODE_VERIFIER_BRIDGE_FAILED") {
        if ($watchdog -and $watchdog.Fired) {
            $failureCode = "NODE_VERIFIER_TIMEOUT"
        }
        elseif ($caught.Exception.Message -match "credential was present|Secret-shaped material") {
            $failureCode = "SECRET_EXPOSURE_DETECTED"
        }
        elseif ($failureStage -eq "CONNECTOR_VAULT_PRESERVATION") {
            $failureCode = "CONNECTOR_VAULT_MUTATION_DETECTED"
        }
        elseif ($failureStage -like "NODE_VERIFIER_PROTOCOL*") {
            $failureCode = "NODE_VERIFIER_PROTOCOL_FAILED"
        }
    }
    if ($null -ne $nodeProcess) {
        try {
            if (-not $nodeProcess.HasExited) {
                $nodeProcess.Kill($true)
            }
            [void]$nodeProcess.WaitForExit(5000)
        }
        catch {
            # No process exception detail is allowed to replace the primary stage failure.
        }
    }
    if ($null -ne $vaultBytesBefore -and $null -ne $vaultPath) {
        try {
            Assert-PrivateFileAcl -Path $vaultPath
            Clear-ByteArray -Bytes $vaultBytesAfter
            $vaultBytesAfter = [IO.File]::ReadAllBytes($vaultPath)
            if (-not (Test-ByteArraysEqual -Left $vaultBytesBefore -Right $vaultBytesAfter)) {
                throw "The finalized connector vault changed during failed verification."
            }
        }
        catch {
            $failureCode = "CONNECTOR_VAULT_MUTATION_DETECTED"
            $failureStage = "CONNECTOR_VAULT_PRESERVATION"
        }
    }
    $bridgeFailureIsReleaseCritical = $failureCode -cin @(
        "SECRET_EXPOSURE_DETECTED",
        "CROSS_OBSERVER_IDENTITY_EXPOSURE",
        "CONNECTOR_VAULT_MUTATION_DETECTED"
    )
    $safeFailureReport = [pscustomobject][ordered]@{
        schema_version = "pulsechain-r12f-node-verifier-bridge-failure@1.0.0"
        generated_at_utc = [DateTime]::UtcNow.ToString("o")
        result = "FAIL"
        error = $failureCode
        release_critical = $bridgeFailureIsReleaseCritical
        external_upstream_blocker_only = $false
        recommended_release_action = if ($bridgeFailureIsReleaseCritical) {
            "ROLLBACK_ONLY_IF_SEPARATELY_AUTHORIZED"
        }
        else {
            "PRESERVE_DEPLOYED_R12F_REPORT_VERIFICATION_FAILURE"
        }
        failure = [pscustomobject][ordered]@{
            stage = $failureStage
            connector_ordinal = $currentOrdinal
            connector_id = $currentObserverId
            exception_class = $caught.Exception.GetType().FullName
            sanitized_exception_message = ConvertTo-SanitizedOperatorText -Value $caught.Exception.Message
            timeout_state = ($failureCode -ceq "NODE_VERIFIER_TIMEOUT")
        }
        connector_completions = @($connectorCompletions)
        publication_mode = "DISABLED"
        disabled_write_attempted = $null
        secrets_in_report = 0
    }
}
finally {
    Clear-ByteArray -Bytes $currentCredentialBytes
    $currentCredentialBytes = $null
    if ($null -ne $nodeProcess) {
        if (-not $stdinClosed) {
            try { $nodeProcess.StandardInput.Close() } catch {}
        }
        if ($null -ne $stderrTask) {
            try { $stderrTask.GetAwaiter().GetResult() } catch {}
        }
    }
    if ($null -ne $watchdog) {
        $watchdog.Dispose()
    }
    if ($null -ne $reader) {
        $reader.Dispose()
    }
    if ($null -ne $stderrCapture) {
        $stderrCapture.Dispose()
    }
    if ($null -ne $nodeProcess) {
        $nodeProcess.Dispose()
    }

    Clear-ByteArray -Bytes $vaultBytesAfter
    Clear-ByteArray -Bytes $vaultBytesBefore
    $vaultBytesAfter = $null
    $vaultBytesBefore = $null
    $vault = $null

    $reportToWrite = if ($null -ne $safeFailureReport) { $safeFailureReport } else { $finalReport }
    if ($null -ne $reportToWrite) {
        $reportJson = $null
        try {
            $reportJson = $reportToWrite | ConvertTo-Json -Depth 100
            Assert-NoSecretShapedText -Text $reportJson
            Write-PrivateTextFile -Path $R12FVerificationReportPath -Text ($reportJson + [Environment]::NewLine) -WriteStage "R12F_VERIFICATION_REPORT_WRITE" -AclStage "R12F_VERIFICATION_REPORT_ACL" -ReadbackStage "R12F_VERIFICATION_REPORT_READBACK" -AclFailureCode "R12F_VERIFICATION_REPORT_ACL_FAILED"
        }
        finally {
            $reportJson = $null
        }
    }
}

if ($null -ne $safeFailureReport) {
    $global:LASTEXITCODE = if ($safeFailureReport.release_critical) { 2 } else { 1 }
    Write-Output "VERIFICATION_STATUS=FAIL"
    return
}
if ($finalReport.result -cne "PASS") {
    $global:LASTEXITCODE = if ($finalReport.result -ceq "SECURITY_STOP") { 2 } else { 1 }
    Write-Output "VERIFICATION_STATUS=FAIL"
    return
}
$global:LASTEXITCODE = 0
Write-Output "VERIFICATION_STATUS=PASS"
