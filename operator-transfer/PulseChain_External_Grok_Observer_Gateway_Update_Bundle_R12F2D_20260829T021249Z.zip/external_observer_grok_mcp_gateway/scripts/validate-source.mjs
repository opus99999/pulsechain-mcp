import { readFile, readdir } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { CONNECTORS, PUBLICATION_MODE, toolsFor } from "../src/contracts.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const forbiddenLiteral = /(?:ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN (?:RSA )?PRIVATE KEY-----\s+[A-Za-z0-9+/=\s]{64,}-----END (?:RSA )?PRIVATE KEY-----|AKIA[0-9A-Z]{16})/u;
async function files(directory) {
  const out = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const absolute = path.join(directory, entry.name);
    if (entry.isDirectory()) out.push(...await files(absolute)); else out.push(absolute);
  }
  return out;
}
for (const file of await files(root)) {
  if (file.includes(`${path.sep}node_modules${path.sep}`)) continue;
  if (file.includes(`${path.sep}tests${path.sep}`)) continue;
  if (file === fileURLToPath(import.meta.url)) continue;
  if (forbiddenLiteral.test(await readFile(file, "utf8"))) throw new Error(`Secret-pattern literal found in ${path.relative(root, file)}`);
}
const forbiddenSchemaKeys = new Set(["observer_id", "repository", "workflow", "issue-title prefix", "ledger path", "github credential", "connector credential", "publication mode"]);
if (PUBLICATION_MODE !== "DISABLED") throw new Error("Gateway source default publication mode is not fail-closed");
for (const connector of CONNECTORS) {
  const tools = toolsFor(connector);
  if (tools.length !== 4 || tools[0].name !== connector.publishTool) throw new Error("Connector tool set is invalid");
  const encoded = JSON.stringify(tools[0].inputSchema).toLowerCase();
  for (const key of forbiddenSchemaKeys) if (encoded.includes(key)) throw new Error(`Forbidden model schema term: ${key}`);
  for (const foreign of CONNECTORS) if (foreign !== connector && tools.some((tool) => tool.name === foreign.publishTool)) throw new Error("Cross-connector publish discovery detected");
}
console.log("gateway source validation: PASS");
