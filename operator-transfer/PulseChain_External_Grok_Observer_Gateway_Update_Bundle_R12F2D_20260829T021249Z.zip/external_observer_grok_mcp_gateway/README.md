# PulseChain external-observer Grok remote MCP gateway

This isolated Cloudflare Worker-compatible service implements five stateless Streamable HTTP MCP connector paths. Each path is separately authenticated and exposes exactly one observer-specific publish tool plus three bounded public read tools. Connector identity is selected from the request path and injected server-side before strict observation validation.

R12C is fail-closed with `PUBLICATION_MODE=DISABLED`. In that mode valid publish calls return `PUBLICATION_MODE_DISABLED`, all publication receipt identities are null, and the gateway never reads a GitHub credential, constructs a GitHub transport, creates an issue, polls a receipt, runs a workflow, or mutates a ledger pointer. The five connector authentication secrets are the only secrets required for a disabled deployment.

`SYNTHETIC_ONLY` and `PROVISIONAL_LIVE` remain unavailable until a separate provider configuration change supplies one complete approved GitHub credential method and a fresh readiness check passes. The preferred method is the complete GitHub App label set. The fine-grained issues token is the approved fallback. When both complete methods are present the App is selected; a partial App set, including a partial App set mixed with the fallback token, fails closed with `GITHUB_PUBLICATION_CREDENTIAL_REQUIRED`. Publication mode is server configuration and cannot be selected by a request or Grok model. No automatic mode promotion exists.

## Secret labels

- `GROK_MCP_TOKEN_X_PROTOCOL`
- `GROK_MCP_TOKEN_INFRASTRUCTURE_INCIDENTS`
- `GROK_MCP_TOKEN_MARKET_LIQUIDITY`
- `GROK_MCP_TOKEN_IDENTITY_EVIDENCE`
- `GROK_MCP_TOKEN_RED_TEAM`
- Later writable-mode preferred GitHub App: `EXTERNAL_OBSERVER_GITHUB_APP_ID`, `EXTERNAL_OBSERVER_GITHUB_INSTALLATION_ID`, `EXTERNAL_OBSERVER_GITHUB_PRIVATE_KEY`
- Later writable-mode approved fallback: `EXTERNAL_OBSERVER_GITHUB_ISSUES_TOKEN`

Only the five connector tokens are bound during the R12C disabled deployment. GitHub credential labels are deferred to a separately authorized writable-mode binding release. Secret values must be entered only in the isolated hosting provider and the matching Grok connector configuration. They must never be committed, logged, described in tool schemas, or copied into a checkpoint.

## Local gate

Run `npm run validate` from this directory. The suite uses invented data and no network writes.
