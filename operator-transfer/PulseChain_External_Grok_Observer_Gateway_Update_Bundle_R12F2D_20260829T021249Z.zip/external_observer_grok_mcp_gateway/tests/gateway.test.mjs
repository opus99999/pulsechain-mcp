import assert from "node:assert/strict";
import test from "node:test";
import { createHash } from "node:crypto";
import { CONNECTORS, DISABLED_CODE, canonicalJson, discoveryFingerprint, toolsFor } from "../src/contracts.mjs";
import { GITHUB_CREDENTIAL_METHOD, GITHUB_CREDENTIAL_REQUIRED, selectGitHubCredentialMethod } from "../src/github-app.mjs";
import { createGateway } from "../src/worker.mjs";

const TOKENS = Object.fromEntries(CONNECTORS.map((connector, index) => [connector.tokenLabel, `r12-test-token-${index}-abcdefghijklmnopqrstuvwxyz`]));
const ENV = { ...TOKENS, PUBLICATION_MODE: "DISABLED", CONTROL_ROOM_ORIGIN: "https://pulsechain-research-control-room.brohexphiat.chatgpt.site" };
const APP_LABELS = ["EXTERNAL_OBSERVER_GITHUB_APP_ID", "EXTERNAL_OBSERVER_GITHUB_INSTALLATION_ID", "EXTERNAL_OBSERVER_GITHUB_PRIVATE_KEY"];
const APP_FIXTURE = {
  EXTERNAL_OBSERVER_GITHUB_APP_ID: "123456",
  EXTERNAL_OBSERVER_GITHUB_INSTALLATION_ID: "654321",
  EXTERNAL_OBSERVER_GITHUB_PRIVATE_KEY: `-----BEGIN PRIVATE KEY-----\n${"A".repeat(96)}\n-----END PRIVATE KEY-----`,
};
const TOKEN_FIXTURE = { EXTERNAL_OBSERVER_GITHUB_ISSUES_TOKEN: "r12c_synthetic_issues_fixture_1234567890" };
const SYNTHETIC_GITHUB_TOKEN_PATTERN = ["gh", "p_", "abcdefghijklmnopqrstuvwxyz", "1234567890"].join("");
const baseObservation = {
  schema_version: "pulsechain-external-observation@1.0.0",
  observation_id: "synthetic-r12-disabled-00001",
  generated_at_utc: "2026-08-27T20:00:00Z",
  observed_window: { from_utc: "2026-08-27T19:55:00Z", to_utc: "2026-08-27T20:00:00Z" },
  source_class: "PUBLIC_SECONDARY_SOURCE",
  source_records: [{ url: "https://example.com/synthetic-r12", source_id: "synthetic-r12-source", author_or_domain: "example.com", published_at_utc: null, retrieved_at_utc: "2026-08-27T20:00:00Z", content_sha256: `sha256:${"1".repeat(64)}`, primary_source: false, authenticated_source: false }],
  claim_summary: "SYNTHETIC_CANARY — INFRASTRUCTURE ONLY. Invented disabled-mode validation payload.",
  what_changed: "Invented test bytes exercised local validation only.",
  why_material: "Proves disabled remote MCP validation without publication.",
  materiality: "HIGH",
  confidence: "HIGH",
  evidence_state: "PROVISIONAL_EXTERNAL_SIGNAL",
  target_workstreams: ["signals-platform"],
  related_assets: [], related_addresses: [], related_contracts: [], related_transactions: [], related_update_ids: [],
  specialist_questions: ["Does this synthetic payload remain nonactionable?"],
  prohibited_inferences: ["No real-world claim may be inferred."],
  duplicate_check: { checked_observation_ids: [], duplicate_of: null, canonical_duplicate_key: `sha256:${"3".repeat(64)}` },
  recheck_at_utc: null,
  adjudication_state: "PENDING_SPECIALIST_REVIEW",
  synthetic_canary: true,
  public_safe: true,
  raw_sensitive_material_included: false,
};

function validArgs(connector, overrides = {}) {
  const args = structuredClone({ ...baseObservation, ...overrides });
  const identity = { ...args, observer_id: connector.observerId };
  args.content_sha256 = `sha256:${createHash("sha256").update(canonicalJson(identity)).digest("hex")}`;
  return args;
}

function rpc(connector, token, method, params, id = 1) {
  return new Request(`https://gateway.test${connector.path}`, { method: "POST", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id, method, ...(params ? { params } : {}) }) });
}

function fakeFetch(url) {
  const parsed = new URL(url);
  if (parsed.pathname.includes("/bootstrap/grok-")) return Promise.resolve(new Response(JSON.stringify({ observer_id: parsed.pathname.split("/").at(-1), ok: true }), { status: 200, headers: { "Content-Type": "application/json" } }));
  if (parsed.pathname.includes("/trusted-team/bootstrap/")) return Promise.resolve(new Response(JSON.stringify({ requested_workstream_id: parsed.pathname.split("/").at(-1), ok: true }), { status: 200, headers: { "Content-Type": "application/json" } }));
  if (parsed.pathname.includes("/observations/")) return Promise.resolve(new Response(JSON.stringify({ observation: { observation_id: parsed.pathname.split("/").at(-1) }, ok: true }), { status: 200, headers: { "Content-Type": "application/json" } }));
  throw new Error(`Unexpected upstream ${url}`);
}

test("five connector mappings are exact and schemas omit server-selected controls", async () => {
  assert.equal(CONNECTORS.length, 5);
  const fingerprints = new Set();
  for (const connector of CONNECTORS) {
    const tools = toolsFor(connector);
    assert.deepEqual(tools.map((tool) => tool.name), [connector.publishTool, "read_external_observer_bootstrap", "read_workstream_bootstrap", "read_external_observation"]);
    const schema = JSON.stringify(tools[0].inputSchema).toLowerCase();
    for (const forbidden of ["observer_id", "repository", "workflow", "ledger path", "github credential", "connector credential", "publication mode"]) assert.equal(schema.includes(forbidden), false);
    assert.equal(schema.includes("$ref"), false);
    const fingerprint = await discoveryFingerprint(connector);
    assert.match(fingerprint, /^sha256:[0-9a-f]{64}$/u);
    assert.equal(fingerprint, `sha256:${createHash("sha256").update(canonicalJson(tools)).digest("hex")}`);
    fingerprints.add(fingerprint);
  }
  assert.equal(fingerprints.size, 5);
});

test("authentication is connector-specific and precedes discovery", async () => {
  const gateway = createGateway({ fetchImpl: fakeFetch });
  for (let index = 0; index < CONNECTORS.length; index += 1) {
    const connector = CONNECTORS[index];
    const correct = TOKENS[connector.tokenLabel];
    assert.equal((await gateway.fetch(rpc(connector, correct, "tools/list"), ENV)).status, 200);
    assert.equal((await gateway.fetch(rpc(connector, "wrong-token-abcdefghijklmnopqrstuvwxyz", "tools/list"), ENV)).status, 401);
    const foreign = TOKENS[CONNECTORS[(index + 1) % CONNECTORS.length].tokenLabel];
    assert.equal((await gateway.fetch(rpc(connector, foreign, "tools/list"), ENV)).status, 401);
  }
});

test("parallel discovery never exposes a foreign publish tool", async () => {
  const gateway = createGateway({ fetchImpl: fakeFetch });
  const responses = await Promise.all(CONNECTORS.map((connector) => gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "tools/list"), ENV).then((response) => response.json())));
  responses.forEach((body, index) => {
    const names = body.result.tools.map((tool) => tool.name).filter((name) => name.startsWith("publish_"));
    assert.deepEqual(names, [CONNECTORS[index].publishTool]);
  });
});

test("five disabled writes validate and inject fixed identities without transport", async () => {
  let upstreamCalls = 0;
  let selectorCalls = 0; let resolverCalls = 0; let constructorCalls = 0;
  const gateway = createGateway({
    fetchImpl: async () => { upstreamCalls += 1; throw new Error("transport forbidden"); },
    credentialSelector: () => { selectorCalls += 1; throw new Error("credential selection forbidden"); },
    credentialResolver: async () => { resolverCalls += 1; throw new Error("credential resolution forbidden"); },
    transportFactory: () => { constructorCalls += 1; throw new Error("transport construction forbidden"); },
  });
  for (const connector of CONNECTORS) {
    const response = await gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "tools/call", { name: connector.publishTool, arguments: validArgs(connector, { observation_id: `${connector.observerId}-r12-disabled` }) }), ENV);
    assert.equal(response.status, 200);
    const body = await response.json();
    assert.equal(body.result.structuredContent.error_code, DISABLED_CODE);
    assert.equal(body.result.structuredContent.issue_number, null);
    assert.equal(body.result.structuredContent.workflow_run_id, null);
    assert.equal(body.result.structuredContent.observation_id, null);
    assert.equal(body.result.structuredContent.publication_commit, null);
    assert.equal(body.result.structuredContent.permanent_url, null);
    assert.equal(body.result.structuredContent.manifest_sha256, null);
  }
  assert.equal(upstreamCalls, 0);
  assert.equal(selectorCalls, 0);
  assert.equal(resolverCalls, 0);
  assert.equal(constructorCalls, 0);
});

test("disabled initialization and publication never evaluate GitHub credential properties", async () => {
  const env = { ...ENV };
  for (const label of [...APP_LABELS, "EXTERNAL_OBSERVER_GITHUB_ISSUES_TOKEN"]) {
    Object.defineProperty(env, label, { enumerable: true, get() { throw new Error(`forbidden credential read: ${label}`); } });
  }
  const connector = CONNECTORS[0];
  const gateway = createGateway({ fetchImpl: async () => { throw new Error("upstream forbidden"); } });
  const initialized = await gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "initialize", { protocolVersion: "2025-06-18", capabilities: {}, clientInfo: { name: "test", version: "1" } }), env).then((response) => response.json());
  assert.deepEqual(initialized.result.publication, {
    publication_mode: "DISABLED",
    publication_ready: false,
    github_publication_transport: "DEFERRED_WHILE_DISABLED",
    credential_method: null,
    error_code: null,
    automatic_promotion: false,
  });
  const listed = await gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "tools/list"), env).then((response) => response.json());
  assert.equal(listed.result.tools.length, 4);
  const disabled = await gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "tools/call", { name: connector.publishTool, arguments: validArgs(connector, { observation_id: "synthetic-r12c-no-github-0001" }) }), env).then((response) => response.json());
  assert.equal(disabled.result.structuredContent.error_code, DISABLED_CODE);
});

test("all five disabled connectors initialize, discover, and expose three credential-independent reads", async () => {
  const gateway = createGateway({ fetchImpl: fakeFetch });
  for (const connector of CONNECTORS) {
    const token = TOKENS[connector.tokenLabel];
    const initialized = await gateway.fetch(rpc(connector, token, "initialize", { protocolVersion: "2025-06-18", capabilities: {}, clientInfo: { name: "test", version: "1" } }), ENV).then((response) => response.json());
    assert.equal(initialized.result.publication.github_publication_transport, "DEFERRED_WHILE_DISABLED");
    const listed = await gateway.fetch(rpc(connector, token, "tools/list"), ENV).then((response) => response.json());
    assert.deepEqual(listed.result.tools.map((tool) => tool.name), [connector.publishTool, "read_external_observer_bootstrap", "read_workstream_bootstrap", "read_external_observation"]);
    const observer = await gateway.fetch(rpc(connector, token, "tools/call", { name: "read_external_observer_bootstrap", arguments: {} }), ENV).then((response) => response.json());
    assert.equal(observer.result.structuredContent.observer_id, connector.observerId);
    const workstream = await gateway.fetch(rpc(connector, token, "tools/call", { name: "read_workstream_bootstrap", arguments: { workstream_id: "investor-intelligence" } }), ENV).then((response) => response.json());
    assert.equal(workstream.result.structuredContent.requested_workstream_id, "investor-intelligence");
    const observation = await gateway.fetch(rpc(connector, token, "tools/call", { name: "read_external_observation", arguments: { observation_id: "synthetic-observation-00001" } }), ENV).then((response) => response.json());
    assert.equal(observation.result.structuredContent.observation.observation_id, "synthetic-observation-00001");
  }
});

test("disabled mode ignores complete GitHub fixtures and never exposes them", async () => {
  let selectorCalls = 0; let resolverCalls = 0; let constructorCalls = 0; let upstreamCalls = 0;
  const gateway = createGateway({
    fetchImpl: async () => { upstreamCalls += 1; throw new Error("upstream forbidden"); },
    credentialSelector: () => { selectorCalls += 1; throw new Error("selector forbidden"); },
    credentialResolver: async () => { resolverCalls += 1; throw new Error("resolver forbidden"); },
    transportFactory: () => { constructorCalls += 1; throw new Error("transport forbidden"); },
  });
  const connector = CONNECTORS[1];
  for (const fixture of [TOKEN_FIXTURE, APP_FIXTURE, { ...APP_FIXTURE, ...TOKEN_FIXTURE }]) {
    const env = { ...ENV, ...fixture };
    const response = await gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "tools/call", { name: connector.publishTool, arguments: validArgs(connector, { observation_id: `synthetic-r12c-present-${Object.keys(fixture).length}` }) }), env);
    const encoded = await response.text();
    assert.equal(JSON.parse(encoded).result.structuredContent.error_code, DISABLED_CODE);
    for (const value of Object.values(fixture)) assert.equal(encoded.includes(value), false);
  }
  assert.deepEqual({ selectorCalls, resolverCalls, constructorCalls, upstreamCalls }, { selectorCalls: 0, resolverCalls: 0, constructorCalls: 0, upstreamCalls: 0 });
});

test("credential selector rejects absent and every partial App combination", () => {
  assert.throws(() => selectGitHubCredentialMethod({}), (error) => error.code === GITHUB_CREDENTIAL_REQUIRED && error.reason === "CREDENTIAL_ABSENT");
  for (let mask = 1; mask < 7; mask += 1) {
    const partial = {};
    APP_LABELS.forEach((label, index) => { if (mask & (1 << index)) partial[label] = APP_FIXTURE[label]; });
    assert.throws(() => selectGitHubCredentialMethod(partial), (error) => error.code === GITHUB_CREDENTIAL_REQUIRED && error.reason === "PARTIAL_GITHUB_APP_CREDENTIALS");
    assert.throws(() => selectGitHubCredentialMethod({ ...TOKEN_FIXTURE, ...partial }), (error) => error.code === GITHUB_CREDENTIAL_REQUIRED && error.reason === "MIXED_PARTIAL_CREDENTIALS");
  }
});

test("both writable readiness surfaces fail closed for every partial and mixed-partial App set", async () => {
  const gateway = createGateway({ fetchImpl: async () => { throw new Error("upstream forbidden"); } });
  const connector = CONNECTORS[0];
  for (const mode of ["SYNTHETIC_ONLY", "PROVISIONAL_LIVE"]) {
    for (let mask = 1; mask < 7; mask += 1) {
      const partial = {};
      APP_LABELS.forEach((label, index) => { if (mask & (1 << index)) partial[label] = APP_FIXTURE[label]; });
      for (const fixture of [partial, { ...TOKEN_FIXTURE, ...partial }]) {
        const env = { ...TOKENS, ...fixture, PUBLICATION_MODE: mode, CONTROL_ROOM_ORIGIN: "https://pulsechain-research-control-room.brohexphiat.chatgpt.site" };
        const initialized = await gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "initialize", { protocolVersion: "2025-06-18", capabilities: {}, clientInfo: { name: "test", version: "1" } }), env).then((response) => response.json());
        assert.equal(initialized.result.publication.publication_ready, false);
        assert.equal(initialized.result.publication.error_code, GITHUB_CREDENTIAL_REQUIRED);
      }
    }
  }
});

test("credential selector accepts complete methods and preserves App preference", () => {
  assert.equal(selectGitHubCredentialMethod(APP_FIXTURE), GITHUB_CREDENTIAL_METHOD.APP);
  assert.equal(selectGitHubCredentialMethod(TOKEN_FIXTURE), GITHUB_CREDENTIAL_METHOD.TOKEN);
  assert.equal(selectGitHubCredentialMethod({ ...TOKEN_FIXTURE, ...APP_FIXTURE }), GITHUB_CREDENTIAL_METHOD.APP);
});

test("credential selector rejects malformed values and near-miss labels", () => {
  const cases = [
    { EXTERNAL_OBSERVER_GITHUB_ISSUES_TOKEN: "short" },
    { ...APP_FIXTURE, EXTERNAL_OBSERVER_GITHUB_APP_ID: "not-numeric" },
    { ...APP_FIXTURE, EXTERNAL_OBSERVER_GITHUB_INSTALLATION_ID: "0" },
    { ...APP_FIXTURE, EXTERNAL_OBSERVER_GITHUB_PRIVATE_KEY: "not-a-private-key" },
    { ...TOKEN_FIXTURE, EXTERNAL_OBSERVER_GITHUB_TOKEN: TOKEN_FIXTURE.EXTERNAL_OBSERVER_GITHUB_ISSUES_TOKEN },
  ];
  for (const fixture of cases) assert.throws(() => selectGitHubCredentialMethod(fixture), (error) => error.code === GITHUB_CREDENTIAL_REQUIRED);
});

test("both writable modes fail readiness and publish before upstream access without a credential", async () => {
  for (const mode of ["SYNTHETIC_ONLY", "PROVISIONAL_LIVE"]) {
    let upstreamCalls = 0; let resolverCalls = 0; let constructorCalls = 0;
    const gateway = createGateway({
      fetchImpl: async () => { upstreamCalls += 1; throw new Error("upstream forbidden"); },
      credentialResolver: async () => { resolverCalls += 1; throw new Error("resolver forbidden"); },
      transportFactory: () => { constructorCalls += 1; throw new Error("transport forbidden"); },
    });
    const connector = CONNECTORS[0]; const env = { ...TOKENS, PUBLICATION_MODE: mode, CONTROL_ROOM_ORIGIN: "https://pulsechain-research-control-room.brohexphiat.chatgpt.site" };
    const initialized = await gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "initialize", { protocolVersion: "2025-06-18", capabilities: {}, clientInfo: { name: "test", version: "1" } }), env).then((response) => response.json());
    assert.equal(initialized.result.publication.publication_ready, false);
    assert.equal(initialized.result.publication.error_code, GITHUB_CREDENTIAL_REQUIRED);
    const overrides = mode === "SYNTHETIC_ONLY" ? { observation_id: "synthetic-r12c-credential-gate" } : {
      observation_id: "provisional-r12c-credential-gate",
      synthetic_canary: false,
      claim_summary: "Public-safe invented credential-gate input with no real-world claim.",
      what_changed: "Invented bytes exercise only the fail-closed credential gate.",
      why_material: "Verifies that writable publication cannot start without a credential.",
    };
    const body = await gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "tools/call", { name: connector.publishTool, arguments: validArgs(connector, overrides) }), env).then((response) => response.json());
    assert.equal(body.result.isError, true);
    assert.equal(body.result.structuredContent.error, GITHUB_CREDENTIAL_REQUIRED);
    assert.deepEqual({ upstreamCalls, resolverCalls, constructorCalls }, { upstreamCalls: 0, resolverCalls: 0, constructorCalls: 0 });
  }
});

test("writable readiness selects a complete method without transport or external mutation", async () => {
  let resolverCalls = 0; let constructorCalls = 0; let upstreamCalls = 0;
  const gateway = createGateway({
    fetchImpl: async () => { upstreamCalls += 1; throw new Error("upstream forbidden"); },
    credentialResolver: async () => { resolverCalls += 1; throw new Error("resolver forbidden"); },
    transportFactory: () => { constructorCalls += 1; throw new Error("transport forbidden"); },
  });
  const connector = CONNECTORS[0];
  for (const mode of ["SYNTHETIC_ONLY", "PROVISIONAL_LIVE"]) {
    for (const [fixture, expected] of [[TOKEN_FIXTURE, GITHUB_CREDENTIAL_METHOD.TOKEN], [APP_FIXTURE, GITHUB_CREDENTIAL_METHOD.APP], [{ ...TOKEN_FIXTURE, ...APP_FIXTURE }, GITHUB_CREDENTIAL_METHOD.APP]]) {
      const env = { ...TOKENS, ...fixture, PUBLICATION_MODE: mode, CONTROL_ROOM_ORIGIN: "https://pulsechain-research-control-room.brohexphiat.chatgpt.site" };
      const initialized = await gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "initialize", { protocolVersion: "2025-06-18", capabilities: {}, clientInfo: { name: "test", version: "1" } }), env).then((response) => response.json());
      assert.equal(initialized.result.publication.publication_ready, true);
      assert.equal(initialized.result.publication.credential_method, expected);
    }
  }
  assert.deepEqual({ resolverCalls, constructorCalls, upstreamCalls }, { resolverCalls: 0, constructorCalls: 0, upstreamCalls: 0 });
});

test("common reads remain credential-independent in writable modes", async () => {
  const gateway = createGateway({ fetchImpl: fakeFetch });
  const connector = CONNECTORS[3];
  for (const mode of ["SYNTHETIC_ONLY", "PROVISIONAL_LIVE"]) {
    const env = { ...TOKENS, PUBLICATION_MODE: mode, CONTROL_ROOM_ORIGIN: "https://pulsechain-research-control-room.brohexphiat.chatgpt.site" };
    const body = await gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "tools/call", { name: "read_external_observer_bootstrap", arguments: {} }), env).then((response) => response.json());
    assert.equal(body.result.structuredContent.observer_id, connector.observerId);
  }
});

test("direct, nested, and foreign publish-tool identity selection are rejected", async () => {
  const gateway = createGateway({ fetchImpl: fakeFetch });
  const connector = CONNECTORS[0];
  for (const injected of [{ ...validArgs(connector), observer_id: connector.observerId }, { ...validArgs(connector), source_records: [{ ...baseObservation.source_records[0], metadata: { observerId: connector.observerId } }] }]) {
    const body = await gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "tools/call", { name: connector.publishTool, arguments: injected }), ENV).then((response) => response.json());
    assert.equal(body.result.isError, true);
    assert.equal(body.result.structuredContent.error, "INVALID_TOOL_INPUT");
  }
  const foreignTool = CONNECTORS[1].publishTool;
  const body = await gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "tools/call", { name: foreignTool, arguments: validArgs(connector) }), ENV).then((response) => response.json());
  assert.equal(body.result.isError, true);
});

test("strict schema, privacy, and secret rejection remain active in disabled mode", async () => {
  const gateway = createGateway({ fetchImpl: fakeFetch });
  const connector = CONNECTORS[0];
  const cases = [
    { ...validArgs(connector), unexpected: true },
    validArgs(connector, { raw_sensitive_material_included: true }),
    validArgs(connector, { public_safe: false }),
    validArgs(connector, { claim_summary: SYNTHETIC_GITHUB_TOKEN_PATTERN }),
    validArgs(connector, { adjudication_state: "ACCEPTED" }),
  ];
  for (const args of cases) {
    const body = await gateway.fetch(rpc(connector, TOKENS[connector.tokenLabel], "tools/call", { name: connector.publishTool, arguments: args }), ENV).then((response) => response.json());
    assert.equal(body.result.isError, true);
  }
});

test("common read tools are bounded to public Control Room routes", async () => {
  const gateway = createGateway({ fetchImpl: fakeFetch });
  const connector = CONNECTORS[2]; const token = TOKENS[connector.tokenLabel];
  const bootstrap = await gateway.fetch(rpc(connector, token, "tools/call", { name: "read_external_observer_bootstrap", arguments: {} }), ENV).then((response) => response.json());
  assert.equal(bootstrap.result.structuredContent.observer_id, connector.observerId);
  const workstream = await gateway.fetch(rpc(connector, token, "tools/call", { name: "read_workstream_bootstrap", arguments: { workstream_id: "investor-intelligence" } }), ENV).then((response) => response.json());
  assert.equal(workstream.result.structuredContent.requested_workstream_id, "investor-intelligence");
  const observation = await gateway.fetch(rpc(connector, token, "tools/call", { name: "read_external_observation", arguments: { observation_id: "synthetic-observation-00001" } }), ENV).then((response) => response.json());
  assert.equal(observation.result.structuredContent.observation.observation_id, "synthetic-observation-00001");
});

test("Streamable HTTP protocol surface is stateless and fail-closed", async () => {
  const gateway = createGateway({ fetchImpl: fakeFetch }); const connector = CONNECTORS[0]; const token = TOKENS[connector.tokenLabel];
  const initialized = await gateway.fetch(rpc(connector, token, "initialize", { protocolVersion: "2025-06-18", capabilities: {}, clientInfo: { name: "test", version: "1" } }), ENV).then((response) => response.json());
  assert.equal(initialized.result.protocolVersion, "2025-06-18");
  assert.equal((await gateway.fetch(new Request(`https://gateway.test${connector.path}`, { method: "GET", headers: { Authorization: `Bearer ${token}` } }), ENV)).status, 405);
  assert.equal((await gateway.fetch(new Request("https://gateway.test/mcp/external-observers/foreign", { method: "POST" }), ENV)).status, 404);
  assert.equal((await gateway.fetch(new Request(`https://gateway.test${connector.path}`, { method: "POST", headers: { Authorization: `Bearer ${token}` }, body: "{" }), ENV)).status, 400);
});
