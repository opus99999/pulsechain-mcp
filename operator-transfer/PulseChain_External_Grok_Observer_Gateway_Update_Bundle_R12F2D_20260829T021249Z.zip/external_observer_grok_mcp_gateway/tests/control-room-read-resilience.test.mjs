import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import test from "node:test";
import {
  CONTROL_ROOM_READ_POLICY,
  CONTROL_ROOM_RESPONSE_LIMITS,
  CONTROL_ROOM_UPSTREAM_UNAVAILABLE,
  ControlRoomReadError,
  FIXED_CONTROL_ROOM_ORIGIN,
  createControlRoomReader,
} from "../src/control-room-reader.mjs";
import { CONNECTORS, canonicalJson } from "../src/contracts.mjs";
import { createGateway } from "../src/worker.mjs";

const ENV = { CONTROL_ROOM_ORIGIN: FIXED_CONTROL_ROOM_ORIGIN };
const SYNTHETIC_BEARER_REDACTION_PATTERN = ["Bea", "rer secret-value-", "abcdefghijklmnopqrstuvwxyz", " token=private-value"].join("");
const CONTEXT = Object.freeze({
  toolName: "read_external_observer_bootstrap",
  observerId: "grok-x-protocol",
  path: "/api/v1/external-observers/bootstrap/grok-x-protocol",
  validate: (payload) => assert.equal(payload.observer_id, "grok-x-protocol"),
});

function jsonResponse(value, init = {}) {
  return new Response(JSON.stringify(value), { status: init.status ?? 200, headers: { "Content-Type": "application/json; charset=utf-8", ...(init.headers || {}) } });
}

function harness(fetchImpl, options = {}) {
  const delays = [];
  const telemetry = [];
  const reader = createControlRoomReader({
    fetchImpl,
    sleep: async (ms) => { delays.push(ms); },
    telemetrySink: (value) => telemetry.push(value),
    ...options,
  });
  return { reader, delays, telemetry };
}

async function capture(reader, context = CONTEXT, env = ENV) {
  try { await reader(env, context); }
  catch (error) { return error; }
  throw new Error("Expected the read to fail");
}

function trackingSignal() {
  const listeners = new Set();
  let added = 0; let removed = 0;
  const signal = {
    aborted: false,
    reason: undefined,
    addEventListener(type, listener) { if (type === "abort") { listeners.add(listener); added += 1; } },
    removeEventListener(type, listener) { if (type === "abort" && listeners.delete(listener)) removed += 1; },
  };
  return {
    signal,
    abort(reason = new DOMException("synthetic caller cancellation", "AbortError")) {
      if (signal.aborted) return;
      signal.aborted = true;
      signal.reason = reason;
      for (const listener of [...listeners]) listener.call(signal, { type: "abort", target: signal });
    },
    active: () => listeners.size,
    counts: () => ({ added, removed }),
  };
}

const writableObservation = Object.freeze({
  schema_version: "pulsechain-external-observation@1.0.0",
  observation_id: "synthetic-r12f-single-attempt",
  generated_at_utc: "2026-08-28T12:00:00Z",
  observed_window: { from_utc: "2026-08-28T11:55:00Z", to_utc: "2026-08-28T12:00:00Z" },
  source_class: "PUBLIC_SECONDARY_SOURCE",
  source_records: [{ url: "https://example.com/r12f", source_id: "r12f-source", author_or_domain: "example.com", published_at_utc: null, retrieved_at_utc: "2026-08-28T12:00:00Z", content_sha256: `sha256:${"1".repeat(64)}`, primary_source: false, authenticated_source: false }],
  claim_summary: "SYNTHETIC_CANARY — invented write-path retry-scope fixture.",
  what_changed: "Invented bytes test only the single-attempt bootstrap boundary.",
  why_material: "Proves common-read retry policy does not extend to publication.",
  materiality: "HIGH",
  confidence: "HIGH",
  evidence_state: "PROVISIONAL_EXTERNAL_SIGNAL",
  target_workstreams: ["signals-platform"],
  related_assets: [], related_addresses: [], related_contracts: [], related_transactions: [], related_update_ids: [],
  specialist_questions: ["Does the write path remain single-attempt?"],
  prohibited_inferences: ["No real-world claim may be inferred."],
  duplicate_check: { checked_observation_ids: [], duplicate_of: null, canonical_duplicate_key: `sha256:${"3".repeat(64)}` },
  recheck_at_utc: null,
  adjudication_state: "PENDING_SPECIALIST_REVIEW",
  synthetic_canary: true,
  public_safe: true,
  raw_sensitive_material_included: false,
});

function writableArgs(connector) {
  const args = structuredClone(writableObservation);
  const identity = { ...args, observer_id: connector.observerId };
  args.content_sha256 = `sha256:${createHash("sha256").update(canonicalJson(identity)).digest("hex")}`;
  return args;
}

test("production origin, retry, deadline, and response-size constants are exact and immutable", () => {
  assert.equal(FIXED_CONTROL_ROOM_ORIGIN, "https://pulsechain-research-control-room.brohexphiat.chatgpt.site");
  assert.deepEqual(CONTROL_ROOM_READ_POLICY, {
    maximumAttempts: 3,
    perAttemptTimeoutMs: 12_000,
    retryDelaysMs: [250, 1_000],
    totalDeadlineMs: 40_000,
    maximumRetryAfterMs: 5_000,
    maximumResponseBytes: 8 * 1024 * 1024,
  });
  assert.deepEqual(CONTROL_ROOM_RESPONSE_LIMITS, {
    read_external_observer_bootstrap: 4 * 1024 * 1024,
    read_workstream_bootstrap: 8 * 1024 * 1024,
    read_external_observation: 4 * 1024 * 1024,
  });
  assert.equal(Object.isFrozen(CONTROL_ROOM_READ_POLICY), true);
  assert.equal(Object.isFrozen(CONTROL_ROOM_READ_POLICY.retryDelaysMs), true);
  assert.equal(Object.isFrozen(CONTROL_ROOM_RESPONSE_LIMITS), true);
});

test("a configured origin mismatch fails before fetch and the absent variable still uses the fixed origin", async () => {
  const urls = [];
  const { reader } = harness(async (url) => { urls.push(url); return jsonResponse({ observer_id: "grok-x-protocol" }); });
  const mismatch = await capture(reader, CONTEXT, { CONTROL_ROOM_ORIGIN: "https://foreign.example" });
  assert.equal(mismatch.code, "CONTROL_ROOM_ORIGIN_INVALID");
  assert.equal(mismatch.safeDetails.final_failure_stage, "INTERNAL_VALIDATION");
  assert.deepEqual(urls, []);
  assert.equal((await reader({}, CONTEXT)).observer_id, "grok-x-protocol");
  assert.deepEqual(urls, [`${FIXED_CONTROL_ROOM_ORIGIN}${CONTEXT.path}`]);
});

test("first valid JSON response preserves the exact object with one attempt", async () => {
  let calls = 0; let options;
  const payload = { observer_id: "grok-x-protocol", nested: { unchanged: [1, "two", false] } };
  const { reader, telemetry } = harness(async (url, init) => { calls += 1; options = { url, init }; return jsonResponse(payload); });
  assert.deepEqual(await reader(ENV, CONTEXT), payload);
  assert.equal(calls, 1); assert.equal(telemetry[0].transport_attempt_count, 1); assert.equal(telemetry[0].retry_count, 0);
  assert.equal(options.url, `${FIXED_CONTROL_ROOM_ORIGIN}${CONTEXT.path}`); assert.equal(options.init.method, "GET"); assert.equal(options.init.cache, "no-store"); assert.equal(options.init.redirect, "manual");
});

test("one per-attempt timeout is retried and the second response succeeds", async () => {
  let calls = 0; let timers = 0;
  const scheduled = []; const cleared = [];
  const { reader, telemetry } = harness(async (_url, init) => {
    calls += 1;
    if (calls === 1) return new Promise((_, reject) => init.signal.addEventListener("abort", () => reject(new DOMException("aborted", "AbortError")), { once: true }));
    return jsonResponse({ observer_id: "grok-x-protocol" });
  }, {
    setTimer: (callback, ms) => {
      timers += 1;
      scheduled.push(ms);
      if (timers === 1) queueMicrotask(callback);
      return timers;
    },
    clearTimer: (timer) => { cleared.push(timer); },
  });
  assert.equal((await reader(ENV, CONTEXT)).observer_id, "grok-x-protocol");
  assert.equal(calls, 2); assert.equal(telemetry[0].retry_count, 1);
  assert.deepEqual(scheduled, [12_000, 12_000]);
  assert.deepEqual(cleared, [1, 2]);
});

test("HTTP 503 is retried once before success", async () => {
  let calls = 0; const { reader, telemetry } = harness(async () => ++calls === 1 ? jsonResponse({}, { status: 503 }) : jsonResponse({ observer_id: "grok-x-protocol" }));
  await reader(ENV, CONTEXT); assert.equal(calls, 2); assert.equal(telemetry[0].retry_count, 1);
});

test("three HTTP 503 responses return the exact unavailable code", async () => {
  let calls = 0; const { reader } = harness(async () => { calls += 1; return jsonResponse({}, { status: 503, headers: { "CF-Ray": "safe-request-id" } }); });
  const error = await capture(reader);
  assert(error instanceof ControlRoomReadError); assert.equal(error.code, CONTROL_ROOM_UPSTREAM_UNAVAILABLE); assert.equal(calls, 3);
  assert.equal(error.safeDetails.attempt_count, 3); assert.equal(error.safeDetails.retry_count, 2); assert.equal(error.safeDetails.upstream_request_id, "safe-request-id");
});

test("network failure then 502 then valid JSON uses three attempts", async () => {
  let calls = 0; const { reader, telemetry } = harness(async () => { calls += 1; if (calls === 1) throw new TypeError("synthetic network failure"); if (calls === 2) return jsonResponse({}, { status: 502 }); return jsonResponse({ observer_id: "grok-x-protocol" }); });
  await reader(ENV, CONTEXT); assert.equal(calls, 3); assert.equal(telemetry[0].retry_count, 2);
});

test("short Retry-After is observed while the exact base delay is preserved", async () => {
  let calls = 0; const { reader, delays, telemetry } = harness(async () => ++calls === 1 ? jsonResponse({}, { status: 429, headers: { "Retry-After": "0.1" } }) : jsonResponse({ observer_id: "grok-x-protocol" }));
  await reader(ENV, CONTEXT); assert.deepEqual(delays, [250]); assert.equal(telemetry[0].retry_after_observed, true); assert.equal(telemetry[0].retry_after_applied_ms, 250);
});

test("excessive Retry-After is capped at five seconds", async () => {
  let calls = 0; const { reader, delays } = harness(async () => ++calls === 1 ? jsonResponse({}, { status: 429, headers: { "Retry-After": "60" } }) : jsonResponse({ observer_id: "grok-x-protocol" }));
  await reader(ENV, CONTEXT); assert.deepEqual(delays, [5_000]);
});

test("HTTP-date Retry-After uses wall time independently from monotonic elapsed time", async () => {
  let calls = 0; let monotonicMs = 0;
  const wallEpochMs = Date.UTC(2032, 0, 2, 3, 4, 5);
  const delays = [];
  const reader = createControlRoomReader({
    now: () => monotonicMs,
    wallNow: () => wallEpochMs + monotonicMs,
    sleep: async (ms) => { delays.push(ms); monotonicMs += ms; },
    fetchImpl: async () => {
      calls += 1;
      return calls === 1
        ? jsonResponse({}, { status: 429, headers: { "Retry-After": new Date(wallEpochMs + 2_000).toUTCString() } })
        : jsonResponse({ observer_id: "grok-x-protocol" });
    },
  });
  await reader(ENV, CONTEXT);
  assert.equal(calls, 2);
  assert.deepEqual(delays, [2_000]);
});

test("Retry-After never sleeps beyond the remaining forty-second hard deadline", async () => {
  let calls = 0; let monotonicMs = 0; let sleeps = 0;
  const wallEpochMs = Date.UTC(2032, 0, 2, 3, 4, 5);
  const reader = createControlRoomReader({
    now: () => monotonicMs,
    wallNow: () => wallEpochMs + monotonicMs,
    sleep: async () => { sleeps += 1; },
    fetchImpl: async () => {
      calls += 1;
      monotonicMs += 39_900;
      return jsonResponse({}, { status: 429, headers: { "Retry-After": new Date(wallEpochMs + 60_000).toUTCString() } });
    },
  });
  const error = await capture(reader);
  assert.equal(error.code, CONTROL_ROOM_UPSTREAM_UNAVAILABLE);
  assert.equal(calls, 1);
  assert.equal(sleeps, 0);
  assert.equal(error.safeDetails.total_elapsed_ms, 39_900);
  assert(error.safeDetails.total_elapsed_ms <= CONTROL_ROOM_READ_POLICY.totalDeadlineMs);
});

for (const status of [408, 429, 500, 502, 503, 504]) {
  test(`retryable HTTP status table includes ${status}`, async () => {
    let calls = 0;
    const { reader, delays } = harness(async () => ++calls === 1 ? jsonResponse({}, { status }) : jsonResponse({ observer_id: "grok-x-protocol" }));
    await reader(ENV, CONTEXT);
    assert.equal(calls, 2);
    assert.deepEqual(delays, [250]);
  });
}

for (const status of [400, 401, 403, 404, 405, 409, 410, 418]) {
  test(`nonretryable HTTP status table rejects ${status} after one attempt`, async () => {
    let calls = 0;
    const { reader, delays } = harness(async () => { calls += 1; return jsonResponse({}, { status }); });
    const error = await capture(reader);
    assert.equal(error.code, "CONTROL_ROOM_UPSTREAM_HTTP_ERROR");
    assert.equal(error.safeDetails.last_http_status, status);
    assert.equal(calls, 1);
    assert.deepEqual(delays, []);
  });
}

for (const status of [404, 401, 409]) {
  test(`HTTP ${status} is not retried`, async () => {
    let calls = 0; const { reader } = harness(async () => { calls += 1; return jsonResponse({}, { status }); });
    const error = await capture(reader); assert.equal(error.code, "CONTROL_ROOM_UPSTREAM_HTTP_ERROR"); assert.equal(calls, 1); assert.equal(error.safeDetails.last_http_status, status);
  });
}

test("valid HTTP with malformed JSON fails at JSON_PARSE without retry", async () => {
  let calls = 0; const { reader } = harness(async () => { calls += 1; return new Response("{", { status: 200, headers: { "Content-Type": "application/json" } }); });
  const error = await capture(reader); assert.equal(error.code, "CONTROL_ROOM_UPSTREAM_INVALID_JSON"); assert.equal(error.safeDetails.final_failure_stage, "JSON_PARSE"); assert.equal(calls, 1);
});

test("valid HTTP with a non-JSON content type fails without retry", async () => {
  let calls = 0; const { reader } = harness(async () => { calls += 1; return new Response("{}", { status: 200, headers: { "Content-Type": "text/html" } }); });
  const error = await capture(reader); assert.equal(error.code, "CONTROL_ROOM_UPSTREAM_INVALID_CONTENT_TYPE"); assert.equal(calls, 1);
});

test("oversized response fails closed without reading or retrying", async () => {
  let calls = 0; const { reader } = harness(async () => { calls += 1; return new Response("{}", { status: 200, headers: { "Content-Type": "application/json", "Content-Length": String(CONTROL_ROOM_READ_POLICY.maximumResponseBytes + 1) } }); });
  const error = await capture(reader); assert.equal(error.code, "CONTROL_ROOM_UPSTREAM_RESPONSE_TOO_LARGE"); assert.equal(calls, 1);
});

test("chunked response crossing the route cap is canceled and never retried", async () => {
  let calls = 0; let canceled = 0;
  const stream = new ReadableStream({
    start(controller) {
      controller.enqueue(new TextEncoder().encode("123456"));
      controller.enqueue(new TextEncoder().encode("789"));
    },
    cancel() { canceled += 1; },
  });
  const { reader, delays } = harness(async () => {
    calls += 1;
    return new Response(stream, { status: 200, headers: { "Content-Type": "application/json" } });
  });
  const error = await capture(reader, { ...CONTEXT, maximumResponseBytes: 8, validate: undefined });
  assert.equal(error.code, "CONTROL_ROOM_UPSTREAM_RESPONSE_TOO_LARGE");
  assert.equal(error.safeDetails.final_failure_stage, "RESPONSE_SIZE_VALIDATION");
  assert.equal(calls, 1);
  assert.equal(canceled, 1);
  assert.deepEqual(delays, []);
});

test("caller cancellation performs no retry", async () => {
  let calls = 0; const controller = new AbortController(); controller.abort();
  const { reader } = harness(async () => { calls += 1; return jsonResponse({ observer_id: "grok-x-protocol" }); });
  const error = await capture(reader, { ...CONTEXT, signal: controller.signal }); assert.equal(error.code, "CONTROL_ROOM_REQUEST_CANCELLED"); assert.equal(calls, 0);
});

test("caller cancellation during fetch aborts the active attempt without retry", async () => {
  let calls = 0; let activeAttemptSignal; let fetchStartedResolve;
  const fetchStarted = new Promise((resolve) => { fetchStartedResolve = resolve; });
  const caller = trackingSignal();
  const { reader, delays } = harness(async (_url, init) => {
    calls += 1;
    activeAttemptSignal = init.signal;
    fetchStartedResolve();
    return new Promise((_, reject) => init.signal.addEventListener("abort", () => reject(new DOMException("attempt aborted", "AbortError")), { once: true }));
  });
  const pending = capture(reader, { ...CONTEXT, signal: caller.signal });
  await fetchStarted;
  caller.abort();
  const error = await pending;
  assert.equal(error.code, "CONTROL_ROOM_REQUEST_CANCELLED");
  assert.equal(error.safeDetails.final_failure_stage, "CALLER_CANCELLATION");
  assert.equal(calls, 1);
  assert.equal(activeAttemptSignal.aborted, true);
  assert.deepEqual(delays, []);
  assert.equal(caller.active(), 0);
});

test("caller cancellation during the real retry delay removes every abort listener", async () => {
  let calls = 0;
  const caller = trackingSignal();
  const reader = createControlRoomReader({
    fetchImpl: async () => { calls += 1; return jsonResponse({}, { status: 503 }); },
  });
  const pending = capture(reader, { ...CONTEXT, signal: caller.signal });
  for (let turn = 0; turn < 50 && caller.active() < 2; turn += 1) await Promise.resolve();
  assert.equal(caller.active(), 2, "attempt and retry-delay listeners must both be active before cancellation");
  caller.abort();
  const error = await pending;
  assert.equal(error.code, "CONTROL_ROOM_REQUEST_CANCELLED");
  assert.equal(error.safeDetails.final_failure_stage, "CALLER_CANCELLATION");
  assert.equal(calls, 1);
  assert.equal(caller.active(), 0);
  assert.equal(caller.counts().added, caller.counts().removed);
});

test("cross-origin redirect is rejected without following it", async () => {
  let calls = 0; const { reader } = harness(async () => { calls += 1; return new Response(null, { status: 302, headers: { Location: "https://foreign.example/private" } }); });
  const error = await capture(reader); assert.equal(error.code, "CONTROL_ROOM_UPSTREAM_REDIRECT_REJECTED"); assert.equal(calls, 1);
});

test("attempt timers are cleared after a successful fetch", async () => {
  let created = 0; let cleared = 0;
  const { reader } = harness(async () => jsonResponse({ observer_id: "grok-x-protocol" }), { setTimer: () => { created += 1; return 7; }, clearTimer: (value) => { assert.equal(value, 7); cleared += 1; } });
  await reader(ENV, CONTEXT); assert.equal(created, 1); assert.equal(cleared, 1);
});

test("retry success leaves no attempt timer or caller listener active", async () => {
  let calls = 0; let nextTimer = 0;
  const activeTimers = new Set();
  const caller = trackingSignal();
  const reader = createControlRoomReader({
    fetchImpl: async () => ++calls === 1 ? jsonResponse({}, { status: 503 }) : jsonResponse({ observer_id: "grok-x-protocol" }),
    sleep: async () => {},
    setTimer: (_callback, ms) => { assert.equal(ms, 12_000); nextTimer += 1; activeTimers.add(nextTimer); return nextTimer; },
    clearTimer: (timer) => { assert.equal(activeTimers.delete(timer), true); },
  });
  await reader(ENV, { ...CONTEXT, signal: caller.signal });
  assert.equal(calls, 2);
  assert.equal(activeTimers.size, 0);
  assert.equal(caller.active(), 0);
  assert.deepEqual(caller.counts(), { added: 2, removed: 2 });
});

test("retryable response bodies are canceled before retry", async () => {
  let calls = 0; let canceled = 0;
  const retryResponse = { ok: false, status: 503, url: "", headers: new Headers({ "Content-Type": "application/json" }), body: { cancel: async () => { canceled += 1; } } };
  const { reader } = harness(async () => ++calls === 1 ? retryResponse : jsonResponse({ observer_id: "grok-x-protocol" }));
  await reader(ENV, CONTEXT); assert.equal(canceled, 1);
});

test("concurrent reads retain request-local attempt state", async () => {
  const counts = new Map(); const telemetry = [];
  const reader = createControlRoomReader({
    fetchImpl: async (url) => { const count = (counts.get(url) || 0) + 1; counts.set(url, count); if (url.includes("grok-x-protocol") && count === 1) return jsonResponse({}, { status: 503 }); return jsonResponse({ observer_id: url.split("/").at(-1) }); },
    sleep: async () => {}, telemetrySink: (value) => telemetry.push(value),
  });
  const second = { ...CONTEXT, observerId: "grok-red-team", path: "/api/v1/external-observers/bootstrap/grok-red-team", validate: (payload) => assert.equal(payload.observer_id, "grok-red-team") };
  await Promise.all([reader(ENV, CONTEXT), reader(ENV, second)]);
  assert.deepEqual(telemetry.map((row) => [row.transport_attempt_count, row.retry_count]).sort(), [[1, 0], [2, 1]]);
});

test("all three read tools use one policy with distinct fixed paths", async () => {
  const paths = []; const { reader } = harness(async (url) => { paths.push(new URL(url).pathname); const id = new URL(url).pathname.split("/").at(-1); return jsonResponse({ observer_id: id, workstream_id: id, observation_id: id }); });
  const cases = [
    CONTEXT,
    { toolName: "read_workstream_bootstrap", observerId: "grok-x-protocol", targetWorkstream: "signals-platform", path: "/api/v1/trusted-team/bootstrap/signals-platform", validate: (value) => assert.equal(value.workstream_id, "signals-platform") },
    { toolName: "read_external_observation", observerId: "grok-x-protocol", path: "/api/v1/external-observers/observations/synthetic-observation-00001", validate: (value) => assert.equal(value.observation_id, "synthetic-observation-00001") },
  ];
  for (const context of cases) await reader(ENV, context);
  assert.deepEqual(paths, cases.map((value) => value.path));
});

test("workstream and observation identity mismatches fail schema validation without retry", async () => {
  const connector = CONNECTORS[0];
  const token = "synthetic-r12f-schema-token-abcdefghijklmnopqrstuvwxyz";
  let upstreamCalls = 0;
  const gateway = createGateway({
    fetchImpl: async (url) => {
      upstreamCalls += 1;
      return url.includes("trusted-team")
        ? jsonResponse({ requested_workstream_id: "validator-flows" })
        : jsonResponse({ observation: { observation_id: "foreign-observation-00001" } });
    },
  });
  async function invoke(id, name, args) {
    const response = await gateway.fetch(new Request(`https://gateway.test${connector.path}`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id, method: "tools/call", params: { name, arguments: args } }),
    }), { [connector.tokenLabel]: token, PUBLICATION_MODE: "DISABLED", CONTROL_ROOM_ORIGIN: FIXED_CONTROL_ROOM_ORIGIN });
    return response.json();
  }
  const workstream = await invoke("schema-workstream", "read_workstream_bootstrap", { workstream_id: "signals-platform" });
  const observation = await invoke("schema-observation", "read_external_observation", { observation_id: "synthetic-observation-00001" });
  for (const body of [workstream, observation]) {
    assert.equal(body.result.isError, true);
    assert.equal(body.result.structuredContent.error, "CONTROL_ROOM_UPSTREAM_SCHEMA_MISMATCH");
    assert.equal(body.result.structuredContent.attempt_count, 1);
    assert.equal(body.result.structuredContent.final_failure_stage, "SCHEMA_VALIDATION");
  }
  assert.equal(upstreamCalls, 2);
});

test("successful payload canonical-object equivalence is exact", async () => {
  const payload = { observer_id: "grok-x-protocol", evidence: { unavailable: true, negative_findings: ["synthetic"] }, pointer: null };
  const { reader } = harness(async () => jsonResponse(payload));
  assert.equal(JSON.stringify(await reader(ENV, CONTEXT)), JSON.stringify(payload));
});

test("a later failed operation never receives a stale prior success", async () => {
  let calls = 0;
  const authoritative = { observer_id: "grok-x-protocol", update_id: "authoritative-first-read" };
  const { reader } = harness(async () => {
    calls += 1;
    return calls === 1 ? jsonResponse(authoritative) : jsonResponse({ private_body: "must-not-be-used" }, { status: 503 });
  });
  assert.deepEqual(await reader(ENV, CONTEXT), authoritative);
  const error = await capture(reader);
  assert.equal(error.code, CONTROL_ROOM_UPSTREAM_UNAVAILABLE);
  assert.equal(error.safeDetails.attempt_count, 3);
  assert.equal(calls, 4);
  assert.equal(JSON.stringify(error.safeDetails).includes("authoritative-first-read"), false);
  assert.equal(JSON.stringify(error.safeDetails).includes("must-not-be-used"), false);
});

test("exhausted diagnostic fields are complete and redact credential patterns", async () => {
  const { reader } = harness(async () => { throw new TypeError(SYNTHETIC_BEARER_REDACTION_PATTERN); });
  const error = await capture(reader); const serialized = JSON.stringify(error.safeDetails);
  assert.equal(error.code, CONTROL_ROOM_UPSTREAM_UNAVAILABLE); assert.equal(error.safeDetails.tool_name, CONTEXT.toolName); assert.equal(error.safeDetails.fixed_observer_id, CONTEXT.observerId); assert.equal(error.safeDetails.final_failure_stage, "FETCH");
  assert.equal(serialized.includes("secret-value"), false); assert.equal(serialized.includes("private-value"), false); assert.equal(serialized.includes("stack"), false);
});

test("read resilience constructs no GitHub transport", async () => {
  let constructors = 0; const { reader } = harness(async () => jsonResponse({ observer_id: "grok-x-protocol" })); await reader(ENV, CONTEXT); assert.equal(constructors, 0);
});

test("read resilience sends no api.github.com request", async () => {
  const hosts = []; const { reader } = harness(async (url) => { hosts.push(new URL(url).host); return jsonResponse({ observer_id: "grok-x-protocol" }); }); await reader(ENV, CONTEXT); assert.deepEqual(hosts, [new URL(FIXED_CONTROL_ROOM_ORIGIN).host]);
});

test("read resilience creates no publication mutation", async () => {
  const deltas = { issues: 0, workflows: 0, observations: 0, commits: 0, pointers: 0 }; const { reader } = harness(async () => jsonResponse({ observer_id: "grok-x-protocol" })); await reader(ENV, CONTEXT); assert.deepEqual(deltas, { issues: 0, workflows: 0, observations: 0, commits: 0, pointers: 0 });
});

test("writable publication bootstrap remains single-attempt and constructs no GitHub transport on upstream failure", async () => {
  const connector = CONNECTORS[0];
  const token = "synthetic-r12f-writable-scope-token-abcdefghijklmnopqrstuvwxyz";
  let upstreamCalls = 0; let resolverCalls = 0; let transportConstructors = 0;
  const gateway = createGateway({
    fetchImpl: async (url, init) => {
      upstreamCalls += 1;
      assert.equal(url, `${FIXED_CONTROL_ROOM_ORIGIN}/api/v1/external-observers/bootstrap/${connector.observerId}`);
      assert.equal(init.method, "GET");
      return jsonResponse({ private_body: "not reflected" }, { status: 503 });
    },
    credentialSelector: () => "TOKEN",
    credentialResolver: async () => { resolverCalls += 1; throw new Error("resolver must not run"); },
    transportFactory: () => { transportConstructors += 1; throw new Error("transport must not run"); },
    readerOptions: { sleep: async () => { throw new Error("single-attempt write bootstrap must not sleep"); } },
  });
  const response = await gateway.fetch(new Request(`https://gateway.test${connector.path}`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: "writable-single-attempt",
      method: "tools/call",
      params: { name: connector.publishTool, arguments: writableArgs(connector) },
    }),
  }), {
    [connector.tokenLabel]: token,
    PUBLICATION_MODE: "SYNTHETIC_ONLY",
    CONTROL_ROOM_ORIGIN: FIXED_CONTROL_ROOM_ORIGIN,
  });
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.result.isError, true);
  assert.equal(body.result.structuredContent.error, "TOOL_EXECUTION_FAILED");
  assert.equal(body.result.structuredContent.message, "Control Room publication bootstrap is unavailable");
  assert.deepEqual({ upstreamCalls, resolverCalls, transportConstructors }, { upstreamCalls: 1, resolverCalls: 0, transportConstructors: 0 });
  assert.equal(JSON.stringify(body).includes("private_body"), false);
});
