import { canonicalJson } from "./contracts.mjs";

const OBSERVATION_SCHEMA = "pulsechain-external-observation@1.0.0";
const CLASSIFICATION = "PENDING_SPECIALIST_REVIEW";
const OBSERVERS = new Set(["grok-x-protocol", "grok-infrastructure-incidents", "grok-market-liquidity", "grok-identity-evidence", "grok-red-team"]);
const WORKSTREAMS = new Set(["signals-platform", "validator-flows", "identity-attribution", "investor-intelligence"]);
const SOURCE_CLASSES = new Set(["X_POST", "X_THREAD", "OFFICIAL_WEB", "STATUS_PAGE", "GITHUB", "LEGAL_OR_CORPORATE_RECORD", "SIGNED_MESSAGE", "DETERMINISTIC_CHAIN_ALERT", "PUBLIC_SECONDARY_SOURCE", "MULTI_SOURCE"]);
const EVIDENCE_STATES = new Set(["PROVISIONAL_EXTERNAL_SIGNAL", "EXTERNAL_REVIEW_FINDING", "SOURCE_CHANGE_ALERT", "NEGATIVE_SEARCH_RESULT"]);
const MATERIALITY = new Set(["LOW", "MEDIUM", "HIGH", "CRITICAL"]);
const CONFIDENCE = new Set(["LOW", "MEDIUM", "HIGH"]);
const HASH = /^sha256:[0-9a-f]{64}$/u;
const OBSERVATION_ID = /^[a-z0-9-]{20,120}$/u;
const SECRET = /(?:-----BEGIN [A-Z ]*PRIVATE KEY-----|gh[opsu]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|xox[baprs]-[A-Za-z0-9-]{10,}|AKIA[0-9A-Z]{16}|(?:api[_-]?key|access[_-]?token|private[_-]?key|seed[_-]?phrase|mnemonic)\s*[:=]\s*["']?[^\s"']{8,})/iu;

export class ObservationValidationError extends TypeError {
  constructor(code, detail) { super(`${code}: ${detail}`); this.code = code; }
}
function fail(code, detail) { throw new ObservationValidationError(code, detail); }
function plain(value) { return Boolean(value && typeof value === "object" && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype); }
function exactKeys(value, keys, label) {
  if (!plain(value)) fail("INVALID_OBJECT", label);
  const expected = new Set(keys); const extra = Object.keys(value).find((key) => !expected.has(key)); const missing = keys.find((key) => !(key in value));
  if (extra || missing) fail("SCHEMA_FIELD_MISMATCH", `${label}:${extra ? `extra:${extra}` : `missing:${missing}`}`);
}
function safeText(value, label, maximum, allowEmpty = false) {
  if (typeof value !== "string" || value.length > maximum || value.includes("\0") || (!allowEmpty && !value.trim())) fail("INVALID_TEXT", label);
  return value;
}
function iso(value, label, nullable = false) {
  if (nullable && value === null) return null;
  const result = safeText(value, label, 40);
  if (!result.endsWith("Z") || Number.isNaN(Date.parse(result))) fail("INVALID_TIMESTAMP", label);
  return result;
}
function array(value, label, maximum, validate, minimum = 0) {
  if (!Array.isArray(value) || value.length < minimum || value.length > maximum) fail("INVALID_ARRAY", label);
  const result = value.map(validate);
  if (new Set(result.map((item) => typeof item === "string" ? item : JSON.stringify(item))).size !== result.length) fail("DUPLICATE_ARRAY_ITEM", label);
  return result;
}
function validateHash(value, label) { if (typeof value !== "string" || !HASH.test(value)) fail("INVALID_SHA256", label); return value; }
function stringArray(value, label, maximum, itemMaximum = 500) { return array(value, label, maximum, (item, index) => safeText(item, `${label}[${index}]`, itemMaximum, true)); }
async function sha256(value) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return `sha256:${[...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("")}`;
}

export async function validateObservationPortable(value, fixedObserver) {
  const fields = ["schema_version", "observation_id", "observer_id", "generated_at_utc", "observed_window", "source_class", "source_records", "claim_summary", "what_changed", "why_material", "materiality", "confidence", "evidence_state", "target_workstreams", "related_assets", "related_addresses", "related_contracts", "related_transactions", "related_update_ids", "specialist_questions", "prohibited_inferences", "duplicate_check", "recheck_at_utc", "adjudication_state", "synthetic_canary", "public_safe", "raw_sensitive_material_included", "content_sha256"];
  exactKeys(value, fields, "observation");
  if (value.schema_version !== OBSERVATION_SCHEMA || !OBSERVATION_ID.test(value.observation_id || "") || !OBSERVERS.has(value.observer_id) || value.observer_id !== fixedObserver) fail("OBSERVATION_IDENTITY_INVALID", value.observation_id || "missing");
  const generated = iso(value.generated_at_utc, "generated_at_utc");
  exactKeys(value.observed_window, ["from_utc", "to_utc"], "observed_window");
  const from = iso(value.observed_window.from_utc, "observed_window.from_utc"); const to = iso(value.observed_window.to_utc, "observed_window.to_utc");
  if (Date.parse(from) > Date.parse(to) || Date.parse(to) > Date.parse(generated)) fail("OBSERVED_WINDOW_INVALID", value.observation_id);
  if (!SOURCE_CLASSES.has(value.source_class)) fail("SOURCE_CLASS_INVALID", value.source_class);
  const sources = array(value.source_records, "source_records", 20, (source, index) => {
    exactKeys(source, ["url", "source_id", "author_or_domain", "published_at_utc", "retrieved_at_utc", "content_sha256", "primary_source", "authenticated_source"], `source_records[${index}]`);
    let url; try { url = new URL(safeText(source.url, `source_records[${index}].url`, 2000)); } catch { fail("SOURCE_URL_INVALID", String(source.url)); }
    if (!new Set(["http:", "https:"]).has(url.protocol) || typeof source.primary_source !== "boolean" || typeof source.authenticated_source !== "boolean") fail("SOURCE_RECORD_INVALID", String(index));
    return { url: url.toString(), source_id: safeText(source.source_id, `source_records[${index}].source_id`, 160), author_or_domain: safeText(source.author_or_domain, `source_records[${index}].author_or_domain`, 300), published_at_utc: iso(source.published_at_utc, `source_records[${index}].published_at_utc`, true), retrieved_at_utc: iso(source.retrieved_at_utc, `source_records[${index}].retrieved_at_utc`), content_sha256: validateHash(source.content_sha256, `source_records[${index}].content_sha256`), primary_source: source.primary_source, authenticated_source: source.authenticated_source };
  }, 1);
  const claim = safeText(value.claim_summary, "claim_summary", 2000); const changed = safeText(value.what_changed, "what_changed", 1000); const why = safeText(value.why_material, "why_material", 1000);
  if (claim.length + changed.length + why.length > 4000 || !MATERIALITY.has(value.materiality) || !CONFIDENCE.has(value.confidence) || !EVIDENCE_STATES.has(value.evidence_state)) fail("OBSERVATION_CLASSIFICATION_INVALID", value.observation_id);
  const targets = array(value.target_workstreams, "target_workstreams", 4, (item) => { if (!WORKSTREAMS.has(item)) fail("TARGET_WORKSTREAM_INVALID", String(item)); return item; }, 1);
  exactKeys(value.duplicate_check, ["checked_observation_ids", "duplicate_of", "canonical_duplicate_key"], "duplicate_check");
  const checked = array(value.duplicate_check.checked_observation_ids, "checked_observation_ids", 100, (item) => { if (!OBSERVATION_ID.test(item || "")) fail("CHECKED_OBSERVATION_ID_INVALID", String(item)); return item; });
  if (value.duplicate_check.duplicate_of !== null && !OBSERVATION_ID.test(value.duplicate_check.duplicate_of || "")) fail("DUPLICATE_OF_INVALID", String(value.duplicate_check.duplicate_of));
  validateHash(value.duplicate_check.canonical_duplicate_key, "canonical_duplicate_key");
  if (value.adjudication_state !== CLASSIFICATION || typeof value.synthetic_canary !== "boolean" || value.public_safe !== true || value.raw_sensitive_material_included !== false) fail("AUTHORITY_OR_PRIVACY_STATE_INVALID", value.observation_id);
  validateHash(value.content_sha256, "content_sha256");
  const identity = { ...value };
  delete identity.content_sha256;
  if (await sha256(canonicalJson(identity)) !== value.content_sha256) fail("CONTENT_HASH_MISMATCH", value.observation_id);
  if (SECRET.test(canonicalJson(value))) fail("PRIVATE_DATA_REJECTED", value.observation_id);
  return { ...value, generated_at_utc: generated, observed_window: { from_utc: from, to_utc: to }, source_records: sources, claim_summary: claim, what_changed: changed, why_material: why, target_workstreams: targets, related_assets: stringArray(value.related_assets, "related_assets", 20, 300), related_addresses: stringArray(value.related_addresses, "related_addresses", 10, 200), related_contracts: stringArray(value.related_contracts, "related_contracts", 10, 200), related_transactions: stringArray(value.related_transactions, "related_transactions", 10, 200), related_update_ids: stringArray(value.related_update_ids, "related_update_ids", 20, 160), specialist_questions: stringArray(value.specialist_questions, "specialist_questions", 10, 500), prohibited_inferences: stringArray(value.prohibited_inferences, "prohibited_inferences", 10, 500), duplicate_check: { checked_observation_ids: checked, duplicate_of: value.duplicate_check.duplicate_of, canonical_duplicate_key: value.duplicate_check.canonical_duplicate_key }, recheck_at_utc: iso(value.recheck_at_utc, "recheck_at_utc", true) };
}
