export const GITHUB_CREDENTIAL_REQUIRED = "GITHUB_PUBLICATION_CREDENTIAL_REQUIRED";

export const GITHUB_CREDENTIAL_METHOD = Object.freeze({
  APP: "GITHUB_APP",
  TOKEN: "FINE_GRAINED_ISSUES_TOKEN",
});

const APP_LABELS = Object.freeze([
  "EXTERNAL_OBSERVER_GITHUB_APP_ID",
  "EXTERNAL_OBSERVER_GITHUB_INSTALLATION_ID",
  "EXTERNAL_OBSERVER_GITHUB_PRIVATE_KEY",
]);
const TOKEN_LABEL = "EXTERNAL_OBSERVER_GITHUB_ISSUES_TOKEN";
const ALLOWED_LABELS = new Set([...APP_LABELS, TOKEN_LABEL]);

let cachedInstallationToken = null;

export class GitHubPublicationCredentialError extends Error {
  constructor(reason) {
    super(GITHUB_CREDENTIAL_REQUIRED);
    this.name = "GitHubPublicationCredentialError";
    this.code = GITHUB_CREDENTIAL_REQUIRED;
    this.reason = reason;
  }
}

function failCredential(reason) {
  throw new GitHubPublicationCredentialError(reason);
}

function labelPresent(env, label) {
  return Object.prototype.hasOwnProperty.call(env, label) && env[label] !== undefined && env[label] !== null && env[label] !== "";
}

function validToken(value) {
  return typeof value === "string" && value.length >= 20 && value.length <= 512 && /^[A-Za-z0-9_]+$/u.test(value);
}

function validAppId(value) {
  return typeof value === "string" && /^[1-9][0-9]*$/u.test(value);
}

function validPrivateKey(value) {
  if (typeof value !== "string" || value.length > 32_768) return false;
  const match = value.match(/^-----BEGIN PRIVATE KEY-----\r?\n([A-Za-z0-9+/=\r\n]+)\r?\n-----END PRIVATE KEY-----\r?\n?$/u);
  return Boolean(match && match[1].replace(/\s/gu, "").length >= 64);
}

export function selectGitHubCredentialMethod(env = {}) {
  for (const label of Object.keys(env)) {
    if (label.startsWith("EXTERNAL_OBSERVER_GITHUB_") && !ALLOWED_LABELS.has(label)) failCredential("MALFORMED_CREDENTIAL_LABEL");
  }

  const tokenPresent = labelPresent(env, TOKEN_LABEL);
  const appPresence = APP_LABELS.map((label) => labelPresent(env, label));
  const appPresentCount = appPresence.filter(Boolean).length;
  const appComplete = appPresentCount === APP_LABELS.length;
  const appPartial = appPresentCount > 0 && !appComplete;

  if (tokenPresent && !validToken(env[TOKEN_LABEL])) failCredential("MALFORMED_FINE_GRAINED_TOKEN");
  if (appPartial) failCredential(tokenPresent ? "MIXED_PARTIAL_CREDENTIALS" : "PARTIAL_GITHUB_APP_CREDENTIALS");
  if (appComplete) {
    if (!validAppId(env[APP_LABELS[0]]) || !validAppId(env[APP_LABELS[1]]) || !validPrivateKey(env[APP_LABELS[2]])) failCredential("MALFORMED_GITHUB_APP_CREDENTIALS");
    // The accepted R12 contract designates the GitHub App as preferred and the
    // fine-grained issues token as fallback, so a complete App wins deterministically.
    return GITHUB_CREDENTIAL_METHOD.APP;
  }
  if (tokenPresent) return GITHUB_CREDENTIAL_METHOD.TOKEN;
  failCredential("CREDENTIAL_ABSENT");
}

function base64url(bytes) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/u, "");
}

function pemBytes(pem) {
  const body = pem.replace(/-----BEGIN PRIVATE KEY-----|-----END PRIVATE KEY-----|\s/gu, "");
  if (!body || !/^[A-Za-z0-9+/=]+$/u.test(body)) throw new Error("GitHub App private key is invalid");
  return Uint8Array.from(atob(body), (character) => character.charCodeAt(0));
}

async function appJwt(appId, privateKey) {
  if (!/^[0-9]+$/u.test(appId || "")) throw new Error("GitHub App ID is invalid");
  const now = Math.floor(Date.now() / 1000);
  const header = base64url(new TextEncoder().encode(JSON.stringify({ alg: "RS256", typ: "JWT" })));
  const payload = base64url(new TextEncoder().encode(JSON.stringify({ iat: now - 30, exp: now + 540, iss: appId })));
  const input = `${header}.${payload}`;
  const key = await crypto.subtle.importKey("pkcs8", pemBytes(privateKey), { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  const signature = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(input));
  return `${input}.${base64url(new Uint8Array(signature))}`;
}

export async function resolveGitHubIssuesToken(env, fetchImpl = fetch, selectedMethod = selectGitHubCredentialMethod(env)) {
  if (selectedMethod === GITHUB_CREDENTIAL_METHOD.TOKEN) return env[TOKEN_LABEL];
  if (selectedMethod !== GITHUB_CREDENTIAL_METHOD.APP) failCredential("UNSUPPORTED_CREDENTIAL_METHOD");
  const appId = env[APP_LABELS[0]];
  const installationId = env[APP_LABELS[1]];
  const privateKey = env[APP_LABELS[2]];
  if (cachedInstallationToken && cachedInstallationToken.expiresAt > Date.now() + 60_000) return cachedInstallationToken.token;
  const jwt = await appJwt(appId, privateKey);
  const response = await fetchImpl(`https://api.github.com/app/installations/${installationId}/access_tokens`, {
    method: "POST",
    headers: { Accept: "application/vnd.github+json", Authorization: `Bearer ${jwt}`, "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "pulsechain-external-observer-grok-mcp" },
  });
  if (!response.ok) throw new Error(`GitHub App installation token request returned HTTP ${response.status}`);
  const body = await response.json();
  if (typeof body.token !== "string" || body.token.length < 20 || Number.isNaN(Date.parse(body.expires_at))) throw new Error("GitHub App installation token response is invalid");
  cachedInstallationToken = { token: body.token, expiresAt: Date.parse(body.expires_at) };
  return body.token;
}
