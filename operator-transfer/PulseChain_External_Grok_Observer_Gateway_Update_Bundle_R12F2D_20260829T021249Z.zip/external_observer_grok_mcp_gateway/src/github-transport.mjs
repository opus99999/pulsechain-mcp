import { canonicalJson } from "./contracts.mjs";

const API_ROOT = "https://api.github.com/repos/opus99999/pulsechain-mcp";
const RECEIPT_MARKER = "<!-- pulsechain-external-observer-machine-receipt@1.0.0 -->";

function exactObject(value, fields, label) {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some((key) => !fields.includes(key)) || fields.some((key) => !(key in value))) throw new TypeError(`${label} field mismatch`);
}

function parseReceipt(body) {
  if (typeof body !== "string" || !body.includes(RECEIPT_MARKER)) return null;
  const match = body.slice(body.indexOf(RECEIPT_MARKER) + RECEIPT_MARKER.length).match(/^\s*```json\s*\n([^\n]+)\n```\s*$/u);
  if (!match) throw new Error("Machine receipt comment is malformed");
  const receipt = JSON.parse(match[1]);
  if (canonicalJson(receipt) !== match[1]) throw new Error("Machine receipt is not canonical");
  return receipt;
}

export function createPortableGitHubTransport({ githubToken, fetchImpl = fetch, sleep = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds)), maxPolls = 20, pollIntervalMs = 3_000 }) {
  if (typeof githubToken !== "string" || githubToken.length < 20 || maxPolls !== 20 || pollIntervalMs !== 3_000) throw new TypeError("GitHub transport configuration is invalid");
  const headers = { Accept: "application/vnd.github+json", Authorization: `Bearer ${githubToken}`, "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "pulsechain-external-observer-grok-mcp" };
  async function request(url, init = {}) {
    const response = await fetchImpl(url, { ...init, headers: { ...headers, ...(init.headers || {}) } });
    if (!response.ok) throw new Error(`GitHub transport returned HTTP ${response.status}`);
    return response.json();
  }
  return Object.freeze({
    async createIssue(args) {
      exactObject(args, ["title", "body"], "issue request");
      if (!args.title.startsWith("EXTERNAL OBSERVER SUBMISSION — ") || args.title.length > 256 || canonicalJson(JSON.parse(args.body)) !== args.body) throw new TypeError("Issue request is invalid");
      const issue = await request(`${API_ROOT}/issues`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title: args.title, body: args.body }) });
      if (!Number.isSafeInteger(issue.number) || issue.number < 1) throw new Error("Issue creation receipt is invalid");
      return { issue_number: issue.number, created_at_utc: issue.created_at, issue_url: issue.html_url };
    },
    async waitForReceipt(criteria) {
      exactObject(criteria, ["issue_number", "observer_id", "observation_id", "submission_nonce", "expected_head"], "receipt criteria");
      for (let attempt = 1; attempt <= maxPolls; attempt += 1) {
        const comments = await request(`${API_ROOT}/issues/${criteria.issue_number}/comments?per_page=100`);
        const receipts = comments.filter((comment) => typeof comment?.body === "string" && comment.body.includes(RECEIPT_MARKER)).map((comment) => {
          if (comment.user?.login !== "github-actions[bot]") throw new Error("Machine receipt author is invalid");
          return parseReceipt(comment.body);
        });
        for (const receipt of receipts) for (const field of ["issue_number", "observer_id", "observation_id", "submission_nonce"]) if (receipt[field] !== criteria[field]) throw new Error("Foreign machine receipt rejected");
        if (receipts.length > 1 && new Set(receipts.map(canonicalJson)).size > 1) throw new Error("Conflicting machine receipts rejected");
        if (receipts.length) return receipts[0];
        if (attempt < maxPolls) await sleep(pollIntervalMs);
      }
      throw new Error("PUBLICATION_RECEIPT_TIMEOUT");
    },
  });
}
