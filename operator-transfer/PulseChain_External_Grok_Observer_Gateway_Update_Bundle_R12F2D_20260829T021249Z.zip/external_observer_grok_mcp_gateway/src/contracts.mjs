import boundInput from "../../BOUND_OBSERVATION_INPUT_SCHEMA.json" with { type: "json" };
import observationSchema from "../../OBSERVATION_SCHEMA.json" with { type: "json" };

export const PROTOCOL_VERSION = "2025-06-18";
export const PUBLICATION_MODE = "DISABLED";
export const DISABLED_CODE = "PUBLICATION_MODE_DISABLED";

export const CONNECTORS = Object.freeze([
  Object.freeze({ observerId: "grok-x-protocol", path: "/mcp/external-observers/grok-x-protocol", publishTool: "publish_external_observation_grok_x_protocol", tokenLabel: "GROK_MCP_TOKEN_X_PROTOCOL" }),
  Object.freeze({ observerId: "grok-infrastructure-incidents", path: "/mcp/external-observers/grok-infrastructure-incidents", publishTool: "publish_external_observation_grok_infrastructure_incidents", tokenLabel: "GROK_MCP_TOKEN_INFRASTRUCTURE_INCIDENTS" }),
  Object.freeze({ observerId: "grok-market-liquidity", path: "/mcp/external-observers/grok-market-liquidity", publishTool: "publish_external_observation_grok_market_liquidity", tokenLabel: "GROK_MCP_TOKEN_MARKET_LIQUIDITY" }),
  Object.freeze({ observerId: "grok-identity-evidence", path: "/mcp/external-observers/grok-identity-evidence", publishTool: "publish_external_observation_grok_identity_evidence", tokenLabel: "GROK_MCP_TOKEN_IDENTITY_EVIDENCE" }),
  Object.freeze({ observerId: "grok-red-team", path: "/mcp/external-observers/grok-red-team", publishTool: "publish_external_observation_grok_red_team", tokenLabel: "GROK_MCP_TOKEN_RED_TEAM" }),
]);

const WORKSTREAM_SCHEMA = Object.freeze({
  type: "object",
  additionalProperties: false,
  required: ["workstream_id"],
  properties: { workstream_id: { enum: ["signals-platform", "validator-flows", "identity-attribution", "investor-intelligence"] } },
});

const OBSERVATION_READ_SCHEMA = Object.freeze({
  type: "object",
  additionalProperties: false,
  required: ["observation_id"],
  properties: { observation_id: { type: "string", pattern: "^[a-z0-9-]{20,120}$" } },
});

function dereference(node) {
  if (Array.isArray(node)) return node.map(dereference);
  if (!node || typeof node !== "object") return node;
  if (typeof node.$ref === "string") {
    const match = node.$ref.match(/^OBSERVATION_SCHEMA\.json#\/properties\/([A-Za-z0-9_]+)$/);
    if (!match || !observationSchema.properties[match[1]]) throw new Error("Unsupported schema reference");
    return dereference(observationSchema.properties[match[1]]);
  }
  return Object.fromEntries(Object.entries(node).filter(([key]) => key !== "server_binding").map(([key, value]) => [key, dereference(value)]));
}

export function publishInputSchema() {
  const schema = dereference(structuredClone(boundInput));
  schema.description = "Model-controlled public observation fields. Connector identity is injected by the service.";
  return schema;
}

export function toolsFor(connector) {
  return [
    { name: connector.publishTool, description: "Validate and submit one public-safe provisional observation using this connector's fixed server binding.", inputSchema: publishInputSchema() },
    { name: "read_external_observer_bootstrap", description: "Read this connector's current observer bootstrap.", inputSchema: { type: "object", additionalProperties: false, properties: {} } },
    { name: "read_workstream_bootstrap", description: "Read one current specialist workstream bootstrap.", inputSchema: WORKSTREAM_SCHEMA },
    { name: "read_external_observation", description: "Read one accepted public external observation.", inputSchema: OBSERVATION_READ_SCHEMA },
  ];
}

export function canonicalJson(value) {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (value && typeof value === "object") return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(",")}}`;
  return JSON.stringify(value);
}

export async function discoveryFingerprint(connector) {
  const bytes = new TextEncoder().encode(canonicalJson(toolsFor(connector)));
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return `sha256:${[...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("")}`;
}
