export const FIXED_CONTROL_ROOM_ORIGIN = "https://pulsechain-research-control-room.brohexphiat.chatgpt.site";
export const CONTROL_ROOM_UPSTREAM_UNAVAILABLE = "CONTROL_ROOM_UPSTREAM_UNAVAILABLE";
// Route caps leave substantial headroom above the governed ~50 KiB bootstraps while bounding
// the Worker memory needed for chunk storage, contiguous decoding, JSON parsing, and MCP output.
export const CONTROL_ROOM_RESPONSE_LIMITS = Object.freeze({
  read_external_observer_bootstrap: 4 * 1024 * 1024,
  read_workstream_bootstrap: 8 * 1024 * 1024,
  read_external_observation: 4 * 1024 * 1024,
});
export const CONTROL_ROOM_READ_POLICY = Object.freeze({
  maximumAttempts: 3,
  perAttemptTimeoutMs: 12_000,
  retryDelaysMs: Object.freeze([250, 1_000]),
  totalDeadlineMs: 40_000,
  maximumRetryAfterMs: 5_000,
  maximumResponseBytes: 8 * 1024 * 1024,
});

const RETRYABLE_HTTP = new Set([408, 429, 500, 502, 503, 504]);
const SAFE_PATH = /^\/api\/v1\/(?:external-observers|trusted-team\/bootstrap\/)[A-Za-z0-9_./-]*$/u;
const JSON_CONTENT_TYPE = /^application\/(?:[A-Za-z0-9!#$&^_.+-]+\+)?json$/iu;
const SECRET_PATTERN = /(?:Bearer\s+\S+|gh[opsu]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|(?:token|authorization|cookie|ciphertext)\s*[:=]\s*\S+)/giu;

export class ControlRoomReadError extends Error {
  constructor(code, details) {
    super(code);
    this.name = "ControlRoomReadError";
    this.code = code;
    this.safeDetails = Object.freeze({ error: code, ...details });
  }
}

function sanitizeText(value, fallback) {
  const text = typeof value === "string" && value.trim() ? value : fallback;
  return text.replace(SECRET_PATTERN, "[REDACTED]").replace(/[\r\n\t]+/gu, " ").slice(0, 320);
}

function safeErrorClass(error) {
  return new Set(["AbortError", "ControlRoomReadError", "Error", "NetworkError", "SyntaxError", "TypeError"]).has(error?.name) ? error.name : "Error";
}

function responseRequestId(response) {
  for (const name of ["cf-ray", "x-request-id", "x-correlation-id", "x-amzn-requestid"]) {
    const value = response.headers.get(name);
    if (value && /^[A-Za-z0-9._:/-]{1,160}$/u.test(value)) return value;
  }
  return null;
}

function jsonContentType(response) {
  const mediaType = (response.headers.get("content-type") || "").split(";", 1)[0].trim().toLowerCase();
  return /^[a-z0-9!#$&^_.+-]{1,64}\/[a-z0-9!#$&^_.+-]{1,64}$/u.test(mediaType) ? mediaType : "";
}

function parseRetryAfter(value, nowMs) {
  if (!value) return null;
  const trimmed = value.trim();
  if (/^\d+(?:\.\d+)?$/u.test(trimmed)) return Math.max(0, Math.ceil(Number(trimmed) * 1_000));
  const date = Date.parse(trimmed);
  return Number.isFinite(date) ? Math.max(0, date - nowMs) : null;
}

async function cancelBody(response) {
  try { await response?.body?.cancel(); } catch { /* response cleanup is best-effort and never changes classification */ }
}

async function boundedBody(response, maximumBytes) {
  const claimed = response.headers.get("content-length");
  if (claimed !== null) {
    const size = Number(claimed);
    if (!Number.isSafeInteger(size) || size < 0 || size > maximumBytes) {
      await cancelBody(response);
      throw new ControlRoomReadError("CONTROL_ROOM_UPSTREAM_RESPONSE_TOO_LARGE", { final_failure_stage: "RESPONSE_SIZE_VALIDATION" });
    }
  }
  if (!response.body) return new Uint8Array();
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maximumBytes) {
        await reader.cancel();
        throw new ControlRoomReadError("CONTROL_ROOM_UPSTREAM_RESPONSE_TOO_LARGE", { final_failure_stage: "RESPONSE_SIZE_VALIDATION" });
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
  return bytes;
}

function defaultSleep(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) { reject(new DOMException("Caller canceled the Control Room read", "AbortError")); return; }
    const finish = () => { signal?.removeEventListener("abort", abort); resolve(); };
    const timer = setTimeout(finish, ms);
    const abort = () => { clearTimeout(timer); signal?.removeEventListener("abort", abort); reject(new DOMException("Caller canceled the Control Room read", "AbortError")); };
    signal?.addEventListener("abort", abort, { once: true });
  });
}

function fixedOrigin(env) {
  if (env?.CONTROL_ROOM_ORIGIN !== undefined && env.CONTROL_ROOM_ORIGIN !== FIXED_CONTROL_ROOM_ORIGIN) {
    throw new ControlRoomReadError("CONTROL_ROOM_ORIGIN_INVALID", { final_failure_stage: "INTERNAL_VALIDATION" });
  }
  return FIXED_CONTROL_ROOM_ORIGIN;
}

function safeDetails(context, telemetry, last, elapsedMs) {
  return {
    message: "Control Room public read is temporarily unavailable",
    tool_name: context.toolName,
    fixed_observer_id: context.observerId,
    target_workstream: context.targetWorkstream ?? null,
    control_room_origin: FIXED_CONTROL_ROOM_ORIGIN,
    target_path: context.path,
    attempt_count: telemetry.transport_attempt_count,
    retry_count: Math.max(0, telemetry.transport_attempt_count - 1),
    logical_upstream_operation_count: 1,
    transport_attempt_count: telemetry.transport_attempt_count,
    total_elapsed_ms: Math.max(0, Math.round(elapsedMs)),
    last_http_status: last.httpStatus,
    last_content_type: last.contentType,
    last_error_class: last.errorClass,
    last_error_message: last.errorMessage,
    retry_after_observed: telemetry.retry_after_observed,
    retry_after_applied_ms: telemetry.retry_after_applied_ms,
    final_failure_stage: last.stage,
    upstream_request_id: last.requestId,
  };
}

function emitTelemetry(sink, telemetry, result) {
  sink?.(Object.freeze({
    logical_operation_count: 1,
    transport_attempt_count: telemetry.transport_attempt_count,
    retry_count: Math.max(0, telemetry.transport_attempt_count - 1),
    retry_after_observed: telemetry.retry_after_observed,
    retry_after_applied_ms: telemetry.retry_after_applied_ms,
    backoff_delay_applied_ms_total: telemetry.backoff_delay_applied_ms_total,
    attempts: telemetry.attempts.map((entry) => Object.freeze({ ...entry })),
    final_result: result,
  }));
}

function classifyNonretryable(error, fallbackStage) {
  if (error instanceof ControlRoomReadError) return error;
  if (error instanceof SyntaxError) return new ControlRoomReadError("CONTROL_ROOM_UPSTREAM_INVALID_JSON", { final_failure_stage: "JSON_PARSE" });
  return new ControlRoomReadError("CONTROL_ROOM_UPSTREAM_INVALID_RESPONSE", { final_failure_stage: fallbackStage });
}

export function createControlRoomReader({
  fetchImpl = fetch,
  now = () => Date.now(),
  wallNow = () => Date.now(),
  sleep = defaultSleep,
  setTimer = setTimeout,
  clearTimer = clearTimeout,
  telemetrySink = null,
  policy = CONTROL_ROOM_READ_POLICY,
} = {}) {
  return async function readControlRoomJson(env, context) {
    if (!context || typeof context !== "object" || !SAFE_PATH.test(context.path || "") || context.path.includes("?") || context.path.includes("#")) {
      throw new ControlRoomReadError("CONTROL_ROOM_READ_PATH_INVALID", { final_failure_stage: "INTERNAL_VALIDATION" });
    }
    const origin = fixedOrigin(env);
    const started = now();
    const telemetry = { transport_attempt_count: 0, retry_after_observed: false, retry_after_applied_ms: 0, backoff_delay_applied_ms_total: 0, attempts: [] };
    let last = { httpStatus: null, contentType: null, errorClass: null, errorMessage: null, stage: "FETCH", requestId: null };

    for (let attempt = 1; attempt <= policy.maximumAttempts; attempt += 1) {
      if (context.signal?.aborted) {
        last = { ...last, errorClass: "AbortError", errorMessage: "Caller canceled the Control Room read", stage: "CALLER_CANCELLATION" };
        const details = safeDetails(context, telemetry, last, now() - started);
        emitTelemetry(telemetrySink, telemetry, "CALLER_CANCELLED");
        throw new ControlRoomReadError("CONTROL_ROOM_REQUEST_CANCELLED", details);
      }
      const remaining = policy.totalDeadlineMs - (now() - started);
      if (remaining <= 0) break;

      telemetry.transport_attempt_count += 1;
      const attemptStarted = now();
      const controller = new AbortController();
      let timedOut = false;
      let timer = null;
      let callerAbort = null;
      let response = null;
      try {
        const timeoutMs = Math.max(1, Math.min(policy.perAttemptTimeoutMs, remaining));
        const timeoutPromise = new Promise((_, reject) => {
          timer = setTimer(() => {
            timedOut = true;
            controller.abort(new DOMException("Control Room read attempt timed out", "AbortError"));
            reject(new DOMException("Control Room read attempt timed out", "AbortError"));
          }, timeoutMs);
        });
        const callerAbortPromise = new Promise((_, reject) => {
          callerAbort = () => {
            controller.abort(context.signal?.reason);
            reject(new DOMException("Caller canceled the Control Room read", "AbortError"));
          };
          context.signal?.addEventListener("abort", callerAbort, { once: true });
        });
        response = await Promise.race([
          fetchImpl(`${origin}${context.path}`, { method: "GET", headers: { Accept: "application/json" }, cache: "no-store", redirect: "manual", signal: controller.signal }),
          timeoutPromise,
          callerAbortPromise,
        ]);
        const contentType = jsonContentType(response);
        const requestId = responseRequestId(response);
        last = { httpStatus: response.status, contentType: contentType || null, errorClass: null, errorMessage: null, stage: "HTTP_STATUS", requestId };

        const location = response.headers.get("location");
        const redirectedOrigin = location && response.status >= 300 && response.status < 400 ? new URL(location, `${origin}${context.path}`).origin : null;
        if ((response.url && new URL(response.url).origin !== origin) || (redirectedOrigin && redirectedOrigin !== origin)) {
          await cancelBody(response);
          throw new ControlRoomReadError("CONTROL_ROOM_UPSTREAM_REDIRECT_REJECTED", { final_failure_stage: "REDIRECT_VALIDATION" });
        }
        if (!response.ok) {
          await cancelBody(response);
          const retryable = RETRYABLE_HTTP.has(response.status);
          const retryAfter = parseRetryAfter(response.headers.get("retry-after"), wallNow());
          if (retryAfter !== null) telemetry.retry_after_observed = true;
          last = { ...last, errorClass: "HttpStatusError", errorMessage: `Control Room returned HTTP ${response.status}` };
          telemetry.attempts.push({ attempt, latency_ms: Math.max(0, Math.round(now() - attemptStarted)), http_status: response.status, error_class: "HttpStatusError", result: retryable ? "RETRYABLE" : "FAILED" });
          if (!retryable) {
            const details = safeDetails(context, telemetry, last, now() - started);
            throw new ControlRoomReadError("CONTROL_ROOM_UPSTREAM_HTTP_ERROR", details);
          }
          if (attempt < policy.maximumAttempts) {
            const baseDelay = policy.retryDelaysMs[attempt - 1];
            const applied = Math.min(policy.maximumRetryAfterMs, Math.max(baseDelay, retryAfter ?? 0));
            const delayBudget = policy.totalDeadlineMs - (now() - started);
            if (applied >= delayBudget) break;
            if (retryAfter !== null) telemetry.retry_after_applied_ms = applied;
            telemetry.backoff_delay_applied_ms_total += applied;
            try { await sleep(applied, context.signal); }
            catch {
              const details = safeDetails(context, telemetry, { ...last, errorClass: "AbortError", errorMessage: "Caller canceled the Control Room read", stage: "CALLER_CANCELLATION" }, now() - started);
              throw new ControlRoomReadError("CONTROL_ROOM_REQUEST_CANCELLED", details);
            }
            continue;
          }
          break;
        }
        if (!JSON_CONTENT_TYPE.test(contentType)) {
          await cancelBody(response);
          last = { ...last, errorClass: "ContentTypeError", errorMessage: "Control Room response content type is not JSON", stage: "CONTENT_TYPE_VALIDATION" };
          telemetry.attempts.push({ attempt, latency_ms: Math.max(0, Math.round(now() - attemptStarted)), http_status: response.status, error_class: "ContentTypeError", result: "FAILED" });
          const details = safeDetails(context, telemetry, last, now() - started);
          throw new ControlRoomReadError("CONTROL_ROOM_UPSTREAM_INVALID_CONTENT_TYPE", details);
        }
        const bytes = await boundedBody(response, context.maximumResponseBytes ?? policy.maximumResponseBytes);
        let payload;
        try { payload = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes)); }
        catch (error) { throw classifyNonretryable(error, "JSON_PARSE"); }
        if (context.validate) {
          try { context.validate(payload); }
          catch { throw new ControlRoomReadError("CONTROL_ROOM_UPSTREAM_SCHEMA_MISMATCH", { final_failure_stage: "SCHEMA_VALIDATION" }); }
        }
        telemetry.attempts.push({ attempt, latency_ms: Math.max(0, Math.round(now() - attemptStarted)), http_status: response.status, error_class: null, result: "SUCCESS" });
        emitTelemetry(telemetrySink, telemetry, "SUCCESS");
        return payload;
      } catch (error) {
        if (error instanceof ControlRoomReadError) {
          const embedded = error.safeDetails || {};
          last = {
            ...last,
            errorClass: error.name,
            errorMessage: sanitizeText(error.code, "Control Room response is invalid"),
            stage: embedded.final_failure_stage || last.stage,
          };
          if (!telemetry.attempts.some((entry) => entry.attempt === attempt)) {
            telemetry.attempts.push({ attempt, latency_ms: Math.max(0, Math.round(now() - attemptStarted)), http_status: response?.status ?? null, error_class: error.name, result: "FAILED" });
          }
          const details = safeDetails(context, telemetry, last, now() - started);
          emitTelemetry(telemetrySink, telemetry, error.code);
          throw new ControlRoomReadError(error.code, details);
        }
        if (context.signal?.aborted && !timedOut) {
          last = { ...last, errorClass: "AbortError", errorMessage: "Caller canceled the Control Room read", stage: "CALLER_CANCELLATION" };
          telemetry.attempts.push({ attempt, latency_ms: Math.max(0, Math.round(now() - attemptStarted)), http_status: null, error_class: "AbortError", result: "FAILED" });
          const details = safeDetails(context, telemetry, last, now() - started);
          emitTelemetry(telemetrySink, telemetry, "CALLER_CANCELLED");
          throw new ControlRoomReadError("CONTROL_ROOM_REQUEST_CANCELLED", details);
        }
        const transportFailure = timedOut || error instanceof TypeError || error?.name === "NetworkError";
        if (!transportFailure) {
          last = { httpStatus: null, contentType: null, errorClass: safeErrorClass(error), errorMessage: "Control Room internal validation failed", stage: "INTERNAL_VALIDATION", requestId: null };
          telemetry.attempts.push({ attempt, latency_ms: Math.max(0, Math.round(now() - attemptStarted)), http_status: null, error_class: last.errorClass, result: "FAILED" });
          const details = safeDetails(context, telemetry, last, now() - started);
          emitTelemetry(telemetrySink, telemetry, "NONRETRYABLE_INTERNAL_ERROR");
          throw new ControlRoomReadError("CONTROL_ROOM_UPSTREAM_INVALID_RESPONSE", details);
        }
        const errorClass = timedOut ? "AbortError" : error?.name === "NetworkError" ? "NetworkError" : "TypeError";
        const errorMessage = timedOut ? "Control Room read attempt timed out" : "Control Room transport failed";
        last = { httpStatus: null, contentType: null, errorClass, errorMessage, stage: timedOut ? "ATTEMPT_TIMEOUT" : "FETCH", requestId: null };
        telemetry.attempts.push({ attempt, latency_ms: Math.max(0, Math.round(now() - attemptStarted)), http_status: null, error_class: errorClass, result: attempt < policy.maximumAttempts ? "RETRYABLE" : "FAILED" });
        if (attempt < policy.maximumAttempts) {
          const delay = policy.retryDelaysMs[attempt - 1];
          const delayBudget = policy.totalDeadlineMs - (now() - started);
          if (delay >= delayBudget) break;
          telemetry.backoff_delay_applied_ms_total += delay;
          try { await sleep(delay, context.signal); }
          catch {
            const details = safeDetails(context, telemetry, { ...last, errorClass: "AbortError", errorMessage: "Caller canceled the Control Room read", stage: "CALLER_CANCELLATION" }, now() - started);
            throw new ControlRoomReadError("CONTROL_ROOM_REQUEST_CANCELLED", details);
          }
          continue;
        }
        break;
      } finally {
        if (timer !== null) clearTimer(timer);
        if (callerAbort) context.signal?.removeEventListener("abort", callerAbort);
      }
    }
    const details = safeDetails(context, telemetry, last, now() - started);
    emitTelemetry(telemetrySink, telemetry, "UNAVAILABLE");
    throw new ControlRoomReadError(CONTROL_ROOM_UPSTREAM_UNAVAILABLE, details);
  };
}
