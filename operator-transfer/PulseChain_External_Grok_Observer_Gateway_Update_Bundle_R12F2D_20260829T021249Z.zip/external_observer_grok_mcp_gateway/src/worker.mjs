import { CONNECTORS, DISABLED_CODE, PROTOCOL_VERSION, PUBLICATION_MODE, canonicalJson, discoveryFingerprint, toolsFor } from "./contracts.mjs";
import { GITHUB_CREDENTIAL_REQUIRED, selectGitHubCredentialMethod, resolveGitHubIssuesToken } from "./github-app.mjs";
import { createPortableGitHubTransport } from "./github-transport.mjs";
import { validateObservationPortable } from "./portable-validation.mjs";
import { CONTROL_ROOM_RESPONSE_LIMITS, FIXED_CONTROL_ROOM_ORIGIN, ControlRoomReadError, createControlRoomReader } from "./control-room-reader.mjs";

const CONNECTOR_BY_PATH = new Map(CONNECTORS.map((connector) => [connector.path, connector]));
const FORBIDDEN_IDENTITY_KEYS = new Set(["observerid", "fixedobserverid", "externalobserverid", "observeridentity"]);
const OBSERVATION_ID = /^[a-z0-9-]{20,120}$/u;
const WORKSTREAMS = new Set(["signals-platform", "validator-flows", "identity-attribution", "investor-intelligence"]);
const WRITABLE_MODES = new Set(["SYNTHETIC_ONLY", "PROVISIONAL_LIVE"]);

function jsonResponse(body, status = 200, headers = {}) {
  return new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...headers } });
}

function rpcResult(id, result) { return { jsonrpc: "2.0", id, result }; }
function rpcError(id, code, message) { return { jsonrpc: "2.0", id: id ?? null, error: { code, message } }; }

function exactObject(value, fields, label) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new TypeError(`${label} must be an object`);
  const allowed = new Set(fields);
  if (Object.keys(value).some((key) => !allowed.has(key)) || fields.some((key) => !(key in value))) throw new TypeError(`${label} field mismatch`);
}

function rejectIdentityInjection(value) {
  if (!value || typeof value !== "object") return;
  if (Array.isArray(value)) return value.forEach(rejectIdentityInjection);
  for (const [key, nested] of Object.entries(value)) {
    if (FORBIDDEN_IDENTITY_KEYS.has(key.toLowerCase().replace(/[^a-z0-9]/gu, ""))) throw new TypeError("Model-controlled connector identity is prohibited");
    rejectIdentityInjection(nested);
  }
}

async function equalToken(actual, expected) {
  if (typeof actual !== "string" || typeof expected !== "string" || expected.length < 32) return false;
  const [left, right] = await Promise.all([actual, expected].map((value) => crypto.subtle.digest("SHA-256", new TextEncoder().encode(value))));
  const a = new Uint8Array(left); const b = new Uint8Array(right); let difference = a.length ^ b.length;
  for (let index = 0; index < Math.min(a.length, b.length); index += 1) difference |= a[index] ^ b[index];
  return difference === 0;
}

async function authorize(request, env, connector) {
  const authorization = request.headers.get("Authorization") || "";
  if (!authorization.startsWith("Bearer ")) return false;
  return equalToken(authorization.slice(7), env[connector.tokenLabel]);
}

function toolContent(value, isError = false) {
  return { content: [{ type: "text", text: JSON.stringify(value) }], structuredContent: value, ...(isError ? { isError: true } : {}) };
}

function publicationMode(env) {
  const mode = env.PUBLICATION_MODE || PUBLICATION_MODE;
  if (mode !== PUBLICATION_MODE && !WRITABLE_MODES.has(mode)) throw new Error("Publication mode is invalid");
  return mode;
}

async function readPublicationBootstrapOnce(env, connector, fetchImpl, signal) {
  if (env?.CONTROL_ROOM_ORIGIN !== undefined && env.CONTROL_ROOM_ORIGIN !== FIXED_CONTROL_ROOM_ORIGIN) {
    throw new Error("Control Room publication origin is invalid");
  }
  const response = await fetchImpl(`${FIXED_CONTROL_ROOM_ORIGIN}/api/v1/external-observers/bootstrap/${connector.observerId}`, {
    method: "GET",
    headers: { Accept: "application/json" },
    cache: "no-store",
    redirect: "manual",
    signal,
  });
  if (!response.ok || (response.url && new URL(response.url).origin !== FIXED_CONTROL_ROOM_ORIGIN)) {
    try { await response.body?.cancel(); } catch { /* fixed one-shot publication bootstrap cleanup */ }
    throw new Error("Control Room publication bootstrap is unavailable");
  }
  let payload;
  try { payload = await response.json(); }
  catch { throw new Error("Control Room publication bootstrap is invalid"); }
  if (payload?.observer_id !== connector.observerId || !/^[0-9a-f]{40}$/u.test(payload?.ledger?.repository_head || "")) {
    throw new Error("Control Room publication bootstrap is invalid");
  }
  return payload;
}

function publicationReadiness(env, context) {
  const mode = publicationMode(env);
  if (mode === PUBLICATION_MODE) {
    return {
      publication_mode: mode,
      publication_ready: false,
      github_publication_transport: "DEFERRED_WHILE_DISABLED",
      credential_method: null,
      error_code: null,
      automatic_promotion: false,
    };
  }
  try {
    return {
      publication_mode: mode,
      publication_ready: true,
      github_publication_transport: "CREDENTIAL_GATE_PASSED",
      credential_method: context.selectGitHubCredentialMethod(env),
      error_code: null,
      automatic_promotion: false,
    };
  } catch (error) {
    if (error?.code !== GITHUB_CREDENTIAL_REQUIRED) throw error;
    return {
      publication_mode: mode,
      publication_ready: false,
      github_publication_transport: "CREDENTIAL_REQUIRED",
      credential_method: null,
      error_code: GITHUB_CREDENTIAL_REQUIRED,
      automatic_promotion: false,
    };
  }
}

async function callTool(connector, name, args, env, context) {
  if (name === "read_external_observer_bootstrap") {
    exactObject(args, [], "bootstrap arguments");
    const value = await context.readControlRoomJson(env, {
      toolName: name,
      observerId: connector.observerId,
      path: `/api/v1/external-observers/bootstrap/${connector.observerId}`,
      maximumResponseBytes: CONTROL_ROOM_RESPONSE_LIMITS.read_external_observer_bootstrap,
      signal: context.requestSignal,
      validate: (payload) => { if (payload?.observer_id !== connector.observerId) throw new Error("Observer bootstrap identity is mismatched"); },
    });
    return toolContent(value);
  }
  if (name === "read_workstream_bootstrap") {
    exactObject(args, ["workstream_id"], "workstream arguments");
    if (!WORKSTREAMS.has(args.workstream_id)) throw new TypeError("workstream_id is not registered");
    return toolContent(await context.readControlRoomJson(env, {
      toolName: name,
      observerId: connector.observerId,
      targetWorkstream: args.workstream_id,
      path: `/api/v1/trusted-team/bootstrap/${args.workstream_id}`,
      maximumResponseBytes: CONTROL_ROOM_RESPONSE_LIMITS.read_workstream_bootstrap,
      signal: context.requestSignal,
      validate: (payload) => { if (payload?.requested_workstream_id !== args.workstream_id) throw new Error("Workstream bootstrap identity is mismatched"); },
    }));
  }
  if (name === "read_external_observation") {
    exactObject(args, ["observation_id"], "observation arguments");
    if (!OBSERVATION_ID.test(args.observation_id || "")) throw new TypeError("observation_id is invalid");
    return toolContent(await context.readControlRoomJson(env, {
      toolName: name,
      observerId: connector.observerId,
      path: `/api/v1/external-observers/observations/${args.observation_id}`,
      maximumResponseBytes: CONTROL_ROOM_RESPONSE_LIMITS.read_external_observation,
      signal: context.requestSignal,
      validate: (payload) => { if (payload?.observation?.observation_id !== args.observation_id) throw new Error("Observation identity is mismatched"); },
    }));
  }
  if (name !== connector.publishTool) throw new TypeError("Tool is not available on this connector");
  rejectIdentityInjection(args);
  const observation = await validateObservationPortable({ ...args, observer_id: connector.observerId }, connector.observerId);
  const mode = publicationMode(env);
  if (mode === PUBLICATION_MODE) {
    return toolContent({
      accepted: false,
      error_code: DISABLED_CODE,
      issue_number: null,
      workflow_run_id: null,
      observation_id: null,
      publication_commit: null,
      permanent_url: null,
      manifest_sha256: null,
    });
  }
  if (mode === "SYNTHETIC_ONLY" && observation.synthetic_canary !== true) throw new TypeError("Synthetic-only publication requires a synthetic canary");
  if (mode === "PROVISIONAL_LIVE" && observation.synthetic_canary !== false) throw new TypeError("Provisional-live publication rejects synthetic canaries");
  const credentialMethod = context.selectGitHubCredentialMethod(env);
  const bootstrap = await context.readPublicationBootstrapOnce(env, connector, context.fetchImpl, context.requestSignal);
  if (bootstrap?.observer_id !== connector.observerId || !/^[0-9a-f]{40}$/u.test(bootstrap?.ledger?.repository_head || "")) throw new Error("Observer bootstrap head is unavailable");
  const githubToken = await context.resolveGitHubIssuesToken(env, context.fetchImpl, credentialMethod);
  const transport = context.createGitHubTransport({ githubToken, fetchImpl: context.fetchImpl });
  const nonceBytes = crypto.getRandomValues(new Uint8Array(24));
  const submissionNonce = [...nonceBytes].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  const envelope = { schema_version: "pulsechain-external-observer-publication@1.0.0", expected_repository_head: bootstrap.ledger.repository_head, expected_latest_observation_id: bootstrap.current_observer_latest_id, submission_nonce: submissionNonce, observation };
  const issue = await transport.createIssue({ title: `EXTERNAL OBSERVER SUBMISSION — ${connector.observerId} — ${observation.observation_id}`, body: canonicalJson(envelope) });
  return toolContent(await transport.waitForReceipt({ issue_number: issue.issue_number, observer_id: connector.observerId, observation_id: observation.observation_id, submission_nonce: submissionNonce, expected_head: envelope.expected_repository_head }));
}

async function handleRpc(request, env, connector, context) {
  let message;
  try { message = await request.json(); } catch { return jsonResponse(rpcError(null, -32700, "Parse error"), 400); }
  if (!message || message.jsonrpc !== "2.0" || typeof message.method !== "string") return jsonResponse(rpcError(message?.id, -32600, "Invalid Request"), 400);
  if (!("id" in message)) return new Response(null, { status: 202 });
  if (message.method === "initialize") return jsonResponse(rpcResult(message.id, { protocolVersion: PROTOCOL_VERSION, capabilities: { tools: { listChanged: false } }, serverInfo: { name: `pulsechain-${connector.observerId}-mcp`, version: "1.0.0" }, publication: publicationReadiness(env, context) }));
  if (message.method === "ping") return jsonResponse(rpcResult(message.id, { publication: publicationReadiness(env, context) }));
  if (message.method === "tools/list") {
    const tools = toolsFor(connector);
    return jsonResponse(rpcResult(message.id, { tools }), 200, { "X-PulseChain-Tool-Discovery-Fingerprint": await discoveryFingerprint(connector) });
  }
  if (message.method === "tools/call") {
    try {
      exactObject(message.params, ["name", "arguments"], "tools/call parameters");
      if (typeof message.params.name !== "string") throw new TypeError("Tool name is invalid");
      return jsonResponse(rpcResult(message.id, await callTool(connector, message.params.name, message.params.arguments, env, context)));
    } catch (error) {
      if (error instanceof ControlRoomReadError) return jsonResponse(rpcResult(message.id, toolContent(error.safeDetails, true)));
      const errorCode = error?.code === GITHUB_CREDENTIAL_REQUIRED ? GITHUB_CREDENTIAL_REQUIRED : error instanceof TypeError ? "INVALID_TOOL_INPUT" : "TOOL_EXECUTION_FAILED";
      return jsonResponse(rpcResult(message.id, toolContent({ error: errorCode, message: error.message }, true)));
    }
  }
  return jsonResponse(rpcError(message.id, -32601, "Method not found"), 404);
}

export function createGateway({ fetchImpl = fetch, credentialSelector = selectGitHubCredentialMethod, credentialResolver = resolveGitHubIssuesToken, transportFactory = createPortableGitHubTransport, readerOptions = {} } = {}) {
  const readControlRoomJson = createControlRoomReader({ fetchImpl, ...readerOptions });
  return {
    async fetch(request, env = {}) {
      const url = new URL(request.url);
      const connector = CONNECTOR_BY_PATH.get(url.pathname);
      if (!connector) return jsonResponse({ error: "NOT_FOUND" }, 404);
      if (!(await authorize(request, env, connector))) return jsonResponse({ error: "UNAUTHORIZED" }, 401, { "WWW-Authenticate": "Bearer" });
      if (request.method === "GET") return jsonResponse({ error: "STREAMABLE_HTTP_POST_REQUIRED" }, 405, { Allow: "POST" });
      if (request.method !== "POST") return jsonResponse({ error: "METHOD_NOT_ALLOWED" }, 405, { Allow: "POST" });
      return handleRpc(request, env, connector, { fetchImpl, readControlRoomJson, readPublicationBootstrapOnce, requestSignal: request.signal, selectGitHubCredentialMethod: credentialSelector, resolveGitHubIssuesToken: credentialResolver, createGitHubTransport: transportFactory });
    },
  };
}

export default createGateway();
