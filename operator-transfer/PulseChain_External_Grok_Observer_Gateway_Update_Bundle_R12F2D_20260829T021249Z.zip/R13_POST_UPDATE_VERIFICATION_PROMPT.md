# R13 post-update verification handoff

Admit this handoff only when the governed R12F disabled-mode report is an exact PASS and the private R12F update receipt records one uploaded Version and one production deployment.

## Bound inputs

- R12F branch: `external-observer-grok-mcp-r12f2d-windows-harness-scope-repair-20260829`
- R12F commit: `9a30f43f90096f2cecb99dbe217c155eaf4b9633`
- R12F tree: `3ca2102d8657f1ab6884f4bf8597170776b25f9c`
- R12F parent: `ebef6c42a5eca2ad30669cf856e669a19e10edf9`
- Update bundle: `PulseChain_External_Grok_Observer_Gateway_Update_Bundle_R12F2D_20260829T021249Z.zip`
- Worker: `pulsechain-external-observer-grok-mcp`
- Worker origin: `https://pulsechain-external-observer-grok-mcp.pulsechain-research-dade45b2.workers.dev`
- Prior rollback Version: `e32f2b34-a572-404e-b969-44c0bf2c9088`

Obtain the exact new Version ID and deployment ID from the private update receipt. Do not infer either from “latest,” a mutable branch, or an operator recollection.

## Required R13 work

1. Revalidate the bundle identity, source commit/tree, private update receipt, and governed report without disclosing their contents.
2. Rerun the Windows ACL preflight and require `TOTAL=25 PASS=25 FAIL=0`.
3. Confirm the exact new Version is at 100% in exactly the recorded deployment and that the prior Version remains readable as the rollback target.
4. Read back and compare Worker name/origin, fixed variables, five secret names and Version bindings, zero GitHub secret names, no unexpected binding, compatibility date/flag, workers.dev enabled, preview URLs disabled, and exact deployed source identity.
5. Prove the finalized R12D connector vault remains byte-for-byte, metadata-, timestamp-, and DACL-identical; do not rewrite its historical `current_version_id`.
6. Admit the complete connector-stage matrix and system-wide mutation audit from the one R12F verifier invocation. Confirm `PUBLICATION_MODE_DISABLED`, no identity crossing, no secret exposure, zero GitHub transport/mutations, and every protected-state delta is zero.
7. Record negative and unresolved findings, including any transient Control Room availability evidence, without retrying or fabricating an authoritative response.

Remain read-only. Do not update the Worker, create another Version or deployment, configure or schedule Grok, begin monitoring, modify the Control Room or observer-runtime, create an issue/observation, or mutate D1, R2, authority, specialist, Signals, portfolio, wallet, order, or execution state.

Return a new coordination checkpoint. If any release-critical invariant fails, stop and request separate rollback authorization; do not execute rollback from this prompt. If the bounded gateway correctly returns `CONTROL_ROOM_UPSTREAM_UNAVAILABLE`, preserve R12F and report the external blocker rather than treating it as a security failure.
