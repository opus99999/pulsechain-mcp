#!/usr/bin/env node

import { createHash } from "node:crypto";

const API_ORIGIN = "https://api.cloudflare.com";
const API_PREFIX = "/client/v4";
const REQUEST_TIMEOUT_MS = 30_000;
const MAX_JSON_BYTES = 2 * 1024 * 1024;
const MAX_STDIN_BYTES = 64 * 1024;
const ACCOUNT_ID_PATTERN = /^[0-9a-f]{32}$/;
const WORKER_NAME_PATTERN = /^[a-z0-9](?:[a-z0-9-]{0,62})$/;
const VERSION_ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

class SafeFailure extends Error {
  constructor(stage, code, httpStatus = null) {
    super(code);
    this.name = "SafeFailure";
    this.stage = stage;
    this.code = code;
    this.httpStatus = httpStatus;
  }
}

function sha256(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

function stableValue(value) {
  if (Array.isArray(value)) return value.map(stableValue);
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.keys(value)
        .sort()
        .map((key) => [key, stableValue(value[key])]),
    );
  }
  return value;
}

function stableJson(value) {
  return JSON.stringify(stableValue(value));
}

function parseArguments(argv) {
  const [mode, ...rest] = argv;
  if (!new Set(["state", "content"]).has(mode)) {
    throw new SafeFailure("ARGUMENTS", "INVALID_MODE");
  }
  const values = new Map();
  for (let index = 0; index < rest.length; index += 2) {
    const flag = rest[index];
    const value = rest[index + 1];
    if (!flag?.startsWith("--") || value === undefined || values.has(flag)) {
      throw new SafeFailure("ARGUMENTS", "INVALID_ARGUMENTS");
    }
    values.set(flag, value);
  }
  const accountId = values.get("--account-id") ?? "";
  const workerName = values.get("--worker-name") ?? "";
  if (!ACCOUNT_ID_PATTERN.test(accountId) || !WORKER_NAME_PATTERN.test(workerName)) {
    throw new SafeFailure("ARGUMENTS", "INVALID_TARGET_IDENTITY");
  }
  if (mode === "state" && values.size !== 2) {
    throw new SafeFailure("ARGUMENTS", "UNEXPECTED_STATE_ARGUMENT");
  }
  const versionId = values.get("--version-id") ?? null;
  const localUploadForm = values.get("--local-upload-form") ?? null;
  if (
    mode === "content" &&
    (values.size !== 4 || !VERSION_ID_PATTERN.test(versionId ?? "") || !localUploadForm)
  ) {
    throw new SafeFailure("ARGUMENTS", "INVALID_CONTENT_ARGUMENT");
  }
  return { mode, accountId, workerName, versionId, localUploadForm };
}

async function readCredentialFrame() {
  const chunks = [];
  let total = 0;
  try {
    for await (const chunk of process.stdin) {
      const bytes = Buffer.from(chunk);
      total += bytes.length;
      if (total > MAX_STDIN_BYTES) {
        bytes.fill(0);
        throw new SafeFailure("AUTH_INPUT", "AUTH_INPUT_TOO_LARGE");
      }
      chunks.push(bytes);
    }
    if (total === 0) throw new SafeFailure("AUTH_INPUT", "AUTH_INPUT_MISSING");
    const combined = Buffer.concat(chunks, total);
    try {
      const decoded = new TextDecoder("utf-8", { fatal: true }).decode(combined);
      const parsed = JSON.parse(decoded);
      if (
        parsed?.type === "oauth" ||
        parsed?.type === "api_token"
      ) {
        if (typeof parsed.token !== "string" || parsed.token.length < 20) {
          throw new SafeFailure("AUTH_INPUT", "AUTH_TOKEN_INVALID");
        }
        return { type: parsed.type, token: parsed.token };
      }
      if (
        parsed?.type === "api_key" &&
        typeof parsed.key === "string" &&
        parsed.key.length >= 20 &&
        typeof parsed.email === "string" &&
        parsed.email.includes("@")
      ) {
        return { type: parsed.type, key: parsed.key, email: parsed.email };
      }
      throw new SafeFailure("AUTH_INPUT", "AUTH_TYPE_UNSUPPORTED");
    } finally {
      combined.fill(0);
    }
  } catch (error) {
    if (error instanceof SafeFailure) throw error;
    throw new SafeFailure("AUTH_INPUT", "AUTH_INPUT_INVALID");
  } finally {
    for (const chunk of chunks) chunk.fill(0);
  }
}

function authHeaders(credentials) {
  if (credentials.type === "api_key") {
    return {
      "X-Auth-Key": credentials.key,
      "X-Auth-Email": credentials.email,
    };
  }
  return { Authorization: `Bearer ${credentials.token}` };
}

async function apiFetch(path, credentials, stage) {
  if (!path.startsWith("/accounts/") || path.includes("#")) {
    throw new SafeFailure(stage, "UNSAFE_API_PATH");
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(`${API_ORIGIN}${API_PREFIX}${path}`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        ...authHeaders(credentials),
      },
      cache: "no-store",
      redirect: "error",
      signal: controller.signal,
    });
    if (!response.ok) {
      await response.body?.cancel().catch(() => {});
      throw new SafeFailure(stage, "CLOUDFLARE_HTTP_ERROR", response.status);
    }
    return response;
  } catch (error) {
    if (error instanceof SafeFailure) throw error;
    if (controller.signal.aborted) {
      throw new SafeFailure(stage, "CLOUDFLARE_READ_TIMEOUT");
    }
    throw new SafeFailure(stage, "CLOUDFLARE_TRANSPORT_ERROR");
  } finally {
    clearTimeout(timer);
  }
}

async function apiJson(path, credentials, stage) {
  const response = await apiFetch(path, credentials, stage);
  const contentType = response.headers.get("content-type") ?? "";
  if (!/^application\/(?:[a-z0-9.+-]+\+)?json(?:\s*;|$)/i.test(contentType)) {
    await response.body?.cancel().catch(() => {});
    throw new SafeFailure(stage, "CLOUDFLARE_CONTENT_TYPE_INVALID");
  }
  const declared = Number(response.headers.get("content-length"));
  if (Number.isFinite(declared) && declared > MAX_JSON_BYTES) {
    await response.body?.cancel().catch(() => {});
    throw new SafeFailure(stage, "CLOUDFLARE_RESPONSE_TOO_LARGE");
  }
  const bytes = Buffer.from(await response.arrayBuffer());
  try {
    if (bytes.length > MAX_JSON_BYTES) {
      throw new SafeFailure(stage, "CLOUDFLARE_RESPONSE_TOO_LARGE");
    }
    const value = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
    if (value?.success !== true || value.result === undefined) {
      throw new SafeFailure(stage, "CLOUDFLARE_ENVELOPE_INVALID");
    }
    return value.result;
  } catch (error) {
    if (error instanceof SafeFailure) throw error;
    throw new SafeFailure(stage, "CLOUDFLARE_JSON_INVALID");
  } finally {
    bytes.fill(0);
  }
}

async function stateSnapshot(target, credentials) {
  const scriptBase = `/accounts/${target.accountId}/workers/scripts/${target.workerName}`;
  const [subdomain, accountSubdomain, service, scriptSettings] = await Promise.all([
    apiJson(`${scriptBase}/subdomain`, credentials, "SCRIPT_SUBDOMAIN"),
    apiJson(`/accounts/${target.accountId}/workers/subdomain`, credentials, "ACCOUNT_SUBDOMAIN"),
    apiJson(`/accounts/${target.accountId}/workers/services/${target.workerName}`, credentials, "WORKER_SERVICE"),
    apiJson(`${scriptBase}/script-settings`, credentials, "SCRIPT_SETTINGS"),
  ]);
  if (
    typeof subdomain?.enabled !== "boolean" ||
    typeof subdomain?.previews_enabled !== "boolean" ||
    typeof accountSubdomain?.subdomain !== "string" ||
    !/^[a-z0-9-]+$/.test(accountSubdomain.subdomain)
  ) {
    throw new SafeFailure("STATE_SCHEMA", "CLOUDFLARE_STATE_SCHEMA_INVALID");
  }
  const script = service?.default_environment?.script;
  if (!script || typeof script.tag !== "string") {
    throw new SafeFailure("STATE_SCHEMA", "CLOUDFLARE_SERVICE_SCHEMA_INVALID");
  }
  return {
    schema_version: "pulsechain-r12f-cloudflare-state@1.0.0",
    result: "PASS",
    account_id: target.accountId,
    worker_name: target.workerName,
    account_subdomain: accountSubdomain.subdomain,
    workers_dev_enabled: subdomain.enabled,
    preview_urls_enabled: subdomain.previews_enabled,
    worker_origin: `https://${target.workerName}.${accountSubdomain.subdomain}.workers.dev`,
    service_script_tag: script.tag,
    last_deployed_from: script.last_deployed_from ?? null,
    script_settings_sha256: sha256(Buffer.from(stableJson(scriptSettings), "utf8")),
  };
}

function boundaryFromMultipart(bytes, stage) {
  const end = bytes.indexOf(Buffer.from("\r\n", "ascii"));
  if (end < 4 || end > 200) throw new SafeFailure(stage, "MULTIPART_BOUNDARY_INVALID");
  const delimiter = bytes.subarray(0, end).toString("ascii");
  if (!delimiter.startsWith("--") || !/^--[A-Za-z0-9_-]+$/.test(delimiter)) {
    throw new SafeFailure(stage, "MULTIPART_BOUNDARY_INVALID");
  }
  return delimiter.slice(2);
}

async function multipartManifest(bytes, contentType, stage) {
  let response;
  try {
    response = new Response(bytes, { headers: { "Content-Type": contentType } });
    const form = await response.formData();
    const parts = [];
    let metadata = null;
    for (const [name, value] of form.entries()) {
      if (typeof value === "string") {
        if (name === "metadata") metadata = JSON.parse(value);
        continue;
      }
      const partBytes = Buffer.from(await value.arrayBuffer());
      try {
        parts.push({
          name,
          content_type: value.type || "application/octet-stream",
          byte_size: partBytes.length,
          sha256: sha256(partBytes),
        });
      } finally {
        partBytes.fill(0);
      }
    }
    parts.sort((left, right) => left.name.localeCompare(right.name) || left.content_type.localeCompare(right.content_type));
    return { parts, metadata };
  } catch (error) {
    if (error instanceof SafeFailure) throw error;
    throw new SafeFailure(stage, "MULTIPART_PARSE_FAILED");
  } finally {
    response = null;
  }
}

async function contentSnapshot(target, credentials) {
  const { readFile } = await import("node:fs/promises");
  const localBytes = await readFile(target.localUploadForm);
  let remoteBytes = null;
  try {
    const boundary = boundaryFromMultipart(localBytes, "LOCAL_UPLOAD_FORM");
    const local = await multipartManifest(
      localBytes,
      `multipart/form-data; boundary=${boundary}`,
      "LOCAL_UPLOAD_FORM",
    );
    const response = await apiFetch(
      `/accounts/${target.accountId}/workers/scripts/${target.workerName}/content/v2?version=${target.versionId}`,
      credentials,
      "VERSION_CONTENT",
    );
    const contentType = response.headers.get("content-type") ?? "";
    if (!/^multipart\/form-data\s*;/i.test(contentType)) {
      await response.body?.cancel().catch(() => {});
      throw new SafeFailure("VERSION_CONTENT", "VERSION_CONTENT_TYPE_INVALID");
    }
    remoteBytes = Buffer.from(await response.arrayBuffer());
    const remote = await multipartManifest(remoteBytes, contentType, "VERSION_CONTENT");
    const localMain = local.metadata?.main_module ?? local.metadata?.body_part ?? null;
    const remoteMain = response.headers.get("cf-entrypoint");
    const localMapCount = local.parts.filter((part) => part.content_type === "application/source-map").length;
    const remoteMapCount = remote.parts.filter((part) => part.content_type === "application/source-map").length;
    return {
      schema_version: "pulsechain-r12f-cloudflare-content@1.0.0",
      result: "PASS",
      account_id: target.accountId,
      worker_name: target.workerName,
      version_id: target.versionId,
      local_entrypoint: localMain,
      remote_entrypoint: remoteMain,
      local_source_map_count: localMapCount,
      remote_source_map_count: remoteMapCount,
      local_remote_content_equal:
        localMain === remoteMain && stableJson(local.parts) === stableJson(remote.parts),
      local_parts: local.parts,
      remote_parts: remote.parts,
    };
  } catch (error) {
    if (error instanceof SafeFailure) throw error;
    throw new SafeFailure("VERSION_CONTENT", "VERSION_CONTENT_READ_FAILED");
  } finally {
    localBytes.fill(0);
    remoteBytes?.fill(0);
  }
}

let credentials = null;
try {
  const target = parseArguments(process.argv.slice(2));
  credentials = await readCredentialFrame();
  const output = target.mode === "state"
    ? await stateSnapshot(target, credentials)
    : await contentSnapshot(target, credentials);
  process.stdout.write(`${JSON.stringify(output)}\n`);
} catch (error) {
  const failure = error instanceof SafeFailure
    ? error
    : new SafeFailure("INTERNAL", "CLOUDFLARE_READ_FAILED");
  process.stdout.write(`${JSON.stringify({
    schema_version: "pulsechain-r12f-cloudflare-read-failure@1.0.0",
    result: "FAIL",
    error: failure.code,
    stage: failure.stage,
    http_status: failure.httpStatus,
  })}\n`);
  process.exitCode = 1;
} finally {
  if (credentials) {
    if ("token" in credentials) credentials.token = "";
    if ("key" in credentials) credentials.key = "";
    if ("email" in credentials) credentials.email = "";
  }
  credentials = null;
}
