import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { existsSync } from "node:fs";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, isAbsolute, join, relative, resolve, sep } from "node:path";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { fileURLToPath } from "node:url";

const testDirectory = dirname(fileURLToPath(import.meta.url));
const operatorDirectory = dirname(testDirectory);
const sourceLayer = operatorDirectory.endsWith("external_observer_grok_mcp_operator");
const updateScript = join(operatorDirectory, sourceLayer
  ? "UPDATE_EXISTING_GATEWAY_R12F.ps1.in"
  : "UPDATE_EXISTING_GATEWAY_R12F.ps1");
const commonScript = join(operatorDirectory, sourceLayer
  ? "OPERATOR_COMMON.ps1.in"
  : "OPERATOR_COMMON.ps1");

test("old async wait expression explains the exact two-object pipeline", async () => {
  const script = await readFile(updateScript, "utf8");
  const harnessSource = await readFile(fileURLToPath(import.meta.url), "utf8");
  assert.match(script, /\[void\]\$process\.WaitForExitAsync\(\)\.GetAwaiter\(\)\.GetResult\(\)/);
  assert.doesNotMatch(script, /^\s*\$process\.WaitForExitAsync\(\)\.GetAwaiter\(\)\.GetResult\(\)\s*$/mu);
  assert.match(harnessSource, /Function:\\script:\$name/);
  assert.match(harnessSource, /Set-Item -LiteralPath \$functionPath -Value \$matches\[0\]\.Body\.GetScriptBlock\(\)/);
  assert.match(harnessSource, /\$selectedFunction = Get-Command -Name \$selectedFunctionName -CommandType Function/);
  assert.doesNotMatch(harnessSource, /Invoke-Expression \$matches\[0\]\.Extent\.Text/);
  assert.doesNotMatch(harnessSource, /Function:\\global:/);

  const previewHelperStart = script.indexOf("function Test-VersionUploadReceiptPreviewFieldsDisabled");
  const previewHelperEnd = script.indexOf("function Assert-VersionBindingContract", previewHelperStart);
  assert.ok(previewHelperStart >= 0 && previewHelperEnd > previewHelperStart);
  const previewHelper = script.slice(previewHelperStart, previewHelperEnd);
  assert.match(previewHelper, /foreach \(\$field in @\("preview_url", "preview_alias_url"\)\)/);
  assert.match(previewHelper, /\$property = \$Receipt\.PSObject\.Properties\[\$field\]/);
  assert.match(previewHelper, /\$null -eq \$property -or \$null -eq \$property\.Value/);
  assert.match(previewHelper, /\$property\.Value -isnot \[string\] -or \[string\]\$property\.Value -cne ""/);

  const uploadReceiptBlockStart = script.indexOf("    $uploadReceipts = @(");
  const uploadReceiptBlockEnd = script.indexOf("    $newVersionId =", uploadReceiptBlockStart);
  assert.ok(uploadReceiptBlockStart >= 0 && uploadReceiptBlockEnd > uploadReceiptBlockStart);
  const uploadReceiptBlock = script.slice(uploadReceiptBlockStart, uploadReceiptBlockEnd);
  assert.match(
    uploadReceiptBlock,
    /-not \(Test-VersionUploadReceiptPreviewFieldsDisabled -Receipt \$uploadReceipt\)/,
  );
  assert.doesNotMatch(uploadReceiptBlock, /\.(?:preview_url|preview_alias_url)\b/);
  assert.match(uploadReceiptBlock, /throw "VERSION_UPLOAD_RECEIPT_MISMATCH"/);

  const uploadInvocationIndex = script.indexOf("    $upload = Invoke-WranglerWithReceipt");
  const previewValidationIndex = script.indexOf(
    "Test-VersionUploadReceiptPreviewFieldsDisabled -Receipt $uploadReceipt",
    uploadInvocationIndex,
  );
  const uploadedVersionReadbackIndex = script.indexOf(
    '    Set-UpdatePhase "UPLOADED_VERSION_READBACK"',
    previewValidationIndex,
  );
  const deploymentInvocationIndex = script.indexOf(
    "    $deployment = Invoke-WranglerWithReceipt",
    uploadedVersionReadbackIndex,
  );
  assert.ok(
    uploadInvocationIndex >= 0 &&
      previewValidationIndex > uploadInvocationIndex &&
      uploadedVersionReadbackIndex > previewValidationIndex &&
      deploymentInvocationIndex > uploadedVersionReadbackIndex,
    "VERSION_UPLOAD_RECEIPT_VALIDATION_SEQUENCE_CHANGED",
  );
  const oldPipeline = [
    { runtime_type: "System.Threading.Tasks.VoidTaskResult", state_fields: 0 },
    { runtime_type: "System.Management.Automation.PSCustomObject", state_fields: 9 },
  ];
  assert.deepEqual(oldPipeline.map((entry) => entry.runtime_type), [
    "System.Threading.Tasks.VoidTaskResult",
    "System.Management.Automation.PSCustomObject",
  ]);
});

test("Windows PowerShell preflight exercises the repaired state contract", {
  skip: process.platform !== "win32",
}, async () => {
  const quote = (value) => `'${value.replaceAll("'", "''")}'`;
  const harness = String.raw`
$ErrorActionPreference = "Stop"
$InformationPreference = "SilentlyContinue"
Set-StrictMode -Version Latest

function Import-SelectedFunctions {
    param([string]$Path, [string[]]$Names)
    $tokens = $null
    $errors = $null
    $ast = [Management.Automation.Language.Parser]::ParseFile($Path, [ref]$tokens, [ref]$errors)
    if (@($errors).Count -ne 0) { throw "SYNTHETIC_FUNCTION_PARSE_FAILED" }
    foreach ($name in $Names) {
        $matches = @($ast.FindAll({
            param($node)
            $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq $name
        }, $true))
        if ($matches.Count -ne 1) { throw "SYNTHETIC_FUNCTION_CARDINALITY_FAILED" }
        $functionPath = "Function:\script:$name"
        Set-Item -LiteralPath $functionPath -Value $matches[0].Body.GetScriptBlock() -Force -ErrorAction Stop
        if (-not (Test-Path -LiteralPath $functionPath)) { throw "SYNTHETIC_FUNCTION_SCOPE_INSTALL_FAILED" }
    }
}

Import-SelectedFunctions -Path ${quote(commonScript)} -Names @(
    "ConvertTo-SanitizedOperatorText",
    "New-SanitizedOperatorFailureRecord"
)
Import-SelectedFunctions -Path ${quote(updateScript)} -Names @(
    "Throw-CloudflareStateFieldFailure",
    "Assert-CloudflareStateShape",
    "Get-CloudflareState",
    "Assert-CloudflareExpectedState",
    "New-UpdateFailureRecord",
    "Test-VersionUploadReceiptPreviewFieldsDisabled"
)
$selectedFunctionCount = 0
foreach ($selectedFunctionName in @(
    "ConvertTo-SanitizedOperatorText",
    "New-SanitizedOperatorFailureRecord",
    "Throw-CloudflareStateFieldFailure",
    "Assert-CloudflareStateShape",
    "Get-CloudflareState",
    "Assert-CloudflareExpectedState",
    "New-UpdateFailureRecord",
    "Test-VersionUploadReceiptPreviewFieldsDisabled"
)) {
    $selectedFunction = Get-Command -Name $selectedFunctionName -CommandType Function -ErrorAction SilentlyContinue
    if ($null -eq $selectedFunction -or $selectedFunction.Name -cne $selectedFunctionName) {
        $scopePersistenceFailure = "SYNTHETIC_FUNCTION_SCOPE_" + "PERSISTENCE_FAILED"
        throw "\${scopePersistenceFailure}:$selectedFunctionName"
    }
    $selectedFunctionCount += 1
}

$ExpectedAccountId = "dade45b2875ee5e98c74b5d06528cd9c"
$WorkerName = "pulsechain-external-observer-grok-mcp"
$ExpectedAccountSubdomain = "pulsechain-research-dade45b2"
$ExpectedOrigin = "https://pulsechain-external-observer-grok-mcp.pulsechain-research-dade45b2.workers.dev"
$ExpectedR12F2GBundleSourceBranch = "synthetic-r12f2g"
$ExpectedR12F2GBundleSourceCommit = "0000000000000000000000000000000000000000"
$ExpectedR12F2GBundleSourceTree = "1111111111111111111111111111111111111111"
$phase = "EXACT_PRE_UPDATE_STATE"

$validState = [pscustomobject][ordered]@{
    schema_version = "pulsechain-r12f-cloudflare-state@1.0.0"
    result = "PASS"
    account_id = $ExpectedAccountId
    worker_name = $WorkerName
    account_subdomain = $ExpectedAccountSubdomain
    workers_dev_enabled = $true
    preview_urls_enabled = $false
    worker_origin = $ExpectedOrigin
    last_deployed_from = "wrangler"
    service_script_tag = "synthetic-service-tag"
    script_settings_sha256 = ("a" * 64)
}

$acceptedPreviewReceipts = @(
    [pscustomobject][ordered]@{},
    [pscustomobject][ordered]@{ preview_alias_url = "" },
    [pscustomobject][ordered]@{ preview_url = "" },
    [pscustomobject][ordered]@{ preview_url = $null; preview_alias_url = $null },
    [pscustomobject][ordered]@{ preview_url = ""; preview_alias_url = "" }
)
$acceptedPreviewReceiptCount = 0
foreach ($receipt in $acceptedPreviewReceipts) {
    if (-not (Test-VersionUploadReceiptPreviewFieldsDisabled -Receipt $receipt)) {
        throw "OPTIONAL_PREVIEW_RECEIPT_ACCEPTANCE_FAILED"
    }
    $acceptedPreviewReceiptCount += 1
}

$rejectedPreviewReceipts = @(
    [pscustomobject][ordered]@{ preview_url = "https://unexpected.invalid"; preview_alias_url = "" },
    [pscustomobject][ordered]@{ preview_url = ""; preview_alias_url = "unexpected-alias" },
    [pscustomobject][ordered]@{ preview_url = " "; preview_alias_url = "" },
    [pscustomobject][ordered]@{ preview_url = ""; preview_alias_url = 0 },
    [pscustomobject][ordered]@{ preview_url = [pscustomobject]@{ value = "" }; preview_alias_url = "" }
)
$rejectedPreviewReceiptCount = 0
foreach ($receipt in $rejectedPreviewReceipts) {
    if (Test-VersionUploadReceiptPreviewFieldsDisabled -Receipt $receipt) {
        throw "OPTIONAL_PREVIEW_RECEIPT_REJECTION_FAILED"
    }
    $rejectedPreviewReceiptCount += 1
}

$probe = [Diagnostics.Process]::new()
$probe.StartInfo.FileName = (Get-Command pwsh -ErrorAction Stop).Source
$probe.StartInfo.UseShellExecute = $false
$probe.StartInfo.CreateNoWindow = $true
[void]$probe.StartInfo.ArgumentList.Add("-NoProfile")
[void]$probe.StartInfo.ArgumentList.Add("-NonInteractive")
[void]$probe.StartInfo.ArgumentList.Add("-Command")
[void]$probe.StartInfo.ArgumentList.Add("exit 0")
try {
    if (-not $probe.Start()) { throw "SYNTHETIC_PROCESS_START_FAILED" }
    $oldOutput = @(
        $probe.WaitForExitAsync().GetAwaiter().GetResult()
        $validState
    )
    if ($oldOutput.Count -ne 2) { throw "OLD_TWO_OBJECT_OUTPUT_NOT_REPRODUCED" }
    if ($oldOutput[0].GetType().FullName -cne "System.Threading.Tasks.VoidTaskResult") { throw "OLD_LEADING_OBJECT_TYPE_MISMATCH" }
    if ($oldOutput[1].GetType().FullName -cne "System.Management.Automation.PSCustomObject") { throw "OLD_STATE_OBJECT_TYPE_MISMATCH" }
}
finally {
    [void]$probe.Dispose()
}

$script:syntheticState = $validState
Set-Item -Path Function:Invoke-CloudflareHelper -Value { Write-Information "synthetic diagnostic"; $script:syntheticState }
$success = @(Get-CloudflareState)
if ($success.Count -ne 1 -or $success[0].account_id -cne $ExpectedAccountId) { throw "REPAIRED_SINGLE_OBJECT_FAILED" }
Assert-CloudflareExpectedState -State $success[0]

Set-Item -Path Function:Invoke-CloudflareHelper -Value { }
$zeroCode = $null
try { $discard = @(Get-CloudflareState) }
catch { $zeroCode = $_.Exception.Message }
if ($zeroCode -cne "CLOUDFLARE_STATE_UNAVAILABLE") { throw "ZERO_STATE_CLASSIFICATION_FAILED" }

Set-Item -Path Function:Invoke-CloudflareHelper -Value { [pscustomobject]@{ diagnostic = "synthetic" }; $script:syntheticState }
$twoCode = $null
try { $discard = @(Get-CloudflareState) }
catch { $twoCode = $_.Exception.Message }
if ($twoCode -cne "CLOUDFLARE_STATE_OUTPUT_CARDINALITY_MISMATCH") { throw "TWO_STATE_CLASSIFICATION_FAILED" }

$wrongState = $validState.PSObject.Copy()
$wrongState.account_id = "00000000000000000000000000000000"
$wrongCode = $null
try { Assert-CloudflareExpectedState -State $wrongState }
catch { $wrongCode = $_.Exception.Message }
if ($wrongCode -cne "CLOUDFLARE_WORKER_STATE_MISMATCH") { throw "WRONG_ACCOUNT_CLASSIFICATION_FAILED" }

$missingState = $validState.PSObject.Copy()
$missingState.PSObject.Properties.Remove("account_id")
$missingError = $null
try { Assert-CloudflareExpectedState -State $missingState }
catch { $missingError = $_ }
if ($missingError.Exception.Message -cne "CLOUDFLARE_STATE_REQUIRED_FIELD_MISSING") { throw "MISSING_ACCOUNT_CLASSIFICATION_FAILED" }
if ($missingError.Exception.Data["PulseChainFailedField"] -cne "account_id") { throw "MISSING_ACCOUNT_FIELD_FAILED" }
$failureRecord = New-UpdateFailureRecord -ErrorRecord $missingError
if (
    $failureRecord.source_branch -cne $ExpectedR12F2GBundleSourceBranch -or
    $failureRecord.source_commit -cne $ExpectedR12F2GBundleSourceCommit -or
    $failureRecord.source_tree -cne $ExpectedR12F2GBundleSourceTree -or
    [string]::IsNullOrWhiteSpace([string]$failureRecord.failure.exception_type) -or
    [string]::IsNullOrWhiteSpace([string]$failureRecord.failure.fully_qualified_error_id) -or
    [int]$failureRecord.failure.source_line -le 0 -or
    [string]::IsNullOrWhiteSpace([string]$failureRecord.failure.script_stack_trace) -or
    $failureRecord.failure.failed_field -cne "account_id"
) { throw "SANITIZED_ERROR_RECORD_INCOMPLETE" }

[pscustomobject][ordered]@{
    result = "PASS"
    old_output_count = 2
    repaired_output_count = 1
    zero_state_code = $zeroCode
    two_state_code = $twoCode
    wrong_account_code = $wrongCode
    missing_field = $failureRecord.failure.failed_field
    selected_function_count = $selectedFunctionCount
    accepted_preview_receipt_count = $acceptedPreviewReceiptCount
    rejected_preview_receipt_count = $rejectedPreviewReceiptCount
    source_branch = $failureRecord.source_branch
    source_commit = $failureRecord.source_commit
    source_tree = $failureRecord.source_tree
} | ConvertTo-Json -Compress
`;
  const temporaryDirectory = await mkdtemp(join(tmpdir(), "pulsechain external observer windows fixture "));
  const temporaryScriptPath = join(
    temporaryDirectory,
    `cloudflare-state-single-object-${randomUUID()}.ps1`,
  );
  const relativeFromOperatorDirectory = relative(
    resolve(operatorDirectory),
    resolve(temporaryDirectory),
  );
  assert.ok(
    isAbsolute(relativeFromOperatorDirectory) ||
      relativeFromOperatorDirectory === ".." ||
      relativeFromOperatorDirectory.startsWith(`..${sep}`),
    "TEMPORARY_WINDOWS_FIXTURE_DIRECTORY_MUST_BE_OUTSIDE_SOURCE_TREE",
  );

  let report;
  try {
    await writeFile(temporaryScriptPath, harness, { encoding: "utf8", flag: "wx" });
    const scriptBytes = await readFile(temporaryScriptPath);
    assert.notDeepEqual(
      Array.from(scriptBytes.subarray(0, 3)),
      [0xef, 0xbb, 0xbf],
      "TEMPORARY_WINDOWS_FIXTURE_UNEXPECTED_UTF8_BOM",
    );

    const result = spawnSync("pwsh", [
      "-NoLogo",
      "-NoProfile",
      "-NonInteractive",
      "-File",
      temporaryScriptPath,
    ], {
      cwd: temporaryDirectory,
      encoding: "utf8",
      maxBuffer: 4 * 1024 * 1024,
      windowsHide: true,
    });
    const stdout = result.stdout ?? "";
    const stderr = result.stderr ?? "";
    const diagnostic = JSON.stringify({
      spawn_error: result.error
        ? { name: result.error.name, message: result.error.message }
        : null,
      exit_code: result.status,
      signal: result.signal,
      stdout,
      stderr,
    });
    assert.equal(result.error, undefined, diagnostic);
    assert.equal(result.status, 0, diagnostic);
    assert.equal(stderr.trim(), "", diagnostic);
    const lines = stdout.split(/\r?\n/u).map((line) => line.trim()).filter(Boolean);
    assert.equal(
      lines.length,
      1,
      `POWERSHELL_HARNESS_STDOUT_RECORD_COUNT_MISMATCH:${diagnostic}`,
    );
    try {
      report = JSON.parse(lines.at(-1));
    }
    catch (error) {
      assert.fail(
        `POWERSHELL_HARNESS_FINAL_JSON_INVALID:${error instanceof Error ? error.message : String(error)}:${diagnostic}`,
      );
    }
  }
  finally {
    await rm(temporaryDirectory, { recursive: true, force: true });
  }
  assert.equal(existsSync(temporaryDirectory), false, "TEMPORARY_WINDOWS_FIXTURE_CLEANUP_FAILED");
  assert.equal(report.result, "PASS");
  assert.equal(report.old_output_count, 2);
  assert.equal(report.repaired_output_count, 1);
  assert.equal(report.two_state_code, "CLOUDFLARE_STATE_OUTPUT_CARDINALITY_MISMATCH");
  assert.equal(report.missing_field, "account_id");
  assert.equal(report.selected_function_count, 8);
  assert.equal(report.accepted_preview_receipt_count, 5);
  assert.equal(report.rejected_preview_receipt_count, 5);
  assert.equal(report.source_branch, "synthetic-r12f2g");
  assert.equal(report.source_commit, "0000000000000000000000000000000000000000");
  assert.equal(report.source_tree, "1111111111111111111111111111111111111111");
});
