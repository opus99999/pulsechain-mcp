import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { fileURLToPath } from "node:url";

const testDirectory = dirname(fileURLToPath(import.meta.url));
const operatorDirectory = dirname(testDirectory);
const sourceLayer = operatorDirectory.endsWith("external_observer_grok_mcp_operator");
const updateScript = join(operatorDirectory, sourceLayer
  ? "UPDATE_EXISTING_GATEWAY_R12F.ps1.in"
  : "UPDATE_EXISTING_GATEWAY_R12F.ps1");
const commonScript = join(operatorDirectory, sourceLayer
  ? "OPERATOR_COMMON.ps1.in"
  : "OPERATOR_COMMON.ps1");

test("old async wait expression explains the exact two-object pipeline", async () => {
  const script = await readFile(updateScript, "utf8");
  assert.match(script, /\[void\]\$process\.WaitForExitAsync\(\)\.GetAwaiter\(\)\.GetResult\(\)/);
  assert.doesNotMatch(script, /^\s*\$process\.WaitForExitAsync\(\)\.GetAwaiter\(\)\.GetResult\(\)\s*$/mu);
  const oldPipeline = [
    { runtime_type: "System.Threading.Tasks.VoidTaskResult", state_fields: 0 },
    { runtime_type: "System.Management.Automation.PSCustomObject", state_fields: 9 },
  ];
  assert.deepEqual(oldPipeline.map((entry) => entry.runtime_type), [
    "System.Threading.Tasks.VoidTaskResult",
    "System.Management.Automation.PSCustomObject",
  ]);
});

test("Windows PowerShell preflight exercises the repaired state contract", {
  skip: process.platform !== "win32",
}, async () => {
  const quote = (value) => `'${value.replaceAll("'", "''")}'`;
  const harness = String.raw`
$ErrorActionPreference = "Stop"
$InformationPreference = "SilentlyContinue"
Set-StrictMode -Version Latest

function Import-SelectedFunctions {
    param([string]$Path, [string[]]$Names)
    $tokens = $null
    $errors = $null
    $ast = [Management.Automation.Language.Parser]::ParseFile($Path, [ref]$tokens, [ref]$errors)
    if (@($errors).Count -ne 0) { throw "SYNTHETIC_FUNCTION_PARSE_FAILED" }
    foreach ($name in $Names) {
        $matches = @($ast.FindAll({
            param($node)
            $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq $name
        }, $true))
        if ($matches.Count -ne 1) { throw "SYNTHETIC_FUNCTION_CARDINALITY_FAILED" }
        Invoke-Expression $matches[0].Extent.Text
    }
}

Import-SelectedFunctions -Path ${quote(commonScript)} -Names @(
    "ConvertTo-SanitizedOperatorText",
    "New-SanitizedOperatorFailureRecord"
)
Import-SelectedFunctions -Path ${quote(updateScript)} -Names @(
    "Throw-CloudflareStateFieldFailure",
    "Assert-CloudflareStateShape",
    "Get-CloudflareState",
    "Assert-CloudflareExpectedState",
    "New-UpdateFailureRecord"
)

$ExpectedAccountId = "dade45b2875ee5e98c74b5d06528cd9c"
$WorkerName = "pulsechain-external-observer-grok-mcp"
$ExpectedAccountSubdomain = "pulsechain-research-dade45b2"
$ExpectedOrigin = "https://pulsechain-external-observer-grok-mcp.pulsechain-research-dade45b2.workers.dev"
$ExpectedR12F2CBundleSourceBranch = "synthetic-r12f2c"
$ExpectedR12F2CBundleSourceCommit = "0000000000000000000000000000000000000000"
$ExpectedR12F2CBundleSourceTree = "1111111111111111111111111111111111111111"
$phase = "EXACT_PRE_UPDATE_STATE"

$validState = [pscustomobject][ordered]@{
    schema_version = "pulsechain-r12f-cloudflare-state@1.0.0"
    result = "PASS"
    account_id = $ExpectedAccountId
    worker_name = $WorkerName
    account_subdomain = $ExpectedAccountSubdomain
    workers_dev_enabled = $true
    preview_urls_enabled = $false
    worker_origin = $ExpectedOrigin
    last_deployed_from = "wrangler"
    service_script_tag = "synthetic-service-tag"
    script_settings_sha256 = ("a" * 64)
}

$probe = [Diagnostics.Process]::new()
$probe.StartInfo.FileName = (Get-Command pwsh -ErrorAction Stop).Source
$probe.StartInfo.UseShellExecute = $false
$probe.StartInfo.CreateNoWindow = $true
[void]$probe.StartInfo.ArgumentList.Add("-NoProfile")
[void]$probe.StartInfo.ArgumentList.Add("-NonInteractive")
[void]$probe.StartInfo.ArgumentList.Add("-Command")
[void]$probe.StartInfo.ArgumentList.Add("exit 0")
try {
    if (-not $probe.Start()) { throw "SYNTHETIC_PROCESS_START_FAILED" }
    $oldOutput = @(
        $probe.WaitForExitAsync().GetAwaiter().GetResult()
        $validState
    )
    if ($oldOutput.Count -ne 2) { throw "OLD_TWO_OBJECT_OUTPUT_NOT_REPRODUCED" }
    if ($oldOutput[0].GetType().FullName -cne "System.Threading.Tasks.VoidTaskResult") { throw "OLD_LEADING_OBJECT_TYPE_MISMATCH" }
    if ($oldOutput[1].GetType().FullName -cne "System.Management.Automation.PSCustomObject") { throw "OLD_STATE_OBJECT_TYPE_MISMATCH" }
}
finally {
    [void]$probe.Dispose()
}

$script:syntheticState = $validState
Set-Item -Path Function:Invoke-CloudflareHelper -Value { Write-Information "synthetic diagnostic"; $script:syntheticState }
$success = @(Get-CloudflareState)
if ($success.Count -ne 1 -or $success[0].account_id -cne $ExpectedAccountId) { throw "REPAIRED_SINGLE_OBJECT_FAILED" }
Assert-CloudflareExpectedState -State $success[0]

Set-Item -Path Function:Invoke-CloudflareHelper -Value { }
$zeroCode = $null
try { $discard = @(Get-CloudflareState) }
catch { $zeroCode = $_.Exception.Message }
if ($zeroCode -cne "CLOUDFLARE_STATE_UNAVAILABLE") { throw "ZERO_STATE_CLASSIFICATION_FAILED" }

Set-Item -Path Function:Invoke-CloudflareHelper -Value { [pscustomobject]@{ diagnostic = "synthetic" }; $script:syntheticState }
$twoCode = $null
try { $discard = @(Get-CloudflareState) }
catch { $twoCode = $_.Exception.Message }
if ($twoCode -cne "CLOUDFLARE_STATE_OUTPUT_CARDINALITY_MISMATCH") { throw "TWO_STATE_CLASSIFICATION_FAILED" }

$wrongState = $validState.PSObject.Copy()
$wrongState.account_id = "00000000000000000000000000000000"
$wrongCode = $null
try { Assert-CloudflareExpectedState -State $wrongState }
catch { $wrongCode = $_.Exception.Message }
if ($wrongCode -cne "CLOUDFLARE_WORKER_STATE_MISMATCH") { throw "WRONG_ACCOUNT_CLASSIFICATION_FAILED" }

$missingState = $validState.PSObject.Copy()
$missingState.PSObject.Properties.Remove("account_id")
$missingError = $null
try { Assert-CloudflareExpectedState -State $missingState }
catch { $missingError = $_ }
if ($missingError.Exception.Message -cne "CLOUDFLARE_STATE_REQUIRED_FIELD_MISSING") { throw "MISSING_ACCOUNT_CLASSIFICATION_FAILED" }
if ($missingError.Exception.Data["PulseChainFailedField"] -cne "account_id") { throw "MISSING_ACCOUNT_FIELD_FAILED" }
$failureRecord = New-UpdateFailureRecord -ErrorRecord $missingError
if (
    [string]::IsNullOrWhiteSpace([string]$failureRecord.failure.exception_type) -or
    [string]::IsNullOrWhiteSpace([string]$failureRecord.failure.fully_qualified_error_id) -or
    [int]$failureRecord.failure.source_line -le 0 -or
    [string]::IsNullOrWhiteSpace([string]$failureRecord.failure.script_stack_trace) -or
    $failureRecord.failure.failed_field -cne "account_id"
) { throw "SANITIZED_ERROR_RECORD_INCOMPLETE" }

[pscustomobject][ordered]@{
    result = "PASS"
    old_output_count = 2
    repaired_output_count = 1
    zero_state_code = $zeroCode
    two_state_code = $twoCode
    wrong_account_code = $wrongCode
    missing_field = $failureRecord.failure.failed_field
} | ConvertTo-Json -Compress
`;
  const result = spawnSync("pwsh", ["-NoProfile", "-NonInteractive", "-Command", "-"], {
    input: harness,
    encoding: "utf8",
    maxBuffer: 4 * 1024 * 1024,
    windowsHide: true,
  });
  assert.equal(result.status, 0, result.stderr || result.stdout);
  const lines = result.stdout.trim().split(/\r?\n/u).filter(Boolean);
  const report = JSON.parse(lines.at(-1));
  assert.equal(report.result, "PASS");
  assert.equal(report.old_output_count, 2);
  assert.equal(report.repaired_output_count, 1);
  assert.equal(report.two_state_code, "CLOUDFLARE_STATE_OUTPUT_CARDINALITY_MISMATCH");
  assert.equal(report.missing_field, "account_id");
});
