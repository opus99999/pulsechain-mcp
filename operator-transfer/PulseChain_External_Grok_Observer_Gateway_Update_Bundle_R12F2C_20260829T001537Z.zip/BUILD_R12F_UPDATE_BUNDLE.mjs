#!/usr/bin/env node
import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import {
  cpSync,
  existsSync,
  lstatSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  readdirSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { basename, dirname, join, relative, resolve, sep } from "node:path";
import { tmpdir } from "node:os";
import {
  renderOperatorTestForBundle,
  validateBundleImports,
} from "./BUNDLE_IMPORT_CONTAINMENT.mjs";
import {
  DEPLOYMENT_EXPECTATIONS_SCHEMA,
  INVENTORY_SCHEMA,
  SOURCE_MANIFEST_SCHEMA,
  inspectBundleContract,
} from "./BUNDLE_CONTRACT_VALIDATION.mjs";

const SOURCE_BRANCH = "external-observer-grok-mcp-r12f2c-prestate-single-object-repair-20260829";
const R12F2B_COMMIT = "e724d72adbeae653695d3198353d35ba173884f9";
const R12F2B_TREE = "b185d749737f83027d3a9573417e4a18cea1d61f";
const R12F2A_COMMIT = "d6db80436ab82a061161be99c53179d481eabfff";
const R12F2A_TREE = "a750a7da63ca1adbea3fe606c12c80bb9caebe3d";
const R12F2_COMMIT = "f535c273c264f2c953ccd925a1d20c3f218c95a4";
const R12F2_TREE = "2e9df9f68850ca588e4a4749db100ec760e57d7c";
const R12F1_COMMIT = "75e3650f8e7f17af0ec2b2f312b920e15f96eb79";
const R12F1_TREE = "1c8bccc87df5abc07b9712a6f6fb839bc0b7c21a";
const R12F_COMMIT = "ebef6c42a5eca2ad30669cf856e669a19e10edf9";
const R12F_TREE = "e4db0de410f89b32a9dca0f3bd1388c0272664e7";
const R12D_COMMIT = "ec70832c69f847ea413666de095ce3d56534ea28";
const R12F1_BUNDLE_FILENAME = "PulseChain_External_Grok_Observer_Gateway_Update_Bundle_R12F1_20260828T183733Z.zip";
const R12F1_BUNDLE_SHA256 = "1b9b03d52dd346dd63addd100c1eadebb4537293560f106a4f2018af1567088d";
const R12F1_BUNDLE_SIZE = 125_883;
const R12F1_BUNDLE_MEMBERS = 36;
const WORKER = "pulsechain-external-observer-grok-mcp";
const WORKER_ORIGIN = "https://pulsechain-external-observer-grok-mcp.pulsechain-research-dade45b2.workers.dev";
const CONTROL_ROOM_ORIGIN = "https://pulsechain-research-control-room.brohexphiat.chatgpt.site";
const PRIOR_DEPLOYMENT = "c776a6e0-14b8-49bc-be9a-7aa0e63c5495";
const PRIOR_VERSION = "e32f2b34-a572-404e-b969-44c0bf2c9088";
const ACCOUNT_ID = "dade45b2875ee5e98c74b5d06528cd9c";
const WRANGLER_VERSION = "4.92.0";
const WINDOWS_RESERVED = /^(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?$/iu;
const SECRET_PATTERNS = [
  /-----BEGIN [A-Z ]*PRIVATE KEY-----\r?\n[A-Za-z0-9+/=\r\n]{40,}-----END [A-Z ]*PRIVATE KEY-----/u,
  /\bgh[opsu]_[A-Za-z0-9]{20,}\b/u,
  /\bgithub_pat_[A-Za-z0-9_]{20,}\b/u,
  /\b(?:AKIA|ASIA)[A-Z0-9]{16}\b/u,
  /\bBearer\s+[A-Za-z0-9._~+/-]{20,}\b/iu,
  /\b(?:mnemonic|private[_ -]?key|connector[_ -]?token)\s*[:=]\s*["']?[A-Za-z0-9+/=_-]{20,}/iu,
];
const SYNTHETIC_SECRET_FIXTURES = Object.freeze([
  ["gh", "p_", "abcdefghijklmnopqrstuvwxyz", "1234567890"].join(""),
  ["Bea", "rer secret-value-", "abcdefghijklmnopqrstuvwxyz", " token=private-value"].join(""),
  ["Authorization: Bea", "rer not-the-current-", "governed-credential"].join(""),
]);
function hasSecretPattern(text) { return SECRET_PATTERNS.some((pattern) => pattern.test(text)); }
for (const fixture of SYNTHETIC_SECRET_FIXTURES) {
  if (!hasSecretPattern(fixture)) throw new Error("Synthetic secret scanner fixture is not detected.");
}
const GOVERNED_BARE_TOKEN_EXCEPTIONS = new Set([
  "P8WirnSpCStzKJFjOjzsW0QQ7oIAiccHdcqjbHmJxRb",
  "github_transport_constructor_count_disabled",
  "grok-infrastructure-incidents-r12c-disabled",
  "pulsechain-bound-external-observation-input",
]);

const [inputZipArgument, outputZipArgument, expectedCommit, expectedTree] = process.argv.slice(2);
if (!inputZipArgument || !outputZipArgument || !expectedCommit || !expectedTree) {
  throw new Error("Usage: node BUILD_R12F_UPDATE_BUNDLE.mjs <exact-R12F1-bundle.zip> <output.zip> <R12F2C-commit> <R12F2C-tree>");
}

const operatorSourceDirectory = dirname(resolve(process.argv[1]));
const repoRoot = resolve(operatorSourceDirectory, "..");
const inputZip = resolve(inputZipArgument);
const outputZip = resolve(outputZipArgument);
const bundleName = basename(outputZip);
if (!/^PulseChain_External_Grok_Observer_Gateway_Update_Bundle_R12F2C_\d{8}T\d{6}Z\.zip$/u.test(bundleName)) throw new Error("R12F2C bundle filename mismatch.");
const bundleLeaf = bundleName.slice(0, -4);
const temporaryRoot = mkdtempSync(join(tmpdir(), "pulsechain-r12f2c-bundle-"));
const inputDirectory = join(temporaryRoot, R12F1_BUNDLE_FILENAME.slice(0, -4));
const stage = join(temporaryRoot, bundleLeaf);

function sha256Bytes(bytes) { return createHash("sha256").update(bytes).digest("hex"); }
function sha256File(path) { return sha256Bytes(readFileSync(path)); }
function writeJson(path, value) { writeFileSync(path, `${JSON.stringify(value, null, 2)}\n`, "utf8"); }
function run(command, args, options = {}) {
  const result = spawnSync(command, args, { encoding: "utf8", maxBuffer: 64 * 1024 * 1024, ...options });
  if (result.status !== 0) throw new Error(`${command} failed`);
  return result.stdout.trim();
}
function git(...args) { return run("git", args, { cwd: repoRoot }); }
function gitBytes(ref, path) {
  const result = spawnSync("git", ["show", `${ref}:${path}`], { cwd: repoRoot, encoding: null, maxBuffer: 64 * 1024 * 1024 });
  if (result.status !== 0) throw new Error(`git show failed for ${ref}:${path}`);
  return result.stdout;
}
function runNodeTests(root, cwd, paths) {
  const result = spawnSync("node", ["--test", ...paths], { cwd, encoding: "utf8", maxBuffer: 64 * 1024 * 1024 });
  if (result.status !== 0) {
    const diagnostic = `${result.stdout}\n${result.stderr}`.replace(/[A-Za-z0-9_-]{43}/gu, "[REDACTED_43_CHAR_VALUE]").slice(-4_000);
    throw new Error(`Extracted operator tests failed from ${cwd}:\n${diagnostic}`);
  }
  const output = `${result.stdout}\n${result.stderr}`;
  const pass = Number(output.match(/(?:^|\n)(?:# |ℹ )pass\s+(\d+)/u)?.[1] ?? 0);
  const fail = Number(output.match(/(?:^|\n)(?:# |ℹ )fail\s+(\d+)/u)?.[1] ?? 0);
  if (!pass || fail) throw new Error(`Extracted operator test totals invalid from ${cwd}`);
  return { cwd, pass, fail, status: "PASS" };
}
function runOperatorTestMatrix(root, unrelatedCwd) {
  const relativeTests = listFiles(join(root, "operator-tests")).filter((path) => path.endsWith(".test.mjs"));
  const absoluteTests = relativeTests.map((path) => join(root, "operator-tests", path));
  return [
    runNodeTests(root, root, relativeTests.map((path) => join("operator-tests", path))),
    runNodeTests(root, join(root, "operator-tests"), relativeTests),
    runNodeTests(root, unrelatedCwd, absoluteTests),
  ];
}
function listFiles(root) {
  const paths = [];
  function visit(directory) {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const absolute = join(directory, entry.name);
      if (entry.isSymbolicLink()) throw new Error("Symbolic links are prohibited.");
      if (entry.isDirectory()) visit(absolute);
      else if (entry.isFile()) paths.push(relative(root, absolute).split(sep).join("/"));
      else throw new Error("Unsupported filesystem member.");
    }
  }
  visit(root);
  return paths.sort();
}
function safePath(path) {
  if (!path || path.startsWith("/") || path.includes("\\") || path.includes(":") || path.endsWith("/") || path.length > 240) return false;
  return path.split("/").every((segment) =>
    segment && segment !== "." && segment !== ".." && segment === segment.trimEnd() && !WINDOWS_RESERVED.test(segment),
  );
}
function assertSafeSet(paths) {
  if (new Set(paths).size !== paths.length || paths.some((path) => !safePath(path))) throw new Error("Path safety failed.");
  const folded = paths.map((path) => path.toLowerCase());
  if (new Set(folded).size !== folded.length) throw new Error("Case-fold path collision detected.");
}
function renderText(text, replacements, pathLabel) {
  for (const [needle, value] of Object.entries(replacements)) text = text.replaceAll(needle, value);
  if (/@@[A-Z0-9_]+@@/u.test(text)) throw new Error(`Unresolved governed placeholder in ${pathLabel}`);
  return text;
}
function render(path, replacements) { return renderText(readFileSync(path, "utf8"), replacements, path); }
function scanUnresolvedPlaceholders(root) {
  const inspected = listFiles(root).filter((path) => /\.(?:ps1|m?js|json|md|txt)$/iu.test(path));
  const findings = [];
  for (const path of inspected) {
    const matches = readFileSync(join(root, path), "utf8").match(/@@[A-Z0-9_]+@@/gu) ?? [];
    for (const placeholder of matches) findings.push({ path, placeholder });
  }
  if (findings.length) throw new Error(`UNRESOLVED_GOVERNED_PLACEHOLDER:${JSON.stringify(findings)}`);
  return { inspected_file_count: inspected.length, unresolved_placeholder_count: 0, result: "PASS" };
}
function validateInventory(root, expectedSchema = INVENTORY_SCHEMA) {
  const inventory = JSON.parse(readFileSync(join(root, "ARTIFACT_INVENTORY.json"), "utf8"));
  const paths = listFiles(root);
  assertSafeSet(paths);
  const expected = paths.filter((path) => path !== "ARTIFACT_INVENTORY.json");
  if (expectedSchema !== null && inventory.schema_version !== expectedSchema) throw new Error("Inventory schema mismatch.");
  if (inventory.artifact_count_excluding_inventory !== expected.length || inventory.artifacts.length !== expected.length) throw new Error("Inventory count mismatch.");
  if (JSON.stringify(inventory.artifacts.map((entry) => entry.path).sort()) !== JSON.stringify(expected)) throw new Error("Inventory path mismatch.");
  for (const entry of inventory.artifacts) {
    const absolute = join(root, entry.path);
    if (statSync(absolute).size !== entry.byte_size || sha256File(absolute) !== entry.sha256) throw new Error(`Inventory identity mismatch: ${entry.path}`);
  }
}
function executableBundleScans(root) {
  const paths = listFiles(root);
  assertSafeSet(paths);
  const forbidden = paths.filter((path) =>
    /(?:^|\/)(?:node_modules|\.git|\.wrangler)(?:\/|$)/u.test(path) ||
    /(?:^|\/)(?:\.env(?:\..*)?|connector-tokens\.dpapi\.json|LOCAL_DISABLED_MODE_VERIFICATION\.json)$/iu.test(path) ||
    /\.(?:log|map|pem|key|pfx|p12)$/iu.test(path),
  );
  if (forbidden.length) throw new Error(`Forbidden bundle paths: ${forbidden.join(",")}`);
  for (const path of paths) {
    const absolute = join(root, path);
    if (lstatSync(absolute).isSymbolicLink()) throw new Error("Reparse-like member detected.");
    const bytes = readFileSync(absolute);
    let text = bytes.toString("latin1");
    if (hasSecretPattern(text)) throw new Error(`Secret-pattern scan failed: ${path}`);
    for (const match of text.matchAll(/(?<![A-Za-z0-9_-])[A-Za-z0-9_-]{43}(?![A-Za-z0-9_-])/gu)) {
      if (!GOVERNED_BARE_TOKEN_EXCEPTIONS.has(match[0])) throw new Error(`Bare connector-format token scan failed: ${path}`);
    }
  }
  return { security_scan: "PASS", secret_scan: "PASS", source_map_count: 0, path_safety: "PASS" };
}

try {
  if (
    basename(inputZip) !== R12F1_BUNDLE_FILENAME ||
    !existsSync(inputZip) ||
    statSync(inputZip).size !== R12F1_BUNDLE_SIZE ||
    sha256File(inputZip) !== R12F1_BUNDLE_SHA256
  ) throw new Error("Exact R12F1 bundle identity mismatch.");
  const inputMembers = run("unzip", ["-Z1", inputZip]).split(/\r?\n/u).filter(Boolean);
  if (inputMembers.length !== R12F1_BUNDLE_MEMBERS) throw new Error("R12F1 member count mismatch.");
  assertSafeSet(inputMembers);
  run("unzip", ["-tqq", inputZip]);
  mkdirSync(inputDirectory, { recursive: true });
  run("unzip", ["-qq", inputZip, "-d", inputDirectory]);
  validateInventory(inputDirectory, null);

  const r12f1Reproduction = inspectBundleContract(inputDirectory);
  const reproducedCodes = [...new Set(r12f1Reproduction.errors.map((entry) => entry.code))];
  for (const code of ["BUNDLE_INVENTORY_INVALID", "BUNDLE_SOURCE_MANIFEST_INVALID", "BUNDLE_DEPLOYMENT_EXPECTATIONS_INVALID"]) {
    if (!reproducedCodes.includes(code)) throw new Error("R12F1 contract defect reproduction incomplete: " + code);
  }

  if (git("branch", "--show-current") !== SOURCE_BRANCH) throw new Error("R12F2C source branch mismatch.");
  if (git("rev-parse", "HEAD") !== expectedCommit || git("show", "-s", "--format=%T", "HEAD") !== expectedTree) throw new Error("R12F2C commit/tree mismatch.");
  if (git("show", "-s", "--format=%P", "HEAD") !== R12F2B_COMMIT) throw new Error("R12F2B is not the direct parent.");
  if (git("show", "-s", "--format=%T", R12F2B_COMMIT) !== R12F2B_TREE) throw new Error("R12F2B predecessor tree mismatch.");
  if (git("show", "-s", "--format=%T", R12F2A_COMMIT) !== R12F2A_TREE) throw new Error("R12F2A predecessor tree mismatch.");
  if (git("show", "-s", "--format=%T", R12F2_COMMIT) !== R12F2_TREE) throw new Error("R12F2 predecessor tree mismatch.");
  if (git("show", "-s", "--format=%T", R12F1_COMMIT) !== R12F1_TREE) throw new Error("R12F1 parent tree mismatch.");
  if (git("show", "-s", "--format=%T", R12F_COMMIT) !== R12F_TREE) throw new Error("R12F parent tree mismatch.");
  git("merge-base", "--is-ancestor", R12F1_COMMIT, "HEAD");
  git("merge-base", "--is-ancestor", R12F_COMMIT, "HEAD");
  git("merge-base", "--is-ancestor", R12F2_COMMIT, "HEAD");
  git("merge-base", "--is-ancestor", R12F2A_COMMIT, "HEAD");
  git("merge-base", "--is-ancestor", R12F2B_COMMIT, "HEAD");
  if (git("status", "--porcelain") !== "") throw new Error("Source worktree is not clean.");
  const changedPaths = git("diff", "--name-only", R12F2B_COMMIT, "HEAD").split(/\r?\n/u).filter(Boolean).sort();
  const permittedChangedPrefixes = ["external_observer_grok_mcp_operator/", "external_observer_grok_mcp_gateway/tests/"];
  if (!changedPaths.length || changedPaths.some((path) => !permittedChangedPrefixes.some((prefix) => path.startsWith(prefix)))) throw new Error("R12F2C changed-path scope mismatch.");
  const governedOperatorPaths = git("diff", "--name-only", R12F_COMMIT, "HEAD").split(/\r?\n/u).filter(Boolean).filter((path) => path.startsWith("external_observer_grok_mcp_operator/")).sort();
  for (const path of governedOperatorPaths) {
    if (git("hash-object", path) !== git("rev-parse", `HEAD:${path}`)) throw new Error(`Working tree differs from commit: ${path}`);
  }

  const gatewaySourcePaths = git("ls-tree", "-r", "--name-only", expectedCommit, "external_observer_grok_mcp_gateway")
    .split(/\r?\n/u)
    .filter(Boolean)
    .sort();
  if (!gatewaySourcePaths.length || gatewaySourcePaths.some((path) => !path.startsWith("external_observer_grok_mcp_gateway/"))) {
    throw new Error("Tracked gateway source inventory invalid.");
  }
  mkdirSync(stage, { recursive: true });
  for (const path of gatewaySourcePaths) {
    const destination = join(stage, path);
    mkdirSync(dirname(destination), { recursive: true });
    writeFileSync(destination, gitBytes(expectedCommit, path));
  }
  for (const path of ["package.json", "package-lock.json", "BOUND_OBSERVATION_INPUT_SCHEMA.json", "OBSERVATION_SCHEMA.json"]) cpSync(join(inputDirectory, path), join(stage, path));
  for (const path of ["OPERATOR_COMMON.ps1", "TEST_WINDOWS_OPERATOR_ACL.ps1"]) cpSync(join(inputDirectory, path), join(stage, path));
  writeFileSync(
    join(stage, "TEST_WINDOWS_OPERATOR_ACL.ps1"),
    readFileSync(join(stage, "TEST_WINDOWS_OPERATOR_ACL.ps1"), "utf8").replaceAll("DEPLOY_GATEWAY.ps1", "UPDATE_EXISTING_GATEWAY_R12F.ps1"),
    "utf8",
  );

  const replacements = {
    "external-observer-grok-mcp-r12f2c-prestate-single-object-repair-20260829": SOURCE_BRANCH,
    "94fb48e8ee4edbe0e48bbbdd71b235c788f8ce8a": expectedCommit,
    "748da99a2935d394d34cbc71d8589cedfda18c87": expectedTree,
    "ebef6c42a5eca2ad30669cf856e669a19e10edf9": R12F_COMMIT,
    "75e3650f8e7f17af0ec2b2f312b920e15f96eb79": R12F1_COMMIT,
    "1c8bccc87df5abc07b9712a6f6fb839bc0b7c21a": R12F1_TREE,
    "f535c273c264f2c953ccd925a1d20c3f218c95a4": R12F2_COMMIT,
    "2e9df9f68850ca588e4a4749db100ec760e57d7c": R12F2_TREE,
    "d6db80436ab82a061161be99c53179d481eabfff": R12F2A_COMMIT,
    "a750a7da63ca1adbea3fe606c12c80bb9caebe3d": R12F2A_TREE,
    "e724d72adbeae653695d3198353d35ba173884f9": R12F2B_COMMIT,
    "b185d749737f83027d3a9573417e4a18cea1d61f": R12F2B_TREE,
    "ebef6c42a5eca2ad30669cf856e669a19e10edf9": R12F_COMMIT,
    "e4db0de410f89b32a9dca0f3bd1388c0272664e7": R12F_TREE,
    "pulsechain-external-observer-r12f-update-inventory@1.0.0": INVENTORY_SCHEMA,
    "pulsechain-external-observer-r12f-source-manifest@1.0.0": SOURCE_MANIFEST_SCHEMA,
    "pulsechain-external-observer-r12f-update-expectations@1.0.0": DEPLOYMENT_EXPECTATIONS_SCHEMA,
    "PulseChain_External_Grok_Observer_Gateway_Update_Bundle_R12F2C_20260829T001537Z.zip": bundleName,
  };
  const rendered = {
    "VERIFY_GATEWAY_DISABLED_R12F.mjs": render(join(operatorSourceDirectory, "VERIFY_GATEWAY_DISABLED_R12F.mjs"), replacements),
    "VERIFY_GATEWAY_DISABLED_R12F.ps1": render(join(operatorSourceDirectory, "VERIFY_GATEWAY_DISABLED_R12F.ps1.in"), replacements),
    "VERIFY_CLOUDFLARE_R12F.mjs": render(join(operatorSourceDirectory, "VERIFY_CLOUDFLARE_R12F.mjs"), replacements),
    "UPDATE_EXISTING_GATEWAY_R12F.ps1": render(join(operatorSourceDirectory, "UPDATE_EXISTING_GATEWAY_R12F.ps1.in"), replacements),
    "OPERATOR_README.md": render(join(operatorSourceDirectory, "OPERATOR_README_R12F.md.in"), replacements),
    "ROLLBACK_R12F.md": render(join(operatorSourceDirectory, "ROLLBACK_R12F.md"), replacements),
    "R13_POST_UPDATE_VERIFICATION_PROMPT.md": render(join(operatorSourceDirectory, "R13_POST_UPDATE_VERIFICATION_PROMPT.md"), replacements),
  };
  for (const [path, text] of Object.entries(rendered)) writeFileSync(join(stage, path), text, "utf8");
  const operatorTests = join(stage, "operator-tests");
  mkdirSync(operatorTests, { recursive: true });
  for (const path of listFiles(join(operatorSourceDirectory, "tests"))) {
    const sourceText = readFileSync(join(operatorSourceDirectory, "tests", path), "utf8");
    writeFileSync(join(operatorTests, path), renderOperatorTestForBundle(path, sourceText, replacements), "utf8");
  }
  cpSync(join(operatorSourceDirectory, "BUNDLE_IMPORT_CONTAINMENT.mjs"), join(stage, "BUNDLE_IMPORT_CONTAINMENT.mjs"));
  cpSync(join(operatorSourceDirectory, "BUNDLE_CONTRACT_VALIDATION.mjs"), join(stage, "BUNDLE_CONTRACT_VALIDATION.mjs"));
  writeFileSync(
    join(stage, "BUILD_R12F_UPDATE_BUNDLE.mjs"),
    render(join(operatorSourceDirectory, "BUILD_R12F_UPDATE_BUNDLE.mjs"), replacements),
    "utf8",
  );

  const connectorLabels = [
    "GROK_MCP_TOKEN_X_PROTOCOL",
    "GROK_MCP_TOKEN_INFRASTRUCTURE_INCIDENTS",
    "GROK_MCP_TOKEN_MARKET_LIQUIDITY",
    "GROK_MCP_TOKEN_IDENTITY_EVIDENCE",
    "GROK_MCP_TOKEN_RED_TEAM",
  ];
  writeJson(join(stage, "REQUIRED_SECRET_LABELS.json"), {
    schema_version: "pulsechain-external-observer-r12f-secret-labels@1.0.0",
    update_operation: "PRESERVE_EXISTING_BINDINGS_ONLY",
    required_existing_connector_secret_labels: connectorLabels,
    required_existing_connector_secret_count: 5,
    github_secret_count: 0,
    secret_values_present: false,
    secret_mutation_commands_permitted: [],
  });
  writeJson(join(stage, "DEPLOYMENT_EXPECTATIONS.json"), {
    schema_version: DEPLOYMENT_EXPECTATIONS_SCHEMA,
    source: {
      branch: SOURCE_BRANCH,
      commit: expectedCommit,
      tree: expectedTree,
      parent: R12F_COMMIT,
      parent_role: "R12F_RUNTIME_AUTHORITY",
    },
    lineage: {
      runtime_source: { commit: R12F_COMMIT, tree: R12F_TREE, parent: R12D_COMMIT },
      r12f1_bundle_source: { commit: R12F1_COMMIT, tree: R12F1_TREE, parent: R12F_COMMIT },
      r12f2_predecessor_source: { commit: R12F2_COMMIT, tree: R12F2_TREE, parent: R12F1_COMMIT },
      r12f2a_predecessor_source: { commit: R12F2A_COMMIT, tree: R12F2A_TREE, parent: R12F2_COMMIT },
      r12f2b_predecessor_source: { commit: R12F2B_COMMIT, tree: R12F2B_TREE, parent: R12F2A_COMMIT },
      r12f2c_bundle_source: { commit: expectedCommit, tree: expectedTree, parent: R12F2B_COMMIT },
    },
    exact_pre_update_state: {
      account_id: ACCOUNT_ID,
      worker_name: WORKER,
      worker_origin: WORKER_ORIGIN,
      active_deployment_id: PRIOR_DEPLOYMENT,
      active_version_id: PRIOR_VERSION,
      traffic_percent: 100,
      variables: { PUBLICATION_MODE: "DISABLED", CONTROL_ROOM_ORIGIN },
      connector_secret_labels: connectorLabels,
      github_secret_count: 0,
      workers_dev_enabled: true,
      preview_urls_enabled: false,
      vault_metadata: "FINALIZED_R12D_EXACT_AND_IMMUTABLE",
      vault_dacl: "PASS",
    },
    update: {
      wrangler_version: WRANGLER_VERSION,
      upload_command: "wrangler versions upload --keep-vars",
      secret_file_used: false,
      secret_mutations: 0,
      pretraffic_remote_readback_required: true,
      final_change_freeze_recheck_required: true,
      traffic_target_percent: 100,
      rollback_version_id: PRIOR_VERSION,
      residual_provider_limitations: [
        "Wrangler versions upload may internally retry its mutation request without a caller idempotency key.",
        "Wrangler versions deploy has no compare-and-swap parameter; exclusive operator change freeze is required between final recheck and deployment.",
      ],
    },
    windows_runtime_validation: "WINDOWS_UPDATE_PREFLIGHT_REQUIRED",
  });

  const sourcePaths = [
    ...gatewaySourcePaths,
    ...governedOperatorPaths,
  ].sort();
  writeJson(join(stage, "SOURCE_MANIFEST.json"), {
    schema_version: SOURCE_MANIFEST_SCHEMA,
    generated_at_utc: new Date().toISOString(),
    source: {
      branch: SOURCE_BRANCH,
      commit: expectedCommit,
      tree: expectedTree,
      parent: R12F_COMMIT,
      parent_role: "R12F_RUNTIME_AUTHORITY",
    },
    lineage: {
      runtime_source: { commit: R12F_COMMIT, tree: R12F_TREE, parent: R12D_COMMIT },
      r12f1_bundle_source: { commit: R12F1_COMMIT, tree: R12F1_TREE, parent: R12F_COMMIT },
      r12f2_predecessor_source: { commit: R12F2_COMMIT, tree: R12F2_TREE, parent: R12F1_COMMIT },
      r12f2a_predecessor_source: { commit: R12F2A_COMMIT, tree: R12F2A_TREE, parent: R12F2_COMMIT },
      r12f2b_predecessor_source: { commit: R12F2B_COMMIT, tree: R12F2B_TREE, parent: R12F2A_COMMIT },
      r12f2c_bundle_source: { commit: expectedCommit, tree: expectedTree, parent: R12F2B_COMMIT },
    },
    worker: { name: WORKER, origin: WORKER_ORIGIN, publication_mode: "DISABLED", control_room_origin: CONTROL_ROOM_ORIGIN, compatibility_date: "2026-08-27", compatibility_flags: ["nodejs_compat"] },
    governed_files: sourcePaths.map((path) => ({ path, git_blob: git("rev-parse", `HEAD:${path}`), byte_size: statSync(join(repoRoot, path)).size, sha256: sha256File(join(repoRoot, path)) })),
    prior_windows_acl_validation: { source: "R12D_OPERATOR_EVIDENCE", passed: 25, failed: 0, rerun_required_before_update: true },
  });

  const runtimePaths = [
    ...listFiles(join(repoRoot, "external_observer_grok_mcp_gateway", "src")).map((path) => `external_observer_grok_mcp_gateway/src/${path}`),
    "external_observer_grok_mcp_gateway/package.json",
    "external_observer_grok_mcp_gateway/wrangler.toml",
  ].sort();
  const runtimeFiles = runtimePaths.map((path) => {
    const r12fSha256 = sha256Bytes(gitBytes(R12F_COMMIT, path));
    const r12f1Sha256 = sha256Bytes(gitBytes(R12F1_COMMIT, path));
    const r12f2Sha256 = sha256Bytes(gitBytes(R12F2_COMMIT, path));
    const r12f2aSha256 = sha256Bytes(gitBytes(R12F2A_COMMIT, path));
    const r12f2bSha256 = sha256Bytes(gitBytes(R12F2B_COMMIT, path));
    const r12f2cSha256 = sha256Bytes(gitBytes(expectedCommit, path));
    const packagedSha256 = sha256File(join(stage, path));
    return {
      path,
      r12f_sha256: r12fSha256,
      r12f1_sha256: r12f1Sha256,
      r12f2_sha256: r12f2Sha256,
      r12f2a_sha256: r12f2aSha256,
      r12f2b_sha256: r12f2bSha256,
      r12f2c_sha256: r12f2cSha256,
      packaged_sha256: packagedSha256,
      equality_status: new Set([r12fSha256, r12f1Sha256, r12f2Sha256, r12f2aSha256, r12f2bSha256, r12f2cSha256, packagedSha256]).size === 1 ? "PASS" : "FAIL",
    };
  });
  const runtimeChangedFiles = runtimeFiles.filter((entry) => entry.equality_status !== "PASS");
  if (runtimeChangedFiles.length) throw new Error(`R12F2C runtime byte identity failed: ${runtimeChangedFiles.map((entry) => entry.path).join(",")}`);
  writeJson(join(stage, "R12F2C_RUNTIME_BYTE_IDENTITY.json"), {
    schema_version: "pulsechain-external-observer-r12f2c-runtime-byte-identity@1.0.0",
    runtime_authority_commit: R12F_COMMIT,
    r12f1_bundle_source_commit: R12F1_COMMIT,
    r12f2_predecessor_source_commit: R12F2_COMMIT,
    r12f2a_predecessor_source_commit: R12F2A_COMMIT,
    r12f2b_predecessor_source_commit: R12F2B_COMMIT,
    r12f2c_bundle_source_commit: expectedCommit,
    runtime_changed_file_count: 0,
    files: runtimeFiles,
    result: "PASS",
  });
  writeJson(join(stage, "ORIGINAL_R12F1_FAILURE_REPRODUCTION.json"), {
    schema_version: "pulsechain-external-observer-r12f2-original-failure-reproduction@1.0.0",
    input_bundle: {
      filename: R12F1_BUNDLE_FILENAME,
      byte_size: R12F1_BUNDLE_SIZE,
      member_count: R12F1_BUNDLE_MEMBERS,
      sha256: R12F1_BUNDLE_SHA256,
    },
    required_leaf_used: R12F1_BUNDLE_FILENAME.slice(0, -4),
    reproduced_failure_codes: reproducedCodes,
    contract_readback: r12f1Reproduction,
    all_three_defects_reproduced: true,
    result: "PASS",
  });
  writeJson(join(stage, "R12F2C_SCHEMA_COHERENCE_VALIDATION.json"), {
    schema_version: "pulsechain-external-observer-r12f2c-schema-coherence@1.0.0",
    decision: "RETAIN_ESTABLISHED_R12F_RUNTIME_SCHEMAS",
    artifact_inventory: { producer: INVENTORY_SCHEMA, consumer: INVENTORY_SCHEMA, exact_equality: true },
    source_manifest: { producer: SOURCE_MANIFEST_SCHEMA, consumer: SOURCE_MANIFEST_SCHEMA, exact_equality: true },
    deployment_expectations: { producer: DEPLOYMENT_EXPECTATIONS_SCHEMA, consumer: DEPLOYMENT_EXPECTATIONS_SCHEMA, exact_equality: true },
    deployment_parent: { producer: R12F_COMMIT, consumer: R12F_COMMIT, role: "R12F_RUNTIME_AUTHORITY", exact_equality: true },
    compatibility_fallbacks: 0,
    result: "PASS",
  });

  const stageImportValidation = validateBundleImports(stage);
  const stageTestRuns = runOperatorTestMatrix(stage, temporaryRoot);
  writeJson(join(stage, "SELF_CONTAINED_IMPORT_VALIDATION.json"), {
    schema_version: "pulsechain-external-observer-r12f2c-import-validation@1.0.0",
    source_test: "external_observer_grok_mcp_operator/tests/node-verifier.test.mjs",
    emitted_test: "operator-tests/node-verifier.test.mjs",
    corrected_import: "../external_observer_grok_mcp_gateway/src/contracts.mjs",
    outside_root_import_count: 0,
    import_validation: stageImportValidation,
    working_directory_matrix: stageTestRuns,
    source_checkout_dependency: false,
    result: "PASS",
  });
  const placeholderScan = scanUnresolvedPlaceholders(stage);
  writeJson(join(stage, "UNRESOLVED_PLACEHOLDER_SCAN.json"), {
    schema_version: "pulsechain-external-observer-r12f2c-placeholder-scan@1.0.0",
    ...placeholderScan,
  });
  const scans = executableBundleScans(stage);
  const checksumPaths = listFiles(stage).filter((path) => !["SHA256SUMS.txt", "ARTIFACT_INVENTORY.json"].includes(path));
  writeFileSync(join(stage, "SHA256SUMS.txt"), `${checksumPaths.map((path) => `${sha256File(join(stage, path))}  ${path}`).join("\n")}\n`, "utf8");
  for (const line of readFileSync(join(stage, "SHA256SUMS.txt"), "utf8").trim().split(/\r?\n/u)) {
    const match = line.match(/^([0-9a-f]{64})  ([A-Za-z0-9._/-]+)$/u);
    if (!match || sha256File(join(stage, match[2])) !== match[1]) throw new Error("SHA256SUMS validation failed.");
  }
  const inventoryPaths = listFiles(stage).filter((path) => path !== "ARTIFACT_INVENTORY.json");
  writeJson(join(stage, "ARTIFACT_INVENTORY.json"), {
    schema_version: INVENTORY_SCHEMA,
    generated_at_utc: new Date().toISOString(),
    artifact_count_excluding_inventory: inventoryPaths.length,
    scans,
    artifacts: inventoryPaths.map((path) => ({ path, byte_size: statSync(join(stage, path)).size, sha256: sha256File(join(stage, path)) })),
  });
  executableBundleScans(stage);
  validateInventory(stage);
  const stageContract = inspectBundleContract(stage);
  if (stageContract.result !== "PASS") throw new Error(`R12F2C stage contract failed: ${JSON.stringify(stageContract.errors)}`);

  mkdirSync(dirname(outputZip), { recursive: true });
  const finalPaths = listFiles(stage);
  assertSafeSet(finalPaths);
  run("zip", ["-X", "-q", outputZip, ...finalPaths], { cwd: stage });
  run("unzip", ["-tqq", outputZip]);
  const zipPaths = run("unzip", ["-Z1", outputZip]).split(/\r?\n/u).filter(Boolean).sort();
  if (JSON.stringify(zipPaths) !== JSON.stringify(finalPaths)) throw new Error("ZIP member readback mismatch.");
  for (const path of finalPaths) {
    const member = spawnSync("unzip", ["-p", outputZip, path], { encoding: null, maxBuffer: 64 * 1024 * 1024 });
    if (member.status !== 0 || !member.stdout.equals(readFileSync(join(stage, path)))) throw new Error(`ZIP byte readback mismatch: ${path}`);
  }
  const isolatedParent = mkdtempSync(join(tmpdir(), "pulsechain r12f2c empty neighborhood é "));
  const isolatedZip = join(isolatedParent, bundleName);
  cpSync(outputZip, isolatedZip);
  const uniqueAttemptParent = join(isolatedParent, "R12F2C Attempt é");
  const extractedRoot = join(uniqueAttemptParent, bundleLeaf);
  mkdirSync(extractedRoot, { recursive: true });
  run("unzip", ["-qq", isolatedZip, "-d", extractedRoot]);
  const extractedContract = inspectBundleContract(extractedRoot);
  if (extractedContract.result !== "PASS") throw new Error(`R12F2C extracted contract failed: ${JSON.stringify(extractedContract.errors)}`);
  const extractedImportValidation = validateBundleImports(extractedRoot);
  const extractedTestRuns = runOperatorTestMatrix(extractedRoot, isolatedParent);
  process.stdout.write(`${JSON.stringify({
    filename: bundleName,
    byte_size: statSync(outputZip).size,
    member_count: finalPaths.length,
    sha256: sha256File(outputZip),
    zip_integrity: "PASS",
    inventory_validation: "PASS",
    path_safety: "PASS",
    secret_scan: "PASS",
    source_branch: SOURCE_BRANCH,
    source_commit: expectedCommit,
    source_tree: expectedTree,
    source_parent: R12F2B_COMMIT,
    r12f2_predecessor_commit: R12F2_COMMIT,
    r12f2a_predecessor_commit: R12F2A_COMMIT,
    r12f2b_predecessor_commit: R12F2B_COMMIT,
    runtime_authority_commit: R12F_COMMIT,
    bound_deployment_parent: R12F_COMMIT,
    prior_version_id: PRIOR_VERSION,
    windows_update_preflight: "REQUIRED",
    schema_coherence: stageContract.result,
    parent_binding: stageContract.values.deployment_parent_actual === R12F_COMMIT ? "PASS" : "FAIL",
    runtime_byte_identity: runtimeChangedFiles.length === 0 ? "PASS" : "FAIL",
    runtime_changed_file_count: runtimeChangedFiles.length,
    unresolved_placeholder_count: placeholderScan.unresolved_placeholder_count,
    exact_leaf_extraction: extractedContract.result,
    import_containment: extractedImportValidation.outside_root_import_count === 0 ? "PASS" : "FAIL",
    extracted_operator_tests: extractedTestRuns.every((entry) => entry.status === "PASS") ? "PASS" : "FAIL",
    extracted_test_runs: extractedTestRuns,
  }, null, 2)}\n`);
} finally {
  rmSync(temporaryRoot, { recursive: true, force: true });
}
